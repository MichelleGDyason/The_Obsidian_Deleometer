'use strict';

var obsidian = require('obsidian');

// Constants for framework IDs
const FRAMEWORKS = {
    TACKTICAL: 'tacktical',
    FREUDIAN: 'freudian',
    LACANIAN: 'lacanian',
    DELEUZIAN: 'deleuzian',
    IRIGARAYIAN: 'irigarayian',
    JUNGIAN: 'jungian',
    ATTACHMENT: 'attachment',
    POSITIVE: 'positive',
    NARRATIVE: 'narrative',
    PHENOMENOLOGY: 'phenomenology',
    EXISTENTIAL: 'existential',
    FEMINIST: 'feminist',
    CRITICAL: 'critical',
    POSTHUMANISM: 'posthumanism',
    BUDDHIST: 'buddhist',
    NIETZSCHEAN: 'nietzschean',
    GESTALT: 'gestalt',
    TRANSPERSONAL: 'transpersonal',
    CBT: 'cbt',
    HERMENEUTICS: 'hermeneutics',
    STOICISM: 'stoicism',
    PSYCHIATRY: 'psychiatry'
};

// Constants for media types
const MEDIA_TYPES = {
    TEXT: 'text',
    IMAGE: 'image',
    AUDIO: 'audio',
    FILM: 'film'
};

// Default plugin settings
const DEFAULT_SETTINGS = {
    enabledFrameworks: {
        [FRAMEWORKS.TACKTICAL]: true,
        [FRAMEWORKS.FREUDIAN]: true,
        [FRAMEWORKS.LACANIAN]: true,
        [FRAMEWORKS.DELEUZIAN]: true,
        [FRAMEWORKS.IRIGARAYIAN]: true,
        [FRAMEWORKS.JUNGIAN]: true,
        [FRAMEWORKS.ATTACHMENT]: true,
        [FRAMEWORKS.POSITIVE]: true,
        [FRAMEWORKS.NARRATIVE]: true,
        [FRAMEWORKS.PHENOMENOLOGY]: true,
        [FRAMEWORKS.EXISTENTIAL]: true,
        [FRAMEWORKS.FEMINIST]: true,
        [FRAMEWORKS.CRITICAL]: true,
        [FRAMEWORKS.POSTHUMANISM]: true,
        [FRAMEWORKS.BUDDHIST]: true,
        [FRAMEWORKS.NIETZSCHEAN]: true,
        [FRAMEWORKS.GESTALT]: true,
        [FRAMEWORKS.TRANSPERSONAL]: true,
        [FRAMEWORKS.CBT]: true,
        [FRAMEWORKS.HERMENEUTICS]: true,
        [FRAMEWORKS.STOICISM]: true,
        [FRAMEWORKS.PSYCHIATRY]: true
    },
    analysisDepth: 'standard',
    enableJournalingPrompts: true,
    autoOpenExportedFiles: true
};

// Main plugin class
class DeleometerPlugin extends obsidian.Plugin {
    async onload() {
        console.log('Loading Deleometer plugin');
        
        // Load settings
        this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
        
        // Add the unified Theoretical Analysis command
        this.addCommand({
            id: 'theoretical-analysis',
            name: 'Theoretical Analysis',
            callback: () => {
                new obsidian.Notice('Deleometer Theoretical Analysis is coming soon!');
            }
        });
        
        // Add ribbon icon (leaf)
        this.addRibbonIcon('leaf', 'Deleometer', () => {
            new obsidian.Notice('Deleometer plugin is working!');
        });
    }
    
    onunload() {
        console.log('Unloading Deleometer plugin');
    }
    
    async saveSettings() {
        await this.saveData(this.settings);
    }
}

module.exports = DeleometerPlugin;
