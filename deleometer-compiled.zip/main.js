'use strict';

var obsidian = require('obsidian');

class DeleometerPlugin extends obsidian.Plugin {
    async onload() {
        console.log('Loading Deleometer plugin');
        
        // Add a simple command to test if the plugin is working
        this.addCommand({
            id: 'show-deleometer-message',
            name: 'Show Deleometer Message',
            callback: () => {
                new obsidian.Notice('Deleometer plugin is working!');
            }
        });
        
        // Add a command for journal analysis
        this.addCommand({
            id: 'analyze-journal',
            name: 'Analyze Journal Entry',
            editorCallback: (editor, view) => {
                const content = editor.getValue();
                this.analyzeJournal(content, view);
            }
        });
        
        // Add a command for artistic analysis
        this.addCommand({
            id: 'analyze-artistic',
            name: 'Analyze Artistic Content',
            callback: () => {
                new obsidian.Notice('Select a file to analyze');
                this.showFileSelectionModal();
            }
        });
        
        // Add a command for comparative analysis
        this.addCommand({
            id: 'comparative-analysis',
            name: 'Comparative Analysis',
            callback: () => {
                new obsidian.Notice('Comparative Analysis feature is working!');
                this.showComparativeAnalysisModal();
            }
        });
    }
    
    onunload() {
        console.log('Unloading Deleometer plugin');
    }
    
    analyzeJournal(content, view) {
        // Simple mock analysis
        const modal = new obsidian.Modal(this.app);
        modal.titleEl.setText('Journal Analysis');
        
        const contentEl = modal.contentEl;
        contentEl.createEl('h2', { text: 'Analysis Results' });
        
        const summary = contentEl.createEl('div', { cls: 'deleometer-summary' });
        summary.createEl('h3', { text: 'Summary' });
        summary.createEl('p', { text: 'This journal entry appears to reflect on personal experiences and emotions. There are themes of reflection, introspection, and self-awareness.' });
        
        const frameworks = contentEl.createEl('div', { cls: 'deleometer-frameworks' });
        frameworks.createEl('h3', { text: 'Theoretical Frameworks' });
        
        const freudian = frameworks.createEl('div', { cls: 'deleometer-framework' });
        freudian.createEl('h4', { text: 'Freudian Analysis' });
        freudian.createEl('p', { text: 'The content suggests underlying anxieties and desires that may be manifesting in daily thoughts and activities.' });
        
        const recommendations = contentEl.createEl('div', { cls: 'deleometer-recommendations' });
        recommendations.createEl('h3', { text: 'Recommendations' });
        recommendations.createEl('ul', el => {
            el.createEl('li', { text: 'Consider journaling more regularly about emotional patterns' });
            el.createEl('li', { text: 'Explore connections between past experiences and current feelings' });
            el.createEl('li', { text: 'Practice mindfulness to enhance self-awareness' });
        });
        
        const buttons = contentEl.createEl('div', { cls: 'deleometer-buttons' });
        const closeButton = buttons.createEl('button', { text: 'Close' });
        closeButton.addEventListener('click', () => {
            modal.close();
        });
        
        modal.open();
    }
    
    showFileSelectionModal() {
        const modal = new obsidian.Modal(this.app);
        modal.titleEl.setText('Select File for Analysis');
        
        const contentEl = modal.contentEl;
        contentEl.createEl('p', { text: 'This is a simplified test version. In the full version, you would see a list of files to select.' });
        
        const buttons = contentEl.createEl('div', { cls: 'deleometer-buttons' });
        
        const analyzeButton = buttons.createEl('button', { text: 'Simulate Analysis' });
        analyzeButton.addEventListener('click', () => {
            modal.close();
            this.showArtisticAnalysisResults();
        });
        
        const closeButton = buttons.createEl('button', { text: 'Cancel' });
        closeButton.addEventListener('click', () => {
            modal.close();
        });
        
        modal.open();
    }
    
    showArtisticAnalysisResults() {
        const modal = new obsidian.Modal(this.app);
        modal.titleEl.setText('Artistic Analysis Results');
        
        const contentEl = modal.contentEl;
        contentEl.createEl('h2', { text: 'Analysis Results' });
        
        const summary = contentEl.createEl('div', { cls: 'deleometer-summary' });
        summary.createEl('h3', { text: 'Summary' });
        summary.createEl('p', { text: 'This is a simulated analysis of an artistic work. The analysis would normally include insights based on the selected theoretical frameworks.' });
        
        const frameworks = contentEl.createEl('div', { cls: 'deleometer-frameworks' });
        frameworks.createEl('h3', { text: 'Theoretical Frameworks' });
        
        const tacktical = frameworks.createEl('div', { cls: 'deleometer-framework' });
        tacktical.createEl('h4', { text: 'Tacktical Methodology' });
        tacktical.createEl('p', { text: 'The work demonstrates tacking patterns between different artistic approaches and perspectives.' });
        
        const deleuzian = frameworks.createEl('div', { cls: 'deleometer-framework' });
        deleuzian.createEl('h4', { text: 'Deleuzian Analysis' });
        deleuzian.createEl('p', { text: 'There are elements of deterritorialization and rhizomatic connections throughout the work.' });
        
        const buttons = contentEl.createEl('div', { cls: 'deleometer-buttons' });
        const closeButton = buttons.createEl('button', { text: 'Close' });
        closeButton.addEventListener('click', () => {
            modal.close();
        });
        
        modal.open();
    }
    
    showComparativeAnalysisModal() {
        const modal = new obsidian.Modal(this.app);
        modal.titleEl.setText('Comparative Analysis');
        
        const contentEl = modal.contentEl;
        contentEl.createEl('p', { text: 'This is a simplified test version. In the full version, you would be able to select multiple files and frameworks for comparison.' });
        
        const buttons = contentEl.createEl('div', { cls: 'deleometer-buttons' });
        
        const analyzeButton = buttons.createEl('button', { text: 'Simulate Analysis' });
        analyzeButton.addEventListener('click', () => {
            modal.close();
            this.showComparativeAnalysisResults();
        });
        
        const closeButton = buttons.createEl('button', { text: 'Cancel' });
        closeButton.addEventListener('click', () => {
            modal.close();
        });
        
        modal.open();
    }
    
    showComparativeAnalysisResults() {
        const modal = new obsidian.Modal(this.app);
        modal.titleEl.setText('Comparative Analysis Results');
        
        const contentEl = modal.contentEl;
        contentEl.createEl('h2', { text: 'Comparison Results' });
        
        const summary = contentEl.createEl('div', { cls: 'deleometer-summary' });
        summary.createEl('h3', { text: 'Summary' });
        summary.createEl('p', { text: 'This is a simulated comparative analysis. The full version would show similarities and differences between the analyzed items.' });
        
        const comparison = contentEl.createEl('div', { cls: 'deleometer-comparison' });
        comparison.createEl('h3', { text: 'Common Themes' });
        comparison.createEl('ul', el => {
            el.createEl('li', { text: 'Theme 1: Self-reflection' });
            el.createEl('li', { text: 'Theme 2: Emotional processing' });
            el.createEl('li', { text: 'Theme 3: Creative expression' });
        });
        
        const buttons = contentEl.createEl('div', { cls: 'deleometer-buttons' });
        const closeButton = buttons.createEl('button', { text: 'Close' });
        closeButton.addEventListener('click', () => {
            modal.close();
        });
        
        modal.open();
    }
}

module.exports = DeleometerPlugin;
