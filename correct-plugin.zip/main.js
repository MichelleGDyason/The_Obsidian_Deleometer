'use strict';

var obsidian = require('obsidian');

class DeleometerPlugin extends obsidian.Plugin {
    async onload() {
        console.log('Loading Deleometer plugin');
        
        // Add a ribbon icon
        this.addRibbonIcon('leaf', 'Deleometer', () => {
            new obsidian.Notice('Deleometer plugin is working!');
        });
        
        // Add a command
        this.addCommand({
            id: 'show-deleometer-message',
            name: 'Show Message',
            callback: () => {
                new obsidian.Notice('Deleometer command executed successfully!');
            }
        });
    }
    
    onunload() {
        console.log('Unloading Deleometer plugin');
    }
}

module.exports = DeleometerPlugin;
