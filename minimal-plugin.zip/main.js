console.log("Deleometer plugin loaded successfully");var main={onload:function(){console.log("Deleometer loaded")}}; module.exports = main;
