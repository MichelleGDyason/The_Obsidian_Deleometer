'use strict';

var obsidian = require('obsidian');

// Import the modal classes
const { UnifiedAnalysisModal } = require('./UnifiedAnalysisModal');
const { AnalysisResultsModal } = require('./AnalysisResultsModal');

// Constants for framework IDs
const FRAMEWORKS = {
    TACKTICAL: 'tacktical',
    FREUDIAN: 'freudian',
    LACANIAN: 'lacanian',
    DELEUZIAN: 'deleuzian',
    IRIGARAYIAN: 'irigarayian',
    JUNGIAN: 'jungian',
    ATTACHMENT: 'attachment',
    POSITIVE: 'positive',
    NARRATIVE: 'narrative',
    PHENOMENOLOGY: 'phenomenology',
    EXISTENTIAL: 'existential',
    FEMINIST: 'feminist',
    CRITICAL: 'critical',
    POSTHUMANISM: 'posthumanism',
    BUDDHIST: 'buddhist',
    NIETZSCHEAN: 'nietzschean',
    GESTALT: 'gestalt',
    TRANSPERSONAL: 'transpersonal',
    CBT: 'cbt',
    HERMENEUTICS: 'hermeneutics',
    STOICISM: 'stoicism',
    PSYCHIATRY: 'psychiatry'
};

// Constants for media types
const MEDIA_TYPES = {
    TEXT: 'text',
    IMAGE: 'image',
    AUDIO: 'audio',
    FILM: 'film'
};

// Default plugin settings
const DEFAULT_SETTINGS = {
    enabledFrameworks: {
        [FRAMEWORKS.TACKTICAL]: true,
        [FRAMEWORKS.FREUDIAN]: true,
        [FRAMEWORKS.LACANIAN]: true,
        [FRAMEWORKS.DELEUZIAN]: true,
        [FRAMEWORKS.IRIGARAYIAN]: true,
        [FRAMEWORKS.JUNGIAN]: true,
        [FRAMEWORKS.ATTACHMENT]: true,
        [FRAMEWORKS.POSITIVE]: true,
        [FRAMEWORKS.NARRATIVE]: true,
        [FRAMEWORKS.PHENOMENOLOGY]: true,
        [FRAMEWORKS.EXISTENTIAL]: true,
        [FRAMEWORKS.FEMINIST]: true,
        [FRAMEWORKS.CRITICAL]: true,
        [FRAMEWORKS.POSTHUMANISM]: true,
        [FRAMEWORKS.BUDDHIST]: true,
        [FRAMEWORKS.NIETZSCHEAN]: true,
        [FRAMEWORKS.GESTALT]: true,
        [FRAMEWORKS.TRANSPERSONAL]: true,
        [FRAMEWORKS.CBT]: true,
        [FRAMEWORKS.HERMENEUTICS]: true,
        [FRAMEWORKS.STOICISM]: true,
        [FRAMEWORKS.PSYCHIATRY]: true
    },
    analysisDepth: 'standard',
    enableJournalingPrompts: true,
    autoOpenExportedFiles: true
};

// Analysis Engine class
class AnalysisEngine {
    constructor(app, settings) {
        this.app = app;
        this.settings = settings;
    }

    // Analyze any content based on its type
    async analyzeContent(content, mediaType, frameworks) {
        switch (mediaType) {
            case MEDIA_TYPES.TEXT:
                return this.analyzeText(content, frameworks);
            case MEDIA_TYPES.IMAGE:
                return this.analyzeImage(content, frameworks);
            case MEDIA_TYPES.AUDIO:
                return this.analyzeAudio(content, frameworks);
            case MEDIA_TYPES.FILM:
                return this.analyzeFilm(content, frameworks);
            default:
                throw new Error(`Unsupported media type: ${mediaType}`);
        }
    }

    // Analyze text content
    async analyzeText(content, frameworks) {
        const result = {
            mediaType: MEDIA_TYPES.TEXT,
            summary: this.generateTextSummary(content),
            frameworkAnalyses: {}
        };

        // Generate analysis for each selected framework
        for (const framework of frameworks) {
            result.frameworkAnalyses[framework] = this.generateFrameworkAnalysis(content, framework, MEDIA_TYPES.TEXT);
        }

        // Generate recommendations based on the analyses
        result.recommendations = this.generateRecommendations(result.frameworkAnalyses);

        return result;
    }

    // Analyze image content
    async analyzeImage(file, frameworks) {
        const result = {
            mediaType: MEDIA_TYPES.IMAGE,
            fileName: file.name,
            summary: `This image (${file.name}) contains visual elements that can be analyzed through multiple theoretical frameworks.`,
            frameworkAnalyses: {}
        };

        // Generate analysis for each selected framework
        for (const framework of frameworks) {
            result.frameworkAnalyses[framework] = this.generateFrameworkAnalysis(file.name, framework, MEDIA_TYPES.IMAGE);
        }

        // Generate recommendations based on the analyses
        result.recommendations = this.generateRecommendations(result.frameworkAnalyses);

        return result;
    }

    // Analyze audio content
    async analyzeAudio(file, frameworks) {
        const result = {
            mediaType: MEDIA_TYPES.AUDIO,
            fileName: file.name,
            summary: `This audio file (${file.name}) contains sonic elements that can be analyzed through multiple theoretical frameworks.`,
            frameworkAnalyses: {}
        };

        // Generate analysis for each selected framework
        for (const framework of frameworks) {
            result.frameworkAnalyses[framework] = this.generateFrameworkAnalysis(file.name, framework, MEDIA_TYPES.AUDIO);
        }

        // Generate recommendations based on the analyses
        result.recommendations = this.generateRecommendations(result.frameworkAnalyses);

        return result;
    }

    // Analyze film content
    async analyzeFilm(file, frameworks) {
        const result = {
            mediaType: MEDIA_TYPES.FILM,
            fileName: file.name,
            summary: `This film/video (${file.name}) contains visual and narrative elements that can be analyzed through multiple theoretical frameworks.`,
            frameworkAnalyses: {}
        };

        // Generate analysis for each selected framework
        for (const framework of frameworks) {
            result.frameworkAnalyses[framework] = this.generateFrameworkAnalysis(file.name, framework, MEDIA_TYPES.FILM);
        }

        // Generate recommendations based on the analyses
        result.recommendations = this.generateRecommendations(result.frameworkAnalyses);

        return result;
    }

    // Generate a summary of text content with more specific analysis
    generateTextSummary(content) {
        // Extract key themes and patterns from the content
        const themes = this.extractThemes(content);
        const emotionalTone = this.analyzeEmotionalTone(content);
        const narrativeStructure = this.analyzeNarrativeStructure(content);

        // Generate a more specific summary based on the content
        return `This text contains themes of ${themes.join(', ')}, with a predominantly ${emotionalTone} emotional tone. The writing suggests ${narrativeStructure}, revealing a nuanced exploration of personal experience and reflection.`;
    }

    // Extract key themes from text content
    extractThemes(content) {
        const themePatterns = {
            reflection: /reflect|contemplat|introspect|think about|ponder|consider/i,
            identity: /who I am|identity|self|authentic|true self/i,
            relationships: /relationship|connect|friend|family|partner|love|intimacy/i,
            transition: /change|transition|shift|transform|evolve|growth|develop/i,
            creativity: /creat|art|express|imagin|inspir|vision|idea/i,
            purpose: /purpose|meaning|significance|direction|goal|aim|mission/i,
            conflict: /conflict|tension|struggle|challenge|difficult|problem|obstacle/i,
            healing: /heal|recover|overcome|process|integrat|accept|reconcile/i
        };

        // Identify themes present in the content
        const presentThemes = [];
        for (const [theme, pattern] of Object.entries(themePatterns)) {
            if (pattern.test(content)) {
                presentThemes.push(theme);
            }
        }

        // Return identified themes or defaults if none found
        return presentThemes.length > 0 ? presentThemes : ['reflection', 'introspection', 'self-awareness'];
    }

    // Analyze the emotional tone of text content
    analyzeEmotionalTone(content) {
        const tonePatterns = {
            reflective: /reflect|contemplat|ponder|think|consider/i,
            melancholic: /sad|depress|melanchol|down|blue|despair|grief/i,
            hopeful: /hope|optimis|look forward|anticipat|excit|eager/i,
            anxious: /anxi|worry|concern|stress|tension|nervous|fear/i,
            content: /content|satisf|peace|calm|serene|tranquil|happy/i,
            frustrated: /frustrat|annoy|irritat|exasperat|anger|resent/i,
            grateful: /gratitude|thankful|appreciat|grateful|blessed/i,
            ambivalent: /ambivalen|conflict|mixed|unsure|uncertain/i
        };

        // Count occurrences of each tone
        const toneCounts = {};
        for (const [tone, pattern] of Object.entries(tonePatterns)) {
            const matches = content.match(pattern) || [];
            toneCounts[tone] = matches.length;
        }

        // Find the dominant tone
        let dominantTone = 'reflective'; // Default
        let maxCount = 0;

        for (const [tone, count] of Object.entries(toneCounts)) {
            if (count > maxCount) {
                maxCount = count;
                dominantTone = tone;
            }
        }

        return dominantTone;
    }

    // Analyze the narrative structure of text content
    analyzeNarrativeStructure(content) {
        // Check for different narrative patterns
        const isPastFocused = /was|were|had|did|went|came|thought|felt/i.test(content);
        const isFutureFocused = /will|going to|plan|future|soon|tomorrow|next/i.test(content);
        const isQuestionFocused = /\?|wonder|question|curious|how|why|what if/i.test(content);
        const isDialogueHeavy = /said|asked|replied|answered|spoke|talked/i.test(content);

        // Determine the dominant structure
        if (isPastFocused && isFutureFocused) {
            return "a reflective examination of past experiences in relation to future aspirations";
        } else if (isPastFocused) {
            return "a retrospective exploration of past experiences and their significance";
        } else if (isFutureFocused) {
            return "a forward-looking contemplation of possibilities and intentions";
        } else if (isQuestionFocused) {
            return "an inquiry-based exploration of questions and uncertainties";
        } else if (isDialogueHeavy) {
            return "a dialogical engagement with different perspectives or voices";
        } else {
            return "a present-centered reflection on current experiences and insights";
        }
    }

    // Generate analysis for a specific framework
    generateFrameworkAnalysis(content, framework, mediaType) {
        // In a real implementation, this would use AI or templates to generate framework-specific analysis
        // For now, we'll use predefined analyses based on the framework and media type

        const analyses = {
            [FRAMEWORKS.FREUDIAN]: {
                [MEDIA_TYPES.TEXT]: "From a Freudian perspective, this content reveals underlying psychological dynamics and unconscious processes. There are suggestions of repressed desires finding expression through symbolic representation and displacement. The formal elements of the work can be interpreted as manifestations of primary process thinking, where logical constraints are loosened in favor of associative connections. Recurring motifs suggest the return of the repressed, with unresolved psychic material seeking acknowledgment. The tension between structure and expression mirrors the ego's mediation between the demands of the id and superego. The work engages with universal psychological conflicts related to desire, prohibition, and sublimation.",
                [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Freudian lens to reveal unconscious symbolic content. Visual elements may represent displaced desires, condensed meanings, or symbolic fulfillment of unconscious wishes. The composition suggests tensions between conscious intention and unconscious expression. Color choices and spatial relationships may indicate psychosexual themes or conflicts. The image potentially functions as a dream-like expression where primary process thinking is evident. The viewer's response to the image may involve projection of their own unconscious material.",
                [MEDIA_TYPES.AUDIO]: "From a Freudian perspective, this audio piece reveals underlying psychological dynamics through its sonic elements. Rhythmic patterns may represent the tension between id impulses and superego constraints. Tonal qualities can be interpreted as expressions of libidinal energy or repressed emotional content. The structure of the piece mirrors psychological defense mechanisms such as sublimation or displacement. Recurring motifs suggest the return of repressed material seeking acknowledgment. The emotional response evoked in the listener may indicate transference or projection of unconscious material. The piece engages with universal psychological conflicts through its auditory symbolism.",
                [MEDIA_TYPES.FILM]: "This film can be analyzed through a Freudian lens to reveal unconscious symbolic content and psychological dynamics. Visual imagery and narrative elements may represent displaced desires or condensed meanings. Character relationships often mirror psychosexual developmental stages or conflicts. The film's structure suggests tensions between conscious intention and unconscious expression. Recurring visual motifs may indicate the return of repressed material seeking acknowledgment. Editing techniques and visual transitions can be interpreted as analogous to dream-work mechanisms. The viewer's emotional response may involve projection of their own unconscious material."
            },
            [FRAMEWORKS.LACANIAN]: {
                [MEDIA_TYPES.TEXT]: "A Lacanian reading of this text reveals the interplay between the Symbolic, Imaginary, and Real orders. The language demonstrates how the subject positions themselves within the symbolic order while grappling with the Real. There are moments where the text approaches the Real—that which resists symbolization—before retreating into symbolic structures. The writing reveals the fundamental split in subjectivity and the impossibility of wholeness that drives desire. Signifiers in the text form chains of meaning that point to an absent center, illustrating Lacan's concept that desire always operates through metonymic displacement. The text demonstrates how language both constructs and alienates the subject, creating a gap between the subject of the statement and the subject of enunciation.",
                [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Lacanian framework to reveal the interplay between the Symbolic, Imaginary, and Real orders. Visual elements function as signifiers in a chain of meaning that points to an absent center. The image potentially operates as a screen upon which fantasies are projected, revealing the structure of desire as lack. Compositional elements may demonstrate the gaze as object a—the unattainable object-cause of desire. The image potentially disrupts the Imaginary order by introducing elements of the Real that resist symbolization. The viewer's relationship to the image reveals the fundamental split in subjectivity. The visual language creates a gap between what is represented and what remains unrepresentable.",
                [MEDIA_TYPES.AUDIO]: "A Lacanian analysis of this audio piece reveals the interplay between the Symbolic, Imaginary, and Real orders through sonic elements. Sound functions as a signifier in chains of meaning that point to an absent center. Rhythmic and tonal patterns demonstrate the structure of desire as lack, always moving metonymically from one signifier to another. Moments of dissonance or silence may represent irruptions of the Real—that which resists symbolization. The listener's experience reveals the fundamental split in subjectivity when engaging with the piece. The audio creates a gap between what is heard and what remains beyond representation. The piece potentially functions as object a—the unattainable object-cause of desire—in its ability to evoke but never satisfy.",
                [MEDIA_TYPES.FILM]: "This film can be analyzed through a Lacanian framework to reveal the interplay between the Symbolic, Imaginary, and Real orders. Visual and narrative elements function as signifiers in chains of meaning that point to an absent center. The film potentially operates as a screen upon which fantasies are projected, revealing the structure of desire as lack. Character relationships demonstrate the mirror stage and the formation of the ego through identification. The gaze operates as object a—the unattainable object-cause of desire—in the visual language of the film. Moments of narrative disruption may represent irruptions of the Real that resist symbolization. The viewer's relationship to the film reveals the fundamental split in subjectivity."
            },
            // Add analyses for other frameworks and media types
        };

        // Return the analysis for the specified framework and media type, or a generic one if not found
        return analyses[framework]?.[mediaType] ||
            `This ${mediaType} can be analyzed through the lens of ${this.getFrameworkName(framework)} to reveal insights about its structure, content, and meaning. The analysis would consider the specific theoretical concepts and methodologies of this framework to interpret the work's significance and implications. Multiple elements of the ${mediaType} demonstrate principles central to this theoretical approach. The relationship between form and content reveals deeper patterns that align with key concepts from this framework. This analysis opens up new perspectives on how the ${mediaType} functions within broader cultural and psychological contexts. The ${mediaType}'s impact can be understood through this framework's unique interpretive lens.`;
    }

    // Generate recommendations based on analyses
    generateRecommendations(frameworkAnalyses) {
        // In a real implementation, this would generate personalized recommendations
        // For now, we'll return generic recommendations
        return [
            "Reflect on recurring patterns and themes that emerged across different theoretical frameworks.",
            "Consider how different perspectives offer complementary insights into the same content.",
            "Explore the relationship between form and content in your creative expression.",
            "Notice how emotional responses may reveal unconscious patterns or desires.",
            "Consider how cultural and historical contexts shape interpretation and meaning.",
            "Experiment with different modes of expression to access different aspects of experience."
        ];
    }

    // Get the display name for a framework ID
    getFrameworkName(frameworkId) {
        const names = {
            [FRAMEWORKS.TACKTICAL]: 'Tacktical Methodology',
            [FRAMEWORKS.FREUDIAN]: 'Freudian Psychoanalysis',
            [FRAMEWORKS.LACANIAN]: 'Lacanian Psychoanalysis',
            [FRAMEWORKS.DELEUZIAN]: 'Deleuzian Schizoanalysis',
            [FRAMEWORKS.IRIGARAYIAN]: 'Irigarayian Feminist Theory',
            [FRAMEWORKS.JUNGIAN]: 'Jungian Analytical Psychology',
            [FRAMEWORKS.ATTACHMENT]: 'Attachment Theory',
            [FRAMEWORKS.POSITIVE]: 'Positive Psychology',
            [FRAMEWORKS.NARRATIVE]: 'Narrative Psychology',
            [FRAMEWORKS.PHENOMENOLOGY]: 'Phenomenology',
            [FRAMEWORKS.EXISTENTIAL]: 'Existential Psychology',
            [FRAMEWORKS.FEMINIST]: 'Feminist Theory',
            [FRAMEWORKS.CRITICAL]: 'Critical Theory',
            [FRAMEWORKS.POSTHUMANISM]: 'Posthumanism',
            [FRAMEWORKS.BUDDHIST]: 'Buddhist Psychology',
            [FRAMEWORKS.NIETZSCHEAN]: 'Nietzschean Philosophy',
            [FRAMEWORKS.GESTALT]: 'Gestalt Psychology',
            [FRAMEWORKS.TRANSPERSONAL]: 'Transpersonal Psychology',
            [FRAMEWORKS.CBT]: 'Cognitive Behavioral Therapy',
            [FRAMEWORKS.HERMENEUTICS]: 'Hermeneutics',
            [FRAMEWORKS.STOICISM]: 'Stoicism',
            [FRAMEWORKS.PSYCHIATRY]: 'Psychiatry'
        };

        return names[frameworkId] || frameworkId;
    }
}

// Settings tab for the plugin
class DeleometerSettingTab extends obsidian.PluginSettingTab {
    constructor(app, plugin) {
        super(app, plugin);
        this.plugin = plugin;
    }

    display() {
        const {containerEl} = this;
        containerEl.empty();

        containerEl.createEl('h2', {text: 'Deleometer Settings'});

        // Framework selection section
        containerEl.createEl('h3', {text: 'Theoretical Frameworks'});
        containerEl.createEl('p', {text: 'Enable or disable theoretical frameworks for analysis.'});

        // Create a toggle for each framework
        Object.keys(FRAMEWORKS).forEach(key => {
            const frameworkId = FRAMEWORKS[key];
            const frameworkName = this.plugin.analysisEngine.getFrameworkName(frameworkId);

            new obsidian.Setting(containerEl)
                .setName(frameworkName)
                .setDesc(`Enable ${frameworkName} for analysis`)
                .addToggle(toggle => toggle
                    .setValue(this.plugin.settings.enabledFrameworks[frameworkId])
                    .onChange(async (value) => {
                        this.plugin.settings.enabledFrameworks[frameworkId] = value;
                        await this.plugin.saveSettings();
                    }));
        });

        // Analysis options section
        containerEl.createEl('h3', {text: 'Analysis Options'});

        new obsidian.Setting(containerEl)
            .setName('Analysis Depth')
            .setDesc('How detailed should the analysis be?')
            .addDropdown(dropdown => dropdown
                .addOption('brief', 'Brief')
                .addOption('standard', 'Standard')
                .addOption('detailed', 'Detailed')
                .setValue(this.plugin.settings.analysisDepth)
                .onChange(async (value) => {
                    this.plugin.settings.analysisDepth = value;
                    await this.plugin.saveSettings();
                }));

        // Journaling prompts option
        new obsidian.Setting(containerEl)
            .setName('Journaling Prompts')
            .setDesc('Enable personalized journaling prompts based on analysis')
            .addToggle(toggle => toggle
                .setValue(this.plugin.settings.enableJournalingPrompts)
                .onChange(async (value) => {
                    this.plugin.settings.enableJournalingPrompts = value;
                    await this.plugin.saveSettings();
                }));
    }
}

// Main plugin class
class DeleometerPlugin extends obsidian.Plugin {
    async onload() {
        console.log('Loading Deleometer plugin');

        // Load settings
        this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());

        // Initialize the analysis engine
        this.analysisEngine = new AnalysisEngine(this.app, this.settings);

        // Add the unified Theoretical Analysis command (combines single and batch analysis)
        this.addCommand({
            id: 'theoretical-analysis',
            name: 'Theoretical Analysis',
            callback: () => {
                this.showUnifiedAnalysisModal();
            }
        });

        // Add settings tab
        this.addSettingTab(new DeleometerSettingTab(this.app, this));

        // Add ribbon icon (leaf)
        this.addRibbonIcon('leaf', 'Deleometer', () => {
            this.showTheoreticalAnalysisModal();
        });
    }

    onunload() {
        console.log('Unloading Deleometer plugin');
    }

    // Show the unified analysis modal (combines single and batch analysis)
    showUnifiedAnalysisModal() {
        const modal = new UnifiedAnalysisModal(this.app, this);
        modal.open();
    }

    // Save settings
    async saveSettings() {
        await this.saveData(this.settings);
    }
}

module.exports = DeleometerPlugin;
