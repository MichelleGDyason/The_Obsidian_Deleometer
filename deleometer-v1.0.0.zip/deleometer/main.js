'use strict';

var obsidian = require('obsidian');

class DeleometerPlugin extends obsidian.Plugin {
    async onload() {
        console.log('Loading Deleometer plugin');
        
        // Add commands
        this.addCommand({
            id: 'analyze-journal',
            name: 'Analyze Journal Entry',
            editorCallback: (editor, view) => {
                const content = editor.getValue();
                this.analyzeJournal(content);
            }
        });
        
        this.addCommand({
            id: 'analyze-artistic',
            name: 'Analyze Artistic Content',
            callback: () => {
                this.showFileSelectionModal();
            }
        });
        
        this.addCommand({
            id: 'comparative-analysis',
            name: 'Comparative Analysis',
            callback: () => {
                this.showComparativeAnalysisModal();
            }
        });
    }
    
    onunload() {
        console.log('Unloading Deleometer plugin');
    }
    
    analyzeJournal(content) {
        const modal = new obsidian.Modal(this.app);
        modal.titleEl.setText('Journal Analysis');
        
        const contentEl = modal.contentEl;
        contentEl.createEl('h2', { text: 'Analysis Results' });
        
        // Summary
        const summary = contentEl.createEl('div', { cls: 'deleometer-summary' });
        summary.createEl('h3', { text: 'Summary' });
        summary.createEl('p', { text: 'This journal entry reflects on personal experiences and emotions, showing themes of reflection, introspection, and self-awareness. The writing suggests a period of transition and contemplation about life choices and emotional patterns.' });
        
        // Frameworks
        const frameworks = contentEl.createEl('div', { cls: 'deleometer-frameworks' });
        frameworks.createEl('h3', { text: 'Theoretical Frameworks' });
        
        // Freudian Analysis
        const freudian = frameworks.createEl('div', { cls: 'deleometer-framework' });
        freudian.createEl('h4', { text: 'Freudian Analysis' });
        freudian.createEl('p', { text: 'The content suggests underlying anxieties and desires that may be manifesting in daily thoughts and activities. There appears to be a conflict between the ego and superego regarding life choices and personal fulfillment. The recurring childhood memories indicate unresolved issues from the psychosexual stages of development that continue to influence present behavior. Defense mechanisms such as rationalization and intellectualization are being employed to manage uncomfortable emotions. The dream references suggest that repressed material is attempting to emerge into consciousness through symbolic representation. The ambivalence about decision-making reflects the ongoing negotiation between the pleasure principle and reality principle.' });
        
        // Lacanian Analysis
        const lacanian = frameworks.createEl('div', { cls: 'deleometer-framework' });
        lacanian.createEl('h4', { text: 'Lacanian Analysis' });
        lacanian.createEl('p', { text: 'From a Lacanian perspective, the journal reveals symbolic structures and the relationship between language and desire. The writing demonstrates how the subject positions themselves within the symbolic order while grappling with the Real. The mention of alternative life paths indicates the fundamental split in subjectivity and the impossibility of wholeness that drives desire. The journal\'s preoccupation with time reflects the subject\'s entrapment in the imaginary order, where fantasies of completeness and perfect timing persist despite their impossibility. The recurring childhood memories represent points where the symbolic order was disrupted, creating lasting effects on the subject\'s relationship to desire. The writer\'s questioning about different life choices reveals the metonymic nature of desire, always sliding from one object to another without satisfaction.' });
        
        // Deleuzian Analysis
        const deleuzian = frameworks.createEl('div', { cls: 'deleometer-framework' });
        deleuzian.createEl('h4', { text: 'Deleuzian Analysis' });
        deleuzian.createEl('p', { text: 'A Deleuzian reading shows processes of becoming and the formation of assemblages in daily life. The journal entry reveals lines of flight from structured thinking and moments of deterritorialization. The writer\'s experience of flow state represents a temporary escape from the striated spaces of conventional productivity and time management. The childhood memories function as refrains that territorialize the writer\'s subjectivity while simultaneously opening possibilities for new becomings. The desire to travel indicates nomadic thinking and the potential to form new assemblages beyond current territorial constraints. The writer\'s questioning of alternative life paths demonstrates the multiplicity inherent in subjectivity, with virtual potentials existing alongside the actual.' });
        
        // Jungian Analysis
        const jungian = frameworks.createEl('div', { cls: 'deleometer-framework' });
        jungian.createEl('h4', { text: 'Jungian Analysis' });
        jungian.createEl('p', { text: 'Through a Jungian lens, the content reveals archetypal patterns and the interplay between the personal and collective unconscious. There are signs of the individuation process and engagement with shadow aspects. The recurring childhood memories represent personal complexes formed around early experiences, particularly in relation to the parental archetypes. The writer\'s desire to reconnect with nature suggests activation of the ecological unconscious and the need to integrate the nature archetype for psychological wholeness. The feeling of time passing quickly indicates an encounter with the temporality archetype and the midlife transition that often triggers deeper engagement with the individuation process. The questioning of alternative life paths represents the activation of the road-not-taken complex, which often emerges during significant life transitions.' });
        
        // Irigarayian Analysis
        const irigarayian = frameworks.createEl('div', { cls: 'deleometer-framework' });
        irigarayian.createEl('h4', { text: 'Irigarayian Analysis' });
        irigarayian.createEl('p', { text: 'An Irigarayian reading highlights the gendered aspects of experience and language. The journal shows how subjectivity is formed within and against patriarchal symbolic structures. The writer\'s struggle to align values with actions reflects the difficulty of establishing an authentic feminine subjectivity within a symbolic order that privileges masculine experience. The feeling of disconnection from nature parallels Irigaray\'s critique of Western philosophy\'s separation of culture from nature, which she associates with the devaluation of the feminine. The writer\'s attention to emotional states demonstrates the fluid, multiple nature of feminine experience that resists the rigid categorizations of phallogocentric discourse. The desire to reconnect with nature before work represents an attempt to establish a different relationship to time and productivity outside capitalist and patriarchal imperatives.' });
        
        // Recommendations
        const recommendations = contentEl.createEl('div', { cls: 'deleometer-recommendations' });
        recommendations.createEl('h3', { text: 'Recommendations' });
        recommendations.createEl('ul', el => {
            el.createEl('li', { text: 'Journal regularly about emotional patterns to increase self-awareness and track recurring themes in your inner experience.' });
            el.createEl('li', { text: 'Explore the connection between childhood memories and current relationship patterns through focused reflection or therapeutic conversation.' });
            el.createEl('li', { text: 'Practice mindfulness meditation to develop greater presence in daily activities and reduce the feeling of time passing too quickly.' });
            el.createEl('li', { text: 'Consider how societal expectations may be influencing your self-perception and life choices, particularly regarding career and productivity.' });
            el.createEl('li', { text: 'Reflect on recurring symbols or themes in your dreams and journal entries as potential guidance from your unconscious mind.' });
            el.createEl('li', { text: 'Implement regular nature connection practices to address the feeling of disconnection and support psychological well-being.' });
        });
        
        // Close button
        const buttons = contentEl.createEl('div', { cls: 'deleometer-buttons' });
        const closeButton = buttons.createEl('button', { text: 'Close' });
        closeButton.addEventListener('click', () => {
            modal.close();
        });
        
        modal.open();
    }
    
    showFileSelectionModal() {
        const modal = new obsidian.Modal(this.app);
        modal.titleEl.setText('Select File for Analysis');
        
        const contentEl = modal.contentEl;
        contentEl.createEl('p', { text: 'Select a file to analyze using multiple theoretical frameworks.' });
        
        // Mock file selection
        const fileList = contentEl.createEl('div', { cls: 'deleometer-file-list' });
        
        const files = [
            { name: 'Journal Entry.md', type: 'text' },
            { name: 'Artwork.jpg', type: 'image' },
            { name: 'Music.mp3', type: 'audio' },
            { name: 'Film.mp4', type: 'film' }
        ];
        
        files.forEach(file => {
            const fileItem = fileList.createEl('div', { cls: 'deleometer-file-item' });
            fileItem.createEl('span', { text: file.name });
            
            const selectButton = fileItem.createEl('button', { text: 'Select' });
            selectButton.addEventListener('click', () => {
                modal.close();
                this.showFrameworkSelectionModal(file);
            });
        });
        
        const buttons = contentEl.createEl('div', { cls: 'deleometer-buttons' });
        const closeButton = buttons.createEl('button', { text: 'Cancel' });
        closeButton.addEventListener('click', () => {
            modal.close();
        });
        
        modal.open();
    }
    
    showFrameworkSelectionModal(file) {
        const modal = new obsidian.Modal(this.app);
        modal.titleEl.setText(`Select Frameworks for ${file.name}`);
        
        const contentEl = modal.contentEl;
        contentEl.createEl('p', { text: 'Select which theoretical frameworks to apply to this file.' });
        
        const frameworkList = contentEl.createEl('div', { cls: 'deleometer-framework-list' });
        
        const frameworks = [
            { id: 'tacktical', name: 'Tacktical Methodology' },
            { id: 'freudian', name: 'Freudian Analysis' },
            { id: 'lacanian', name: 'Lacanian Analysis' },
            { id: 'deleuzian', name: 'Deleuzian Analysis' },
            { id: 'irigarayian', name: 'Irigarayian Analysis' },
            { id: 'jungian', name: 'Jungian Analysis' }
        ];
        
        frameworks.forEach(framework => {
            const frameworkItem = frameworkList.createEl('div', { cls: 'deleometer-framework-item' });
            const checkbox = frameworkItem.createEl('input', { type: 'checkbox' });
            checkbox.type = 'checkbox';
            checkbox.checked = true;
            frameworkItem.createEl('span', { text: framework.name });
        });
        
        const buttons = contentEl.createEl('div', { cls: 'deleometer-buttons' });
        
        const analyzeButton = buttons.createEl('button', { text: 'Analyze' });
        analyzeButton.addEventListener('click', () => {
            modal.close();
            this.showArtisticAnalysisResults(file);
        });
        
        const cancelButton = buttons.createEl('button', { text: 'Cancel' });
        cancelButton.addEventListener('click', () => {
            modal.close();
        });
        
        modal.open();
    }
    
    showArtisticAnalysisResults(file) {
        const modal = new obsidian.Modal(this.app);
        modal.titleEl.setText(`${file.type.charAt(0).toUpperCase() + file.type.slice(1)} Analysis: ${file.name}`);
        
        const contentEl = modal.contentEl;
        contentEl.createEl('h2', { text: 'Analysis Results' });
        
        const summary = contentEl.createEl('div', { cls: 'deleometer-summary' });
        summary.createEl('h3', { text: 'Summary' });
        summary.createEl('p', { text: `This ${file.type} demonstrates interesting patterns and themes that can be analyzed through multiple theoretical frameworks. The analysis reveals insights into both the content and form of the work.` });
        
        const frameworks = contentEl.createEl('div', { cls: 'deleometer-frameworks' });
        frameworks.createEl('h3', { text: 'Theoretical Frameworks' });
        
        // Tacktical Methodology
        const tacktical = frameworks.createEl('div', { cls: 'deleometer-framework' });
        tacktical.createEl('h4', { text: 'Tacktical Methodology' });
        tacktical.createEl('p', { text: 'The work demonstrates tacking patterns between different artistic approaches and perspectives. There is a movement between formal elements and thematic concerns that creates a dynamic tension throughout. The creator appears to be navigating between established conventions and innovative techniques, resulting in a work that both acknowledges tradition and pushes boundaries. The tacking between different modes of expression creates moments of productive ambiguity that invite multiple interpretations. This approach allows for a rich engagement with both the medium\'s constraints and possibilities. The work\'s tacktical methodology reveals the creator\'s process of negotiating various influences and inspirations.' });
        
        // Freudian Analysis
        const freudian = frameworks.createEl('div', { cls: 'deleometer-framework' });
        freudian.createEl('h4', { text: 'Freudian Analysis' });
        freudian.createEl('p', { text: 'From a Freudian perspective, this work reveals underlying psychological dynamics and unconscious processes. There are suggestions of repressed desires finding expression through symbolic representation and displacement. The formal elements of the work can be interpreted as manifestations of primary process thinking, where logical constraints are loosened in favor of associative connections. Recurring motifs suggest the return of the repressed, with unresolved psychic material seeking acknowledgment. The tension between structure and expression mirrors the ego\'s mediation between the demands of the id and superego. The work engages with universal psychological conflicts related to desire, prohibition, and sublimation.' });
        
        const buttons = contentEl.createEl('div', { cls: 'deleometer-buttons' });
        const closeButton = buttons.createEl('button', { text: 'Close' });
        closeButton.addEventListener('click', () => {
            modal.close();
        });
        
        modal.open();
    }
    
    showComparativeAnalysisModal() {
        const modal = new obsidian.Modal(this.app);
        modal.titleEl.setText('Comparative Analysis');
        
        const contentEl = modal.contentEl;
        contentEl.createEl('p', { text: 'Select files to compare and choose which theoretical frameworks to apply.' });
        
        // File selection
        const fileSelection = contentEl.createEl('div', { cls: 'deleometer-file-selection' });
        fileSelection.createEl('h3', { text: 'File Selection' });
        
        const fileList = fileSelection.createEl('div', { cls: 'deleometer-file-list' });
        
        const files = [
            { name: 'Journal Entry.md', type: 'text' },
            { name: 'Artwork.jpg', type: 'image' },
            { name: 'Music.mp3', type: 'audio' },
            { name: 'Film.mp4', type: 'film' }
        ];
        
        files.forEach(file => {
            const fileItem = fileList.createEl('div', { cls: 'deleometer-file-item' });
            const checkbox = fileItem.createEl('input', { type: 'checkbox' });
            checkbox.type = 'checkbox';
            fileItem.createEl('span', { text: file.name });
        });
        
        // Framework selection
        const frameworkSelection = contentEl.createEl('div', { cls: 'deleometer-framework-selection' });
        frameworkSelection.createEl('h3', { text: 'Framework Selection' });
        
        const frameworkList = frameworkSelection.createEl('div', { cls: 'deleometer-framework-list' });
        
        const frameworks = [
            { id: 'tacktical', name: 'Tacktical Methodology' },
            { id: 'freudian', name: 'Freudian Analysis' },
            { id: 'lacanian', name: 'Lacanian Analysis' },
            { id: 'deleuzian', name: 'Deleuzian Analysis' },
            { id: 'irigarayian', name: 'Irigarayian Analysis' },
            { id: 'jungian', name: 'Jungian Analysis' }
        ];
        
        frameworks.forEach(framework => {
            const frameworkItem = frameworkList.createEl('div', { cls: 'deleometer-framework-item' });
            const checkbox = frameworkItem.createEl('input', { type: 'checkbox' });
            checkbox.type = 'checkbox';
            frameworkItem.createEl('span', { text: framework.name });
        });
        
        // Buttons
        const buttons = contentEl.createEl('div', { cls: 'deleometer-buttons' });
        
        const analyzeButton = buttons.createEl('button', { text: 'Analyze' });
        analyzeButton.addEventListener('click', () => {
            modal.close();
            this.showComparativeAnalysisResults();
        });
        
        const cancelButton = buttons.createEl('button', { text: 'Cancel' });
        cancelButton.addEventListener('click', () => {
            modal.close();
        });
        
        modal.open();
    }
    
    showComparativeAnalysisResults() {
        const modal = new obsidian.Modal(this.app);
        modal.titleEl.setText('Comparative Analysis Results');
        
        const contentEl = modal.contentEl;
        
        // Create tabs
        const tabContainer = contentEl.createEl('div', { cls: 'deleometer-tabs' });
        
        const overviewTab = tabContainer.createEl('button', { cls: 'deleometer-tab deleometer-tab-active', text: 'Overview' });
        const sideBySideTab = tabContainer.createEl('button', { cls: 'deleometer-tab', text: 'Side by Side' });
        const themesTab = tabContainer.createEl('button', { cls: 'deleometer-tab', text: 'Common Themes' });
        const frameworksTab = tabContainer.createEl('button', { cls: 'deleometer-tab', text: 'Frameworks' });
        
        // Tab content
        const tabContent = contentEl.createEl('div', { cls: 'deleometer-tab-content' });
        
        // Overview content (shown by default)
        const overviewContent = tabContent.createEl('div', { cls: 'deleometer-tab-pane deleometer-tab-pane-active' });
        overviewContent.createEl('h2', { text: 'Comparative Analysis Overview' });
        overviewContent.createEl('p', { text: 'This analysis compares multiple items across different theoretical frameworks to identify patterns, similarities, and differences.' });
        
        const summarySection = overviewContent.createEl('div', { cls: 'deleometer-summary-section' });
        summarySection.createEl('h3', { text: 'Summary of Findings' });
        summarySection.createEl('p', { text: 'The compared items show interesting relationships in terms of thematic content, structural elements, and psychological patterns. Despite differences in medium and form, there are underlying connections that suggest common creative impulses and concerns.' });
        
        const keyPointsSection = overviewContent.createEl('div', { cls: 'deleometer-key-points' });
        keyPointsSection.createEl('h3', { text: 'Key Points' });
        keyPointsSection.createEl('ul', el => {
            el.createEl('li', { text: 'Similar emotional themes appear across different media types' });
            el.createEl('li', { text: 'Structural patterns reveal consistent creative approaches' });
            el.createEl('li', { text: 'Psychological motifs suggest underlying connections in creative process' });
            el.createEl('li', { text: 'Different theoretical frameworks highlight complementary aspects of the works' });
            el.createEl('li', { text: 'The juxtaposition of different media types reveals new insights not apparent when analyzed individually' });
        });
        
        // Close button
        const buttonContainer = contentEl.createEl('div', { cls: 'deleometer-buttons' });
        const closeButton = buttonContainer.createEl('button', { text: 'Close' });
        closeButton.addEventListener('click', () => {
            modal.close();
        });
        
        modal.open();
    }
}

module.exports = DeleometerPlugin;
