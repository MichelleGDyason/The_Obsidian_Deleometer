'use strict';

var obsidian = require('obsidian');

class DeleometerPlugin extends obsidian.Plugin {
    async onload() {
        console.log('Loading Deleometer plugin');
        
        // Add a simple command to test if the plugin is working
        this.addCommand({
            id: 'show-deleometer-message',
            name: 'Show Deleometer Message',
            callback: () => {
                new obsidian.Notice('Deleometer plugin is working!');
            }
        });
        
        // Add a command for journal analysis
        this.addCommand({
            id: 'analyze-journal',
            name: 'Analyze Journal Entry',
            editorCallback: (editor, view) => {
                const content = editor.getValue();
                this.analyzeJournal(content, view);
            }
        });
        
        // Add a command for artistic analysis
        this.addCommand({
            id: 'analyze-artistic',
            name: 'Analyze Artistic Content',
            callback: () => {
                new obsidian.Notice('Select a file to analyze');
                this.showFileSelectionModal();
            }
        });
        
        // Add a command for comparative analysis
        this.addCommand({
            id: 'comparative-analysis',
            name: 'Comparative Analysis',
            callback: () => {
                new obsidian.Notice('Comparative Analysis feature is working!');
                this.showComparativeAnalysisModal();
            }
        });
    }
    
    onunload() {
        console.log('Unloading Deleometer plugin');
    }
    
    analyzeJournal(content, view) {
        // Enhanced journal analysis with more frameworks and recommendations
        const modal = new obsidian.Modal(this.app);
        modal.titleEl.setText('Journal Analysis');
        
        const contentEl = modal.contentEl;
        contentEl.createEl('h2', { text: 'Analysis Results' });
        
        const summary = contentEl.createEl('div', { cls: 'deleometer-summary' });
        summary.createEl('h3', { text: 'Summary' });
        summary.createEl('p', { text: 'This journal entry reflects on personal experiences and emotions, showing themes of reflection, introspection, and self-awareness. The writing suggests a period of transition and contemplation about life choices and emotional patterns. There appears to be a tension between past experiences and future aspirations, with an underlying desire for greater authenticity and meaning.' });
        
        const frameworks = contentEl.createEl('div', { cls: 'deleometer-frameworks' });
        frameworks.createEl('h3', { text: 'Theoretical Frameworks' });
        
        // Freudian Analysis - expanded to 6+ sentences
        const freudian = frameworks.createEl('div', { cls: 'deleometer-framework' });
        freudian.createEl('h4', { text: 'Freudian Analysis' });
        freudian.createEl('p', { text: 'The content suggests underlying anxieties and desires that may be manifesting in daily thoughts and activities. There appears to be a conflict between the ego and superego regarding life choices and personal fulfillment. The recurring childhood memories indicate unresolved issues from the psychosexual stages of development that continue to influence present behavior. Defense mechanisms such as rationalization and intellectualization are being employed to manage uncomfortable emotions. The dream references suggest that repressed material is attempting to emerge into consciousness through symbolic representation. The ambivalence about decision-making reflects the ongoing negotiation between the pleasure principle and reality principle. The writer's preoccupation with time passing quickly may represent death anxiety, a fundamental concern in Freudian theory.' });
        
        // Lacanian Analysis - expanded to 6+ sentences
        const lacanian = frameworks.createEl('div', { cls: 'deleometer-framework' });
        lacanian.createEl('h4', { text: 'Lacanian Analysis' });
        lacanian.createEl('p', { text: 'From a Lacanian perspective, the journal reveals symbolic structures and the relationship between language and desire. The writing demonstrates how the subject positions themselves within the symbolic order while grappling with the Real. The mention of alternative life paths indicates the fundamental split in subjectivity and the impossibility of wholeness that drives desire. The journal's preoccupation with time reflects the subject's entrapment in the imaginary order, where fantasies of completeness and perfect timing persist despite their impossibility. The recurring childhood memories represent points where the symbolic order was disrupted, creating lasting effects on the subject's relationship to desire. The writer's questioning about different life choices reveals the metonymic nature of desire, always sliding from one object to another without satisfaction. The tension between personal values and daily actions demonstrates the gap between the subject of the statement and the subject of the enunciation, a key Lacanian distinction.' });
        
        // Deleuzian Analysis - expanded to 6+ sentences
        const deleuzian = frameworks.createEl('div', { cls: 'deleometer-framework' });
        deleuzian.createEl('h4', { text: 'Deleuzian Analysis' });
        deleuzian.createEl('p', { text: 'A Deleuzian reading shows processes of becoming and the formation of assemblages in daily life. The journal entry reveals lines of flight from structured thinking and moments of deterritorialization. The writer's experience of flow state represents a temporary escape from the striated spaces of conventional productivity and time management. The childhood memories function as refrains that territorialize the writer's subjectivity while simultaneously opening possibilities for new becomings. The desire to travel indicates nomadic thinking and the potential to form new assemblages beyond current territorial constraints. The writer's questioning of alternative life paths demonstrates the multiplicity inherent in subjectivity, with virtual potentials existing alongside the actual. The feeling of disconnection from nature represents the molar segmentarity of contemporary life that separates humans from non-human assemblages. The writer's intention to hike before work represents a minor practice that might create molecular revolutions in daily experience.' });
        
        // Jungian Analysis - expanded to 6+ sentences
        const jungian = frameworks.createEl('div', { cls: 'deleometer-framework' });
        jungian.createEl('h4', { text: 'Jungian Analysis' });
        jungian.createEl('p', { text: 'Through a Jungian lens, the content reveals archetypal patterns and the interplay between the personal and collective unconscious. There are signs of the individuation process and engagement with shadow aspects. The recurring childhood memories represent personal complexes formed around early experiences, particularly in relation to the parental archetypes. The writer's desire to reconnect with nature suggests activation of the ecological unconscious and the need to integrate the nature archetype for psychological wholeness. The feeling of time passing quickly indicates an encounter with the temporality archetype and the midlife transition that often triggers deeper engagement with the individuation process. The questioning of alternative life paths represents the activation of the road-not-taken complex, which often emerges during significant life transitions. The mention of dreams and their impact suggests that the unconscious is actively communicating through symbolic language, offering guidance for the individuation journey. The intention to hike before work represents a ritual act that may facilitate communication between the conscious and unconscious mind.' });
        
        // Irigarayian Analysis - expanded to 6+ sentences
        const irigarayian = frameworks.createEl('div', { cls: 'deleometer-framework' });
        irigarayian.createEl('h4', { text: 'Irigarayian Analysis' });
        irigarayian.createEl('p', { text: 'An Irigarayian reading highlights the gendered aspects of experience and language. The journal shows how subjectivity is formed within and against patriarchal symbolic structures. The writer's struggle to align values with actions reflects the difficulty of establishing an authentic feminine subjectivity within a symbolic order that privileges masculine experience. The feeling of disconnection from nature parallels Irigaray's critique of Western philosophy's separation of culture from nature, which she associates with the devaluation of the feminine. The writer's attention to emotional states demonstrates the fluid, multiple nature of feminine experience that resists the rigid categorizations of phallogocentric discourse. The desire to reconnect with nature before work represents an attempt to establish a different relationship to time and productivity outside capitalist and patriarchal imperatives. The questioning of life choices reveals the tension between autonomous desire and the social expectations that shape gendered subjectivity. The writer's reflective practice itself can be seen as developing what Irigaray calls "parler femme" or "speaking (as) woman"—a mode of expression that exceeds the constraints of patriarchal discourse.' });
        
        // Recommendations with actual content - fixed
        const recommendations = contentEl.createEl('div', { cls: 'deleometer-recommendations' });
        recommendations.createEl('h3', { text: 'Recommendations' });
        recommendations.createEl('ul', el => {
            el.createEl('li', { text: 'Journal regularly about emotional patterns to increase self-awareness and track recurring themes in your inner experience.' });
            el.createEl('li', { text: 'Explore the connection between childhood memories and current relationship patterns through focused reflection or therapeutic conversation.' });
            el.createEl('li', { text: 'Practice mindfulness meditation to develop greater presence in daily activities and reduce the feeling of time passing too quickly.' });
            el.createEl('li', { text: 'Consider how societal expectations may be influencing your self-perception and life choices, particularly regarding career and productivity.' });
            el.createEl('li', { text: 'Reflect on recurring symbols or themes in your dreams and journal entries as potential guidance from your unconscious mind.' });
            el.createEl('li', { text: 'Experiment with creative expression such as art, music, or movement to access different aspects of your psyche and develop non-verbal understanding.' });
            el.createEl('li', { text: 'Implement regular nature connection practices to address the feeling of disconnection and support psychological well-being.' });
            el.createEl('li', { text: 'Consider creating a personal ritual to mark this transitional period and consciously engage with the process of change.' });
        });
        
        const buttons = contentEl.createEl('div', { cls: 'deleometer-buttons' });
        const closeButton = buttons.createEl('button', { text: 'Close' });
        closeButton.addEventListener('click', () => {
            modal.close();
        });
        
        modal.open();
    }
    
    showFileSelectionModal() {
        const modal = new obsidian.Modal(this.app);
        modal.titleEl.setText('Select File for Analysis');
        
        const contentEl = modal.contentEl;
        contentEl.createEl('p', { text: 'This is a simplified test version. In the full version, you would see a list of files to select.' });
        
        const buttons = contentEl.createEl('div', { cls: 'deleometer-buttons' });
        
        const analyzeButton = buttons.createEl('button', { text: 'Simulate Analysis' });
        analyzeButton.addEventListener('click', () => {
            modal.close();
            this.showArtisticAnalysisResults();
        });
        
        const closeButton = buttons.createEl('button', { text: 'Cancel' });
        closeButton.addEventListener('click', () => {
            modal.close();
        });
        
        modal.open();
    }
    
    showArtisticAnalysisResults() {
        const modal = new obsidian.Modal(this.app);
        modal.titleEl.setText('Artistic Analysis Results');
        
        const contentEl = modal.contentEl;
        contentEl.createEl('h2', { text: 'Analysis Results' });
        
        const summary = contentEl.createEl('div', { cls: 'deleometer-summary' });
        summary.createEl('h3', { text: 'Summary' });
        summary.createEl('p', { text: 'This is a simulated analysis of an artistic work. The analysis would normally include insights based on the selected theoretical frameworks.' });
        
        const frameworks = contentEl.createEl('div', { cls: 'deleometer-frameworks' });
        frameworks.createEl('h3', { text: 'Theoretical Frameworks' });
        
        const tacktical = frameworks.createEl('div', { cls: 'deleometer-framework' });
        tacktical.createEl('h4', { text: 'Tacktical Methodology' });
        tacktical.createEl('p', { text: 'The work demonstrates tacking patterns between different artistic approaches and perspectives.' });
        
        const deleuzian = frameworks.createEl('div', { cls: 'deleometer-framework' });
        deleuzian.createEl('h4', { text: 'Deleuzian Analysis' });
        deleuzian.createEl('p', { text: 'There are elements of deterritorialization and rhizomatic connections throughout the work.' });
        
        const buttons = contentEl.createEl('div', { cls: 'deleometer-buttons' });
        const closeButton = buttons.createEl('button', { text: 'Close' });
        closeButton.addEventListener('click', () => {
            modal.close();
        });
        
        modal.open();
    }
    
    showComparativeAnalysisModal() {
        const modal = new obsidian.Modal(this.app);
        modal.titleEl.setText('Comparative Analysis');
        
        const contentEl = modal.contentEl;
        contentEl.createEl('p', { text: 'This is a simplified test version. In the full version, you would be able to select multiple files and frameworks for comparison.' });
        
        const buttons = contentEl.createEl('div', { cls: 'deleometer-buttons' });
        
        const analyzeButton = buttons.createEl('button', { text: 'Simulate Analysis' });
        analyzeButton.addEventListener('click', () => {
            modal.close();
            this.showComparativeAnalysisResults();
        });
        
        const closeButton = buttons.createEl('button', { text: 'Cancel' });
        closeButton.addEventListener('click', () => {
            modal.close();
        });
        
        modal.open();
    }
    
    showComparativeAnalysisResults() {
        const modal = new obsidian.Modal(this.app);
        modal.titleEl.setText('Comparative Analysis Results');
        
        const contentEl = modal.contentEl;
        contentEl.createEl('h2', { text: 'Comparison Results' });
        
        const summary = contentEl.createEl('div', { cls: 'deleometer-summary' });
        summary.createEl('h3', { text: 'Summary' });
        summary.createEl('p', { text: 'This is a simulated comparative analysis. The full version would show similarities and differences between the analyzed items.' });
        
        const comparison = contentEl.createEl('div', { cls: 'deleometer-comparison' });
        comparison.createEl('h3', { text: 'Common Themes' });
        comparison.createEl('ul', el => {
            el.createEl('li', { text: 'Theme 1: Self-reflection' });
            el.createEl('li', { text: 'Theme 2: Emotional processing' });
            el.createEl('li', { text: 'Theme 3: Creative expression' });
        });
        
        const buttons = contentEl.createEl('div', { cls: 'deleometer-buttons' });
        const closeButton = buttons.createEl('button', { text: 'Close' });
        closeButton.addEventListener('click', () => {
            modal.close();
        });
        
        modal.open();
    }
}

module.exports = DeleometerPlugin;
