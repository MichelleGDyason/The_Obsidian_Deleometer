'use strict';

var obsidian = require('obsidian');

// Import the modal classes
const { UnifiedAnalysisModal } = require('./UnifiedAnalysisModal');
const { AnalysisResultsModal } = require('./AnalysisResultsModal');

// Constants for framework IDs
const FRAMEWORKS = {
    TACKTICAL: 'tacktical',
    FREUDIAN: 'freudian',
    LACANIAN: 'lacanian',
    DELEUZIAN: 'deleuzian',
    IRIGARAYIAN: 'irigarayian',
    JUNGIAN: 'jungian',
    ATTACHMENT: 'attachment',
    POSITIVE: 'positive',
    NARRATIVE: 'narrative',
    PHENOMENOLOGY: 'phenomenology',
    EXISTENTIAL: 'existential',
    FEMINIST: 'feminist',
    CRITICAL: 'critical',
    POSTHUMANISM: 'posthumanism',
    BUDDHIST: 'buddhist',
    NIETZSCHEAN: 'nietzschean',
    GESTALT: 'gestalt',
    TRANSPERSONAL: 'transpersonal',
    CBT: 'cbt',
    HERMENEUTICS: 'hermeneutics',
    STOICISM: 'stoicism',
    PSYCHIATRY: 'psychiatry'
};

// Constants for media types
const MEDIA_TYPES = {
    TEXT: 'text',
    IMAGE: 'image',
    AUDIO: 'audio',
    FILM: 'film'
};

// Default plugin settings
const DEFAULT_SETTINGS = {
    enabledFrameworks: {
        [FRAMEWORKS.TACKTICAL]: true,
        [FRAMEWORKS.FREUDIAN]: true,
        [FRAMEWORKS.LACANIAN]: true,
        [FRAMEWORKS.DELEUZIAN]: true,
        [FRAMEWORKS.IRIGARAYIAN]: true,
        [FRAMEWORKS.JUNGIAN]: true,
        [FRAMEWORKS.ATTACHMENT]: true,
        [FRAMEWORKS.POSITIVE]: true,
        [FRAMEWORKS.NARRATIVE]: true,
        [FRAMEWORKS.PHENOMENOLOGY]: true,
        [FRAMEWORKS.EXISTENTIAL]: true,
        [FRAMEWORKS.FEMINIST]: true,
        [FRAMEWORKS.CRITICAL]: true,
        [FRAMEWORKS.POSTHUMANISM]: true,
        [FRAMEWORKS.BUDDHIST]: true,
        [FRAMEWORKS.NIETZSCHEAN]: true,
        [FRAMEWORKS.GESTALT]: true,
        [FRAMEWORKS.TRANSPERSONAL]: true,
        [FRAMEWORKS.CBT]: true,
        [FRAMEWORKS.HERMENEUTICS]: true,
        [FRAMEWORKS.STOICISM]: true,
        [FRAMEWORKS.PSYCHIATRY]: true
    },
    analysisDepth: 'standard',
    enableJournalingPrompts: true,
    autoOpenExportedFiles: true
};

// Analysis Engine class
class AnalysisEngine {
    constructor(app, settings) {
        this.app = app;
        this.settings = settings;
    }

    // Analyze any content based on its type
    async analyzeContent(content, mediaType, frameworks) {
        switch (mediaType) {
            case MEDIA_TYPES.TEXT:
                return this.analyzeText(content, frameworks);
            case MEDIA_TYPES.IMAGE:
                return this.analyzeImage(content, frameworks);
            case MEDIA_TYPES.AUDIO:
                return this.analyzeAudio(content, frameworks);
            case MEDIA_TYPES.FILM:
                return this.analyzeFilm(content, frameworks);
            default:
                throw new Error(`Unsupported media type: ${mediaType}`);
        }
    }

    // Analyze text content
    async analyzeText(content, frameworks) {
        const result = {
            mediaType: MEDIA_TYPES.TEXT,
            summary: this.generateTextSummary(content),
            frameworkAnalyses: {}
        };

        // Generate analysis for each selected framework
        for (const framework of frameworks) {
            result.frameworkAnalyses[framework] = this.generateFrameworkAnalysis(content, framework, MEDIA_TYPES.TEXT);
        }

        // Generate recommendations based on the analyses
        result.recommendations = this.generateRecommendations(result.frameworkAnalyses);

        return result;
    }

    // Analyze image content
    async analyzeImage(file, frameworks) {
        const result = {
            mediaType: MEDIA_TYPES.IMAGE,
            fileName: file.name,
            summary: `This image (${file.name}) contains visual elements that can be analyzed through multiple theoretical frameworks.`,
            frameworkAnalyses: {}
        };

        // Generate analysis for each selected framework
        for (const framework of frameworks) {
            result.frameworkAnalyses[framework] = this.generateFrameworkAnalysis(file.name, framework, MEDIA_TYPES.IMAGE);
        }

        // Generate recommendations based on the analyses
        result.recommendations = this.generateRecommendations(result.frameworkAnalyses);

        return result;
    }

    // Analyze audio content
    async analyzeAudio(file, frameworks) {
        const result = {
            mediaType: MEDIA_TYPES.AUDIO,
            fileName: file.name,
            summary: `This audio file (${file.name}) contains sonic elements that can be analyzed through multiple theoretical frameworks.`,
            frameworkAnalyses: {}
        };

        // Generate analysis for each selected framework
        for (const framework of frameworks) {
            result.frameworkAnalyses[framework] = this.generateFrameworkAnalysis(file.name, framework, MEDIA_TYPES.AUDIO);
        }

        // Generate recommendations based on the analyses
        result.recommendations = this.generateRecommendations(result.frameworkAnalyses);

        return result;
    }

    // Analyze film content
    async analyzeFilm(file, frameworks) {
        const result = {
            mediaType: MEDIA_TYPES.FILM,
            fileName: file.name,
            summary: `This film/video (${file.name}) contains visual and narrative elements that can be analyzed through multiple theoretical frameworks.`,
            frameworkAnalyses: {}
        };

        // Generate analysis for each selected framework
        for (const framework of frameworks) {
            result.frameworkAnalyses[framework] = this.generateFrameworkAnalysis(file.name, framework, MEDIA_TYPES.FILM);
        }

        // Generate recommendations based on the analyses
        result.recommendations = this.generateRecommendations(result.frameworkAnalyses);

        return result;
    }

    // Generate a summary of text content with more specific analysis
    generateTextSummary(content) {
        // Extract key themes and patterns from the content
        const themes = this.extractThemes(content);
        const emotionalTone = this.analyzeEmotionalTone(content);
        const narrativeStructure = this.analyzeNarrativeStructure(content);

        // Generate a more specific summary based on the content
        return `This text contains themes of ${themes.join(', ')}, with a predominantly ${emotionalTone} emotional tone. The writing suggests ${narrativeStructure}, revealing a nuanced exploration of personal experience and reflection.`;
    }

    // Extract key themes from text content
    extractThemes(content) {
        const themePatterns = {
            reflection: /reflect|contemplat|introspect|think about|ponder|consider/i,
            identity: /who I am|identity|self|authentic|true self/i,
            relationships: /relationship|connect|friend|family|partner|love|intimacy/i,
            transition: /change|transition|shift|transform|evolve|growth|develop/i,
            creativity: /creat|art|express|imagin|inspir|vision|idea/i,
            purpose: /purpose|meaning|significance|direction|goal|aim|mission/i,
            conflict: /conflict|tension|struggle|challenge|difficult|problem|obstacle/i,
            healing: /heal|recover|overcome|process|integrat|accept|reconcile/i
        };

        // Identify themes present in the content
        const presentThemes = [];
        for (const [theme, pattern] of Object.entries(themePatterns)) {
            if (pattern.test(content)) {
                presentThemes.push(theme);
            }
        }

        // Return identified themes or defaults if none found
        return presentThemes.length > 0 ? presentThemes : ['reflection', 'introspection', 'self-awareness'];
    }

    // Analyze the emotional tone of text content
    analyzeEmotionalTone(content) {
        const tonePatterns = {
            reflective: /reflect|contemplat|ponder|think|consider/i,
            melancholic: /sad|depress|melanchol|down|blue|despair|grief/i,
            hopeful: /hope|optimis|look forward|anticipat|excit|eager/i,
            anxious: /anxi|worry|concern|stress|tension|nervous|fear/i,
            content: /content|satisf|peace|calm|serene|tranquil|happy/i,
            frustrated: /frustrat|annoy|irritat|exasperat|anger|resent/i,
            grateful: /gratitude|thankful|appreciat|grateful|blessed/i,
            ambivalent: /ambivalen|conflict|mixed|unsure|uncertain/i
        };

        // Count occurrences of each tone
        const toneCounts = {};
        for (const [tone, pattern] of Object.entries(tonePatterns)) {
            const matches = content.match(pattern) || [];
            toneCounts[tone] = matches.length;
        }

        // Find the dominant tone
        let dominantTone = 'reflective'; // Default
        let maxCount = 0;

        for (const [tone, count] of Object.entries(toneCounts)) {
            if (count > maxCount) {
                maxCount = count;
                dominantTone = tone;
            }
        }

        return dominantTone;
    }

    // Analyze the narrative structure of text content
    analyzeNarrativeStructure(content) {
        // Check for different narrative patterns
        const isPastFocused = /was|were|had|did|went|came|thought|felt/i.test(content);
        const isFutureFocused = /will|going to|plan|future|soon|tomorrow|next/i.test(content);
        const isQuestionFocused = /\?|wonder|question|curious|how|why|what if/i.test(content);
        const isDialogueHeavy = /said|asked|replied|answered|spoke|talked/i.test(content);

        // Determine the dominant structure
        if (isPastFocused && isFutureFocused) {
            return "a reflective examination of past experiences in relation to future aspirations";
        } else if (isPastFocused) {
            return "a retrospective exploration of past experiences and their significance";
        } else if (isFutureFocused) {
            return "a forward-looking contemplation of possibilities and intentions";
        } else if (isQuestionFocused) {
            return "an inquiry-based exploration of questions and uncertainties";
        } else if (isDialogueHeavy) {
            return "a dialogical engagement with different perspectives or voices";
        } else {
            return "a present-centered reflection on current experiences and insights";
        }
    }

    // Generate analysis for a specific framework
    generateFrameworkAnalysis(content, framework, mediaType) {
        // In a real implementation, this would use AI or templates to generate framework-specific analysis
        // For now, we'll use predefined analyses based on the framework and media type

        const analyses = {
            [FRAMEWORKS.FREUDIAN]: {
                [MEDIA_TYPES.TEXT]: "From a Freudian perspective, this content reveals underlying psychological dynamics and unconscious processes. There are suggestions of repressed desires finding expression through symbolic representation and displacement. The formal elements of the work can be interpreted as manifestations of primary process thinking, where logical constraints are loosened in favor of associative connections. Recurring motifs suggest the return of the repressed, with unresolved psychic material seeking acknowledgment. The tension between structure and expression mirrors the ego's mediation between the demands of the id and superego. The work engages with universal psychological conflicts related to desire, prohibition, and sublimation.",
                [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Freudian lens to reveal unconscious symbolic content. Visual elements may represent displaced desires, condensed meanings, or symbolic fulfillment of unconscious wishes. The composition suggests tensions between conscious intention and unconscious expression. Color choices and spatial relationships may indicate psychosexual themes or conflicts. The image potentially functions as a dream-like expression where primary process thinking is evident. The viewer's response to the image may involve projection of their own unconscious material.",
                [MEDIA_TYPES.AUDIO]: "From a Freudian perspective, this audio piece reveals underlying psychological dynamics through its sonic elements. Rhythmic patterns may represent the tension between id impulses and superego constraints. Tonal qualities can be interpreted as expressions of libidinal energy or repressed emotional content. The structure of the piece mirrors psychological defense mechanisms such as sublimation or displacement. Recurring motifs suggest the return of repressed material seeking acknowledgment. The emotional response evoked in the listener may indicate transference or projection of unconscious material. The piece engages with universal psychological conflicts through its auditory symbolism.",
                [MEDIA_TYPES.FILM]: "This film can be analyzed through a Freudian lens to reveal unconscious symbolic content and psychological dynamics. Visual imagery and narrative elements may represent displaced desires or condensed meanings. Character relationships often mirror psychosexual developmental stages or conflicts. The film's structure suggests tensions between conscious intention and unconscious expression. Recurring visual motifs may indicate the return of repressed material seeking acknowledgment. Editing techniques and visual transitions can be interpreted as analogous to dream-work mechanisms. The viewer's emotional response may involve projection of their own unconscious material."
            },
            [FRAMEWORKS.LACANIAN]: {
                [MEDIA_TYPES.TEXT]: "A Lacanian reading of this text reveals the interplay between the Symbolic, Imaginary, and Real orders. The language demonstrates how the subject positions themselves within the symbolic order while grappling with the Real. There are moments where the text approaches the Real—that which resists symbolization—before retreating into symbolic structures. The writing reveals the fundamental split in subjectivity and the impossibility of wholeness that drives desire. Signifiers in the text form chains of meaning that point to an absent center, illustrating Lacan's concept that desire always operates through metonymic displacement. The text demonstrates how language both constructs and alienates the subject, creating a gap between the subject of the statement and the subject of enunciation.",
                [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Lacanian framework to reveal the interplay between the Symbolic, Imaginary, and Real orders. Visual elements function as signifiers in a chain of meaning that points to an absent center. The image potentially operates as a screen upon which fantasies are projected, revealing the structure of desire as lack. Compositional elements may demonstrate the gaze as object a—the unattainable object-cause of desire. The image potentially disrupts the Imaginary order by introducing elements of the Real that resist symbolization. The viewer's relationship to the image reveals the fundamental split in subjectivity. The visual language creates a gap between what is represented and what remains unrepresentable.",
                [MEDIA_TYPES.AUDIO]: "A Lacanian analysis of this audio piece reveals the interplay between the Symbolic, Imaginary, and Real orders through sonic elements. Sound functions as a signifier in chains of meaning that point to an absent center. Rhythmic and tonal patterns demonstrate the structure of desire as lack, always moving metonymically from one signifier to another. Moments of dissonance or silence may represent irruptions of the Real—that which resists symbolization. The listener's experience reveals the fundamental split in subjectivity when engaging with the piece. The audio creates a gap between what is heard and what remains beyond representation. The piece potentially functions as object a—the unattainable object-cause of desire—in its ability to evoke but never satisfy.",
                [MEDIA_TYPES.FILM]: "This film can be analyzed through a Lacanian framework to reveal the interplay between the Symbolic, Imaginary, and Real orders. Visual and narrative elements function as signifiers in chains of meaning that point to an absent center. The film potentially operates as a screen upon which fantasies are projected, revealing the structure of desire as lack. Character relationships demonstrate the mirror stage and the formation of the ego through identification. The gaze operates as object a—the unattainable object-cause of desire—in the visual language of the film. Moments of narrative disruption may represent irruptions of the Real that resist symbolization. The viewer's relationship to the film reveals the fundamental split in subjectivity."
            },
            // Add analyses for other frameworks and media types
        };

        // Return the analysis for the specified framework and media type, or a generic one if not found
        return analyses[framework]?.[mediaType] ||
            `This ${mediaType} can be analyzed through the lens of ${this.getFrameworkName(framework)} to reveal insights about its structure, content, and meaning. The analysis would consider the specific theoretical concepts and methodologies of this framework to interpret the work's significance and implications. Multiple elements of the ${mediaType} demonstrate principles central to this theoretical approach. The relationship between form and content reveals deeper patterns that align with key concepts from this framework. This analysis opens up new perspectives on how the ${mediaType} functions within broader cultural and psychological contexts. The ${mediaType}'s impact can be understood through this framework's unique interpretive lens.`;
    }

    // Generate recommendations based on analyses
    generateRecommendations(frameworkAnalyses) {
        // In a real implementation, this would generate personalized recommendations
        // For now, we'll return generic recommendations
        return [
            "Reflect on recurring patterns and themes that emerged across different theoretical frameworks.",
            "Consider how different perspectives offer complementary insights into the same content.",
            "Explore the relationship between form and content in your creative expression.",
            "Notice how emotional responses may reveal unconscious patterns or desires.",
            "Consider how cultural and historical contexts shape interpretation and meaning.",
            "Experiment with different modes of expression to access different aspects of experience."
        ];
    }

    // Get the display name for a framework ID
    getFrameworkName(frameworkId) {
        const names = {
            [FRAMEWORKS.TACKTICAL]: 'Tacktical Methodology',
            [FRAMEWORKS.FREUDIAN]: 'Freudian Psychoanalysis',
            [FRAMEWORKS.LACANIAN]: 'Lacanian Psychoanalysis',
            [FRAMEWORKS.DELEUZIAN]: 'Deleuzian Schizoanalysis',
            [FRAMEWORKS.IRIGARAYIAN]: 'Irigarayian Feminist Theory',
            [FRAMEWORKS.JUNGIAN]: 'Jungian Analytical Psychology',
            [FRAMEWORKS.ATTACHMENT]: 'Attachment Theory',
            [FRAMEWORKS.POSITIVE]: 'Positive Psychology',
            [FRAMEWORKS.NARRATIVE]: 'Narrative Psychology',
            [FRAMEWORKS.PHENOMENOLOGY]: 'Phenomenology',
            [FRAMEWORKS.EXISTENTIAL]: 'Existential Psychology',
            [FRAMEWORKS.FEMINIST]: 'Feminist Theory',
            [FRAMEWORKS.CRITICAL]: 'Critical Theory',
            [FRAMEWORKS.POSTHUMANISM]: 'Posthumanism',
            [FRAMEWORKS.BUDDHIST]: 'Buddhist Psychology',
            [FRAMEWORKS.NIETZSCHEAN]: 'Nietzschean Philosophy',
            [FRAMEWORKS.GESTALT]: 'Gestalt Psychology',
            [FRAMEWORKS.TRANSPERSONAL]: 'Transpersonal Psychology',
            [FRAMEWORKS.CBT]: 'Cognitive Behavioral Therapy',
            [FRAMEWORKS.HERMENEUTICS]: 'Hermeneutics',
            [FRAMEWORKS.STOICISM]: 'Stoicism',
            [FRAMEWORKS.PSYCHIATRY]: 'Psychiatry'
        };

        return names[frameworkId] || frameworkId;
    }
}

// Settings tab for the plugin
class DeleometerSettingTab extends obsidian.PluginSettingTab {
    constructor(app, plugin) {
        super(app, plugin);
        this.plugin = plugin;
    }

    display() {
        const {containerEl} = this;
        containerEl.empty();

        containerEl.createEl('h2', {text: 'Deleometer Settings'});

        // Framework selection section
        containerEl.createEl('h3', {text: 'Theoretical Frameworks'});
        containerEl.createEl('p', {text: 'Enable or disable theoretical frameworks for analysis.'});

        // Create a toggle for each framework
        Object.keys(FRAMEWORKS).forEach(key => {
            const frameworkId = FRAMEWORKS[key];
            const frameworkName = this.plugin.analysisEngine.getFrameworkName(frameworkId);

            new obsidian.Setting(containerEl)
                .setName(frameworkName)
                .setDesc(`Enable ${frameworkName} for analysis`)
                .addToggle(toggle => toggle
                    .setValue(this.plugin.settings.enabledFrameworks[frameworkId])
                    .onChange(async (value) => {
                        this.plugin.settings.enabledFrameworks[frameworkId] = value;
                        await this.plugin.saveSettings();
                    }));
        });

        // Analysis options section
        containerEl.createEl('h3', {text: 'Analysis Options'});

        new obsidian.Setting(containerEl)
            .setName('Analysis Depth')
            .setDesc('How detailed should the analysis be?')
            .addDropdown(dropdown => dropdown
                .addOption('brief', 'Brief')
                .addOption('standard', 'Standard')
                .addOption('detailed', 'Detailed')
                .setValue(this.plugin.settings.analysisDepth)
                .onChange(async (value) => {
                    this.plugin.settings.analysisDepth = value;
                    await this.plugin.saveSettings();
                }));

        // Journaling prompts option
        new obsidian.Setting(containerEl)
            .setName('Journaling Prompts')
            .setDesc('Enable personalized journaling prompts based on analysis')
            .addToggle(toggle => toggle
                .setValue(this.plugin.settings.enableJournalingPrompts)
                .onChange(async (value) => {
                    this.plugin.settings.enableJournalingPrompts = value;
                    await this.plugin.saveSettings();
                }));
    }
}

// Main plugin class
class DeleometerPlugin extends obsidian.Plugin {
    async onload() {
        console.log('Loading Deleometer plugin');

        // Load settings
        this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());

        // Initialize the analysis engine
        this.analysisEngine = new AnalysisEngine(this.app, this.settings);

        // Add the unified Theoretical Analysis command (combines single and batch analysis)
        this.addCommand({
            id: 'theoretical-analysis',
            name: 'Theoretical Analysis',
            callback: () => {
                this.showUnifiedAnalysisModal();
            }
        });

        // Add settings tab
        this.addSettingTab(new DeleometerSettingTab(this.app, this));

        // Add ribbon icon (leaf)
        this.addRibbonIcon('leaf', 'Deleometer', () => {
            this.showTheoreticalAnalysisModal();
        });
    }

    onunload() {
        console.log('Unloading Deleometer plugin');
    }

    // Show the unified analysis modal (combines single and batch analysis)
    showUnifiedAnalysisModal() {
        const modal = new UnifiedAnalysisModal(this.app, this);
        modal.open();
    }

    // Save settings
    async saveSettings() {
        await this.saveData(this.settings);
    }
}

module.exports = DeleometerPlugin;
// Combining all files into one
'use strict';

var obsidian = require('obsidian');

// Constants for media types (must match the ones in main.js)
const MEDIA_TYPES = {
    TEXT: 'text',
    IMAGE: 'image',
    AUDIO: 'audio',
    FILM: 'film'
};

// Unified Analysis Modal - combines single and batch analysis
class UnifiedAnalysisModal extends obsidian.Modal {
    constructor(app, plugin) {
        super(app);
        this.app = app;
        this.plugin = plugin;
        this.selectedFiles = [];
        this.selectedFrameworks = Object.keys(plugin.settings.enabledFrameworks)
            .filter(key => plugin.settings.enabledFrameworks[key]);
        this.isBatchMode = false;
    }

    onOpen() {
        const { contentEl } = this;

        contentEl.createEl('h2', { text: 'Theoretical Analysis' });

        // Analysis Mode Selection
        const modeSelection = contentEl.createEl('div', { cls: 'deleometer-mode-selection' });

        const singleModeRadio = modeSelection.createEl('input', {
            type: 'radio',
            attr: { name: 'analysis-mode', id: 'single-mode', checked: true }
        });
        modeSelection.createEl('label', {
            text: 'Single File Analysis',
            attr: { for: 'single-mode' }
        });

        modeSelection.createEl('span', { text: ' | ' });

        const batchModeRadio = modeSelection.createEl('input', {
            type: 'radio',
            attr: { name: 'analysis-mode', id: 'batch-mode' }
        });
        modeSelection.createEl('label', {
            text: 'Batch Analysis',
            attr: { for: 'batch-mode' }
        });

        // Content selection container
        const contentSelectionContainer = contentEl.createEl('div', { cls: 'deleometer-content-selection-container' });

        // Single file selection (initially visible)
        const singleFileSelection = contentSelectionContainer.createEl('div', { cls: 'deleometer-single-file-selection' });

        // Option for current file
        const currentFileOption = singleFileSelection.createEl('div', { cls: 'deleometer-option' });
        const currentFileRadio = currentFileOption.createEl('input', {
            type: 'radio',
            attr: { name: 'content-source', id: 'current-file', checked: true }
        });
        currentFileOption.createEl('label', {
            text: 'Current file/note',
            attr: { for: 'current-file' }
        });

        // Option for selecting a file
        const selectFileOption = singleFileSelection.createEl('div', { cls: 'deleometer-option' });
        const selectFileRadio = selectFileOption.createEl('input', {
            type: 'radio',
            attr: { name: 'content-source', id: 'select-file' }
        });
        selectFileOption.createEl('label', {
            text: 'Select a file',
            attr: { for: 'select-file' }
        });

        // File browser button (initially hidden)
        const fileBrowserButton = singleFileSelection.createEl('button', {
            text: 'Browse Files',
            cls: 'deleometer-file-browser-button'
        });
        fileBrowserButton.style.display = 'none';

        // Selected file display
        const selectedFileDisplay = singleFileSelection.createEl('div', {
            cls: 'deleometer-selected-file-display'
        });
        selectedFileDisplay.style.display = 'none';

        // Batch file selection (initially hidden)
        const batchFileSelection = contentSelectionContainer.createEl('div', {
            cls: 'deleometer-batch-file-selection'
        });
        batchFileSelection.style.display = 'none';

        // Batch file selection button
        const batchFileBrowserButton = batchFileSelection.createEl('button', {
            text: 'Select Files for Analysis',
            cls: 'deleometer-batch-file-browser-button'
        });

        // Selected files display
        const selectedFilesDisplay = batchFileSelection.createEl('div', {
            cls: 'deleometer-selected-files-display'
        });
        const selectedFilesList = selectedFilesDisplay.createEl('ul', {
            cls: 'deleometer-selected-files-list'
        });
        selectedFilesList.createEl('li', { text: 'No files selected' });

        // Framework selection section
        const frameworkSelection = contentEl.createEl('div', { cls: 'deleometer-framework-selection' });
        frameworkSelection.createEl('h3', { text: 'Framework Selection' });

        // Select All/None buttons
        const frameworkSelectionButtons = frameworkSelection.createEl('div', {
            cls: 'deleometer-framework-selection-buttons'
        });

        const selectAllButton = frameworkSelectionButtons.createEl('button', {
            text: 'Select All',
            cls: 'deleometer-select-all-button'
        });

        const selectNoneButton = frameworkSelectionButtons.createEl('button', {
            text: 'Select None',
            cls: 'deleometer-select-none-button'
        });

        // Create a checkbox for each framework
        const frameworkList = frameworkSelection.createEl('div', { cls: 'deleometer-framework-list' });

        const frameworkCheckboxes = {};

        Object.keys(this.plugin.settings.enabledFrameworks).forEach(frameworkId => {
            if (this.plugin.settings.enabledFrameworks[frameworkId]) {
                const frameworkItem = frameworkList.createEl('div', { cls: 'deleometer-framework-item' });
                const checkbox = frameworkItem.createEl('input', { type: 'checkbox' });
                checkbox.type = 'checkbox';
                checkbox.id = `framework-${frameworkId}`;
                checkbox.checked = true; // All frameworks selected by default
                checkbox.addEventListener('change', () => {
                    if (checkbox.checked) {
                        if (!this.selectedFrameworks.includes(frameworkId)) {
                            this.selectedFrameworks.push(frameworkId);
                        }
                    } else {
                        this.selectedFrameworks = this.selectedFrameworks.filter(id => id !== frameworkId);
                    }
                });

                frameworkItem.createEl('label', {
                    text: this.plugin.analysisEngine.getFrameworkName(frameworkId),
                    attr: { for: `framework-${frameworkId}` }
                });

                frameworkCheckboxes[frameworkId] = checkbox;
            }
        });

        // Select All button functionality
        selectAllButton.addEventListener('click', () => {
            Object.keys(frameworkCheckboxes).forEach(frameworkId => {
                frameworkCheckboxes[frameworkId].checked = true;
                if (!this.selectedFrameworks.includes(frameworkId)) {
                    this.selectedFrameworks.push(frameworkId);
                }
            });
        });

        // Select None button functionality
        selectNoneButton.addEventListener('click', () => {
            Object.keys(frameworkCheckboxes).forEach(frameworkId => {
                frameworkCheckboxes[frameworkId].checked = false;
            });
            this.selectedFrameworks = [];
        });

        // Analysis options
        const analysisOptions = contentEl.createEl('div', { cls: 'deleometer-analysis-options' });
        analysisOptions.createEl('h3', { text: 'Analysis Options' });

        // Analysis depth
        const depthSelection = analysisOptions.createEl('div', { cls: 'deleometer-depth-selection' });
        depthSelection.createEl('label', { text: 'Analysis Depth:' });
        const depthSelect = depthSelection.createEl('select');

        const depthOptions = [
            { value: 'brief', text: 'Brief' },
            { value: 'standard', text: 'Standard' },
            { value: 'detailed', text: 'Detailed' }
        ];

        depthOptions.forEach(option => {
            const optionEl = depthSelect.createEl('option', {
                text: option.text,
                attr: { value: option.value }
            });
            if (option.value === this.plugin.settings.analysisDepth) {
                optionEl.selected = true;
            }
        });

        depthSelect.addEventListener('change', () => {
            this.plugin.settings.analysisDepth = depthSelect.value;
        });

        // Export options (only visible in batch mode)
        const exportOptions = contentEl.createEl('div', { cls: 'deleometer-export-options' });
        exportOptions.style.display = 'none';
        exportOptions.createEl('h3', { text: 'Export Options' });

        const exportFormat = exportOptions.createEl('div', { cls: 'deleometer-export-format' });
        exportFormat.createEl('label', { text: 'Export Format:' });
        const formatSelect = exportFormat.createEl('select');
        formatSelect.createEl('option', { text: 'Markdown', attr: { value: 'markdown', selected: true } });
        formatSelect.createEl('option', { text: 'HTML', attr: { value: 'html' } });

        // Auto-open exported files
        const autoOpenOption = exportOptions.createEl('div', { cls: 'deleometer-auto-open-option' });
        const autoOpenCheckbox = autoOpenOption.createEl('input', {
            type: 'checkbox',
            attr: { id: 'auto-open-files' }
        });
        autoOpenCheckbox.checked = this.plugin.settings.autoOpenExportedFiles;
        autoOpenOption.createEl('label', {
            text: 'Automatically open exported files',
            attr: { for: 'auto-open-files' }
        });

        autoOpenCheckbox.addEventListener('change', async () => {
            this.plugin.settings.autoOpenExportedFiles = autoOpenCheckbox.checked;
            await this.plugin.saveSettings();
        });

        // Buttons
        const buttonContainer = contentEl.createEl('div', { cls: 'deleometer-buttons' });

        const analyzeButton = buttonContainer.createEl('button', { text: 'Analyze' });
        analyzeButton.addEventListener('click', () => {
            this.close();
            this.performAnalysis(singleModeRadio.checked, currentFileRadio.checked, formatSelect.value);
        });

        const cancelButton = buttonContainer.createEl('button', { text: 'Cancel' });
        cancelButton.addEventListener('click', () => {
            this.close();
        });

        // Event listeners for mode switching
        singleModeRadio.addEventListener('change', () => {
            if (singleModeRadio.checked) {
                this.isBatchMode = false;
                singleFileSelection.style.display = 'block';
                batchFileSelection.style.display = 'none';
                exportOptions.style.display = 'none';
            }
        });

        batchModeRadio.addEventListener('change', () => {
            if (batchModeRadio.checked) {
                this.isBatchMode = true;
                singleFileSelection.style.display = 'none';
                batchFileSelection.style.display = 'block';
                exportOptions.style.display = 'block';
            }
        });

        // Event listeners for file selection
        selectFileRadio.addEventListener('change', () => {
            if (selectFileRadio.checked) {
                fileBrowserButton.style.display = 'block';
            } else {
                fileBrowserButton.style.display = 'none';
                selectedFileDisplay.style.display = 'none';
            }
        });

        // File browser button functionality
        fileBrowserButton.addEventListener('click', () => {
            this.openFileBrowser(selectedFileDisplay);
        });

        // Batch file browser button functionality
        batchFileBrowserButton.addEventListener('click', () => {
            this.openBatchFileBrowser(selectedFilesList);
        });
    }

    // Open Obsidian's file browser for single file selection
    openFileBrowser(selectedFileDisplay) {
        const fileExplorer = this.app.workspace.getLeavesOfType('file-explorer')[0];
        if (!fileExplorer) {
            new obsidian.Notice('File explorer not found');
            return;
        }

        // Create a temporary event handler for file clicks
        const fileClickHandler = (event) => {
            const target = event.target;
            if (target && target.classList.contains('nav-file-title')) {
                const filePath = target.getAttribute('data-path');
                if (filePath) {
                    const file = this.app.vault.getAbstractFileByPath(filePath);
                    if (file instanceof obsidian.TFile) {
                        this.selectedFile = {
                            file: file,
                            mediaType: this.getMediaType(file)
                        };

                        // Update the selected file display
                        selectedFileDisplay.empty();
                        selectedFileDisplay.style.display = 'block';
                        selectedFileDisplay.createEl('div', {
                            text: `Selected: ${file.name}`,
                            cls: 'deleometer-selected-file'
                        });

                        // Remove the event listener
                        document.removeEventListener('click', fileClickHandler, true);
                    }
                }
            }
        };

        // Add the event listener
        document.addEventListener('click', fileClickHandler, true);

        // Show a notice to guide the user
        new obsidian.Notice('Click on a file in the explorer to select it');
    }

    // Open Obsidian's file browser for batch file selection
    openBatchFileBrowser(selectedFilesList) {
        const fileExplorer = this.app.workspace.getLeavesOfType('file-explorer')[0];
        if (!fileExplorer) {
            new obsidian.Notice('File explorer not found');
            return;
        }

        // Create a temporary event handler for file clicks
        const fileClickHandler = (event) => {
            const target = event.target;
            if (target && target.classList.contains('nav-file-title')) {
                const filePath = target.getAttribute('data-path');
                if (filePath) {
                    const file = this.app.vault.getAbstractFileByPath(filePath);
                    if (file instanceof obsidian.TFile) {
                        // Check if file is already selected
                        const isAlreadySelected = this.selectedFiles.some(f => f.file.path === file.path);

                        if (!isAlreadySelected) {
                            this.selectedFiles.push({
                                file: file,
                                mediaType: this.getMediaType(file)
                            });

                            // Update the selected files list
                            this.updateSelectedFilesList(selectedFilesList);
                        }
                    }
                }
            }
        };

        // Add the event listener
        document.addEventListener('click', fileClickHandler, true);

        // Show a notice to guide the user
        new obsidian.Notice('Click on files in the explorer to select them. Click "Done" when finished.');

        // Add a "Done" button to the modal
        const doneButton = this.contentEl.createEl('button', {
            text: 'Done Selecting Files',
            cls: 'deleometer-done-selecting-button'
        });

        doneButton.addEventListener('click', () => {
            // Remove the event listener and the button
            document.removeEventListener('click', fileClickHandler, true);
            doneButton.remove();
        });
    }

    // Update the selected files list
    updateSelectedFilesList(selectedFilesList) {
        selectedFilesList.empty();

        if (this.selectedFiles.length === 0) {
            selectedFilesList.createEl('li', { text: 'No files selected' });
        } else {
            this.selectedFiles.forEach(fileInfo => {
                const item = selectedFilesList.createEl('li');
                item.createEl('span', { text: fileInfo.file.name });
                const removeButton = item.createEl('button', {
                    text: 'Remove',
                    cls: 'deleometer-remove-file'
                });
                removeButton.addEventListener('click', () => {
                    this.selectedFiles = this.selectedFiles.filter(f => f.file.path !== fileInfo.file.path);
                    this.updateSelectedFilesList(selectedFilesList);
                });
            });
        }
    }

    // Get media type based on file extension
    getMediaType(file) {
        if (file.extension === 'md') {
            return MEDIA_TYPES.TEXT;
        } else if (['png', 'jpg', 'jpeg', 'gif', 'bmp', 'svg'].includes(file.extension.toLowerCase())) {
            return MEDIA_TYPES.IMAGE;
        } else if (['mp3', 'wav', 'ogg', 'm4a', 'flac'].includes(file.extension.toLowerCase())) {
            return MEDIA_TYPES.AUDIO;
        } else if (['mp4', 'webm', 'ogv', 'mov', 'avi'].includes(file.extension.toLowerCase())) {
            return MEDIA_TYPES.FILM;
        } else {
            return MEDIA_TYPES.TEXT; // Default to text
        }
    }

    // Perform the analysis based on selected options
    async performAnalysis(isSingleMode, useCurrentFile, exportFormat) {
        try {
            if (isSingleMode) {
                // Single file analysis
                let file;
                let mediaType;
                let content;

                if (useCurrentFile) {
                    // Get the current file
                    file = this.app.workspace.getActiveFile();
                    if (!file) {
                        new obsidian.Notice('No file is currently open');
                        return;
                    }

                    mediaType = this.getMediaType(file);
                } else {
                    // Use the selected file
                    if (!this.selectedFile) {
                        new obsidian.Notice('No file selected');
                        return;
                    }

                    file = this.selectedFile.file;
                    mediaType = this.selectedFile.mediaType;
                }

                // Get content based on media type
                if (mediaType === MEDIA_TYPES.TEXT) {
                    content = await this.app.vault.read(file);
                } else {
                    content = file;
                }

                // Check if any frameworks are selected
                if (this.selectedFrameworks.length === 0) {
                    new obsidian.Notice('No frameworks selected');
                    return;
                }

                // Perform the analysis
                const result = await this.plugin.analysisEngine.analyzeContent(
                    content,
                    mediaType,
                    this.selectedFrameworks
                );

                // Show the analysis results
                const modal = new AnalysisResultsModal(this.app, result, file.name, this.plugin);
                modal.open();

            } else {
                // Batch analysis
                if (this.selectedFiles.length === 0) {
                    new obsidian.Notice('No files selected for batch analysis');
                    return;
                }

                // Check if any frameworks are selected
                if (this.selectedFrameworks.length === 0) {
                    new obsidian.Notice('No frameworks selected');
                    return;
                }

                // Show loading notice
                new obsidian.Notice(`Analyzing ${this.selectedFiles.length} files...`);

                // Analyze each file
                const results = [];
                for (const fileInfo of this.selectedFiles) {
                    let content;
                    if (fileInfo.mediaType === MEDIA_TYPES.TEXT) {
                        content = await this.app.vault.read(fileInfo.file);
                    } else {
                        content = fileInfo.file;
                    }

                    const result = await this.plugin.analysisEngine.analyzeContent(
                        content,
                        fileInfo.mediaType,
                        this.selectedFrameworks
                    );

                    results.push({
                        fileName: fileInfo.file.name,
                        result: result
                    });
                }

                // Export the results
                let exportedFilePath;
                if (exportFormat === 'markdown') {
                    exportedFilePath = await this.exportBatchResultsAsMarkdown(results);
                } else {
                    exportedFilePath = await this.exportBatchResultsAsHtml(results);
                }

                // Open the exported file if auto-open is enabled
                if (this.plugin.settings.autoOpenExportedFiles && exportedFilePath) {
                    const exportedFile = this.app.vault.getAbstractFileByPath(exportedFilePath);
                    if (exportedFile) {
                        this.app.workspace.getLeaf().openFile(exportedFile);
                    }
                }
            }
        } catch (error) {
            console.error('Analysis error:', error);
            new obsidian.Notice(`Analysis failed: ${error.message}`);
        }
    }

    // Export batch analysis results as Markdown
    async exportBatchResultsAsMarkdown(results) {
        try {
            let markdown = `# Batch Analysis Results\n\n`;
            markdown += `*Generated on ${new Date().toLocaleString()}*\n\n`;
            markdown += `## Overview\n\n`;
            markdown += `- **Files Analyzed**: ${results.length}\n`;
            markdown += `- **Frameworks Used**: ${this.selectedFrameworks.map(id => this.plugin.analysisEngine.getFrameworkName(id)).join(', ')}\n\n`;

            // Add results for each file
            results.forEach(({ fileName, result }) => {
                markdown += `## ${result.mediaType.charAt(0).toUpperCase() + result.mediaType.slice(1)} Analysis: ${fileName}\n\n`;

                // Summary
                markdown += `### Summary\n\n${result.summary}\n\n`;

                // Framework analyses
                markdown += `### Theoretical Frameworks\n\n`;

                Object.keys(result.frameworkAnalyses).forEach(frameworkId => {
                    const frameworkName = this.plugin.analysisEngine.getFrameworkName(frameworkId);
                    markdown += `#### ${frameworkName}\n\n${result.frameworkAnalyses[frameworkId]}\n\n`;
                });

                // Recommendations
                markdown += `### Recommendations\n\n`;
                result.recommendations.forEach(rec => {
                    markdown += `- ${rec}\n`;
                });

                markdown += `\n---\n\n`;
            });

            // Create the file
            const fileName = `batch_analysis_${new Date().toISOString().replace(/[:.]/g, '-')}.md`;
            await this.app.vault.create(fileName, markdown);
            new obsidian.Notice(`Batch analysis exported as ${fileName}`);

            return fileName;
        } catch (error) {
            console.error('Export error:', error);
            new obsidian.Notice('Export failed: ' + error.message);
            return null;
        }
    }

    // Export batch analysis results as HTML
    async exportBatchResultsAsHtml(results) {
        try {
            let html = `<!DOCTYPE html>\n<html>\n<head>\n<meta charset="UTF-8">\n<title>Batch Analysis Results</title>\n<style>\n`;

            // Add CSS
            html += `body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif; line-height: 1.6; color: #333; max-width: 800px; margin: 0 auto; padding: 20px; }\n`;
            html += `h1, h2, h3, h4 { margin-top: 1.5em; margin-bottom: 0.5em; }\n`;
            html += `.file-analysis { margin-bottom: 40px; border-bottom: 1px solid #eee; padding-bottom: 20px; }\n`;
            html += `.framework { margin-bottom: 20px; padding: 15px; border-left: 4px solid #5c7cfa; background-color: #f8f9fa; border-radius: 4px; }\n`;
            html += `.recommendations { margin-top: 20px; }\n`;
            html += `.recommendations ul { padding-left: 20px; }\n`;
            html += `.overview { background-color: #f8f9fa; padding: 15px; border-radius: 4px; margin-bottom: 30px; }\n`;
            html += `.footer { margin-top: 40px; font-size: 0.8em; color: #888; border-top: 1px solid #eee; padding-top: 10px; }\n`;
            html += `</style>\n</head>\n<body>\n`;

            // Add content
            html += `<h1>Batch Analysis Results</h1>\n`;
            html += `<p><em>Generated on ${new Date().toLocaleString()}</em></p>\n`;

            // Overview
            html += `<div class="overview">\n<h2>Overview</h2>\n`;
            html += `<p><strong>Files Analyzed</strong>: ${results.length}</p>\n`;
            html += `<p><strong>Frameworks Used</strong>: ${this.selectedFrameworks.map(id => this.plugin.analysisEngine.getFrameworkName(id)).join(', ')}</p>\n`;
            html += `</div>\n`;

            // Add results for each file
            results.forEach(({ fileName, result }) => {
                html += `<div class="file-analysis">\n`;
                html += `<h2>${result.mediaType.charAt(0).toUpperCase() + result.mediaType.slice(1)} Analysis: ${fileName}</h2>\n`;

                // Summary
                html += `<h3>Summary</h3>\n<p>${result.summary}</p>\n`;

                // Framework analyses
                html += `<h3>Theoretical Frameworks</h3>\n`;

                Object.keys(result.frameworkAnalyses).forEach(frameworkId => {
                    const frameworkName = this.plugin.analysisEngine.getFrameworkName(frameworkId);
                    html += `<div class="framework">\n<h4>${frameworkName}</h4>\n<p>${result.frameworkAnalyses[frameworkId]}</p>\n</div>\n`;
                });

                // Recommendations
                html += `<div class="recommendations">\n<h3>Recommendations</h3>\n<ul>\n`;
                result.recommendations.forEach(rec => {
                    html += `<li>${rec}</li>\n`;
                });
                html += `</ul>\n</div>\n`;

                html += `</div>\n`;
            });

            // Add footer
            html += `<div class="footer">Generated by Deleometer on ${new Date().toLocaleString()}</div>\n`;

            html += `</body>\n</html>`;

            // Create the file
            const fileName = `batch_analysis_${new Date().toISOString().replace(/[:.]/g, '-')}.html`;
            await this.app.vault.create(fileName, html);
            new obsidian.Notice(`Batch analysis exported as ${fileName}`);

            return fileName;
        } catch (error) {
            console.error('Export error:', error);
            new obsidian.Notice('Export failed: ' + error.message);
            return null;
        }
    }

    onClose() {
        const { contentEl } = this;
        contentEl.empty();
    }
}

module.exports = { UnifiedAnalysisModal };
'use strict';

var obsidian = require('obsidian');

// Constants for media types (must match the ones in main.js)
const MEDIA_TYPES = {
    TEXT: 'text',
    IMAGE: 'image',
    AUDIO: 'audio',
    FILM: 'film'
};

// Modal for displaying analysis results
class AnalysisResultsModal extends obsidian.Modal {
    constructor(app, result, fileName, plugin) {
        super(app);
        this.result = result;
        this.fileName = fileName;
        this.plugin = plugin;
    }
    
    onOpen() {
        const { contentEl } = this;
        
        // Set modal title based on media type
        let title;
        switch (this.result.mediaType) {
            case MEDIA_TYPES.TEXT:
                title = 'Text Analysis';
                break;
            case MEDIA_TYPES.IMAGE:
                title = 'Image Analysis';
                break;
            case MEDIA_TYPES.AUDIO:
                title = 'Audio Analysis';
                break;
            case MEDIA_TYPES.FILM:
                title = 'Film Analysis';
                break;
            default:
                title = 'Analysis Results';
        }
        
        contentEl.createEl('h2', { text: `${title}: ${this.fileName}` });
        
        // Summary section
        const summary = contentEl.createEl('div', { cls: 'deleometer-summary' });
        summary.createEl('h3', { text: 'Summary' });
        summary.createEl('p', { text: this.result.summary });
        
        // Framework analyses
        const frameworks = contentEl.createEl('div', { cls: 'deleometer-frameworks' });
        frameworks.createEl('h3', { text: 'Theoretical Frameworks' });
        
        Object.keys(this.result.frameworkAnalyses).forEach(frameworkId => {
            const framework = frameworks.createEl('div', { cls: 'deleometer-framework' });
            framework.createEl('h4', { text: this.plugin.analysisEngine.getFrameworkName(frameworkId) });
            framework.createEl('p', { text: this.result.frameworkAnalyses[frameworkId] });
        });
        
        // Recommendations
        const recommendations = contentEl.createEl('div', { cls: 'deleometer-recommendations' });
        recommendations.createEl('h3', { text: 'Recommendations' });
        const recList = recommendations.createEl('ul');
        this.result.recommendations.forEach(rec => {
            recList.createEl('li', { text: rec });
        });
        
        // Export options
        const exportSection = contentEl.createEl('div', { cls: 'deleometer-export' });
        exportSection.createEl('h3', { text: 'Export Options' });
        
        const exportButtons = exportSection.createEl('div', { cls: 'deleometer-export-buttons' });
        
        // Export as Markdown
        const exportMarkdownButton = exportButtons.createEl('button', { text: 'Export as Markdown' });
        exportMarkdownButton.addEventListener('click', () => {
            this.exportAsMarkdown();
        });
        
        // Export as HTML
        const exportHtmlButton = exportButtons.createEl('button', { text: 'Export as HTML' });
        exportHtmlButton.addEventListener('click', () => {
            this.exportAsHtml();
        });
        
        // Close button
        const buttonContainer = contentEl.createEl('div', { cls: 'deleometer-buttons' });
        const closeButton = buttonContainer.createEl('button', { text: 'Close' });
        closeButton.addEventListener('click', () => {
            this.close();
        });
    }
    
    // Export analysis as Markdown
    async exportAsMarkdown() {
        try {
            const markdown = this.generateMarkdown();
            const fileName = `${this.fileName.replace(/\.[^/.]+$/, '')}_analysis.md`;
            await this.app.vault.create(fileName, markdown);
            new obsidian.Notice(`Analysis exported as ${fileName}`);
            
            // Auto-open the file if enabled in settings
            if (this.plugin.settings.autoOpenExportedFiles) {
                const exportedFile = this.app.vault.getAbstractFileByPath(fileName);
                if (exportedFile) {
                    this.app.workspace.getLeaf().openFile(exportedFile);
                }
            }
        } catch (error) {
            console.error('Export error:', error);
            new obsidian.Notice('Export failed: ' + error.message);
        }
    }
    
    // Export analysis as HTML
    async exportAsHtml() {
        try {
            const html = this.generateHtml();
            const fileName = `${this.fileName.replace(/\.[^/.]+$/, '')}_analysis.html`;
            await this.app.vault.create(fileName, html);
            new obsidian.Notice(`Analysis exported as ${fileName}`);
            
            // Auto-open the file if enabled in settings
            if (this.plugin.settings.autoOpenExportedFiles) {
                const exportedFile = this.app.vault.getAbstractFileByPath(fileName);
                if (exportedFile) {
                    this.app.workspace.getLeaf().openFile(exportedFile);
                }
            }
        } catch (error) {
            console.error('Export error:', error);
            new obsidian.Notice('Export failed: ' + error.message);
        }
    }
    
    // Generate Markdown representation of the analysis
    generateMarkdown() {
        let markdown = `# ${this.result.mediaType.charAt(0).toUpperCase() + this.result.mediaType.slice(1)} Analysis: ${this.fileName}\n\n`;
        
        // Summary
        markdown += `## Summary\n\n${this.result.summary}\n\n`;
        
        // Framework analyses
        markdown += `## Theoretical Frameworks\n\n`;
        
        Object.keys(this.result.frameworkAnalyses).forEach(frameworkId => {
            const frameworkName = this.plugin.analysisEngine.getFrameworkName(frameworkId);
            markdown += `### ${frameworkName}\n\n${this.result.frameworkAnalyses[frameworkId]}\n\n`;
        });
        
        // Recommendations
        markdown += `## Recommendations\n\n`;
        this.result.recommendations.forEach(rec => {
            markdown += `- ${rec}\n`;
        });
        
        // Add metadata
        markdown += `\n---\nGenerated by Deleometer on ${new Date().toLocaleString()}\n`;
        
        return markdown;
    }
    
    // Generate HTML representation of the analysis
    generateHtml() {
        let html = `<!DOCTYPE html>\n<html>\n<head>\n<meta charset="UTF-8">\n<title>${this.result.mediaType.charAt(0).toUpperCase() + this.result.mediaType.slice(1)} Analysis: ${this.fileName}</title>\n<style>\n`;
        
        // Add CSS
        html += `body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif; line-height: 1.6; color: #333; max-width: 800px; margin: 0 auto; padding: 20px; }\n`;
        html += `h1, h2, h3, h4 { margin-top: 1.5em; margin-bottom: 0.5em; }\n`;
        html += `.framework { margin-bottom: 20px; padding: 15px; border-left: 4px solid #5c7cfa; background-color: #f8f9fa; border-radius: 4px; }\n`;
        html += `.recommendations { margin-top: 30px; }\n`;
        html += `.recommendations ul { padding-left: 20px; }\n`;
        html += `.footer { margin-top: 40px; font-size: 0.8em; color: #888; border-top: 1px solid #eee; padding-top: 10px; }\n`;
        html += `</style>\n</head>\n<body>\n`;
        
        // Add content
        html += `<h1>${this.result.mediaType.charAt(0).toUpperCase() + this.result.mediaType.slice(1)} Analysis: ${this.fileName}</h1>\n`;
        
        // Summary
        html += `<h2>Summary</h2>\n<p>${this.result.summary}</p>\n`;
        
        // Framework analyses
        html += `<h2>Theoretical Frameworks</h2>\n`;
        
        Object.keys(this.result.frameworkAnalyses).forEach(frameworkId => {
            const frameworkName = this.plugin.analysisEngine.getFrameworkName(frameworkId);
            html += `<div class="framework">\n<h3>${frameworkName}</h3>\n<p>${this.result.frameworkAnalyses[frameworkId]}</p>\n</div>\n`;
        });
        
        // Recommendations
        html += `<div class="recommendations">\n<h2>Recommendations</h2>\n<ul>\n`;
        this.result.recommendations.forEach(rec => {
            html += `<li>${rec}</li>\n`;
        });
        html += `</ul>\n</div>\n`;
        
        // Add footer
        html += `<div class="footer">Generated by Deleometer on ${new Date().toLocaleString()}</div>\n`;
        
        html += `</body>\n</html>`;
        
        return html;
    }
    
    onClose() {
        const { contentEl } = this;
        contentEl.empty();
    }
}

module.exports = { AnalysisResultsModal };
