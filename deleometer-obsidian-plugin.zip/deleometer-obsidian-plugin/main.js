'use strict';

var obsidian = require('obsidian');

// Constants for framework IDs
const FRAMEWORKS = {
    TACKTICAL: 'tacktical',
    FREUDIAN: 'freudian',
    LACANIAN: 'lacanian',
    DELEUZIAN: 'deleuzian',
    IRIGARAYIAN: 'irigarayian',
    JUNGIAN: 'jungian',
    ATTACHMENT: 'attachment',
    POSITIVE: 'positive',
    NARRATIVE: 'narrative',
    PHENOMENOLOGY: 'phenomenology',
    EXISTENTIAL: 'existential',
    FEMINIST: 'feminist',
    CRITICAL: 'critical',
    POSTHUMANISM: 'posthumanism',
    BUDDHIST: 'buddhist',
    NIETZSCHEAN: 'nietzschean',
    GESTALT: 'gestalt',
    TRANSPERSONAL: 'transpersonal',
    CBT: 'cbt',
    HERMENEUTICS: 'hermeneutics',
    STOICISM: 'stoicism',
    PSYCHIATRY: 'psychiatry',
    EPICUREAN: 'epicurean'
};
// Constants for media types
const MEDIA_TYPES = {
    TEXT: 'text',
    IMAGE: 'image',
    AUDIO: 'audio',
    FILM: 'film'
};
// Tier options
var AnalysisTier;
(function (AnalysisTier) {
    AnalysisTier["FREE"] = "free";
    AnalysisTier["PREMIUM"] = "premium";
})(AnalysisTier || (AnalysisTier = {}));
// OpenAI model options
var OpenAIModel;
(function (OpenAIModel) {
    OpenAIModel["GPT_3_5"] = "gpt-3.5-turbo";
    OpenAIModel["GPT_4"] = "gpt-4";
})(OpenAIModel || (OpenAIModel = {}));
// Default plugin settings
const DEFAULT_SETTINGS = {
    enabledFrameworks: {
        [FRAMEWORKS.TACKTICAL]: true,
        [FRAMEWORKS.FREUDIAN]: true,
        [FRAMEWORKS.LACANIAN]: true,
        [FRAMEWORKS.DELEUZIAN]: true,
        [FRAMEWORKS.IRIGARAYIAN]: true,
        [FRAMEWORKS.JUNGIAN]: true,
        [FRAMEWORKS.ATTACHMENT]: true,
        [FRAMEWORKS.POSITIVE]: true,
        [FRAMEWORKS.NARRATIVE]: true,
        [FRAMEWORKS.PHENOMENOLOGY]: true,
        [FRAMEWORKS.EXISTENTIAL]: true,
        [FRAMEWORKS.FEMINIST]: true,
        [FRAMEWORKS.CRITICAL]: true,
        [FRAMEWORKS.POSTHUMANISM]: true,
        [FRAMEWORKS.BUDDHIST]: true,
        [FRAMEWORKS.NIETZSCHEAN]: true,
        [FRAMEWORKS.GESTALT]: true,
        [FRAMEWORKS.TRANSPERSONAL]: true,
        [FRAMEWORKS.CBT]: true,
        [FRAMEWORKS.HERMENEUTICS]: true,
        [FRAMEWORKS.STOICISM]: true,
        [FRAMEWORKS.PSYCHIATRY]: true,
        [FRAMEWORKS.EPICUREAN]: true
    },
    analysisDepth: 'standard',
    enableJournalingPrompts: true,
    autoOpenExportedFiles: true,
    analysisTier: AnalysisTier.FREE,
    enableOpenAI: false,
    openaiApiKey: '',
    openaiModel: OpenAIModel.GPT_3_5,
    openaiUsageLimit: 50,
    openaiUsageCount: 0,
    openaiLastReset: Date.now()
};

class DeleuzianAnalysis {
    /**
     * Analyze content using Deleuzian schizoanalysis
     */
    analyzeContent(content, mediaType) {
        switch (mediaType) {
            case MEDIA_TYPES.TEXT:
                return this.analyzeText(content);
            case MEDIA_TYPES.IMAGE:
                return this.analyzeImage(content);
            case MEDIA_TYPES.AUDIO:
                return this.analyzeAudio(content);
            case MEDIA_TYPES.FILM:
                return this.analyzeFilm(content);
            default:
                throw new Error(`Unsupported media type for Deleuzian analysis: ${mediaType}`);
        }
    }
    /**
     * Analyze text content using Deleuzian concepts
     */
    analyzeText(text) {
        // Extract key patterns and themes
        const themes = this.extractThemes(text);
        const emotionalPatterns = this.analyzeEmotionalPatterns(text);
        const narrativeStructure = this.analyzeNarrativeStructure(text);
        // Identify rhizomatic connections
        const rhizomaticConnections = this.identifyRhizomaticConnections(text, themes);
        // Identify assemblages
        const assemblages = this.identifyAssemblages(text, themes, emotionalPatterns);
        // Identify deterritorializations
        const deterritorializations = this.identifyDeterritorializations(text);
        // Analyze lines (molar, molecular, flight)
        const lines = this.analyzeLines(text);
        // Analyze desiring-production
        const desiring = this.analyzeDesiring(text);
        // Identify the body without organs
        const bodyWithoutOrgans = this.identifyBodyWithoutOrgans(text, narrativeStructure);
        // Generate summary
        const summary = this.generateSummary(rhizomaticConnections, assemblages, deterritorializations, lines, desiring, bodyWithoutOrgans);
        return {
            rhizomaticConnections,
            assemblages,
            deterritorializations,
            lines,
            desiring,
            bodyWithoutOrgans,
            summary
        };
    }
    /**
     * Analyze image content using Deleuzian concepts
     */
    analyzeImage(file) {
        // For images, we'll create a placeholder analysis based on the filename
        // In a real implementation, this would analyze the actual image content
        const fileName = file.name;
        const rhizomaticConnections = [
            "Visual elements form non-hierarchical connections across the image plane",
            "Color relationships create unexpected pathways of association",
            "Formal elements connect to cultural and historical references"
        ];
        const assemblages = [
            "The image functions as an assemblage of visual elements, cultural codes, and viewer perception",
            "Technical components (medium, format, technique) form a material assemblage",
            "Representational elements combine with abstract qualities in a visual assemblage"
        ];
        const deterritorializations = [
            "The image deterritorializes conventional visual language through its formal innovations",
            "Representational elements are deterritorialized through their contextual placement",
            "The viewing experience deterritorializes habitual modes of perception"
        ];
        const lines = {
            molar: [
                "Recognizable forms and conventional compositional structures",
                "Cultural codes and established visual language"
            ],
            molecular: [
                "Subtle variations in tone, texture, and color",
                "Micro-movements and tensions within the composition"
            ],
            flight: [
                "Elements that escape categorization or fixed meaning",
                "Visual components that suggest movement beyond the frame"
            ]
        };
        const desiring = {
            machines: [
                "The technical apparatus of image creation",
                "The perceptual mechanisms of viewing",
                "The cultural machinery of image circulation"
            ],
            productions: [
                "Production of visual intensity and affect",
                "Production of meaning through visual juxtaposition",
                "Production of new perceptual possibilities"
            ]
        };
        const bodyWithoutOrgans = "The image as a surface of intensities, prior to organization into fixed meaning";
        const summary = `This image (${fileName}) functions as a visual assemblage that generates multiple rhizomatic connections. It operates through the interplay of molar structures and molecular variations, with lines of flight that open toward new perceptual possibilities. The image can be understood as a body without organs—a surface of visual intensities that resists fixed organization. Through its visual deterritorializations, it produces new affective and conceptual potentials that exceed conventional categorization.`;
        return {
            rhizomaticConnections,
            assemblages,
            deterritorializations,
            lines,
            desiring,
            bodyWithoutOrgans,
            summary
        };
    }
    /**
     * Analyze audio content using Deleuzian concepts
     */
    analyzeAudio(file) {
        // For audio, we'll create a placeholder analysis based on the filename
        // In a real implementation, this would analyze the actual audio content
        const fileName = file.name;
        const rhizomaticConnections = [
            "Sonic elements form non-hierarchical networks of relation",
            "Timbral qualities create unexpected connections across different moments",
            "Rhythmic patterns establish temporal rhizomes"
        ];
        const assemblages = [
            "The audio functions as a sonic assemblage of frequencies, rhythms, and timbres",
            "Technical components (recording, mixing, playback) form a technological assemblage",
            "Cultural references and sonic signifiers create a semiotic assemblage"
        ];
        const deterritorializations = [
            "Sound deterritorializes spatial perception through its immersive qualities",
            "Temporal experience is deterritorialized through rhythmic variations",
            "Familiar sonic elements are deterritorialized through processing and contextualization"
        ];
        const lines = {
            molar: [
                "Recognizable musical structures and conventional forms",
                "Established sonic languages and genre conventions"
            ],
            molecular: [
                "Micro-variations in timbre, pitch, and rhythm",
                "Subtle modulations and textural shifts"
            ],
            flight: [
                "Sonic elements that escape categorization or fixed meaning",
                "Moments that break from established patterns and open new possibilities"
            ]
        };
        const desiring = {
            machines: [
                "The technical apparatus of sound production and reproduction",
                "The physiological mechanisms of hearing",
                "The cultural machinery of musical categorization"
            ],
            productions: [
                "Production of affective intensities through sound",
                "Production of temporal experience through rhythm and duration",
                "Production of new listening modalities"
            ]
        };
        const bodyWithoutOrgans = "The sonic continuum as a field of intensities, prior to organization into fixed structures";
        const summary = `This audio piece (${fileName}) functions as a sonic assemblage that generates multiple rhizomatic connections through its temporal unfolding. It operates through the interplay of molar structures and molecular variations, with lines of flight that open toward new listening experiences. The piece can be understood as a sonic body without organs—a field of auditory intensities that resists fixed organization. Through its sonic deterritorializations, it produces new affective and temporal potentials that exceed conventional categorization.`;
        return {
            rhizomaticConnections,
            assemblages,
            deterritorializations,
            lines,
            desiring,
            bodyWithoutOrgans,
            summary
        };
    }
    /**
     * Analyze film content using Deleuzian concepts
     */
    analyzeFilm(file) {
        // For film, we'll create a placeholder analysis based on the filename
        // In a real implementation, this would analyze the actual film content
        const fileName = file.name;
        const rhizomaticConnections = [
            "Visual and sonic elements form non-hierarchical networks across the duration",
            "Temporal connections create unexpected pathways between different moments",
            "Narrative and formal elements establish rhizomatic relationships"
        ];
        const assemblages = [
            "The film functions as a time-image assemblage of visual, sonic, and narrative elements",
            "Technical components (camera, editing, sound) form a cinematic assemblage",
            "Cultural references and cinematic language create a semiotic assemblage"
        ];
        const deterritorializations = [
            "Cinema deterritorializes spatial and temporal perception",
            "Montage deterritorializes linear temporality through juxtaposition",
            "The frame deterritorializes the visual field through selection and composition"
        ];
        const lines = {
            molar: [
                "Recognizable narrative structures and conventional cinematic language",
                "Established genres and representational codes"
            ],
            molecular: [
                "Micro-movements within the frame and subtle rhythmic variations",
                "Affective modulations and atmospheric shifts"
            ],
            flight: [
                "Moments that escape narrative or representational logic",
                "Elements that open toward virtual potentials beyond the actual film"
            ]
        };
        const desiring = {
            machines: [
                "The technical apparatus of film production and projection",
                "The perceptual mechanisms of audio-visual processing",
                "The cultural machinery of cinematic reception"
            ],
            productions: [
                "Production of movement-images and time-images",
                "Production of affective intensities through audio-visual means",
                "Production of new perceptual and conceptual possibilities"
            ]
        };
        const bodyWithoutOrgans = "The film as a plane of audio-visual intensities, prior to organization into fixed meaning";
        const summary = `This film (${fileName}) functions as a cinematic assemblage that generates multiple rhizomatic connections through its temporal unfolding. It operates through the interplay of movement-images and time-images, with lines of flight that open toward new perceptual possibilities. The film can be understood as an audio-visual body without organs—a plane of intensities that resists fixed organization. Through its cinematic deterritorializations, it produces new affective, temporal, and conceptual potentials that exceed conventional categorization.`;
        return {
            rhizomaticConnections,
            assemblages,
            deterritorializations,
            lines,
            desiring,
            bodyWithoutOrgans,
            summary
        };
    }
    /**
     * Extract themes from text content
     */
    extractThemes(text) {
        // In a real implementation, this would use NLP or other techniques
        // For now, we'll use a simplified approach with keyword matching
        const themePatterns = {
            desire: /desire|want|wish|crave|yearn|long/i,
            becoming: /becom|transform|chang|evolv|shift|transition/i,
            multiplicity: /multipl|many|various|diverse|different|heterogeneous/i,
            intensity: /intens|strong|powerful|force|energy|vibrant/i,
            flow: /flow|stream|current|movement|flux|continuous/i,
            connection: /connect|relation|link|join|associate|bind/i,
            assemblage: /assembl|gather|collect|arrange|combine|composition/i,
            territory: /territor|space|place|area|region|domain/i,
            machine: /machine|mechanism|apparatus|device|system|function/i,
            rhizome: /rhizome|network|web|mesh|interconnect|root/i
        };
        // Identify themes present in the text
        const presentThemes = [];
        for (const [theme, pattern] of Object.entries(themePatterns)) {
            if (pattern.test(text)) {
                presentThemes.push(theme);
            }
        }
        // Return identified themes or defaults if none found
        return presentThemes.length > 0 ? presentThemes : ['desire', 'becoming', 'multiplicity'];
    }
    /**
     * Analyze emotional patterns in text
     */
    analyzeEmotionalPatterns(text) {
        // In a real implementation, this would use sentiment analysis
        // For now, we'll use a simplified approach
        const patterns = [];
        if (/joy|happy|delight|excite|content|satisf/i.test(text)) {
            patterns.push("flows of joyful affects that increase capacity for action");
        }
        if (/sad|depress|melanchol|despair|grief|sorrow/i.test(text)) {
            patterns.push("reactive forces that diminish potential connections");
        }
        if (/anger|rage|frustrat|irritat|annoy|resent/i.test(text)) {
            patterns.push("intensive flows redirected through reactive channels");
        }
        if (/fear|anxi|worry|concern|dread|terror/i.test(text)) {
            patterns.push("territorializing affects that limit lines of flight");
        }
        if (/love|affection|care|compassion|kindness/i.test(text)) {
            patterns.push("connective flows that form new assemblages");
        }
        if (/confus|uncertain|ambivalen|unclear|perplex/i.test(text)) {
            patterns.push("deterritorializing forces opening to new possibilities");
        }
        // Return identified patterns or a default
        return patterns.length > 0 ? patterns : ["complex affective flows with varying intensities"];
    }
    /**
     * Analyze narrative structure in text
     */
    analyzeNarrativeStructure(text) {
        // Check for different narrative patterns from a Deleuzian perspective
        if (/progress|develop|grow|advance|improve/i.test(text)) {
            return "arborescent structure with linear progression";
        }
        if (/connect|link|relation|network|web/i.test(text)) {
            return "rhizomatic structure with multiple entry and exit points";
        }
        if (/cycle|return|repeat|again|back/i.test(text)) {
            return "circular structure with eternal return of difference";
        }
        if (/fragment|piece|section|part|segment/i.test(text)) {
            return "fragmented structure with plateaus of intensity";
        }
        if (/layer|level|strata|plane|dimension/i.test(text)) {
            return "stratified structure with different planes of consistency";
        }
        // Default
        return "complex assemblage with multiple structural elements";
    }
    /**
     * Identify rhizomatic connections in text
     */
    identifyRhizomaticConnections(text, themes) {
        const connections = [];
        // Generate connections based on identified themes
        if (themes.includes('desire')) {
            connections.push("Flows of desire connect multiple elements without hierarchical organization");
        }
        if (themes.includes('becoming')) {
            connections.push("Processes of becoming establish connections between heterogeneous elements");
        }
        if (themes.includes('multiplicity')) {
            connections.push("Multiplicities form through non-hierarchical connections between singular elements");
        }
        if (themes.includes('flow')) {
            connections.push("Flows of intensity create pathways between different states and experiences");
        }
        if (themes.includes('connection')) {
            connections.push("Connective syntheses establish relations between disparate elements");
        }
        if (themes.includes('rhizome')) {
            connections.push("Rhizomatic structures link any point to any other point without fixed order");
        }
        // Add general rhizomatic connections
        connections.push("Multiple entry and exit points create a map rather than a tracing");
        connections.push("Heterogeneous elements connect without subordination to a unifying structure");
        return connections;
    }
    /**
     * Identify assemblages in text
     */
    identifyAssemblages(text, themes, emotionalPatterns) {
        const assemblages = [];
        // Generate assemblages based on identified themes
        if (themes.includes('assemblage')) {
            assemblages.push("Heterogeneous elements form assemblages with emergent properties");
        }
        if (themes.includes('machine')) {
            assemblages.push("Machinic assemblages connect bodies, actions, and passions");
        }
        if (themes.includes('territory')) {
            assemblages.push("Territorial assemblages establish temporary stability through coding");
        }
        // Generate assemblages based on emotional patterns
        if (emotionalPatterns.some(pattern => pattern.includes("joyful"))) {
            assemblages.push("Joyful assemblages increase capacity for action and connection");
        }
        if (emotionalPatterns.some(pattern => pattern.includes("reactive"))) {
            assemblages.push("Reactive assemblages restrict flows and limit connections");
        }
        // Add general assemblages
        assemblages.push("Content and expression form a double articulation within assemblages");
        assemblages.push("Social, material, and semiotic elements combine in functional assemblages");
        return assemblages;
    }
    /**
     * Identify deterritorializations in text
     */
    identifyDeterritorializations(text) {
        const deterritorializations = [];
        // Check for patterns of deterritorialization
        if (/change|transform|shift|alter|modify/i.test(text)) {
            deterritorializations.push("Transformative processes deterritorialize fixed identities");
        }
        if (/break|disrupt|interrupt|disturb|destabilize/i.test(text)) {
            deterritorializations.push("Disruptive elements deterritorialize established patterns");
        }
        if (/escape|flee|avoid|evade|elude/i.test(text)) {
            deterritorializations.push("Lines of flight deterritorialize through escape from fixed structures");
        }
        if (/question|challenge|doubt|contest|dispute/i.test(text)) {
            deterritorializations.push("Critical questioning deterritorializes accepted meanings");
        }
        if (/create|invent|imagine|generate|produce/i.test(text)) {
            deterritorializations.push("Creative processes deterritorialize through production of the new");
        }
        // Add general deterritorializations
        deterritorializations.push("Relative deterritorializations open new connections while maintaining some structure");
        deterritorializations.push("Absolute deterritorializations open onto the plane of immanence");
        return deterritorializations;
    }
    /**
     * Analyze lines (molar, molecular, flight) in text
     */
    analyzeLines(text) {
        const molar = [];
        const molecular = [];
        const flight = [];
        // Identify molar lines
        if (/structure|system|organization|institution|rule|law/i.test(text)) {
            molar.push("Structured systems establish molar lines through rigid segmentation");
        }
        if (/identity|category|classification|type|group/i.test(text)) {
            molar.push("Categorical identities form through molar lines of rigid segmentarity");
        }
        if (/should|must|have to|need to|require/i.test(text)) {
            molar.push("Normative imperatives establish molar lines of obligation");
        }
        // Identify molecular lines
        if (/subtle|slight|minor|small|little/i.test(text)) {
            molecular.push("Subtle variations create molecular lines of supple segmentarity");
        }
        if (/flow|flux|shift|drift|slide/i.test(text)) {
            molecular.push("Flowing movements establish molecular lines between segments");
        }
        if (/ambiguous|unclear|uncertain|indistinct/i.test(text)) {
            molecular.push("Ambiguous elements form molecular lines that destabilize fixed categories");
        }
        // Identify lines of flight
        if (/escape|break|rupture|crack|split/i.test(text)) {
            flight.push("Ruptures create lines of flight that escape established patterns");
        }
        if (/create|invent|new|novel|original/i.test(text)) {
            flight.push("Creative innovations establish lines of flight toward new possibilities");
        }
        if (/transform|metamorphosis|becoming|change/i.test(text)) {
            flight.push("Transformative becomings trace lines of flight beyond fixed identities");
        }
        // Add general lines
        molar.push("Binary oppositions establish molar lines of rigid segmentarity");
        molecular.push("Micropolitical processes operate through molecular lines");
        flight.push("Lines of flight open onto the plane of consistency");
        return { molar, molecular, flight };
    }
    /**
     * Analyze desiring-production in text
     */
    analyzeDesiring(text) {
        const machines = [];
        const productions = [];
        // Identify desiring-machines
        if (/connect|link|join|attach|couple/i.test(text)) {
            machines.push("Connective syntheses operate through coupling of partial objects");
        }
        if (/record|register|inscribe|mark|trace/i.test(text)) {
            machines.push("Disjunctive syntheses record and distribute flows on the body without organs");
        }
        if (/consume|use|utilize|employ|experience/i.test(text)) {
            machines.push("Conjunctive syntheses consume intensities as states of becoming");
        }
        // Identify productions
        if (/produce|create|generate|make|form/i.test(text)) {
            productions.push("Productive syntheses generate real effects through desiring-production");
        }
        if (/transform|convert|change|alter|modify/i.test(text)) {
            productions.push("Transformative processes produce new connections and possibilities");
        }
        if (/intensify|strengthen|amplify|increase/i.test(text)) {
            productions.push("Intensive productions amplify affective capacities");
        }
        // Add general desiring elements
        machines.push("Desiring-machines function through breaks and flows");
        machines.push("Social machines organize flows of desire through coding");
        productions.push("Desire produces the real through machinic processes");
        productions.push("Production occurs through connection, disjunction, and conjunction");
        return { machines, productions };
    }
    /**
     * Identify the body without organs in text
     */
    identifyBodyWithoutOrgans(text, narrativeStructure) {
        // Generate a description of the BwO based on the text and narrative structure
        if (narrativeStructure.includes("arborescent")) {
            return "The text moves toward a body without organs that resists hierarchical organization, seeking to dismantle the arborescent structure in favor of a plane of consistency.";
        }
        if (narrativeStructure.includes("rhizomatic")) {
            return "The text functions as a body without organs—a plane of consistency where intensities circulate and distribute without hierarchical organization, enabling rhizomatic connections.";
        }
        if (narrativeStructure.includes("circular")) {
            return "The circular structure forms a body without organs where the eternal return produces difference rather than identity, creating a plane of immanence.";
        }
        if (narrativeStructure.includes("fragmented")) {
            return "The fragmented structure creates a body without organs composed of plateaus—regions of continuous intensity that communicate with one another across the plane of consistency.";
        }
        if (narrativeStructure.includes("stratified")) {
            return "Beneath the stratified structure lies a body without organs—a destratified plane of consistency that enables deterritorialization and new connections.";
        }
        // Default
        return "The text contains a virtual body without organs—an unformed, unorganized plane of consistency where intensities pass and circulate, enabling becomings and transformations.";
    }
    /**
     * Generate a summary of the Deleuzian analysis
     */
    generateSummary(rhizomaticConnections, assemblages, deterritorializations, lines, desiring, bodyWithoutOrgans) {
        return `From a Deleuzian perspective, this content operates through rhizomatic connections that link heterogeneous elements without hierarchical organization. It functions as an assemblage where content and expression form a double articulation. The text exhibits processes of deterritorialization that open new possibilities while maintaining some structural coherence. It operates through the interplay of molar lines (rigid segmentarity), molecular lines (supple segmentarity), and lines of flight that escape established patterns. Desiring-production functions through connective, disjunctive, and conjunctive syntheses, generating real effects. ${bodyWithoutOrgans} Through these processes, the content produces new affective intensities and conceptual possibilities that exceed conventional categorization.`;
    }
}

class IrigarayianAnalysis {
    /**
     * Analyze content using Irigarayian feminist theory
     */
    analyzeContent(content, mediaType) {
        switch (mediaType) {
            case MEDIA_TYPES.TEXT:
                return this.analyzeText(content);
            case MEDIA_TYPES.IMAGE:
                return this.analyzeImage(content);
            case MEDIA_TYPES.AUDIO:
                return this.analyzeAudio(content);
            case MEDIA_TYPES.FILM:
                return this.analyzeFilm(content);
            default:
                throw new Error(`Unsupported media type for Irigarayian analysis: ${mediaType}`);
        }
    }
    /**
     * Analyze text content using Irigarayian concepts
     */
    analyzeText(text) {
        // Extract key patterns and themes
        const themes = this.extractThemes(text);
        const linguisticPatterns = this.analyzeLinguisticPatterns(text);
        const relationality = this.analyzeRelationality(text);
        // Analyze sexual difference
        const sexualDifference = this.analyzeSexualDifference(text, themes);
        // Analyze feminine speaking
        const feminineSpeaking = this.analyzeFeminineSpeaking(text, linguisticPatterns);
        // Analyze mimesis
        const mimesis = this.analyzeMimesis(text);
        // Analyze fluid logic
        const fluidLogic = this.analyzeFluidLogic(text, linguisticPatterns);
        // Analyze mucous exchange
        const mucousExchange = this.analyzeMucousExchange(text, relationality);
        // Analyze divine feminine
        const divineFeminine = this.analyzeDivineFeminine(text);
        // Analyze ethical relation
        const ethicalRelation = this.analyzeEthicalRelation(text, relationality);
        // Generate summary
        const summary = this.generateSummary(sexualDifference, feminineSpeaking, mimesis, fluidLogic, mucousExchange, divineFeminine, ethicalRelation);
        return {
            sexualDifference,
            feminineSpeaking,
            mimesis,
            fluidLogic,
            mucousExchange,
            divineFeminine,
            ethicalRelation,
            summary
        };
    }
    /**
     * Analyze image content using Irigarayian concepts
     */
    analyzeImage(file) {
        // For images, we'll create a placeholder analysis based on the filename
        // In a real implementation, this would analyze the actual image content
        const fileName = file.name;
        const sexualDifference = [
            "The image engages with sexual difference through its visual language",
            "Visual elements suggest a non-binary approach to difference",
            "The composition explores morphological specificity beyond phallocentric representation"
        ];
        const feminineSpeaking = [
            "Visual syntax disrupts conventional representational logic",
            "The image speaks in the feminine through its formal qualities",
            "Multiple focal points create a non-linear visual language"
        ];
        const mimesis = [
            "The image engages in strategic mimesis of conventional visual codes",
            "Mimetic elements are subtly subverted to reveal their constructed nature",
            "Playful repetition with difference challenges visual conventions"
        ];
        const fluidLogic = [
            "Visual elements flow and connect in non-hierarchical ways",
            "The composition resists static categorization through fluid formal relationships",
            "Boundaries between elements remain permeable and in flux"
        ];
        const mucousExchange = [
            "The image facilitates a tactile, embodied viewing experience",
            "Visual textures evoke sensory engagement beyond the purely optical",
            "The relationship between viewer and image suggests reciprocal exchange"
        ];
        const divineFeminine = [
            "The image suggests possibilities for feminine transcendence",
            "Visual elements evoke a horizontal rather than vertical spirituality",
            "The composition creates space for feminine becoming"
        ];
        const ethicalRelation = [
            "The image establishes an ethical relation with the viewer through recognition of difference",
            "Visual elements create space for intersubjective encounter",
            "The composition respects alterity while enabling connection"
        ];
        const summary = `This image (${fileName}) engages with Irigarayian concepts of sexual difference through its visual language, challenging phallogocentric representation. It speaks in the feminine through a fluid visual syntax that disrupts linear and hierarchical organization. The image employs strategic mimesis to subvert conventional visual codes while establishing new possibilities for representation. Its fluid logic resists static categorization, while tactile elements evoke a mucous exchange between viewer and image. The composition suggests possibilities for a divine feminine that honors immanence and transcendence simultaneously. Through these qualities, the image establishes an ethical relation based on recognition of difference and intersubjective encounter.`;
        return {
            sexualDifference,
            feminineSpeaking,
            mimesis,
            fluidLogic,
            mucousExchange,
            divineFeminine,
            ethicalRelation,
            summary
        };
    }
    /**
     * Analyze audio content using Irigarayian concepts
     */
    analyzeAudio(file) {
        // For audio, we'll create a placeholder analysis based on the filename
        // In a real implementation, this would analyze the actual audio content
        const fileName = file.name;
        const sexualDifference = [
            "The audio engages with sexual difference through its sonic qualities",
            "Sound elements suggest a non-binary approach to difference",
            "The composition explores morphological specificity beyond phallocentric sonic structures"
        ];
        const feminineSpeaking = [
            "Sonic syntax disrupts conventional musical/auditory logic",
            "The audio speaks in the feminine through its formal qualities",
            "Multiple sonic layers create a non-linear auditory experience"
        ];
        const mimesis = [
            "The audio engages in strategic mimesis of conventional sonic codes",
            "Mimetic elements are subtly subverted to reveal their constructed nature",
            "Playful repetition with difference challenges auditory conventions"
        ];
        const fluidLogic = [
            "Sonic elements flow and connect in non-hierarchical ways",
            "The composition resists static categorization through fluid tonal relationships",
            "Boundaries between sounds remain permeable and in flux"
        ];
        const mucousExchange = [
            "The audio facilitates a tactile, embodied listening experience",
            "Sonic textures evoke sensory engagement beyond the purely auditory",
            "The relationship between listener and sound suggests reciprocal exchange"
        ];
        const divineFeminine = [
            "The audio suggests possibilities for feminine transcendence",
            "Sonic elements evoke a horizontal rather than vertical spirituality",
            "The composition creates space for feminine becoming through sound"
        ];
        const ethicalRelation = [
            "The audio establishes an ethical relation with the listener through recognition of difference",
            "Sonic elements create space for intersubjective encounter",
            "The composition respects alterity while enabling connection"
        ];
        const summary = `This audio piece (${fileName}) engages with Irigarayian concepts of sexual difference through its sonic language, challenging phallogocentric structures. It speaks in the feminine through a fluid sonic syntax that disrupts linear and hierarchical organization. The piece employs strategic mimesis to subvert conventional auditory codes while establishing new possibilities for expression. Its fluid logic resists static categorization, while textural elements evoke a mucous exchange between listener and sound. The composition suggests possibilities for a divine feminine that honors immanence and transcendence simultaneously. Through these qualities, the audio establishes an ethical relation based on recognition of difference and intersubjective encounter.`;
        return {
            sexualDifference,
            feminineSpeaking,
            mimesis,
            fluidLogic,
            mucousExchange,
            divineFeminine,
            ethicalRelation,
            summary
        };
    }
    /**
     * Analyze film content using Irigarayian concepts
     */
    analyzeFilm(file) {
        // For film, we'll create a placeholder analysis based on the filename
        // In a real implementation, this would analyze the actual film content
        const fileName = file.name;
        const sexualDifference = [
            "The film engages with sexual difference through its visual and narrative language",
            "Cinematic elements suggest a non-binary approach to difference",
            "The composition explores morphological specificity beyond phallocentric representation"
        ];
        const feminineSpeaking = [
            "Cinematic syntax disrupts conventional narrative logic",
            "The film speaks in the feminine through its formal and temporal qualities",
            "Multiple perspectives create a non-linear cinematic language"
        ];
        const mimesis = [
            "The film engages in strategic mimesis of conventional cinematic codes",
            "Mimetic elements are subtly subverted to reveal their constructed nature",
            "Playful repetition with difference challenges cinematic conventions"
        ];
        const fluidLogic = [
            "Cinematic elements flow and connect in non-hierarchical ways",
            "The composition resists static categorization through fluid temporal relationships",
            "Boundaries between scenes and sequences remain permeable and in flux"
        ];
        const mucousExchange = [
            "The film facilitates a tactile, embodied viewing experience",
            "Cinematic textures evoke sensory engagement beyond the purely visual",
            "The relationship between viewer and film suggests reciprocal exchange"
        ];
        const divineFeminine = [
            "The film suggests possibilities for feminine transcendence",
            "Cinematic elements evoke a horizontal rather than vertical spirituality",
            "The composition creates space for feminine becoming"
        ];
        const ethicalRelation = [
            "The film establishes an ethical relation with the viewer through recognition of difference",
            "Cinematic elements create space for intersubjective encounter",
            "The composition respects alterity while enabling connection"
        ];
        const summary = `This film (${fileName}) engages with Irigarayian concepts of sexual difference through its cinematic language, challenging phallogocentric representation. It speaks in the feminine through a fluid cinematic syntax that disrupts linear and hierarchical organization. The film employs strategic mimesis to subvert conventional cinematic codes while establishing new possibilities for representation. Its fluid logic resists static categorization, while tactile elements evoke a mucous exchange between viewer and image. The composition suggests possibilities for a divine feminine that honors immanence and transcendence simultaneously. Through these qualities, the film establishes an ethical relation based on recognition of difference and intersubjective encounter.`;
        return {
            sexualDifference,
            feminineSpeaking,
            mimesis,
            fluidLogic,
            mucousExchange,
            divineFeminine,
            ethicalRelation,
            summary
        };
    }
    /**
     * Extract themes from text content
     */
    extractThemes(text) {
        // In a real implementation, this would use NLP or other techniques
        // For now, we'll use a simplified approach with keyword matching
        const themePatterns = {
            difference: /differen|distinct|divers|varie|other|alter/i,
            feminine: /feminin|woman|female|girl|womanhood/i,
            masculine: /masculin|man|male|boy|manhood/i,
            language: /language|speak|talk|voice|word|discourse/i,
            body: /body|embod|flesh|corpor|physical/i,
            fluidity: /fluid|flow|liquid|stream|flux/i,
            ethics: /ethic|moral|relation|connect|responsibility/i,
            divine: /divin|sacred|spirit|transcend|god/i,
            mimesis: /mime|imitat|copy|repeat|mirror/i,
            touch: /touch|contact|tactile|feel|sensation/i
        };
        // Identify themes present in the text
        const presentThemes = [];
        for (const [theme, pattern] of Object.entries(themePatterns)) {
            if (pattern.test(text)) {
                presentThemes.push(theme);
            }
        }
        // Return identified themes or defaults if none found
        return presentThemes.length > 0 ? presentThemes : ['difference', 'feminine', 'language'];
    }
    /**
     * Analyze linguistic patterns in text
     */
    analyzeLinguisticPatterns(text) {
        // In a real implementation, this would use linguistic analysis
        // For now, we'll use a simplified approach
        const patterns = [];
        // Check for non-linear syntax
        if (/[;:,.]\s*[a-z]/i.test(text) || text.split(/[.!?]/).some(s => s.length > 100)) {
            patterns.push("non-linear syntax that disrupts phallogocentric discourse");
        }
        // Check for repetition with difference
        if (/(the|a|an|this|that|these|those|it|they)\s+\w+\s+\1\s+\w+/i.test(text)) {
            patterns.push("repetition with difference that creates new meaning");
        }
        // Check for metaphorical language
        if (/like|as if|seems|appears|resembles/i.test(text)) {
            patterns.push("metaphorical language that exceeds literal meaning");
        }
        // Check for questions
        if (/\?/.test(text)) {
            patterns.push("questioning that opens space for dialogue");
        }
        // Check for embodied language
        if (/feel|touch|sense|body|flesh/i.test(text)) {
            patterns.push("embodied language that reconnects thought with corporeality");
        }
        // Return identified patterns or a default
        return patterns.length > 0 ? patterns : ["complex linguistic patterns that suggest feminine modes of expression"];
    }
    /**
     * Analyze relationality in text
     */
    analyzeRelationality(text) {
        // In a real implementation, this would use more sophisticated analysis
        // For now, we'll use a simplified approach
        const relationality = [];
        // Check for intersubjective relations
        if (/we|us|our|together|between|relation|connect/i.test(text)) {
            relationality.push("intersubjective relations that respect difference");
        }
        // Check for recognition of otherness
        if (/other|different|foreign|strange|unfamiliar/i.test(text)) {
            relationality.push("recognition of otherness without appropriation");
        }
        // Check for ethical language
        if (/ethic|moral|responsib|care|respect/i.test(text)) {
            relationality.push("ethical orientation toward the other");
        }
        // Check for dialogue
        if (/speak|talk|convers|dialogue|discuss/i.test(text)) {
            relationality.push("dialogical engagement that preserves difference");
        }
        // Check for love
        if (/love|affection|care|compassion|tenderness/i.test(text)) {
            relationality.push("love as recognition of irreducible difference");
        }
        // Return identified relationality or a default
        return relationality.length > 0 ? relationality : ["complex relational patterns that suggest ethical engagement with difference"];
    }
    /**
     * Analyze sexual difference in text
     */
    analyzeSexualDifference(text, themes) {
        const sexualDifference = [];
        // Generate insights based on identified themes
        if (themes.includes('difference')) {
            sexualDifference.push("Engagement with difference as positive and productive rather than hierarchical");
        }
        if (themes.includes('feminine')) {
            sexualDifference.push("Exploration of feminine specificity beyond phallocentric definitions");
        }
        if (themes.includes('masculine')) {
            sexualDifference.push("Critical examination of masculine subjectivity and its relation to the feminine");
        }
        if (themes.includes('body')) {
            sexualDifference.push("Recognition of embodied sexual difference as foundational to subjectivity");
        }
        // Check for specific patterns related to sexual difference
        if (/two|dual|both|pair|couple/i.test(text)) {
            sexualDifference.push("Acknowledgment of twoness that cannot be reduced to unity or hierarchy");
        }
        if (/beyond|exceed|transcend|more than/i.test(text)) {
            sexualDifference.push("Movement beyond binary opposition toward positive sexual difference");
        }
        // Add general insights on sexual difference
        sexualDifference.push("Sexual difference as irreducible and constitutive of human experience");
        sexualDifference.push("Difference understood as positive and productive rather than as lack or opposition");
        return sexualDifference;
    }
    /**
     * Analyze feminine speaking in text
     */
    analyzeFeminineSpeaking(text, linguisticPatterns) {
        const feminineSpeaking = [];
        // Generate insights based on linguistic patterns
        if (linguisticPatterns.includes("non-linear syntax that disrupts phallogocentric discourse")) {
            feminineSpeaking.push("Non-linear syntax that disrupts the subject-predicate logic of phallogocentric discourse");
        }
        if (linguisticPatterns.includes("repetition with difference that creates new meaning")) {
            feminineSpeaking.push("Repetition with difference that creates new meaning through variation");
        }
        if (linguisticPatterns.includes("metaphorical language that exceeds literal meaning")) {
            feminineSpeaking.push("Metaphorical language that exceeds the literal and opens to multiplicity");
        }
        if (linguisticPatterns.includes("questioning that opens space for dialogue")) {
            feminineSpeaking.push("Questioning that opens space for dialogue rather than asserting mastery");
        }
        if (linguisticPatterns.includes("embodied language that reconnects thought with corporeality")) {
            feminineSpeaking.push("Embodied language that reconnects thought with corporeality and desire");
        }
        // Check for specific patterns related to feminine speaking
        if (/plural|multiple|many|various/i.test(text)) {
            feminineSpeaking.push("Plurality and multiplicity that resist singular meaning");
        }
        if (/touch|contact|proximity|near|close/i.test(text)) {
            feminineSpeaking.push("Language of proximity and touch that challenges visual distance");
        }
        // Add general insights on feminine speaking
        feminineSpeaking.push("Speaking (as) woman that exceeds phallogocentric discourse");
        feminineSpeaking.push("Language that remains open, fluid, and in process rather than fixed");
        return feminineSpeaking;
    }
    /**
     * Analyze mimesis in text
     */
    analyzeMimesis(text) {
        const mimesis = [];
        // Check for patterns related to mimesis
        if (/repeat|echo|mirror|reflect|copy/i.test(text)) {
            mimesis.push("Strategic repetition that reveals the constructed nature of discourse");
        }
        if (/play|jest|joke|humor|irony/i.test(text)) {
            mimesis.push("Playful mimicry that subverts through apparent compliance");
        }
        if (/exaggerat|amplif|intensif|heighten/i.test(text)) {
            mimesis.push("Exaggeration that exposes underlying assumptions through amplification");
        }
        if (/question|challenge|disrupt|subvert/i.test(text)) {
            mimesis.push("Questioning that challenges from within dominant discourse");
        }
        if (/transform|convert|change|alter/i.test(text)) {
            mimesis.push("Transformation of existing language through mimetic engagement");
        }
        // Add general insights on mimesis
        mimesis.push("Strategic mimesis that engages with dominant discourse to reveal its assumptions");
        mimesis.push("Mimetic practice that creates space for difference within apparent sameness");
        return mimesis;
    }
    /**
     * Analyze fluid logic in text
     */
    analyzeFluidLogic(text, linguisticPatterns) {
        const fluidLogic = [];
        // Generate insights based on linguistic patterns
        if (linguisticPatterns.includes("non-linear syntax that disrupts phallogocentric discourse")) {
            fluidLogic.push("Non-linear movement that resists the fixed logic of identity");
        }
        if (linguisticPatterns.includes("metaphorical language that exceeds literal meaning")) {
            fluidLogic.push("Metaphorical fluidity that exceeds literal and fixed meaning");
        }
        // Check for patterns related to fluid logic
        if (/flow|flux|stream|current|liquid/i.test(text)) {
            fluidLogic.push("Flowing movement that resists fixity and stasis");
        }
        if (/change|shift|transform|alter|modify/i.test(text)) {
            fluidLogic.push("Constant change and transformation that challenges fixed identity");
        }
        if (/connect|relation|link|join|touch/i.test(text)) {
            fluidLogic.push("Connective logic that establishes relations without hierarchy");
        }
        if (/multiple|plural|many|various|diverse/i.test(text)) {
            fluidLogic.push("Multiplicity that exceeds binary opposition and singular truth");
        }
        // Add general insights on fluid logic
        fluidLogic.push("Fluid logic that challenges the solid mechanics of phallogocentric thought");
        fluidLogic.push("Movement between and across categories that resists fixed classification");
        return fluidLogic;
    }
    /**
     * Analyze mucous exchange in text
     */
    analyzeMucousExchange(text, relationality) {
        const mucousExchange = [];
        // Generate insights based on relationality
        if (relationality.includes("intersubjective relations that respect difference")) {
            mucousExchange.push("Intersubjective exchange that preserves the integrity of each subject");
        }
        if (relationality.includes("recognition of otherness without appropriation")) {
            mucousExchange.push("Recognition of otherness that allows for exchange without appropriation");
        }
        if (relationality.includes("dialogical engagement that preserves difference")) {
            mucousExchange.push("Dialogical engagement that maintains the threshold between subjects");
        }
        // Check for patterns related to mucous exchange
        if (/touch|contact|feel|sensation|tactile/i.test(text)) {
            mucousExchange.push("Tactile engagement that respects boundaries while enabling contact");
        }
        if (/between|threshold|boundary|border|limit/i.test(text)) {
            mucousExchange.push("Threshold consciousness that recognizes the space between subjects");
        }
        if (/share|exchange|give|receive|reciprocal/i.test(text)) {
            mucousExchange.push("Reciprocal exchange that maintains difference within relation");
        }
        // Add general insights on mucous exchange
        mucousExchange.push("Mucous as mediating threshold that enables exchange while preserving difference");
        mucousExchange.push("Embodied relationality that challenges the visual economy of appropriation");
        return mucousExchange;
    }
    /**
     * Analyze divine feminine in text
     */
    analyzeDivineFeminine(text) {
        const divineFeminine = [];
        // Check for patterns related to divine feminine
        if (/divine|sacred|holy|spirit|transcend/i.test(text)) {
            divineFeminine.push("Recognition of the divine as inclusive of feminine becoming");
        }
        if (/horizon|future|beyond|potential|possibility/i.test(text)) {
            divineFeminine.push("Orientation toward a horizon of feminine becoming");
        }
        if (/immanent|present|here|now|embodied/i.test(text)) {
            divineFeminine.push("Immanent spirituality that honors embodied experience");
        }
        if (/nature|natural|earth|world|cosmos/i.test(text)) {
            divineFeminine.push("Reconnection of the divine with the natural world");
        }
        if (/love|compassion|care|nurture|tend/i.test(text)) {
            divineFeminine.push("Love as divine principle that respects difference");
        }
        // Add general insights on divine feminine
        divineFeminine.push("Divine feminine as horizon of becoming rather than fixed transcendence");
        divineFeminine.push("Spirituality that honors immanence and embodiment alongside transcendence");
        return divineFeminine;
    }
    /**
     * Analyze ethical relation in text
     */
    analyzeEthicalRelation(text, relationality) {
        const ethicalRelation = [];
        // Generate insights based on relationality
        if (relationality.includes("intersubjective relations that respect difference")) {
            ethicalRelation.push("Intersubjective ethics founded on respect for irreducible difference");
        }
        if (relationality.includes("recognition of otherness without appropriation")) {
            ethicalRelation.push("Recognition of otherness as foundation for ethical relation");
        }
        if (relationality.includes("ethical orientation toward the other")) {
            ethicalRelation.push("Ethical orientation that prioritizes relation while preserving difference");
        }
        if (relationality.includes("love as recognition of irreducible difference")) {
            ethicalRelation.push("Love as ethical principle that honors the mystery of the other");
        }
        // Check for patterns related to ethical relation
        if (/respect|honor|value|appreciate|acknowledge/i.test(text)) {
            ethicalRelation.push("Respect for difference as foundation of ethical engagement");
        }
        if (/responsib|obligation|duty|commit|pledge/i.test(text)) {
            ethicalRelation.push("Responsibility toward the other that does not appropriate or reduce");
        }
        // Add general insights on ethical relation
        ethicalRelation.push("Ethics of sexual difference that recognizes the irreducibility of the other");
        ethicalRelation.push("Relational ethics founded on wonder rather than mastery");
        return ethicalRelation;
    }
    /**
     * Generate a summary of the Irigarayian analysis
     */
    generateSummary(sexualDifference, feminineSpeaking, mimesis, fluidLogic, mucousExchange, divineFeminine, ethicalRelation) {
        return `From an Irigarayian perspective, this content engages with sexual difference as irreducible and constitutive of human experience. It speaks in the feminine through a syntax that disrupts the subject-predicate logic of phallogocentric discourse, employing repetition with difference and metaphorical language that exceeds literal meaning. The content demonstrates strategic mimesis that engages with dominant discourse to reveal its assumptions while creating space for difference. It operates through a fluid logic that challenges the solid mechanics of phallocentric thought, establishing connections without hierarchy. The content suggests a mucous exchange that enables intersubjective relation while preserving the integrity of each subject. It points toward a divine feminine that honors immanence and embodiment alongside transcendence, establishing an ethical relation founded on respect for irreducible difference.`;
    }
}

// Tacktical analysis class
class TackticalAnalysis {
    constructor() {
        // Methodologies concepts
        this.methodologies = [
            "Systematic observation",
            "Contextual analysis",
            "Pattern recognition",
            "Structural mapping",
            "Integrative synthesis"
        ];
        // Approaches concepts
        this.approaches = [
            "Multi-dimensional perspective",
            "Cross-disciplinary integration",
            "Dialectical reasoning",
            "Emergent understanding",
            "Holistic interpretation"
        ];
        // Insights concepts
        this.insights = [
            "Underlying patterns",
            "Hidden connections",
            "Systemic dynamics",
            "Transformative potentials",
            "Integrative frameworks"
        ];
    }
    // Analyze content with Tacktical framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const methodologiesElements = this.getRandomElements(this.methodologies, 2);
        const approachesElements = this.getRandomElements(this.approaches, 2);
        const insightsElements = this.getRandomElements(this.insights, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "From a Tacktical methodology perspective, this text reveals underlying patterns and systemic dynamics through a multi-dimensional analytical approach.";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through Tacktical methodology to reveal visual patterns and symbolic structures that emerge through systematic observation.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "This audio piece can be understood through Tacktical methodology as a sonic structure with emergent patterns and integrative elements.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through Tacktical methodology to reveal narrative structures and visual patterns that form an integrative whole.";
        }
        // Return structured analysis
        return {
            methodologies: methodologiesElements,
            approaches: approachesElements,
            insights: insightsElements,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Freudian analysis class
class FreudianAnalysis {
    constructor() {
        // Unconscious elements concepts
        this.unconsciousElements = [
            "Repressed desires",
            "Latent content",
            "Primary process thinking",
            "Unconscious symbolism",
            "Id impulses"
        ];
        // Psychosexual stages concepts
        this.psychosexualStages = [
            "Oral fixation",
            "Anal retention",
            "Phallic symbolism",
            "Oedipal complex",
            "Genital maturity"
        ];
        // Defense mechanisms concepts
        this.defenseMechanisms = [
            "Repression",
            "Projection",
            "Displacement",
            "Sublimation",
            "Reaction formation"
        ];
        // Dream symbols concepts
        this.dreamSymbols = [
            "Manifest content",
            "Latent meaning",
            "Condensation",
            "Displacement",
            "Secondary revision"
        ];
    }
    // Analyze content with Freudian framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const unconsciousElements = this.getRandomElements(this.unconsciousElements, 2);
        const psychosexualStages = this.getRandomElements(this.psychosexualStages, 2);
        const defenseMechanisms = this.getRandomElements(this.defenseMechanisms, 2);
        const dreamSymbols = this.getRandomElements(this.dreamSymbols, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "From a Freudian perspective, this text reveals underlying psychological dynamics and unconscious processes. There are suggestions of repressed desires finding expression through symbolic representation and displacement.";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through a Freudian lens to reveal unconscious symbolic content. Visual elements may represent displaced desires, condensed meanings, or symbolic fulfillment of unconscious wishes.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "From a Freudian perspective, this audio piece reveals underlying psychological dynamics through its sonic elements. Rhythmic patterns may represent the tension between id impulses and superego constraints.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through a Freudian lens to reveal unconscious symbolic content and psychological dynamics. Visual imagery and narrative elements may represent displaced desires or condensed meanings.";
        }
        // Return structured analysis
        return {
            unconsciousElements,
            psychosexualStages,
            defenseMechanisms,
            dreamSymbols,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Lacanian analysis class
class LacanianAnalysis {
    constructor() {
        // Orders concepts
        this.orders = {
            symbolic: ["Signifying chains", "Linguistic structure", "Symbolic law", "Name-of-the-Father", "Symbolic castration"],
            imaginary: ["Mirror stage", "Ego formation", "Imaginary identification", "Specular image", "Narcissistic relation"],
            real: ["Trauma", "Impossible", "Beyond symbolization", "Jouissance", "Symptom"]
        };
        // Subject formation concepts
        this.subjectFormation = [
            "Split subject",
            "Alienation",
            "Separation",
            "Subject of the unconscious",
            "Subject of enunciation"
        ];
        // Desire concepts
        this.desire = [
            "Desire as lack",
            "Desire of the Other",
            "Object a",
            "Metonymic sliding",
            "Desire as impossible"
        ];
        // Jouissance concepts
        this.jouissance = [
            "Phallic jouissance",
            "Feminine jouissance",
            "Surplus jouissance",
            "Jouissance beyond the pleasure principle",
            "Symptom as jouissance"
        ];
    }
    // Analyze content with Lacanian framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const symbolicElements = this.getRandomElements(this.orders.symbolic, 2);
        const imaginaryElements = this.getRandomElements(this.orders.imaginary, 2);
        const realElements = this.getRandomElements(this.orders.real, 2);
        const subjectFormationElements = this.getRandomElements(this.subjectFormation, 2);
        const desireElements = this.getRandomElements(this.desire, 2);
        const jouissanceElements = this.getRandomElements(this.jouissance, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "A Lacanian reading of this text reveals the interplay between the Symbolic, Imaginary, and Real orders. The language demonstrates how the subject positions themselves within the symbolic order while grappling with the Real.";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through a Lacanian framework to reveal the interplay between the Symbolic, Imaginary, and Real orders. Visual elements function as signifiers in a chain of meaning that points to an absent center.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "A Lacanian analysis of this audio piece reveals the interplay between the Symbolic, Imaginary, and Real orders through sonic elements. Sound functions as a signifier in chains of meaning that point to an absent center.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through a Lacanian framework to reveal the interplay between the Symbolic, Imaginary, and Real orders. Visual and narrative elements function as signifiers in chains of meaning that point to an absent center.";
        }
        // Return structured analysis
        return {
            orders: {
                symbolic: symbolicElements,
                imaginary: imaginaryElements,
                real: realElements
            },
            subjectFormation: subjectFormationElements,
            desire: desireElements,
            jouissance: jouissanceElements,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Jungian analysis class
class JungianAnalysis {
    constructor() {
        // Archetypes concepts
        this.archetypes = [
            "The Self",
            "The Shadow",
            "The Anima/Animus",
            "The Persona",
            "The Wise Old Man/Woman",
            "The Trickster",
            "The Hero",
            "The Great Mother"
        ];
        // Collective unconscious concepts
        this.collectiveUnconscious = [
            "Universal patterns",
            "Inherited structures",
            "Primordial images",
            "Collective memory",
            "Shared symbolic language"
        ];
        // Individuation concepts
        this.individuation = [
            "Self-realization",
            "Integration of unconscious",
            "Wholeness",
            "Transcendent function",
            "Psychological rebirth"
        ];
        // Symbols concepts
        this.symbols = [
            "Mandala",
            "Circle",
            "Quaternity",
            "Tree of life",
            "Water/rebirth",
            "Journey/quest"
        ];
    }
    // Analyze content with Jungian framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const archetypesElements = this.getRandomElements(this.archetypes, 2);
        const collectiveUnconsciousElements = this.getRandomElements(this.collectiveUnconscious, 2);
        const individuationElements = this.getRandomElements(this.individuation, 2);
        const symbolsElements = this.getRandomElements(this.symbols, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "From a Jungian perspective, this content engages with archetypal patterns and collective unconscious symbols. The narrative reveals a process of individuation through the integration of unconscious material.";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through a Jungian lens to reveal archetypal symbols and collective unconscious patterns. Visual elements suggest a process of individuation and self-realization.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "From a Jungian perspective, this audio piece engages with archetypal patterns through its sonic elements. The composition suggests a journey toward psychological wholeness.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through a Jungian lens to reveal archetypal narratives and collective unconscious symbols. The visual and narrative elements depict a process of individuation.";
        }
        // Return structured analysis
        return {
            archetypes: archetypesElements,
            collectiveUnconscious: collectiveUnconsciousElements,
            individuation: individuationElements,
            symbols: symbolsElements,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Attachment analysis class
class AttachmentAnalysis {
    constructor() {
        // Attachment styles concepts
        this.attachmentStyles = [
            "Secure attachment",
            "Anxious-ambivalent attachment",
            "Avoidant attachment",
            "Disorganized attachment",
            "Earned secure attachment"
        ];
        // Relationship patterns concepts
        this.relationshipPatterns = [
            "Proximity seeking",
            "Safe haven",
            "Secure base",
            "Separation anxiety",
            "Internal working models"
        ];
        // Internal working models concepts
        this.internalWorkingModels = [
            "Self-representation",
            "Other-representation",
            "Relationship expectations",
            "Emotional regulation strategies",
            "Interpersonal scripts"
        ];
    }
    // Analyze content with Attachment framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const attachmentStylesElements = this.getRandomElements(this.attachmentStyles, 2);
        const relationshipPatternsElements = this.getRandomElements(this.relationshipPatterns, 2);
        const internalWorkingModelsElements = this.getRandomElements(this.internalWorkingModels, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "From an Attachment Theory perspective, this text reveals patterns of relationship dynamics and internal working models that shape interpersonal expectations and emotional responses.";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through Attachment Theory to reveal representations of relationship dynamics and attachment patterns through visual symbolism.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "From an Attachment Theory perspective, this audio piece expresses emotional patterns and relationship dynamics through its sonic qualities and emotional resonance.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through Attachment Theory to reveal character relationships, attachment styles, and internal working models through narrative and visual elements.";
        }
        // Return structured analysis
        return {
            attachmentStyles: attachmentStylesElements,
            relationshipPatterns: relationshipPatternsElements,
            internalWorkingModels: internalWorkingModelsElements,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Positive Psychology analysis class
class PositiveAnalysis {
    constructor() {
        // Character strengths concepts
        this.strengths = [
            "Wisdom and knowledge",
            "Courage",
            "Humanity",
            "Justice",
            "Temperance",
            "Transcendence"
        ];
        // Well-being factors concepts
        this.wellBeingFactors = [
            "Positive emotions",
            "Engagement",
            "Relationships",
            "Meaning",
            "Accomplishment"
        ];
        // Flow experiences concepts
        this.flowExperiences = [
            "Clear goals",
            "Immediate feedback",
            "Balance between challenge and skill",
            "Concentration on the task",
            "Loss of self-consciousness"
        ];
    }
    // Analyze content with Positive Psychology framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const strengthsElements = this.getRandomElements(this.strengths, 2);
        const wellBeingFactorsElements = this.getRandomElements(this.wellBeingFactors, 2);
        const flowExperiencesElements = this.getRandomElements(this.flowExperiences, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "From a Positive Psychology perspective, this text reveals character strengths and elements of well-being that contribute to flourishing and optimal human experience.";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through Positive Psychology to reveal visual representations of character strengths, positive emotions, and elements that contribute to well-being.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "From a Positive Psychology perspective, this audio piece expresses elements of flow experience and positive emotions through its sonic qualities and emotional resonance.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through Positive Psychology to reveal narrative elements of character strengths, well-being factors, and optimal human experience.";
        }
        // Return structured analysis
        return {
            strengths: strengthsElements,
            wellBeingFactors: wellBeingFactorsElements,
            flowExperiences: flowExperiencesElements,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Narrative analysis class
class NarrativeAnalysis {
    constructor() {
        // Narrative structures concepts
        this.narrativeStructures = [
            "Plot development",
            "Character arcs",
            "Temporal organization",
            "Thematic coherence",
            "Narrative voice"
        ];
        // Identity construction concepts
        this.identityConstruction = [
            "Self-narrative",
            "Autobiographical reasoning",
            "Identity integration",
            "Life story development",
            "Narrative identity"
        ];
        // Meaning making concepts
        this.meaningMaking = [
            "Causal connections",
            "Thematic coherence",
            "Redemptive sequences",
            "Meaning reconstruction",
            "Narrative transformation"
        ];
    }
    // Analyze content with Narrative framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const narrativeStructuresElements = this.getRandomElements(this.narrativeStructures, 2);
        const identityConstructionElements = this.getRandomElements(this.identityConstruction, 2);
        const meaningMakingElements = this.getRandomElements(this.meaningMaking, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "From a Narrative Psychology perspective, this text reveals processes of meaning-making and identity construction through narrative structures and thematic coherence.";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through Narrative Psychology to reveal visual elements of storytelling and meaning-making through symbolic representation.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "From a Narrative Psychology perspective, this audio piece constructs meaning through sonic narrative structures and emotional progression.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through Narrative Psychology to reveal processes of identity construction and meaning-making through visual and narrative elements.";
        }
        // Return structured analysis
        return {
            narrativeStructures: narrativeStructuresElements,
            identityConstruction: identityConstructionElements,
            meaningMaking: meaningMakingElements,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Phenomenology analysis class
class PhenomenologyAnalysis {
    constructor() {
        // Lived experience concepts
        this.livedExperience = [
            "Subjective experience",
            "First-person perspective",
            "Experiential qualities",
            "Phenomenal consciousness",
            "Qualitative aspects"
        ];
        // Intentionality concepts
        this.intentionality = [
            "Directedness toward objects",
            "Subject-object relation",
            "Meaning-making",
            "Horizons of experience",
            "Intentional structure"
        ];
        // Embodiment concepts
        this.embodiment = [
            "Lived body",
            "Bodily awareness",
            "Corporeal schema",
            "Embodied cognition",
            "Bodily intentionality"
        ];
    }
    // Analyze content with Phenomenology framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const livedExperienceElements = this.getRandomElements(this.livedExperience, 2);
        const intentionalityElements = this.getRandomElements(this.intentionality, 2);
        const embodimentElements = this.getRandomElements(this.embodiment, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "From a Phenomenological perspective, this text reveals structures of lived experience and intentionality, exploring the qualitative aspects of subjective consciousness.";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through Phenomenology to reveal visual representations of embodied experience and intentional structures of perception.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "From a Phenomenological perspective, this audio piece expresses qualities of lived auditory experience and embodied listening through its sonic elements.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through Phenomenology to reveal structures of perceptual experience, embodiment, and intentionality through visual and narrative elements.";
        }
        // Return structured analysis
        return {
            livedExperience: livedExperienceElements,
            intentionality: intentionalityElements,
            embodiment: embodimentElements,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Existential analysis class
class ExistentialAnalysis {
    constructor() {
        // Freedom concepts
        this.freedom = [
            "Radical freedom",
            "Freedom as burden",
            "Choice and responsibility",
            "Existential choice",
            "Freedom-toward-death"
        ];
        // Authenticity concepts
        this.authenticity = [
            "Authentic existence",
            "Inauthentic existence",
            "Self-creation",
            "Being-for-itself",
            "Overcoming bad faith"
        ];
        // Anxiety concepts
        this.anxiety = [
            "Existential anxiety",
            "Angst",
            "Dread",
            "Confronting nothingness",
            "Anxiety of freedom"
        ];
        // Meaning concepts
        this.meaning = [
            "Creating meaning",
            "Absurdity",
            "Existential vacuum",
            "Will to meaning",
            "Meaning in suffering"
        ];
    }
    // Analyze content with Existential framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const freedomElements = this.getRandomElements(this.freedom, 2);
        const authenticityElements = this.getRandomElements(this.authenticity, 2);
        const anxietyElements = this.getRandomElements(this.anxiety, 2);
        const meaningElements = this.getRandomElements(this.meaning, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "From an Existential perspective, this text explores themes of freedom, choice, and the search for authentic meaning in an inherently meaningless universe. It reveals the tension between existential anxiety and the human project of self-creation.";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through an Existential lens to reveal visual representations of freedom, authenticity, and the confrontation with nothingness that characterizes human existence.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "From an Existential perspective, this audio piece expresses the tension between freedom and anxiety, and the search for authentic meaning through its sonic qualities and emotional resonance.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through an Existential framework to reveal narrative elements of freedom, choice, authenticity, and the human struggle to create meaning in an absurd universe.";
        }
        // Return structured analysis
        return {
            freedom: freedomElements,
            authenticity: authenticityElements,
            anxiety: anxietyElements,
            meaning: meaningElements,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Feminist analysis class
class FeministAnalysis {
    constructor() {
        // Gender construction concepts
        this.genderConstruction = [
            "Social construction of gender",
            "Gender performativity",
            "Gender as process",
            "Gender socialization",
            "Gender as relational"
        ];
        // Patriarchal structures concepts
        this.patriarchalStructures = [
            "Systemic oppression",
            "Male privilege",
            "Institutional sexism",
            "Hegemonic masculinity",
            "Phallogocentrism"
        ];
        // Feminist perspectives concepts
        this.feministPerspectives = [
            "Liberal feminism",
            "Radical feminism",
            "Socialist feminism",
            "Postmodern feminism",
            "Ecofeminism",
            "Transfeminism"
        ];
        // Intersectionality concepts
        this.intersectionality = [
            "Interlocking oppressions",
            "Multiple identities",
            "Intersectional analysis",
            "Matrix of domination",
            "Situated knowledge"
        ];
    }
    // Analyze content with Feminist framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const genderConstructionElements = this.getRandomElements(this.genderConstruction, 2);
        const patriarchalStructuresElements = this.getRandomElements(this.patriarchalStructures, 2);
        const feministPerspectivesElements = this.getRandomElements(this.feministPerspectives, 2);
        const intersectionalityElements = this.getRandomElements(this.intersectionality, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "From a Feminist perspective, this text reveals the social construction of gender and the operation of patriarchal structures. It can be analyzed through various feminist lenses to understand how gender shapes experience and social relations.";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through a Feminist framework to reveal visual representations of gender construction, patriarchal structures, and the potential for resistance and transformation.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "From a Feminist perspective, this audio piece expresses gendered experiences and the potential for challenging patriarchal structures through its sonic qualities and emotional resonance.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through a Feminist framework to reveal narrative elements of gender construction, patriarchal structures, and the potential for feminist resistance and transformation.";
        }
        // Return structured analysis
        return {
            genderConstruction: genderConstructionElements,
            patriarchalStructures: patriarchalStructuresElements,
            feministPerspectives: feministPerspectivesElements,
            intersectionality: intersectionalityElements,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Critical Theory analysis class
class CriticalAnalysis {
    constructor() {
        // Power structures concepts
        this.powerStructures = [
            "Hegemony",
            "Domination",
            "Cultural capital",
            "Symbolic violence",
            "Disciplinary power"
        ];
        // Ideological critique concepts
        this.ideologicalCritique = [
            "False consciousness",
            "Reification",
            "Commodity fetishism",
            "Culture industry",
            "Ideological state apparatuses"
        ];
        // Emancipation concepts
        this.emancipation = [
            "Praxis",
            "Critical consciousness",
            "Communicative action",
            "Radical democracy",
            "Utopian thinking"
        ];
        // Dialectics concepts
        this.dialectics = [
            "Dialectical thinking",
            "Contradiction",
            "Negation",
            "Mediation",
            "Totality"
        ];
    }
    // Analyze content with Critical Theory framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const powerStructuresElements = this.getRandomElements(this.powerStructures, 2);
        const ideologicalCritiqueElements = this.getRandomElements(this.ideologicalCritique, 2);
        const emancipationElements = this.getRandomElements(this.emancipation, 2);
        const dialecticsElements = this.getRandomElements(this.dialectics, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "From a Critical Theory perspective, this text reveals underlying power structures and ideological formations. It can be analyzed dialectically to understand how it both reproduces and potentially challenges dominant social relations.";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through Critical Theory to reveal visual representations of power structures, ideological formations, and the potential for emancipatory consciousness.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "From a Critical Theory perspective, this audio piece expresses the tension between domination and emancipation through its sonic qualities and structural elements.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through Critical Theory to reveal narrative and visual elements of power structures, ideological formations, and the dialectical relationship between domination and emancipation.";
        }
        // Return structured analysis
        return {
            powerStructures: powerStructuresElements,
            ideologicalCritique: ideologicalCritiqueElements,
            emancipation: emancipationElements,
            dialectics: dialecticsElements,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Posthumanism analysis class
class PosthumanismAnalysis {
    constructor() {
        // Beyond humanism concepts
        this.beyondHumanism = [
            "Critique of anthropocentrism",
            "Post-anthropocentric perspective",
            "Decentering the human",
            "Beyond human exceptionalism",
            "Distributed subjectivity"
        ];
        // Technological mediations concepts
        this.technologicalMediations = [
            "Human-technology entanglement",
            "Technological embodiment",
            "Digital mediation",
            "Cybernetic systems",
            "Technological unconscious"
        ];
        // Nonhuman agency concepts
        this.nonhumanAgency = [
            "Material agency",
            "Nonhuman actants",
            "Vibrant matter",
            "Object-oriented ontology",
            "More-than-human worlds"
        ];
        // Hybridities concepts
        this.hybridities = [
            "Cyborg subjectivity",
            "Human-animal continuum",
            "Naturecultures",
            "Hybrid assemblages",
            "Boundary crossings"
        ];
    }
    // Analyze content with Posthumanism framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const beyondHumanismElements = this.getRandomElements(this.beyondHumanism, 2);
        const technologicalMediationsElements = this.getRandomElements(this.technologicalMediations, 2);
        const nonhumanAgencyElements = this.getRandomElements(this.nonhumanAgency, 2);
        const hybriditiesElements = this.getRandomElements(this.hybridities, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "From a Posthumanist perspective, this text challenges anthropocentric assumptions and explores the entanglements between human and nonhuman agencies. It reveals how subjectivity is distributed across networks of human, technological, and material actors.";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through a Posthumanist framework to reveal visual representations of human-nonhuman entanglements, technological mediations, and hybrid forms of agency and subjectivity.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "From a Posthumanist perspective, this audio piece expresses the distributed nature of agency and subjectivity across human and nonhuman actors through its sonic qualities and technological mediations.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through a Posthumanist framework to reveal narrative and visual elements that challenge anthropocentrism and explore the entanglements between human, technological, and nonhuman agencies.";
        }
        // Return structured analysis
        return {
            beyondHumanism: beyondHumanismElements,
            technologicalMediations: technologicalMediationsElements,
            nonhumanAgency: nonhumanAgencyElements,
            hybridities: hybriditiesElements,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Buddhist analysis class
class BuddhistAnalysis {
    constructor() {
        // Four Noble Truths concepts
        this.fourNobleTruths = [
            "Suffering (dukkha)",
            "Origin of suffering (samudaya)",
            "Cessation of suffering (nirodha)",
            "Path to cessation (magga)",
            "Eightfold path"
        ];
        // Impermanence concepts
        this.impermanence = [
            "Anicca (impermanence)",
            "Constant change",
            "Transience",
            "Momentariness",
            "Flux and flow"
        ];
        // Non-self concepts
        this.nonSelf = [
            "Anatta (non-self)",
            "No permanent self",
            "Interdependent arising",
            "Emptiness (sunyata)",
            "Five aggregates"
        ];
        // Mindfulness concepts
        this.mindfulness = [
            "Present-moment awareness",
            "Bare attention",
            "Non-judgmental observation",
            "Vipassana (insight)",
            "Samatha (calm abiding)"
        ];
    }
    // Analyze content with Buddhist framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const fourNobleTruthsElements = this.getRandomElements(this.fourNobleTruths, 2);
        const impermanenceElements = this.getRandomElements(this.impermanence, 2);
        const nonSelfElements = this.getRandomElements(this.nonSelf, 2);
        const mindfulnessElements = this.getRandomElements(this.mindfulness, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "From a Buddhist perspective, this text reveals the nature of impermanence (anicca) and the absence of a permanent self (anatta). It can be understood in terms of the Four Noble Truths, which address the nature of suffering and the path to its cessation.";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through a Buddhist framework to reveal visual representations of impermanence, interdependent arising, and the potential for mindful awareness of present experience.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "From a Buddhist perspective, this audio piece expresses the nature of impermanence and the potential for mindful awareness through its sonic qualities and temporal unfolding.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through a Buddhist framework to reveal narrative and visual elements of impermanence, non-self, and the potential for awakening to the true nature of reality.";
        }
        // Return structured analysis
        return {
            fourNobleTruths: fourNobleTruthsElements,
            impermanence: impermanenceElements,
            nonSelf: nonSelfElements,
            mindfulness: mindfulnessElements,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Nietzschean analysis class
class NietzscheanAnalysis {
    constructor() {
        // Will to Power concepts
        this.willToPower = [
            "Creative force",
            "Self-overcoming",
            "Life-affirmation",
            "Growth and expansion",
            "Power as interpretation"
        ];
        // Eternal Recurrence concepts
        this.eternalRecurrence = [
            "Affirmation of life",
            "Amor fati (love of fate)",
            "Eternal return",
            "Existential weight",
            "Highest affirmation"
        ];
        // Perspectivism concepts
        this.perspectivism = [
            "No absolute truth",
            "Multiple interpretations",
            "Knowledge as perspective",
            "Beyond objectivity",
            "Interpretive pluralism"
        ];
        // Beyond Good and Evil concepts
        this.beyondGoodEvil = [
            "Critique of morality",
            "Master vs. slave morality",
            "Transvaluation of values",
            "Genealogy of morals",
            "Beyond conventional morality"
        ];
    }
    // Analyze content with Nietzschean framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const willToPowerElements = this.getRandomElements(this.willToPower, 2);
        const eternalRecurrenceElements = this.getRandomElements(this.eternalRecurrence, 2);
        const perspectivismElements = this.getRandomElements(this.perspectivism, 2);
        const beyondGoodEvilElements = this.getRandomElements(this.beyondGoodEvil, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "From a Nietzschean perspective, this text expresses the will to power as a creative force of self-overcoming. It reveals a perspectival understanding of truth that goes beyond conventional moral categories of good and evil.";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through a Nietzschean framework to reveal visual expressions of the will to power, perspectivism, and the potential for going beyond conventional moral interpretations.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "From a Nietzschean perspective, this audio piece expresses the will to power as a creative force and the affirmation of life through its sonic qualities and emotional resonance.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through a Nietzschean framework to reveal narrative and visual elements of the will to power, eternal recurrence, and the transvaluation of conventional moral values.";
        }
        // Return structured analysis
        return {
            willToPower: willToPowerElements,
            eternalRecurrence: eternalRecurrenceElements,
            perspectivism: perspectivismElements,
            beyondGoodEvil: beyondGoodEvilElements,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Gestalt analysis class
class GestaltAnalysis {
    constructor() {
        // Wholeness principles concepts
        this.wholenessPrinciples = [
            "The whole is greater than the sum of parts",
            "Figure-ground relationship",
            "Prägnanz (good form)",
            "Closure and completion",
            "Holistic perception"
        ];
        // Contact boundary concepts
        this.contactBoundary = [
            "Contact and withdrawal",
            "Boundary disturbances",
            "Confluence and isolation",
            "Introjection and projection",
            "Retroflection and deflection"
        ];
        // Awareness process concepts
        this.awarenessProcess = [
            "Here-and-now awareness",
            "Phenomenological method",
            "Organismic self-regulation",
            "Paradoxical theory of change",
            "Creative adjustment"
        ];
        // Polarities concepts
        this.polarities = [
            "Top dog/underdog",
            "Integration of opposites",
            "Dialectical thinking",
            "Polarization and synthesis",
            "Complementary aspects"
        ];
    }
    // Analyze content with Gestalt framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const wholenessPrinciplesElements = this.getRandomElements(this.wholenessPrinciples, 2);
        const contactBoundaryElements = this.getRandomElements(this.contactBoundary, 2);
        const awarenessProcessElements = this.getRandomElements(this.awarenessProcess, 2);
        const polaritiesElements = this.getRandomElements(this.polarities, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "From a Gestalt perspective, this text reveals the principles of wholeness and figure-ground relationships. It can be understood in terms of contact boundaries, awareness processes, and the integration of polarities.";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through a Gestalt framework to reveal visual principles of wholeness, figure-ground relationships, and the integration of polarities.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "From a Gestalt perspective, this audio piece expresses principles of wholeness and figure-ground relationships through its sonic qualities and temporal unfolding.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through a Gestalt framework to reveal narrative and visual elements of wholeness, contact boundaries, awareness processes, and the integration of polarities.";
        }
        // Return structured analysis
        return {
            wholenessPrinciples: wholenessPrinciplesElements,
            contactBoundary: contactBoundaryElements,
            awarenessProcess: awarenessProcessElements,
            polarities: polaritiesElements,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Transpersonal analysis class
class TranspersonalAnalysis {
    constructor() {
        // Beyond ego concepts
        this.beyondEgo = [
            "Transcendence of ego",
            "Transpersonal self",
            "Expanded identity",
            "Ego transcendence",
            "Beyond personal boundaries"
        ];
        // Spiritual experiences concepts
        this.spiritualExperiences = [
            "Peak experiences",
            "Mystical states",
            "Cosmic consciousness",
            "Unitive experiences",
            "Transcendent awareness"
        ];
        // Consciousness states concepts
        this.consciousnessStates = [
            "Non-ordinary states",
            "Holotropic states",
            "Expanded consciousness",
            "Altered states",
            "Higher consciousness"
        ];
        // Transformation concepts
        this.transformation = [
            "Spiritual emergence",
            "Psychospiritual development",
            "Transformative process",
            "Evolutionary consciousness",
            "Integral transformation"
        ];
    }
    // Analyze content with Transpersonal framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const beyondEgoElements = this.getRandomElements(this.beyondEgo, 2);
        const spiritualExperiencesElements = this.getRandomElements(this.spiritualExperiences, 2);
        const consciousnessStatesElements = this.getRandomElements(this.consciousnessStates, 2);
        const transformationElements = this.getRandomElements(this.transformation, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "From a Transpersonal perspective, this text explores dimensions of experience that transcend the boundaries of the ego. It reveals potential states of consciousness that connect the individual to spiritual, cosmic, or universal dimensions of existence.";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through a Transpersonal framework to reveal visual representations of experiences that transcend ordinary ego boundaries and connect to spiritual or cosmic dimensions.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "From a Transpersonal perspective, this audio piece expresses states of consciousness that transcend ordinary ego boundaries through its sonic qualities and emotional resonance.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through a Transpersonal framework to reveal narrative and visual elements of experiences that transcend ordinary ego boundaries and connect to spiritual or cosmic dimensions.";
        }
        // Return structured analysis
        return {
            beyondEgo: beyondEgoElements,
            spiritualExperiences: spiritualExperiencesElements,
            consciousnessStates: consciousnessStatesElements,
            transformation: transformationElements,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Cognitive-Behavioral Therapy analysis class
class CbtAnalysis {
    constructor() {
        // Cognitive distortions concepts
        this.cognitiveDistortions = [
            "All-or-nothing thinking",
            "Overgeneralization",
            "Mental filtering",
            "Catastrophizing",
            "Emotional reasoning",
            "Should statements",
            "Personalization"
        ];
        // Behavioral patterns concepts
        this.behavioralPatterns = [
            "Avoidance behaviors",
            "Safety behaviors",
            "Reinforcement patterns",
            "Behavioral activation",
            "Stimulus-response patterns"
        ];
        // Core beliefs concepts
        this.coreBeliefs = [
            "Schemas about self",
            "Schemas about others",
            "Schemas about the world",
            "Intermediate beliefs",
            "Automatic thoughts"
        ];
        // Adaptive strategies concepts
        this.adaptiveStrategies = [
            "Cognitive restructuring",
            "Behavioral experiments",
            "Exposure techniques",
            "Problem-solving skills",
            "Mindfulness integration"
        ];
    }
    // Analyze content with CBT framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const cognitiveDistortionsElements = this.getRandomElements(this.cognitiveDistortions, 2);
        const behavioralPatternsElements = this.getRandomElements(this.behavioralPatterns, 2);
        const coreBeliefsElements = this.getRandomElements(this.coreBeliefs, 2);
        const adaptiveStrategiesElements = this.getRandomElements(this.adaptiveStrategies, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "From a Cognitive-Behavioral perspective, this text reveals patterns of thinking that may include cognitive distortions and underlying core beliefs. It can be analyzed in terms of the relationship between thoughts, emotions, and behaviors.";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through a Cognitive-Behavioral framework to reveal visual representations of cognitive patterns, emotional responses, and behavioral tendencies.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "From a Cognitive-Behavioral perspective, this audio piece expresses patterns of thinking, emotional responses, and behavioral tendencies through its sonic qualities and emotional resonance.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through a Cognitive-Behavioral framework to reveal narrative and visual elements of cognitive patterns, emotional responses, and behavioral tendencies.";
        }
        // Return structured analysis
        return {
            cognitiveDistortions: cognitiveDistortionsElements,
            behavioralPatterns: behavioralPatternsElements,
            coreBeliefs: coreBeliefsElements,
            adaptiveStrategies: adaptiveStrategiesElements,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Hermeneutics analysis class
class HermeneuticsAnalysis {
    constructor() {
        // Interpretive circle concepts
        this.interpretiveCircle = [
            "Part-whole relationship",
            "Hermeneutic circle",
            "Circular understanding",
            "Interpretive process",
            "Dialectical movement"
        ];
        // Historical context concepts
        this.historicalContext = [
            "Historical situatedness",
            "Effective history",
            "Tradition and prejudice",
            "Historical consciousness",
            "Temporal distance"
        ];
        // Linguistic meaning concepts
        this.linguisticMeaning = [
            "Language as medium",
            "Textual interpretation",
            "Semantic depth",
            "Polysemy",
            "Linguistic world-disclosure"
        ];
        // Horizon fusion concepts
        this.horizonFusion = [
            "Fusion of horizons",
            "Dialogical understanding",
            "Interpretive openness",
            "Application",
            "Productive understanding"
        ];
    }
    // Analyze content with Hermeneutics framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const interpretiveCircleElements = this.getRandomElements(this.interpretiveCircle, 2);
        const historicalContextElements = this.getRandomElements(this.historicalContext, 2);
        const linguisticMeaningElements = this.getRandomElements(this.linguisticMeaning, 2);
        const horizonFusionElements = this.getRandomElements(this.horizonFusion, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "From a Hermeneutic perspective, this text reveals layers of meaning that emerge through the interpretive circle of part and whole. It can be understood in terms of its historical context, linguistic dimensions, and the fusion of horizons between text and interpreter.";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through a Hermeneutic framework to reveal visual meanings that emerge through the interpretive circle of part and whole, historical context, and the fusion of horizons between image and viewer.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "From a Hermeneutic perspective, this audio piece expresses meanings that emerge through the interpretive circle of part and whole, historical context, and the fusion of horizons between sound and listener.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through a Hermeneutic framework to reveal narrative and visual meanings that emerge through the interpretive circle of part and whole, historical context, and the fusion of horizons between film and viewer.";
        }
        // Return structured analysis
        return {
            interpretiveCircle: interpretiveCircleElements,
            historicalContext: historicalContextElements,
            linguisticMeaning: linguisticMeaningElements,
            horizonFusion: horizonFusionElements,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Stoicism analysis class
class StoicismAnalysis {
    constructor() {
        // Virtue ethics concepts
        this.virtueEthics = [
            "Cardinal virtues",
            "Wisdom (sophia)",
            "Courage (andreia)",
            "Justice (dikaiosyne)",
            "Temperance (sophrosyne)"
        ];
        // Dichotomy of control concepts
        this.dichotomyOfControl = [
            "What is up to us",
            "What is not up to us",
            "Focusing on what we can control",
            "Accepting what we cannot control",
            "Appropriate action"
        ];
        // Rational nature concepts
        this.rationalNature = [
            "Living according to nature",
            "Rational faculty",
            "Logos",
            "Assent to impressions",
            "Cognitive distancing"
        ];
        // Cosmic perspective concepts
        this.cosmicPerspective = [
            "View from above",
            "Amor fati",
            "Memento mori",
            "Cosmopolitanism",
            "Universal nature"
        ];
    }
    // Analyze content with Stoicism framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const virtueEthicsElements = this.getRandomElements(this.virtueEthics, 2);
        const dichotomyOfControlElements = this.getRandomElements(this.dichotomyOfControl, 2);
        const rationalNatureElements = this.getRandomElements(this.rationalNature, 2);
        const cosmicPerspectiveElements = this.getRandomElements(this.cosmicPerspective, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "From a Stoic perspective, this text reveals themes related to virtue, the dichotomy of control, and living according to rational nature. It can be understood in terms of the Stoic emphasis on focusing on what is within our control and maintaining a cosmic perspective.";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through a Stoic framework to reveal visual representations of virtue, the dichotomy of control, and the cosmic perspective that characterizes Stoic philosophy.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "From a Stoic perspective, this audio piece expresses themes related to virtue, the dichotomy of control, and living according to rational nature through its sonic qualities and emotional resonance.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through a Stoic framework to reveal narrative and visual elements of virtue, the dichotomy of control, and the cosmic perspective that characterizes Stoic philosophy.";
        }
        // Return structured analysis
        return {
            virtueEthics: virtueEthicsElements,
            dichotomyOfControl: dichotomyOfControlElements,
            rationalNature: rationalNatureElements,
            cosmicPerspective: cosmicPerspectiveElements,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Psychiatry analysis class
class PsychiatryAnalysis {
    constructor() {
        // Diagnostic categories concepts
        this.diagnosticCategories = [
            "Mood disorders",
            "Anxiety disorders",
            "Psychotic disorders",
            "Personality disorders",
            "Neurodevelopmental disorders",
            "Trauma-related disorders"
        ];
        // Neurobiological factors concepts
        this.neurobiologicalFactors = [
            "Neurotransmitter systems",
            "Brain structure and function",
            "Genetic factors",
            "Neuroplasticity",
            "Neuroendocrine processes"
        ];
        // Psychosocial factors concepts
        this.psychosocialFactors = [
            "Environmental stressors",
            "Social determinants",
            "Developmental factors",
            "Interpersonal relationships",
            "Cultural factors"
        ];
        // Treatment approaches concepts
        this.treatmentApproaches = [
            "Psychopharmacology",
            "Psychotherapy",
            "Integrated treatment",
            "Biopsychosocial approach",
            "Recovery model"
        ];
    }
    // Analyze content with Psychiatry framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const diagnosticCategoriesElements = this.getRandomElements(this.diagnosticCategories, 2);
        const neurobiologicalFactorsElements = this.getRandomElements(this.neurobiologicalFactors, 2);
        const psychosocialFactorsElements = this.getRandomElements(this.psychosocialFactors, 2);
        const treatmentApproachesElements = this.getRandomElements(this.treatmentApproaches, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "From a Psychiatric perspective, this text reveals themes that can be understood in terms of diagnostic categories, neurobiological factors, and psychosocial determinants. It can be analyzed using the biopsychosocial model that integrates multiple levels of explanation.";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through a Psychiatric framework to reveal visual representations of psychological states, neurobiological processes, and psychosocial factors that contribute to mental health and illness.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "From a Psychiatric perspective, this audio piece expresses themes related to psychological states, neurobiological processes, and psychosocial factors through its sonic qualities and emotional resonance.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through a Psychiatric framework to reveal narrative and visual elements of psychological states, neurobiological processes, and psychosocial factors that contribute to mental health and illness.";
        }
        // Return structured analysis
        return {
            diagnosticCategories: diagnosticCategoriesElements,
            neurobiologicalFactors: neurobiologicalFactorsElements,
            psychosocialFactors: psychosocialFactorsElements,
            treatmentApproaches: treatmentApproachesElements,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Epicurean analysis class
class EpicureanAnalysis {
    constructor() {
        // Pleasure concepts
        this.pleasure = [
            "Absence of pain (aponia)",
            "Tranquility (ataraxia)",
            "Static pleasures",
            "Kinetic pleasures",
            "Pleasure as the highest good"
        ];
        // Ataraxia concepts
        this.ataraxia = [
            "Freedom from disturbance",
            "Mental tranquility",
            "Peace of mind",
            "Absence of fear",
            "Equanimity"
        ];
        // Natural desires concepts
        this.naturalDesires = [
            "Natural and necessary desires",
            "Natural but unnecessary desires",
            "Vain and empty desires",
            "Limiting desires",
            "Simple living"
        ];
        // Friendship concepts
        this.friendship = [
            "Friendship as essential good",
            "Community of like-minded individuals",
            "Philosophical friendship",
            "Security through social bonds",
            "Shared pleasure in company"
        ];
    }
    // Analyze content with Epicurean framework
    analyzeContent(content, mediaType) {
        // Get random elements from each concept array
        const pleasureElements = this.getRandomElements(this.pleasure, 2);
        const ataraxiaElements = this.getRandomElements(this.ataraxia, 2);
        const naturalDesiresElements = this.getRandomElements(this.naturalDesires, 2);
        const friendshipElements = this.getRandomElements(this.friendship, 2);
        // Generate summary based on media type
        let summary = "";
        if (mediaType === MEDIA_TYPES.TEXT) {
            summary = "From an Epicurean perspective, this text explores themes related to the pursuit of pleasure understood as freedom from pain and mental disturbance. It reveals insights about natural desires, the value of friendship, and the path to tranquility (ataraxia).";
        }
        else if (mediaType === MEDIA_TYPES.IMAGE) {
            summary = "This image can be analyzed through an Epicurean lens to reveal visual representations of pleasure, tranquility, natural desires, and the importance of friendship and community.";
        }
        else if (mediaType === MEDIA_TYPES.AUDIO) {
            summary = "From an Epicurean perspective, this audio piece expresses themes related to pleasure, tranquility, and the satisfaction of natural desires through its sonic qualities and emotional resonance.";
        }
        else if (mediaType === MEDIA_TYPES.FILM) {
            summary = "This film can be analyzed through an Epicurean framework to reveal narrative elements of pleasure, tranquility, natural desires, and the importance of friendship and community.";
        }
        // Return structured analysis
        return {
            pleasure: pleasureElements,
            ataraxia: ataraxiaElements,
            naturalDesires: naturalDesiresElements,
            friendship: friendshipElements,
            summary
        };
    }
    // Helper method to get random elements from an array
    getRandomElements(array, count) {
        const result = [];
        const arrayCopy = [...array];
        for (let i = 0; i < count && arrayCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * arrayCopy.length);
            result.push(arrayCopy[randomIndex]);
            arrayCopy.splice(randomIndex, 1);
        }
        return result;
    }
}

// Framework factory to get the appropriate analysis class
function getFrameworkAnalysis(frameworkId) {
    switch (frameworkId) {
        case 'deleuzian':
            return new DeleuzianAnalysis();
        case 'irigarayian':
            return new IrigarayianAnalysis();
        case 'tacktical':
            return new TackticalAnalysis();
        case 'freudian':
            return new FreudianAnalysis();
        case 'lacanian':
            return new LacanianAnalysis();
        case 'jungian':
            return new JungianAnalysis();
        case 'attachment':
            return new AttachmentAnalysis();
        case 'positive':
            return new PositiveAnalysis();
        case 'narrative':
            return new NarrativeAnalysis();
        case 'phenomenology':
            return new PhenomenologyAnalysis();
        case 'existential':
            return new ExistentialAnalysis();
        case 'feminist':
            return new FeministAnalysis();
        case 'critical':
            return new CriticalAnalysis();
        case 'posthumanism':
            return new PosthumanismAnalysis();
        case 'buddhist':
            return new BuddhistAnalysis();
        case 'nietzschean':
            return new NietzscheanAnalysis();
        case 'gestalt':
            return new GestaltAnalysis();
        case 'transpersonal':
            return new TranspersonalAnalysis();
        case 'cbt':
            return new CbtAnalysis();
        case 'hermeneutics':
            return new HermeneuticsAnalysis();
        case 'stoicism':
            return new StoicismAnalysis();
        case 'psychiatry':
            return new PsychiatryAnalysis();
        case 'epicurean':
            return new EpicureanAnalysis();
        default:
            throw new Error(`Framework not implemented: ${frameworkId}`);
    }
}

const deleuzianAnalyses = {
    [MEDIA_TYPES.TEXT]: "From a Deleuzian perspective, this text operates as an assemblage of heterogeneous elements, creating rhizomatic connections rather than hierarchical structures. The content reveals lines of flight that deterritorialize fixed meanings and identities, opening up new possibilities for becoming. The writing demonstrates the productive nature of desire as a force of creation rather than lack. Multiple voices and perspectives suggest a nomadic subjectivity that resists fixed identity positions. The text functions as a body without organs, a surface of intensities rather than organized meaning. Recurring motifs operate as refrains that temporarily organize territories of meaning before dissolving into new configurations.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed as a Deleuzian assemblage of visual elements that create rhizomatic connections rather than hierarchical structures. Visual components function as intensities on a plane of consistency, creating affects that operate below the level of representation. The composition suggests lines of flight that deterritorialize fixed meanings and open up new possibilities for becoming. Color relationships and spatial arrangements can be understood as expressions of desire as a productive force rather than lack. The image potentially functions as a body without organs, a surface of intensities rather than organized meaning. The viewer's encounter with the image creates a becoming-other that transforms both viewer and image.",
    [MEDIA_TYPES.AUDIO]: "From a Deleuzian perspective, this audio piece functions as an assemblage of sonic elements that create rhizomatic connections rather than hierarchical structures. Sound operates as intensities on a plane of consistency, creating affects that work below the level of representation. Rhythmic and tonal patterns suggest lines of flight that deterritorialize fixed meanings and open up new possibilities for becoming. The structure of the piece demonstrates the productive nature of desire as a force of creation rather than lack. Recurring motifs operate as refrains that temporarily organize territories of meaning before dissolving into new configurations. The listener's encounter with the sound creates a becoming-other that transforms both listener and sound.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed as a Deleuzian assemblage of visual, narrative, and sonic elements that create rhizomatic connections rather than hierarchical structures. The film operates through movement-images and time-images that directly present duration rather than representing it. Visual components function as intensities on a plane of consistency, creating affects that operate below the level of representation. The narrative suggests lines of flight that deterritorialize fixed meanings and identities, opening up new possibilities for becoming. Character relationships demonstrate nomadic subjectivity that resists fixed identity positions. Editing techniques and visual transitions can be understood as expressions of desire as a productive force rather than lack."
};

const irigarayianAnalyses = {
    [MEDIA_TYPES.TEXT]: "An Irigarayian reading of this text reveals how it engages with or challenges phallogocentric discourse. The writing potentially demonstrates a feminine syntax that privileges multiplicity, fluidity, and proximity over linear logic and fixed meanings. There are moments where the text approaches feminine jouissance—a pleasure beyond the phallic economy of desire. The content explores sexual difference not as binary opposition but as radical alterity. The writing style may reflect the morphology of the female body through its rhythms, gaps, and fluid connections. The text potentially creates a space for feminine subjectivity that has been excluded from dominant philosophical and cultural discourses.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through an Irigarayian framework to reveal how it engages with or challenges phallogocentric visual language. Visual elements potentially demonstrate a feminine morphology that privileges multiplicity, fluidity, and proximity over linear perspective and fixed meanings. Compositional elements may reflect the specificity of female embodiment through formal qualities such as multiplicity, fluidity, and tactility. The image potentially creates a space for feminine jouissance—a pleasure beyond the phallic economy of desire. The relationship between figure and ground may challenge the subject-object division central to masculine visual economy. The viewer's relationship to the image potentially allows for an encounter with sexual difference as radical alterity.",
    [MEDIA_TYPES.AUDIO]: "An Irigarayian analysis of this audio piece reveals how it engages with or challenges phallogocentric sonic language. Sound elements potentially demonstrate a feminine morphology that privileges multiplicity, fluidity, and proximity over linear progression and fixed meanings. Rhythmic and tonal patterns may reflect the specificity of female embodiment through formal qualities such as multiplicity, fluidity, and tactility. The piece potentially creates a space for feminine jouissance—a pleasure beyond the phallic economy of desire. The relationship between figure and ground in the sonic landscape may challenge the subject-object division central to masculine economy. The listener's relationship to the sound potentially allows for an encounter with sexual difference as radical alterity.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through an Irigarayian framework to reveal how it engages with or challenges phallogocentric visual and narrative language. Visual and narrative elements potentially demonstrate a feminine morphology that privileges multiplicity, fluidity, and proximity over linear perspective and fixed meanings. Character relationships may explore sexual difference not as binary opposition but as radical alterity. The film potentially creates a space for feminine jouissance—a pleasure beyond the phallic economy of desire. Editing techniques and visual transitions may reflect the specificity of female embodiment through formal qualities such as multiplicity, fluidity, and tactility. The viewer's relationship to the film potentially allows for an encounter with feminine subjectivity that has been excluded from dominant cinematic discourses."
};

const freudianAnalyses = {
    [MEDIA_TYPES.TEXT]: "From a Freudian perspective, this content reveals underlying psychological dynamics and unconscious processes. There are suggestions of repressed desires finding expression through symbolic representation and displacement. The formal elements of the work can be interpreted as manifestations of primary process thinking, where logical constraints are loosened in favor of associative connections. Recurring motifs suggest the return of the repressed, with unresolved psychic material seeking acknowledgment. The tension between structure and expression mirrors the ego's mediation between the demands of the id and superego. The work engages with universal psychological conflicts related to desire, prohibition, and sublimation.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Freudian lens to reveal unconscious symbolic content. Visual elements may represent displaced desires, condensed meanings, or symbolic fulfillment of unconscious wishes. The composition suggests tensions between conscious intention and unconscious expression. Color choices and spatial relationships may indicate psychosexual themes or conflicts. The image potentially functions as a dream-like expression where primary process thinking is evident. The viewer's response to the image may involve projection of their own unconscious material.",
    [MEDIA_TYPES.AUDIO]: "From a Freudian perspective, this audio piece reveals underlying psychological dynamics through its sonic elements. Rhythmic patterns may represent the tension between id impulses and superego constraints. Tonal qualities can be interpreted as expressions of libidinal energy or repressed emotional content. The structure of the piece mirrors psychological defense mechanisms such as sublimation or displacement. Recurring motifs suggest the return of repressed material seeking acknowledgment. The emotional response evoked in the listener may indicate transference or projection of unconscious material. The piece engages with universal psychological conflicts through its auditory symbolism.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through a Freudian lens to reveal unconscious symbolic content and psychological dynamics. Visual imagery and narrative elements may represent displaced desires or condensed meanings. Character relationships often mirror psychosexual developmental stages or conflicts. The film's structure suggests tensions between conscious intention and unconscious expression. Recurring visual motifs may indicate the return of repressed material seeking acknowledgment. Editing techniques and visual transitions can be interpreted as analogous to dream-work mechanisms. The viewer's emotional response may involve projection of their own unconscious material."
};

const lacanianAnalyses = {
    [MEDIA_TYPES.TEXT]: "A Lacanian reading of this text reveals the interplay between the Symbolic, Imaginary, and Real orders. The language demonstrates how the subject positions themselves within the symbolic order while grappling with the Real. There are moments where the text approaches the Real—that which resists symbolization—before retreating into symbolic structures. The writing reveals the fundamental split in subjectivity and the impossibility of wholeness that drives desire. Signifiers in the text form chains of meaning that point to an absent center, illustrating Lacan's concept that desire always operates through metonymic displacement. The text demonstrates how language both constructs and alienates the subject, creating a gap between the subject of the statement and the subject of enunciation.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Lacanian framework to reveal the interplay between the Symbolic, Imaginary, and Real orders. Visual elements function as signifiers in a chain of meaning that points to an absent center. The image potentially operates as a screen upon which fantasies are projected, revealing the structure of desire as lack. Compositional elements may demonstrate the gaze as object a—the unattainable object-cause of desire. The image potentially disrupts the Imaginary order by introducing elements of the Real that resist symbolization. The viewer's relationship to the image reveals the fundamental split in subjectivity. The visual language creates a gap between what is represented and what remains unrepresentable.",
    [MEDIA_TYPES.AUDIO]: "A Lacanian analysis of this audio piece reveals the interplay between the Symbolic, Imaginary, and Real orders through sonic elements. Sound functions as a signifier in chains of meaning that point to an absent center. Rhythmic and tonal patterns demonstrate the structure of desire as lack, always moving metonymically from one signifier to another. Moments of dissonance or silence may represent irruptions of the Real—that which resists symbolization. The listener's experience reveals the fundamental split in subjectivity when engaging with the piece. The audio creates a gap between what is heard and what remains beyond representation. The piece potentially functions as object a—the unattainable object-cause of desire—in its ability to evoke but never satisfy.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through a Lacanian framework to reveal the interplay between the Symbolic, Imaginary, and Real orders. Visual and narrative elements function as signifiers in chains of meaning that point to an absent center. The film potentially operates as a screen upon which fantasies are projected, revealing the structure of desire as lack. Character relationships demonstrate the mirror stage and the formation of the ego through identification. The gaze operates as object a—the unattainable object-cause of desire—in the visual language of the film. Moments of narrative disruption may represent irruptions of the Real that resist symbolization. The viewer's relationship to the film reveals the fundamental split in subjectivity."
};

const epicureanAnalyses = {
    [MEDIA_TYPES.TEXT]: "From an Epicurean perspective, this text explores themes related to the pursuit of pleasure understood as freedom from pain and mental disturbance (ataraxia). The content reveals insights about natural desires, the value of friendship, and the path to tranquility. The writing potentially demonstrates how understanding natural phenomena can free us from unnecessary fears and anxieties. There are suggestions of how simple living and limiting desires can lead to greater contentment. The text may explore how philosophical understanding contributes to a life of tranquility and modest pleasure.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through an Epicurean lens to reveal visual representations of pleasure, tranquility, natural desires, and the importance of friendship and community. Visual elements may suggest the value of simple pleasures and freedom from disturbance. The composition potentially reflects the Epicurean ideal of ataraxia—a state of mental tranquility free from fear and anxiety. Color relationships and spatial arrangements might express the distinction between necessary and unnecessary desires. The image potentially invites contemplation of natural phenomena as a way to dispel superstition and unnecessary fears.",
    [MEDIA_TYPES.AUDIO]: "From an Epicurean perspective, this audio piece expresses themes related to pleasure, tranquility, and the satisfaction of natural desires through its sonic qualities and emotional resonance. Sound elements may suggest the value of simple pleasures and freedom from disturbance. The structure of the piece potentially reflects the Epicurean ideal of ataraxia—a state of mental tranquility free from fear and anxiety. Rhythmic and tonal patterns might express the distinction between necessary and unnecessary desires. The piece potentially invites contemplation of natural phenomena as a way to dispel superstition and unnecessary fears.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through an Epicurean framework to reveal narrative and visual elements of pleasure, tranquility, natural desires, and the importance of friendship and community. Character relationships may explore the Epicurean understanding of friendship as an essential good. The narrative potentially demonstrates how understanding natural phenomena can free us from unnecessary fears and anxieties. Visual elements may suggest the value of simple pleasures and freedom from disturbance. The film's structure might reflect the Epicurean ideal of ataraxia—a state of mental tranquility free from fear and anxiety. The viewer is potentially invited to consider how limiting desires to what is natural and necessary can lead to greater contentment."
};

const attachmentAnalyses = {
    [MEDIA_TYPES.TEXT]: "From an Attachment Theory perspective, this text reveals patterns of relational dynamics and attachment styles. The content explores themes of connection, separation, security, and autonomy that reflect fundamental attachment needs. Narrative elements may demonstrate secure, anxious, avoidant, or disorganized attachment patterns in how relationships are portrayed. The emotional tone suggests underlying internal working models that shape expectations about self and others. The text potentially reveals how early attachment experiences continue to influence adult relationships through transference and projection. The writing style itself may reflect attachment patterns in its approach to engaging or distancing the reader.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through an Attachment Theory framework to reveal visual representations of relational dynamics and attachment styles. Compositional elements may suggest themes of connection, separation, security, and autonomy that reflect fundamental attachment needs. The spatial relationships between figures or objects potentially demonstrate secure, anxious, avoidant, or disorganized attachment patterns. Visual cues of emotional expression and proximity suggest underlying internal working models that shape expectations about self and others. The image potentially evokes attachment responses in the viewer that reflect their own relational patterns.",
    [MEDIA_TYPES.AUDIO]: "From an Attachment Theory perspective, this audio piece expresses relational dynamics and attachment patterns through its sonic qualities. Sound elements may suggest themes of connection, separation, security, and autonomy that reflect fundamental attachment needs. Rhythmic and tonal patterns potentially demonstrate secure, anxious, avoidant, or disorganized attachment styles in how sonic elements relate to each other. The emotional resonance suggests underlying internal working models that shape expectations about relationships. The piece potentially evokes attachment responses in the listener that reflect their own relational patterns. The structure of the audio may mirror attachment dynamics through patterns of approach and withdrawal.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through an Attachment Theory framework to reveal narrative and visual elements of relational dynamics and attachment styles. Character relationships demonstrate secure, anxious, avoidant, or disorganized attachment patterns in how connections, separations, and reunions are portrayed. The narrative potentially explores how early attachment experiences continue to influence adult relationships through transference and projection. Visual cues of emotional expression and proximity suggest underlying internal working models that shape expectations about self and others. The film's structure may mirror attachment dynamics through patterns of approach and withdrawal. The viewer's emotional response potentially reflects their own attachment patterns."
};

const buddhistAnalyses = {
    [MEDIA_TYPES.TEXT]: "From a Buddhist perspective, this text reveals the nature of impermanence (anicca) and the absence of a permanent self (anatta). The content can be understood in terms of the Four Noble Truths, which address the nature of suffering (dukkha) and the path to its cessation. Narrative elements potentially demonstrate how attachment to fixed views and desires leads to suffering, while mindful awareness offers a path to liberation. The text may reveal interdependent arising (pratityasamutpada) in how phenomena emerge from complex conditions rather than existing independently. The writing potentially invites the reader into a state of present-moment awareness that transcends conceptual thinking.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Buddhist framework to reveal visual representations of impermanence (anicca), non-self (anatta), and the nature of suffering (dukkha). Compositional elements may suggest the interdependent arising (pratityasamutpada) of phenomena through visual relationships. The image potentially invites contemplation of emptiness (sunyata) through its play of form and space. Visual qualities may evoke states of mindful awareness or meditative absorption. The relationship between figure and ground potentially demonstrates the Middle Way between extremes of existence and non-existence. The viewer's experience of the image offers an opportunity for direct insight into the nature of perception and reality.",
    [MEDIA_TYPES.AUDIO]: "From a Buddhist perspective, this audio piece expresses the nature of impermanence (anicca) through its temporal unfolding. Sound elements demonstrate the interdependent arising (pratityasamutpada) of phenomena as sonic elements emerge from and dissolve into each other. The piece potentially invites the listener into a state of mindful awareness through its engagement with present-moment experience. Rhythmic and tonal patterns may reflect the Middle Way between extremes of existence and non-existence. The experience of listening offers an opportunity to observe how sounds arise and pass away without attachment, reflecting the Buddhist understanding of non-self (anatta) and the nature of suffering (dukkha).",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through a Buddhist framework to reveal narrative and visual elements of impermanence (anicca), non-self (anatta), and the nature of suffering (dukkha). Character arcs potentially demonstrate how attachment to fixed views and desires leads to suffering, while mindful awareness offers a path to liberation. Visual elements may suggest the interdependent arising (pratityasamutpada) of phenomena through compositional relationships. The film's temporal structure reflects the Buddhist understanding of impermanence as all things arise and pass away. The relationship between narrative and visual elements potentially demonstrates the Middle Way between extremes. The viewer's experience offers an opportunity for direct insight into the nature of perception and reality."
};

const cbtAnalyses = {
    [MEDIA_TYPES.TEXT]: "From a Cognitive-Behavioral perspective, this text reveals patterns of thinking that may include cognitive distortions such as all-or-nothing thinking, overgeneralization, or emotional reasoning. The content demonstrates the relationship between thoughts, emotions, and behaviors, showing how cognitive patterns influence emotional responses and behavioral choices. Narrative elements potentially reveal core beliefs and schemas about self, others, and the world that shape interpretation of events. The text may demonstrate adaptive or maladaptive coping strategies in response to challenging situations. The writing potentially offers opportunities for cognitive restructuring by presenting alternative perspectives or challenging irrational beliefs.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Cognitive-Behavioral framework to reveal visual representations of cognitive patterns, emotional responses, and behavioral tendencies. Compositional elements may suggest cognitive distortions such as mental filtering, catastrophizing, or personalization through selective focus or exaggerated elements. Visual cues potentially evoke emotional responses that demonstrate the connection between perception, interpretation, and feeling. The image may represent core beliefs and schemas about self, others, and the world through symbolic content. The viewer's response to the image offers an opportunity to observe automatic thoughts and practice cognitive restructuring.",
    [MEDIA_TYPES.AUDIO]: "From a Cognitive-Behavioral perspective, this audio piece expresses patterns of thinking, emotional responses, and behavioral tendencies through its sonic qualities. Sound elements may suggest cognitive patterns such as rumination, worry, or adaptive problem-solving through repetitive or resolving structures. Rhythmic and tonal patterns potentially evoke emotional responses that demonstrate the connection between perception, interpretation, and feeling. The structure of the piece may represent adaptive or maladaptive coping strategies through tension and resolution. The listener's response to the audio offers an opportunity to observe automatic thoughts and practice cognitive restructuring.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through a Cognitive-Behavioral framework to reveal narrative and visual elements of cognitive patterns, emotional responses, and behavioral tendencies. Character arcs potentially demonstrate how thoughts influence emotions and behaviors, showing the consequences of cognitive distortions or the benefits of cognitive restructuring. Narrative elements may reveal core beliefs and schemas about self, others, and the world that shape interpretation of events. Visual techniques potentially represent internal cognitive processes such as rumination, worry, or adaptive problem-solving. The film may demonstrate adaptive or maladaptive coping strategies in response to challenging situations. The viewer's response offers an opportunity to observe automatic thoughts and practice perspective-taking."
};

const criticalAnalyses = {
    [MEDIA_TYPES.TEXT]: "From a Critical Theory perspective, this text reveals underlying power structures and ideological formations. The content can be analyzed dialectically to understand how it both reproduces and potentially challenges dominant social relations. The writing demonstrates how cultural products are shaped by historical and material conditions rather than existing as autonomous expressions. There are elements that suggest how ideology functions to naturalize social arrangements that serve particular interests. The text potentially contains contradictions that reveal the tensions within current social formations. The work can be understood as a form of praxis that either reinforces hegemonic power or creates spaces for emancipatory consciousness.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through Critical Theory to reveal visual representations of power structures, ideological formations, and the potential for emancipatory consciousness. Compositional elements may demonstrate how visual language is shaped by historical and material conditions rather than existing as autonomous expression. The image potentially functions as a form of reification that naturalizes social arrangements or as a dialectical representation that reveals contradictions within current social formations. Visual techniques may reveal how cultural products both reproduce and potentially challenge dominant social relations. The viewer's relationship to the image is mediated by ideological formations that shape perception and interpretation.",
    [MEDIA_TYPES.AUDIO]: "From a Critical Theory perspective, this audio piece expresses the tension between domination and emancipation through its sonic qualities and structural elements. Sound components demonstrate how cultural products are shaped by historical and material conditions rather than existing as autonomous expressions. The piece potentially functions as a form of reification that naturalizes social arrangements or as a dialectical representation that reveals contradictions within current social formations. Rhythmic and tonal patterns may reveal how cultural products both reproduce and potentially challenge dominant social relations. The listener's relationship to the sound is mediated by ideological formations that shape perception and interpretation.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through Critical Theory to reveal narrative and visual elements of power structures, ideological formations, and the dialectical relationship between domination and emancipation. Character relationships and social dynamics demonstrate how cultural products are shaped by historical and material conditions rather than existing as autonomous expressions. The film potentially functions as a form of reification that naturalizes social arrangements or as a dialectical representation that reveals contradictions within current social formations. Visual and narrative techniques may reveal how cultural products both reproduce and potentially challenge dominant social relations. The viewer's relationship to the film is mediated by ideological formations that shape perception and interpretation."
};

const existentialAnalyses = {
    [MEDIA_TYPES.TEXT]: "From an Existential perspective, this text explores themes of freedom, choice, and the search for authentic meaning in an inherently meaningless universe. The content reveals the tension between existential anxiety and the human project of self-creation. Narrative elements potentially demonstrate how individuals confront the fundamental existential givens of death, freedom, isolation, and meaninglessness. The writing may explore the concept of authenticity as living in accordance with one's freely chosen values despite the absurdity of existence. The text potentially reveals how human beings create meaning through their choices and commitments in a world without predetermined essence or purpose.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through an Existential lens to reveal visual representations of freedom, authenticity, and the confrontation with nothingness that characterizes human existence. Compositional elements may suggest the tension between existential anxiety and the human project of self-creation. Visual cues potentially demonstrate how individuals confront the fundamental existential givens of death, freedom, isolation, and meaninglessness. The image may explore the concept of authenticity through its representation of human subjects or symbolic content. The visual language potentially reveals how human beings create meaning through their choices and commitments in a world without predetermined essence or purpose.",
    [MEDIA_TYPES.AUDIO]: "From an Existential perspective, this audio piece expresses the tension between freedom and anxiety, and the search for authentic meaning through its sonic qualities and emotional resonance. Sound elements may suggest the confrontation with nothingness that characterizes human existence. Rhythmic and tonal patterns potentially demonstrate how individuals navigate the fundamental existential givens of death, freedom, isolation, and meaninglessness. The structure of the piece may explore the concept of authenticity through its development and resolution. The sonic experience potentially reveals how human beings create meaning through their choices and commitments in a world without predetermined essence or purpose.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through an Existential framework to reveal narrative elements of freedom, choice, authenticity, and the human struggle to create meaning in an absurd universe. Character arcs potentially demonstrate how individuals confront the fundamental existential givens of death, freedom, isolation, and meaninglessness. The narrative may explore the concept of authenticity as living in accordance with one's freely chosen values despite the absurdity of existence. Visual techniques potentially represent the tension between existential anxiety and the human project of self-creation. The film's structure may reflect the non-linear, subjective nature of lived experience. The viewer is potentially invited to reflect on their own freedom, responsibility, and the creation of personal meaning."
};

const feministAnalyses = {
    [MEDIA_TYPES.TEXT]: "From a Feminist perspective, this text reveals the social construction of gender and the operation of patriarchal structures. The content can be analyzed through various feminist lenses to understand how gender shapes experience and social relations. The writing potentially demonstrates how language and narrative forms have been shaped by gendered power dynamics. There are elements that suggest how intersecting identities of race, class, sexuality, and ability influence gendered experience. The text may challenge or reinforce traditional gender roles and expectations. The work potentially creates space for marginalized voices and experiences that have been excluded from dominant cultural narratives.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Feminist framework to reveal visual representations of gender construction, patriarchal structures, and the potential for resistance and transformation. Compositional elements may demonstrate how visual language has been shaped by gendered power dynamics and the male gaze. The image potentially challenges or reinforces traditional gender roles and expectations through its representation of bodies, spaces, and relationships. Visual techniques may reveal how intersecting identities of race, class, sexuality, and ability influence gendered experience. The viewer's relationship to the image is mediated by gendered patterns of looking and being looked at. The work potentially creates space for marginalized perspectives that have been excluded from dominant visual culture.",
    [MEDIA_TYPES.AUDIO]: "From a Feminist perspective, this audio piece expresses gendered experiences and the potential for challenging patriarchal structures through its sonic qualities and emotional resonance. Sound elements may demonstrate how auditory expression has been shaped by gendered power dynamics. The piece potentially challenges or reinforces traditional gender roles and expectations through its sonic representation of voices, spaces, and relationships. Rhythmic and tonal patterns may reveal how intersecting identities of race, class, sexuality, and ability influence gendered experience. The listener's relationship to the sound is mediated by gendered patterns of speaking and listening. The work potentially creates space for marginalized voices that have been excluded from dominant auditory culture.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through a Feminist framework to reveal narrative and visual elements of gender construction, patriarchal structures, and the potential for feminist resistance and transformation. Character relationships and social dynamics demonstrate how visual and narrative language has been shaped by gendered power dynamics and the male gaze. The film potentially challenges or reinforces traditional gender roles and expectations through its representation of bodies, spaces, and relationships. Visual and narrative techniques may reveal how intersecting identities of race, class, sexuality, and ability influence gendered experience. The viewer's relationship to the film is mediated by gendered patterns of looking and being looked at. The work potentially creates space for marginalized perspectives that have been excluded from dominant cinema."
};

const gestaltAnalyses = {
    [MEDIA_TYPES.TEXT]: "From a Gestalt perspective, this text reveals the principles of wholeness and figure-ground relationships. The content can be understood in terms of contact boundaries, awareness processes, and the integration of polarities. The writing demonstrates how meaning emerges from the relationship between parts and wholes rather than from isolated elements. There are elements that suggest how awareness functions in the here-and-now to organize experience into meaningful gestalts. The text potentially reveals patterns of contact and withdrawal that characterize the relationship between self and environment. The work may demonstrate the paradoxical theory of change through its exploration of acceptance and transformation.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Gestalt framework to reveal visual principles of wholeness, figure-ground relationships, and the integration of polarities. Compositional elements demonstrate how perception organizes visual elements into meaningful wholes according to principles such as proximity, similarity, continuity, and closure. The image potentially reveals contact boundaries between visual elements that create meaningful distinctions while maintaining connection. Visual techniques may demonstrate the principle of prägnanz, where perception tends toward the simplest and most stable organization. The viewer's experience of the image involves an active process of gestalt formation that reveals how meaning emerges from relationship rather than isolated elements.",
    [MEDIA_TYPES.AUDIO]: "From a Gestalt perspective, this audio piece expresses principles of wholeness and figure-ground relationships through its sonic qualities and temporal unfolding. Sound elements demonstrate how auditory perception organizes sonic elements into meaningful wholes according to principles such as proximity, similarity, continuity, and closure. The piece potentially reveals patterns of contact and withdrawal through its dynamics of sound and silence. Rhythmic and tonal patterns may demonstrate the integration of polarities through tension and resolution. The structure of the piece potentially reveals how meaning emerges from the relationship between parts and wholes rather than from isolated elements. The listener's experience involves an active process of gestalt formation in the here-and-now.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through a Gestalt framework to reveal narrative and visual elements of wholeness, contact boundaries, awareness processes, and the integration of polarities. Character relationships demonstrate patterns of contact and withdrawal that characterize the relationship between self and environment. The narrative potentially reveals how awareness functions in the here-and-now to organize experience into meaningful gestalts. Visual techniques demonstrate principles of perception such as figure-ground relationships, proximity, similarity, continuity, and closure. The film's structure may reveal the paradoxical theory of change through its exploration of acceptance and transformation. The viewer's experience involves an active process of gestalt formation that reveals how meaning emerges from relationship rather than isolated elements."
};

const hermeneuticsAnalyses = {
    [MEDIA_TYPES.TEXT]: "From a Hermeneutic perspective, this text reveals layers of meaning that emerge through the interpretive circle of part and whole. The content can be understood in terms of its historical context, linguistic dimensions, and the fusion of horizons between text and interpreter. The writing demonstrates how understanding is always situated within traditions and pre-understandings that shape interpretation. There are elements that suggest how language functions not merely as a tool but as the medium in which understanding occurs. The text potentially reveals the temporal nature of understanding as a dialogue between past and present. The work invites a process of interpretation that acknowledges both the historical distance and the productive application of meaning to the interpreter's situation.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Hermeneutic framework to reveal visual meanings that emerge through the interpretive circle of part and whole, historical context, and the fusion of horizons between image and viewer. Compositional elements demonstrate how visual understanding is always situated within traditions and pre-understandings that shape interpretation. The image potentially reveals the temporal nature of understanding as a dialogue between past and present visual languages. Visual techniques may demonstrate how meaning emerges not from isolated elements but from their relationships within broader contexts. The viewer's engagement with the image involves a fusion of horizons where the historical world of the image meets the present situation of the interpreter. The work invites a process of interpretation that acknowledges both historical distance and productive application.",
    [MEDIA_TYPES.AUDIO]: "From a Hermeneutic perspective, this audio piece expresses meanings that emerge through the interpretive circle of part and whole, historical context, and the fusion of horizons between sound and listener. Sound elements demonstrate how auditory understanding is always situated within traditions and pre-understandings that shape interpretation. The piece potentially reveals the temporal nature of understanding as a dialogue between past and present sonic languages. Rhythmic and tonal patterns may demonstrate how meaning emerges not from isolated elements but from their relationships within broader contexts. The listener's engagement with the audio involves a fusion of horizons where the historical world of the sound meets the present situation of the interpreter. The work invites a process of interpretation that acknowledges both historical distance and productive application.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through a Hermeneutic framework to reveal narrative and visual meanings that emerge through the interpretive circle of part and whole, historical context, and the fusion of horizons between film and viewer. Character relationships and narrative elements demonstrate how understanding is always situated within traditions and pre-understandings that shape interpretation. The film potentially reveals the temporal nature of understanding as a dialogue between past and present visual and narrative languages. Visual techniques may demonstrate how meaning emerges not from isolated elements but from their relationships within broader contexts. The viewer's engagement with the film involves a fusion of horizons where the historical world of the film meets the present situation of the interpreter. The work invites a process of interpretation that acknowledges both historical distance and productive application."
};

const jungianAnalyses = {
    [MEDIA_TYPES.TEXT]: "From a Jungian perspective, this text reveals archetypal patterns and symbolic expressions of the collective unconscious. The content can be understood in terms of the individuation process, as the ego relates to both personal and collective unconscious material. The writing potentially demonstrates the interplay of various archetypes such as the Shadow, Anima/Animus, Self, or the Hero's journey. There are elements that suggest how symbolic language expresses psychic content that cannot be directly articulated. The text may reveal the transcendent function as it mediates between conscious and unconscious, creating new symbolic syntheses. The work potentially demonstrates synchronistic connections that reveal meaningful patterns beyond causal explanation.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Jungian framework to reveal archetypal patterns and symbolic expressions of the collective unconscious. Visual elements potentially represent archetypes such as the Shadow, Anima/Animus, Self, or stages of the Hero's journey. The composition may demonstrate the mandala structure as an expression of psychic wholeness and integration. Color relationships and symbolic content potentially express psychic material that cannot be directly articulated. The image may function as a container for projection of unconscious content, revealing aspects of the viewer's psyche. The visual language potentially demonstrates the transcendent function as it mediates between conscious and unconscious, creating new symbolic syntheses.",
    [MEDIA_TYPES.AUDIO]: "From a Jungian perspective, this audio piece expresses archetypal patterns and symbolic expressions of the collective unconscious through its sonic qualities and emotional resonance. Sound elements potentially represent archetypes such as the Shadow, Anima/Animus, Self, or stages of the Hero's journey. Rhythmic and tonal patterns may demonstrate the mandala structure as an expression of psychic wholeness and integration. The sonic experience potentially expresses psychic material that cannot be directly articulated. The piece may function as a container for projection of unconscious content, revealing aspects of the listener's psyche. The auditory language potentially demonstrates the transcendent function as it mediates between conscious and unconscious, creating new symbolic syntheses.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through a Jungian framework to reveal narrative and visual elements of archetypal patterns and symbolic expressions of the collective unconscious. Character relationships potentially represent archetypes such as the Shadow, Anima/Animus, Self, or stages of the Hero's journey. The narrative structure may demonstrate the individuation process as characters integrate conscious and unconscious aspects of the psyche. Visual techniques potentially express psychic material that cannot be directly articulated. The film may function as a container for projection of unconscious content, revealing aspects of the viewer's psyche. The visual and narrative language potentially demonstrates the transcendent function as it mediates between conscious and unconscious, creating new symbolic syntheses."
};

const narrativeAnalyses = {
    [MEDIA_TYPES.TEXT]: "From a Narrative Psychology perspective, this text reveals how human experience is organized and made meaningful through storytelling processes. The content demonstrates how narrative structures shape identity formation and the interpretation of life events. There are elements that suggest how cultural master narratives influence personal storytelling, providing templates for understanding experience. The writing potentially reveals narrative coherence or fragmentation as indicators of psychological integration. The text may demonstrate how narrative revision allows for reinterpretation of past experiences and the creation of new meaning. The work potentially shows how narratives function not just as representations of experience but as constitutive elements that shape lived reality.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Narrative Psychology framework to reveal visual representations of storytelling processes and identity formation. Compositional elements may suggest narrative structures that organize experience and create meaning. Visual cues potentially demonstrate how cultural master narratives influence personal visual storytelling, providing templates for understanding experience. The image may reveal narrative coherence or fragmentation as indicators of psychological integration. Visual techniques potentially show how narratives function not just as representations of experience but as constitutive elements that shape perception and identity. The viewer's engagement with the image involves the co-construction of narrative meaning based on personal and cultural storytelling patterns.",
    [MEDIA_TYPES.AUDIO]: "From a Narrative Psychology perspective, this audio piece expresses how human experience is organized and made meaningful through storytelling processes. Sound elements demonstrate how narrative structures shape identity formation and the interpretation of events. Rhythmic and tonal patterns may suggest how cultural master narratives influence personal storytelling, providing templates for understanding experience. The piece potentially reveals narrative coherence or fragmentation as indicators of psychological integration. The sonic experience may demonstrate how narrative revision allows for reinterpretation of past experiences and the creation of new meaning. The listener's engagement with the audio involves the co-construction of narrative meaning based on personal and cultural storytelling patterns.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through a Narrative Psychology framework to reveal how human experience is organized and made meaningful through storytelling processes. Character arcs and plot structures demonstrate how narratives shape identity formation and the interpretation of life events. The film potentially reveals how cultural master narratives influence personal storytelling, providing templates for understanding experience. Visual and narrative techniques may demonstrate narrative coherence or fragmentation as indicators of psychological integration. The film's structure potentially shows how narrative revision allows for reinterpretation of past experiences and the creation of new meaning. The viewer's engagement with the film involves the co-construction of narrative meaning based on personal and cultural storytelling patterns."
};

const nietzscheanAnalyses = {
    [MEDIA_TYPES.TEXT]: "From a Nietzschean perspective, this text expresses the will to power as a creative force of self-overcoming. The content reveals a perspectival understanding of truth that goes beyond conventional moral categories of good and evil. The writing potentially demonstrates the tension between Apollonian form and Dionysian creative energy. There are elements that suggest a transvaluation of values, challenging established moral and metaphysical assumptions. The text may explore the concept of eternal recurrence as the ultimate affirmation of life. The work potentially embodies Nietzsche's call for a philosophy that serves life and enhances human potential rather than diminishing vital forces.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Nietzschean framework to reveal visual expressions of the will to power, perspectivism, and the potential for going beyond conventional moral interpretations. Compositional elements may demonstrate the tension between Apollonian form and Dionysian creative energy. Visual cues potentially suggest a transvaluation of values, challenging established aesthetic and moral assumptions. The image may embody the concept of amor fati—the love of fate and affirmation of life with all its suffering and joy. The visual language potentially expresses Nietzsche's emphasis on becoming rather than being, showing reality as a dynamic process rather than a fixed state. The viewer's encounter with the image involves a perspectival interpretation that reveals the impossibility of absolute truth.",
    [MEDIA_TYPES.AUDIO]: "From a Nietzschean perspective, this audio piece expresses the will to power as a creative force and the affirmation of life through its sonic qualities and emotional resonance. Sound elements demonstrate the tension between Apollonian form and Dionysian creative energy. Rhythmic and tonal patterns potentially suggest a transvaluation of values, challenging established musical and aesthetic assumptions. The piece may embody the concept of eternal recurrence through cyclical structures that affirm repetition as creative rather than merely mechanical. The sonic experience potentially expresses Nietzsche's emphasis on becoming rather than being, showing reality as a dynamic process rather than a fixed state. The listener's encounter with the sound involves a perspectival interpretation that reveals the impossibility of absolute truth.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through a Nietzschean framework to reveal narrative and visual elements of the will to power, eternal recurrence, and the transvaluation of conventional moral values. Character arcs potentially demonstrate the process of self-overcoming and the creation of new values beyond good and evil. The narrative may explore the tension between Apollonian form and Dionysian creative energy. Visual techniques potentially express Nietzsche's emphasis on becoming rather than being, showing reality as a dynamic process rather than a fixed state. The film's structure may embody the concept of amor fati—the love of fate and affirmation of life with all its suffering and joy. The viewer's encounter with the film involves a perspectival interpretation that reveals the impossibility of absolute truth."
};

const phenomenologyAnalyses = {
    [MEDIA_TYPES.TEXT]: "From a Phenomenological perspective, this text reveals the structures of lived experience as they appear to consciousness. The content demonstrates how meaning emerges through the intentional relationship between consciousness and its objects. The writing potentially employs the phenomenological reduction, bracketing theoretical assumptions to return to the things themselves as they appear in experience. There are elements that suggest the embodied nature of perception and understanding. The text may explore the intersubjective dimension of experience, showing how meaning is constituted in relation to others. The work potentially reveals the temporal structure of consciousness as it synthesizes past, present, and anticipated future moments.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Phenomenological framework to reveal the structures of visual experience as they appear to consciousness. Compositional elements demonstrate how visual meaning emerges through the intentional relationship between perception and its objects. The image potentially invites a phenomenological reduction, bracketing theoretical assumptions to return to visual phenomena as they appear in direct experience. Visual cues may suggest the embodied nature of perception, showing how visual understanding is grounded in bodily experience. The image potentially reveals the intersubjective dimension of visual experience, showing how meaning is constituted in relation to others. The viewer's engagement with the image involves a lived experience that synthesizes past, present, and anticipated future moments of perception.",
    [MEDIA_TYPES.AUDIO]: "From a Phenomenological perspective, this audio piece expresses the structures of auditory experience as they appear to consciousness. Sound elements demonstrate how sonic meaning emerges through the intentional relationship between listening and its objects. The piece potentially invites a phenomenological reduction, bracketing theoretical assumptions to return to auditory phenomena as they appear in direct experience. Rhythmic and tonal patterns may suggest the embodied nature of listening, showing how auditory understanding is grounded in bodily experience. The sonic experience potentially reveals the intersubjective dimension of listening, showing how meaning is constituted in relation to others. The listener's engagement with the audio involves a lived experience that synthesizes past, present, and anticipated future moments of auditory perception.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through a Phenomenological framework to reveal the structures of audiovisual experience as they appear to consciousness. Narrative and visual elements demonstrate how meaning emerges through the intentional relationship between perception and its objects. The film potentially invites a phenomenological reduction, bracketing theoretical assumptions to return to phenomena as they appear in direct experience. Visual techniques may suggest the embodied nature of perception, showing how understanding is grounded in bodily experience. The film potentially reveals the intersubjective dimension of experience, showing how meaning is constituted in relation to others. The viewer's engagement with the film involves a lived experience that synthesizes past, present, and anticipated future moments of perception."
};

const positiveAnalyses = {
    [MEDIA_TYPES.TEXT]: "From a Positive Psychology perspective, this text reveals elements of well-being, flourishing, and human strengths. The content can be analyzed in terms of PERMA elements: Positive emotions, Engagement, Relationships, Meaning, and Accomplishment. The writing potentially demonstrates character strengths and virtues such as wisdom, courage, humanity, justice, temperance, or transcendence. There are elements that suggest how positive experiences and meaning-making contribute to psychological resilience. The text may explore the balance between hedonic well-being (pleasure) and eudaimonic well-being (meaning and purpose). The work potentially reveals how growth can emerge from challenging experiences through post-traumatic growth or benefit-finding.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Positive Psychology framework to reveal visual representations of well-being, flourishing, and human strengths. Compositional elements may suggest PERMA components: Positive emotions, Engagement, Relationships, Meaning, and Accomplishment. Visual cues potentially demonstrate character strengths and virtues such as wisdom, courage, humanity, justice, temperance, or transcendence. The image may explore the balance between hedonic well-being (pleasure) and eudaimonic well-being (meaning and purpose). Visual techniques potentially reveal how growth can emerge from challenging experiences through post-traumatic growth or benefit-finding. The viewer's engagement with the image may elicit positive emotions or states of flow that contribute to well-being.",
    [MEDIA_TYPES.AUDIO]: "From a Positive Psychology perspective, this audio piece expresses elements of well-being, flourishing, and human strengths through its sonic qualities and emotional resonance. Sound elements may suggest PERMA components: Positive emotions, Engagement, Relationships, Meaning, and Accomplishment. Rhythmic and tonal patterns potentially demonstrate character strengths and virtues such as wisdom, courage, humanity, justice, temperance, or transcendence. The piece may explore the balance between hedonic well-being (pleasure) and eudaimonic well-being (meaning and purpose). The sonic experience potentially reveals how growth can emerge from challenging experiences through post-traumatic growth or benefit-finding. The listener's engagement with the audio may elicit positive emotions or states of flow that contribute to well-being.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through a Positive Psychology framework to reveal narrative and visual elements of well-being, flourishing, and human strengths. Character arcs potentially demonstrate PERMA components: Positive emotions, Engagement, Relationships, Meaning, and Accomplishment. The narrative may explore character strengths and virtues such as wisdom, courage, humanity, justice, temperance, or transcendence. Visual techniques potentially reveal the balance between hedonic well-being (pleasure) and eudaimonic well-being (meaning and purpose). The film's structure may demonstrate how growth can emerge from challenging experiences through post-traumatic growth or benefit-finding. The viewer's engagement with the film may elicit positive emotions or states of flow that contribute to well-being."
};

const posthumanismAnalyses = {
    [MEDIA_TYPES.TEXT]: "From a Posthumanist perspective, this text challenges anthropocentric assumptions and explores the entanglements between human and nonhuman agencies. The content reveals how subjectivity is distributed across networks of human, technological, and material actors. The writing potentially demonstrates a critique of human exceptionalism and the nature/culture binary. There are elements that suggest how technology mediates and transforms human experience rather than serving as a mere tool. The text may explore how agency emerges from assemblages of human and nonhuman actors rather than from autonomous human subjects. The work potentially reveals the material agency of nonhuman entities and their participation in meaning-making processes.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Posthumanist framework to reveal visual representations of human-nonhuman entanglements, technological mediations, and hybrid forms of agency and subjectivity. Compositional elements may demonstrate a critique of human exceptionalism and the nature/culture binary. Visual cues potentially suggest how technology mediates and transforms human experience rather than serving as a mere tool. The image may explore cyborg or hybrid identities that challenge traditional boundaries between human, animal, and machine. Visual techniques potentially reveal the material agency of nonhuman entities and their participation in meaning-making processes. The viewer's relationship to the image involves a distributed form of perception that extends beyond the human subject.",
    [MEDIA_TYPES.AUDIO]: "From a Posthumanist perspective, this audio piece expresses the distributed nature of agency and subjectivity across human and nonhuman actors through its sonic qualities and technological mediations. Sound elements demonstrate a critique of human exceptionalism and the nature/culture binary. Rhythmic and tonal patterns potentially suggest how technology mediates and transforms human experience rather than serving as a mere tool. The piece may explore how agency emerges from assemblages of human and nonhuman sonic actors rather than from autonomous human subjects. The sonic experience potentially reveals the material agency of nonhuman entities and their participation in meaning-making processes. The listener's relationship to the audio involves a distributed form of perception that extends beyond the human subject.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through a Posthumanist framework to reveal narrative and visual elements that challenge anthropocentrism and explore the entanglements between human, technological, and nonhuman agencies. Character relationships potentially demonstrate a critique of human exceptionalism and the nature/culture binary. The narrative may explore cyborg or hybrid identities that challenge traditional boundaries between human, animal, and machine. Visual techniques potentially suggest how technology mediates and transforms human experience rather than serving as a mere tool. The film's structure may reveal how agency emerges from assemblages of human and nonhuman actors rather than from autonomous human subjects. The viewer's relationship to the film involves a distributed form of perception that extends beyond the human subject."
};

const psychiatryAnalyses = {
    [MEDIA_TYPES.TEXT]: "From a Psychiatric perspective, this text reveals themes that can be understood in terms of diagnostic categories, neurobiological factors, and psychosocial determinants. The content can be analyzed using the biopsychosocial model that integrates multiple levels of explanation. The writing potentially demonstrates psychological processes that may relate to mental health and illness. There are elements that suggest how biological, psychological, and social factors interact in shaping human experience. The text may explore themes related to specific psychiatric conditions or general mental health concerns. The work potentially reveals how narrative and meaning-making processes contribute to psychological well-being or distress.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Psychiatric framework to reveal visual representations of psychological states, neurobiological processes, and psychosocial factors that contribute to mental health and illness. Compositional elements may suggest emotional states or cognitive patterns that relate to psychological functioning. Visual cues potentially demonstrate how biological, psychological, and social factors interact in shaping human experience. The image may explore themes related to specific psychiatric conditions or general mental health concerns. Visual techniques potentially reveal how perception and interpretation processes contribute to psychological well-being or distress. The viewer's response to the image may provide insights into psychological processes such as projection, identification, or emotional regulation.",
    [MEDIA_TYPES.AUDIO]: "From a Psychiatric perspective, this audio piece expresses themes related to psychological states, neurobiological processes, and psychosocial factors through its sonic qualities and emotional resonance. Sound elements may suggest emotional states or cognitive patterns that relate to psychological functioning. Rhythmic and tonal patterns potentially demonstrate how biological, psychological, and social factors interact in shaping human experience. The piece may explore themes related to specific psychiatric conditions or general mental health concerns. The sonic experience potentially reveals how auditory processing and interpretation contribute to psychological well-being or distress. The listener's response to the audio may provide insights into psychological processes such as emotional regulation, attention, or memory.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through a Psychiatric framework to reveal narrative and visual elements of psychological states, neurobiological processes, and psychosocial factors that contribute to mental health and illness. Character arcs potentially demonstrate how biological, psychological, and social factors interact in shaping human experience. The narrative may explore themes related to specific psychiatric conditions or general mental health concerns. Visual techniques potentially reveal how perception, cognition, and emotion interact in psychological functioning. The film's structure may demonstrate psychological processes such as memory, attention, or executive functioning. The viewer's response to the film may provide insights into psychological processes such as empathy, identification, or emotional regulation."
};

const stoicismAnalyses = {
    [MEDIA_TYPES.TEXT]: "From a Stoic perspective, this text reveals themes related to virtue, the dichotomy of control, and living according to rational nature. The content can be understood in terms of the Stoic emphasis on focusing on what is within our control and maintaining a cosmic perspective. The writing potentially demonstrates the four cardinal virtues of wisdom, courage, justice, and temperance. There are elements that suggest how emotional responses are shaped by judgments rather than external events. The text may explore the concept of amor fati—the acceptance and love of one's fate. The work potentially reveals how philosophical understanding contributes to tranquility (ataraxia) and emotional resilience.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Stoic framework to reveal visual representations of virtue, the dichotomy of control, and the cosmic perspective that characterizes Stoic philosophy. Compositional elements may suggest the four cardinal virtues of wisdom, courage, justice, and temperance. Visual cues potentially demonstrate the Stoic emphasis on focusing on what is within our control and maintaining equanimity toward external circumstances. The image may explore the concept of memento mori—the reminder of mortality that puts daily concerns into perspective. Visual techniques potentially reveal how philosophical understanding contributes to tranquility (ataraxia) and emotional resilience. The viewer's relationship to the image offers an opportunity to practice the Stoic discipline of assent—choosing how to interpret and respond to impressions.",
    [MEDIA_TYPES.AUDIO]: "From a Stoic perspective, this audio piece expresses themes related to virtue, the dichotomy of control, and living according to rational nature through its sonic qualities and emotional resonance. Sound elements may suggest the four cardinal virtues of wisdom, courage, justice, and temperance. Rhythmic and tonal patterns potentially demonstrate the Stoic emphasis on focusing on what is within our control and maintaining equanimity toward external circumstances. The piece may explore the concept of amor fati—the acceptance and love of one's fate. The sonic experience potentially reveals how philosophical understanding contributes to tranquility (ataraxia) and emotional resilience. The listener's relationship to the audio offers an opportunity to practice the Stoic discipline of assent—choosing how to interpret and respond to impressions.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through a Stoic framework to reveal narrative and visual elements of virtue, the dichotomy of control, and the cosmic perspective that characterizes Stoic philosophy. Character arcs potentially demonstrate the four cardinal virtues of wisdom, courage, justice, and temperance. The narrative may explore how emotional responses are shaped by judgments rather than external events. Visual techniques potentially reveal the Stoic emphasis on focusing on what is within our control and maintaining equanimity toward external circumstances. The film's structure may explore concepts such as memento mori or amor fati that put daily concerns into perspective. The viewer's relationship to the film offers an opportunity to practice the Stoic discipline of assent—choosing how to interpret and respond to impressions."
};

const tackticalAnalyses = {
    [MEDIA_TYPES.TEXT]: "From a Tacktical Methodology perspective, this text reveals patterns of tactical engagement with established structures and systems. The content demonstrates how individuals navigate and repurpose dominant cultural forms through everyday practices and creative appropriation. The writing potentially shows how tactical operations work within strategic spaces, finding opportunities for resistance and creative expression. There are elements that suggest how meaning emerges through use rather than through predetermined structures. The text may explore the temporal nature of tactics as they seize opportunities in the moment. The work potentially reveals how power operates through both strategic impositions and tactical responses.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Tacktical Methodology framework to reveal visual representations of tactical engagement with established structures and systems. Compositional elements may demonstrate how individuals navigate and repurpose dominant visual languages through creative appropriation. Visual cues potentially show how tactical operations work within strategic spaces, finding opportunities for resistance and creative expression. The image may explore how meaning emerges through use rather than through predetermined structures. Visual techniques potentially reveal the temporal nature of tactics as they seize opportunities in the moment. The viewer's relationship to the image involves a tactical reading that finds spaces for alternative interpretations within dominant visual codes.",
    [MEDIA_TYPES.AUDIO]: "From a Tacktical Methodology perspective, this audio piece expresses patterns of tactical engagement with established structures and systems through its sonic qualities. Sound elements demonstrate how individuals navigate and repurpose dominant auditory forms through everyday practices and creative appropriation. Rhythmic and tonal patterns potentially show how tactical operations work within strategic spaces, finding opportunities for resistance and creative expression. The piece may explore how meaning emerges through use rather than through predetermined structures. The sonic experience potentially reveals the temporal nature of tactics as they seize opportunities in the moment. The listener's relationship to the audio involves a tactical hearing that finds spaces for alternative interpretations within dominant sonic codes.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through a Tacktical Methodology framework to reveal narrative and visual elements of tactical engagement with established structures and systems. Character relationships potentially demonstrate how individuals navigate and repurpose dominant cultural forms through everyday practices and creative appropriation. The narrative may show how tactical operations work within strategic spaces, finding opportunities for resistance and creative expression. Visual techniques potentially explore how meaning emerges through use rather than through predetermined structures. The film's structure may reveal the temporal nature of tactics as they seize opportunities in the moment. The viewer's relationship to the film involves a tactical reading that finds spaces for alternative interpretations within dominant cinematic codes."
};

const transpersonalAnalyses = {
    [MEDIA_TYPES.TEXT]: "From a Transpersonal perspective, this text explores dimensions of experience that transcend the boundaries of the ego. The content reveals potential states of consciousness that connect the individual to spiritual, cosmic, or universal dimensions of existence. The writing potentially demonstrates how identity can expand beyond the personal self to include broader aspects of humanity, nature, or consciousness itself. There are elements that suggest how non-ordinary states of consciousness can provide access to transpersonal insights and transformative experiences. The text may explore spiritual or mystical themes that point toward the integration of psychological and spiritual dimensions of human experience. The work potentially reveals how personal development can lead toward self-transcendence and higher states of consciousness.",
    [MEDIA_TYPES.IMAGE]: "This image can be analyzed through a Transpersonal framework to reveal visual representations of experiences that transcend ordinary ego boundaries and connect to spiritual or cosmic dimensions. Compositional elements may suggest states of consciousness that go beyond everyday awareness to include transpersonal realms. Visual cues potentially demonstrate how identity can expand beyond the personal self to include broader aspects of humanity, nature, or consciousness itself. The image may explore spiritual or mystical themes that point toward the integration of psychological and spiritual dimensions of human experience. Visual techniques potentially reveal how personal development can lead toward self-transcendence and higher states of consciousness. The viewer's engagement with the image may evoke non-ordinary states of awareness that provide access to transpersonal insights.",
    [MEDIA_TYPES.AUDIO]: "From a Transpersonal perspective, this audio piece expresses states of consciousness that transcend ordinary ego boundaries through its sonic qualities and emotional resonance. Sound elements suggest dimensions of experience that connect the individual to spiritual, cosmic, or universal aspects of existence. Rhythmic and tonal patterns potentially demonstrate how identity can expand beyond the personal self to include broader aspects of humanity, nature, or consciousness itself. The piece may explore spiritual or mystical themes that point toward the integration of psychological and spiritual dimensions of human experience. The sonic experience potentially reveals how personal development can lead toward self-transcendence and higher states of consciousness. The listener's engagement with the audio may evoke non-ordinary states of awareness that provide access to transpersonal insights.",
    [MEDIA_TYPES.FILM]: "This film can be analyzed through a Transpersonal framework to reveal narrative and visual elements of experiences that transcend ordinary ego boundaries and connect to spiritual or cosmic dimensions. Character arcs potentially demonstrate how identity can expand beyond the personal self to include broader aspects of humanity, nature, or consciousness itself. The narrative may explore spiritual or mystical themes that point toward the integration of psychological and spiritual dimensions of human experience. Visual techniques potentially suggest non-ordinary states of consciousness that provide access to transpersonal insights and transformative experiences. The film's structure may reveal how personal development can lead toward self-transcendence and higher states of consciousness. The viewer's engagement with the film may evoke expanded states of awareness that transcend everyday perception."
};

// Import predefined analyses
// Map of framework IDs to predefined analyses
const predefinedAnalyses = {
    'deleuzian': deleuzianAnalyses,
    'irigarayian': irigarayianAnalyses,
    'freudian': freudianAnalyses,
    'lacanian': lacanianAnalyses,
    'epicurean': epicureanAnalyses,
    'attachment': attachmentAnalyses,
    'buddhist': buddhistAnalyses,
    'cbt': cbtAnalyses,
    'critical': criticalAnalyses,
    'existential': existentialAnalyses,
    'feminist': feministAnalyses,
    'gestalt': gestaltAnalyses,
    'hermeneutics': hermeneuticsAnalyses,
    'jungian': jungianAnalyses,
    'narrative': narrativeAnalyses,
    'nietzschean': nietzscheanAnalyses,
    'phenomenology': phenomenologyAnalyses,
    'positive': positiveAnalyses,
    'posthumanism': posthumanismAnalyses,
    'psychiatry': psychiatryAnalyses,
    'stoicism': stoicismAnalyses,
    'tacktical': tackticalAnalyses,
    'transpersonal': transpersonalAnalyses
};
/**
 * Get a predefined analysis for a framework and media type
 * @param frameworkId The ID of the framework
 * @param mediaType The media type
 * @returns The predefined analysis text, or undefined if not found
 */
function getPredefinedAnalysis(frameworkId, mediaType) {
    var _a;
    return (_a = predefinedAnalyses[frameworkId]) === null || _a === void 0 ? void 0 : _a[mediaType];
}
/**
 * Generate a generic analysis for a framework and media type
 * @param frameworkId The ID of the framework
 * @param mediaType The media type
 * @param fileName The name of the file being analyzed
 * @param frameworkName The display name of the framework
 * @returns A generic analysis text
 */
function generateGenericAnalysis(frameworkId, mediaType, fileName, frameworkName) {
    return `This ${mediaType} "${fileName}" can be analyzed through the lens of ${frameworkName} to reveal insights about its structure, content, and meaning. The analysis would consider the specific theoretical concepts and methodologies of this framework to interpret the work's significance and implications. Multiple elements of the ${mediaType} demonstrate principles central to this theoretical approach. The relationship between form and content reveals deeper patterns that align with key concepts from this framework. This analysis opens up new perspectives on how the ${mediaType} functions within broader cultural and psychological contexts. The ${mediaType}'s impact can be understood through this framework's unique interpretive lens.`;
}

class OpenAIService {
    constructor(settings) {
        this.apiUrl = 'https://api.openai.com/v1/chat/completions';
        this.cache = new Map();
        this.apiKey = settings.openaiApiKey || '';
        this.model = settings.openaiModel || 'gpt-3.5-turbo';
    }
    /**
     * Update the service configuration
     */
    updateConfig(settings) {
        this.apiKey = settings.openaiApiKey || '';
        this.model = settings.openaiModel || 'gpt-3.5-turbo';
    }
    /**
     * Check if the OpenAI integration is properly configured
     */
    isConfigured() {
        return !!this.apiKey;
    }
    /**
     * Generate a cache key for a request
     */
    generateCacheKey(framework, content, mediaType) {
        // Create a simple hash of the content to use as part of the cache key
        let contentHash = 0;
        for (let i = 0; i < content.length; i++) {
            contentHash = ((contentHash << 5) - contentHash) + content.charCodeAt(i);
            contentHash = contentHash & contentHash; // Convert to 32bit integer
        }
        return `${framework}-${mediaType}-${contentHash}`;
    }
    /**
     * Analyze content using OpenAI API
     */
    async analyzeContent(content, framework, mediaType, frameworkName) {
        var _a, _b;
        // Check if API key is configured
        if (!this.isConfigured()) {
            throw new Error('OpenAI API key is not configured');
        }
        // Check cache first
        const cacheKey = this.generateCacheKey(framework, content, mediaType);
        if (this.cache.has(cacheKey)) {
            return this.cache.get(cacheKey);
        }
        try {
            // Prepare the prompt based on the framework and media type
            const systemPrompt = this.getSystemPrompt(framework, mediaType, frameworkName);
            const userPrompt = this.getUserPrompt(content, mediaType, frameworkName);
            // Prepare the request
            const request = {
                model: this.model,
                messages: [
                    { role: 'system', content: systemPrompt },
                    { role: 'user', content: userPrompt }
                ],
                max_tokens: 1000,
                temperature: 0.7
            };
            // Call the OpenAI API
            const response = await fetch(this.apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.apiKey}`
                },
                body: JSON.stringify(request)
            });
            // Parse the response
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`OpenAI API error: ${response.status} ${errorText}`);
            }
            const data = await response.json();
            const analysisText = ((_b = (_a = data.choices[0]) === null || _a === void 0 ? void 0 : _a.message) === null || _b === void 0 ? void 0 : _b.content) || 'Analysis could not be generated.';
            // Cache the result
            this.cache.set(cacheKey, analysisText);
            return analysisText;
        }
        catch (error) {
            console.error('Error calling OpenAI API:', error);
            throw error;
        }
    }
    /**
     * Get the system prompt for a specific framework and media type
     */
    getSystemPrompt(framework, mediaType, frameworkName) {
        return `You are an expert in ${frameworkName} analysis. 
Your task is to analyze ${mediaType} content from a ${frameworkName} perspective.
Provide a detailed, insightful analysis that demonstrates deep understanding of ${frameworkName} concepts and methodology.
Your analysis should be approximately 6-8 sentences long, well-structured, and focused on the most relevant aspects of ${frameworkName} theory.
Use specific terminology and concepts from ${frameworkName} in your analysis.
Do not include phrases like "From a ${frameworkName} perspective" or similar introductory phrases.
Focus on providing substantive analysis rather than meta-commentary about the analysis itself.`;
    }
    /**
     * Get the user prompt for a specific content and media type
     */
    getUserPrompt(content, mediaType, frameworkName) {
        const contentPreview = content.length > 1000
            ? content.substring(0, 1000) + '...'
            : content;
        return `Analyze the following ${mediaType} content using ${frameworkName} theory and methodology:

${contentPreview}

Provide a detailed analysis that applies key concepts from ${frameworkName}.`;
    }
    /**
     * Clear the cache
     */
    clearCache() {
        this.cache.clear();
    }
}

class AnalysisEngine {
    constructor(app, settings) {
        this.openaiService = null;
        this.app = app;
        this.settings = settings;
        // Initialize OpenAI service if enabled
        if (settings.enableOpenAI) {
            this.openaiService = new OpenAIService(settings);
        }
    }
    /**
     * Update the engine configuration
     */
    updateConfig(settings) {
        this.settings = settings;
        // Initialize or update OpenAI service
        if (settings.enableOpenAI) {
            if (this.openaiService) {
                this.openaiService.updateConfig(settings);
            }
            else {
                this.openaiService = new OpenAIService(settings);
            }
        }
        else {
            this.openaiService = null;
        }
    }
    // Analyze any content based on its type
    analyzeContent(content, mediaType, frameworks) {
        try {
            // Check if mediaType is valid
            let isValidMediaType = false;
            for (const type in MEDIA_TYPES) {
                if (MEDIA_TYPES[type] === mediaType) {
                    isValidMediaType = true;
                    break;
                }
            }
            if (!isValidMediaType) {
                console.warn(`Unsupported media type: ${mediaType}`);
                return {
                    mediaType,
                    summary: `Unsupported media type: ${mediaType}`,
                    frameworkAnalyses: {},
                    recommendations: []
                };
            }
            // Process based on media type
            switch (mediaType) {
                case MEDIA_TYPES.TEXT:
                    const contentStr = typeof content === 'string' ? content : content.path;
                    return this.analyzeText(contentStr, frameworks);
                case MEDIA_TYPES.IMAGE:
                    return this.analyzeImage(content, frameworks);
                case MEDIA_TYPES.AUDIO:
                    return this.analyzeAudio(content, frameworks);
                case MEDIA_TYPES.FILM:
                    return this.analyzeFilm(content, frameworks);
                default:
                    // This should never happen due to the validation above
                    throw new Error(`Unsupported media type: ${mediaType}`);
            }
        }
        catch (error) {
            console.error(`Error in analyzeContent:`, error);
            // Return a basic result in case of error
            return {
                mediaType: mediaType,
                summary: `Analysis could not be completed due to an error.`,
                frameworkAnalyses: {},
                recommendations: ["Try analyzing a different file or content."],
                fileName: typeof content !== 'string' ? content.path : undefined
            };
        }
    }
    // Analyze text content
    analyzeText(content, frameworks) {
        const result = {
            mediaType: MEDIA_TYPES.TEXT,
            summary: this.generateTextSummary(content),
            frameworkAnalyses: {},
            recommendations: []
        };
        // Generate analysis for each framework
        for (const framework of frameworks) {
            try {
                // Try to get a specialized framework analyzer
                try {
                    const frameworkAnalyzer = getFrameworkAnalysis(framework);
                    result.frameworkAnalyses[framework] = frameworkAnalyzer.analyzeContent(content, MEDIA_TYPES.TEXT);
                }
                catch (e) {
                    // Fall back to generic analysis if specialized framework not available
                    result.frameworkAnalyses[framework] = this.generateFrameworkAnalysis(content, framework, MEDIA_TYPES.TEXT);
                }
            }
            catch (error) {
                console.error(`Error analyzing with framework ${framework}:`, error);
                result.frameworkAnalyses[framework] = this.generateFrameworkAnalysis(content, framework, MEDIA_TYPES.TEXT);
            }
        }
        // Generate recommendations
        result.recommendations = this.generateRecommendations(result.frameworkAnalyses);
        return result;
    }
    // Analyze image content
    analyzeImage(file, frameworks) {
        const result = {
            mediaType: MEDIA_TYPES.IMAGE,
            fileName: file.path,
            summary: `This image (${file.path}) contains visual elements that can be analyzed through multiple theoretical frameworks.`,
            frameworkAnalyses: {},
            recommendations: []
        };
        // Generate analysis for each framework
        for (const framework of frameworks) {
            try {
                // Try to get a specialized framework analyzer
                try {
                    const frameworkAnalyzer = getFrameworkAnalysis(framework);
                    result.frameworkAnalyses[framework] = frameworkAnalyzer.analyzeContent(file, MEDIA_TYPES.IMAGE);
                }
                catch (e) {
                    // Fall back to generic analysis if specialized framework not available
                    result.frameworkAnalyses[framework] = this.generateFrameworkAnalysis(file.path, framework, MEDIA_TYPES.IMAGE);
                }
            }
            catch (error) {
                console.error(`Error analyzing with framework ${framework}:`, error);
                result.frameworkAnalyses[framework] = this.generateFrameworkAnalysis(file.path, framework, MEDIA_TYPES.IMAGE);
            }
        }
        // Generate recommendations
        result.recommendations = this.generateRecommendations(result.frameworkAnalyses);
        return result;
    }
    // Analyze audio content
    analyzeAudio(file, frameworks) {
        const result = {
            mediaType: MEDIA_TYPES.AUDIO,
            fileName: file.path,
            summary: `This audio file (${file.path}) contains sonic elements that can be analyzed through multiple theoretical frameworks.`,
            frameworkAnalyses: {},
            recommendations: []
        };
        // Generate analysis for each framework
        for (const framework of frameworks) {
            try {
                // Try to get a specialized framework analyzer
                try {
                    const frameworkAnalyzer = getFrameworkAnalysis(framework);
                    result.frameworkAnalyses[framework] = frameworkAnalyzer.analyzeContent(file, MEDIA_TYPES.AUDIO);
                }
                catch (e) {
                    // Fall back to generic analysis if specialized framework not available
                    result.frameworkAnalyses[framework] = this.generateFrameworkAnalysis(file.path, framework, MEDIA_TYPES.AUDIO);
                }
            }
            catch (error) {
                console.error(`Error analyzing with framework ${framework}:`, error);
                result.frameworkAnalyses[framework] = this.generateFrameworkAnalysis(file.path, framework, MEDIA_TYPES.AUDIO);
            }
        }
        // Generate recommendations
        result.recommendations = this.generateRecommendations(result.frameworkAnalyses);
        return result;
    }
    // Analyze film content
    analyzeFilm(file, frameworks) {
        const result = {
            mediaType: MEDIA_TYPES.FILM,
            fileName: file.path,
            summary: `This film/video (${file.path}) contains visual and narrative elements that can be analyzed through multiple theoretical frameworks.`,
            frameworkAnalyses: {},
            recommendations: []
        };
        // Generate analysis for each framework
        for (const framework of frameworks) {
            try {
                // Try to get a specialized framework analyzer
                try {
                    const frameworkAnalyzer = getFrameworkAnalysis(framework);
                    result.frameworkAnalyses[framework] = frameworkAnalyzer.analyzeContent(file, MEDIA_TYPES.FILM);
                }
                catch (e) {
                    // Fall back to generic analysis if specialized framework not available
                    result.frameworkAnalyses[framework] = this.generateFrameworkAnalysis(file.path, framework, MEDIA_TYPES.FILM);
                }
            }
            catch (error) {
                console.error(`Error analyzing with framework ${framework}:`, error);
                result.frameworkAnalyses[framework] = this.generateFrameworkAnalysis(file.path, framework, MEDIA_TYPES.FILM);
            }
        }
        // Generate recommendations
        result.recommendations = this.generateRecommendations(result.frameworkAnalyses);
        return result;
    }
    // Generate a summary of text content with more specific analysis
    generateTextSummary(content) {
        // Extract key themes and patterns from the content
        const themes = this.extractThemes(content);
        const emotionalTone = this.analyzeEmotionalTone(content);
        const narrativeStructure = this.analyzeNarrativeStructure(content);
        // Generate a more specific summary based on the content
        return `This text contains themes of ${themes.join(', ')}, with a predominantly ${emotionalTone} emotional tone. The writing suggests ${narrativeStructure}, revealing a nuanced exploration of personal experience and reflection.`;
    }
    // Extract key themes from text content
    extractThemes(content) {
        const themePatterns = {
            reflection: /reflect|contemplat|introspect|think about|ponder|consider/i,
            identity: /who I am|identity|self|authentic|true self/i,
            relationships: /relationship|connect|friend|family|partner|love|intimacy/i,
            transition: /change|transition|shift|transform|evolve|growth|develop/i,
            creativity: /creat|art|express|imagin|inspir|vision|idea/i,
            purpose: /purpose|meaning|significance|direction|goal|aim|mission/i,
            conflict: /conflict|tension|struggle|challenge|difficult|problem|obstacle/i,
            healing: /heal|recover|overcome|process|integrat|accept|reconcile/i
        };
        // Identify themes present in the content
        const presentThemes = [];
        Object.keys(themePatterns).forEach(theme => {
            const pattern = themePatterns[theme];
            if (pattern.test(content)) {
                presentThemes.push(theme);
            }
        });
        // Return identified themes or defaults if none found
        return presentThemes.length > 0 ? presentThemes : ['reflection', 'introspection', 'self-awareness'];
    }
    // Analyze the emotional tone of text content
    analyzeEmotionalTone(content) {
        const tonePatterns = {
            reflective: /reflect|contemplat|ponder|think|consider/i,
            melancholic: /sad|depress|melanchol|down|blue|despair|grief/i,
            hopeful: /hope|optimis|look forward|anticipat|excit|eager/i,
            anxious: /anxi|worry|concern|stress|tension|nervous|fear/i,
            content: /content|satisf|peace|calm|serene|tranquil|happy/i,
            frustrated: /frustrat|annoy|irritat|exasperat|anger|resent/i,
            grateful: /gratitude|thankful|appreciat|grateful|blessed/i,
            ambivalent: /ambivalen|conflict|mixed|unsure|uncertain/i
        };
        // Count occurrences of each tone
        const toneCounts = {};
        Object.keys(tonePatterns).forEach(tone => {
            const pattern = tonePatterns[tone];
            const matches = content.match(pattern) || [];
            toneCounts[tone] = matches.length;
        });
        // Find the dominant tone
        let dominantTone = 'reflective'; // Default
        let maxCount = 0;
        Object.keys(toneCounts).forEach(tone => {
            const count = toneCounts[tone];
            if (count > maxCount) {
                maxCount = count;
                dominantTone = tone;
            }
        });
        return dominantTone;
    }
    // Analyze the narrative structure of text content
    analyzeNarrativeStructure(content) {
        // Check for different narrative patterns
        const isPastFocused = /was|were|had|did|went|came|thought|felt/i.test(content);
        const isFutureFocused = /will|going to|plan|future|soon|tomorrow|next/i.test(content);
        const isQuestionFocused = /\?|wonder|question|curious|how|why|what if/i.test(content);
        const isDialogueHeavy = /said|asked|replied|answered|spoke|talked/i.test(content);
        // Determine the dominant structure
        if (isPastFocused && isFutureFocused) {
            return "a reflective examination of past experiences in relation to future aspirations";
        }
        else if (isPastFocused) {
            return "a retrospective exploration of past experiences and their significance";
        }
        else if (isFutureFocused) {
            return "a forward-looking contemplation of possibilities and intentions";
        }
        else if (isQuestionFocused) {
            return "an inquiry-based exploration of questions and uncertainties";
        }
        else if (isDialogueHeavy) {
            return "a dialogical engagement with different perspectives or voices";
        }
        else {
            return "a present-centered reflection on current experiences and insights";
        }
    }
    // Generate analysis for a specific framework
    async generateFrameworkAnalysis(contentPath, framework, mediaType) {
        var _a;
        // Check if we should use OpenAI for analysis
        const shouldUseOpenAI = this.settings.enableOpenAI &&
            this.settings.analysisTier === AnalysisTier.PREMIUM &&
            ((_a = this.openaiService) === null || _a === void 0 ? void 0 : _a.isConfigured());
        // Check if we've reached the usage limit
        const reachedUsageLimit = this.settings.openaiUsageCount >= this.settings.openaiUsageLimit;
        // If we should use OpenAI and haven't reached the usage limit, try to use it
        if (shouldUseOpenAI && !reachedUsageLimit) {
            try {
                // Get the framework name for better prompting
                const frameworkName = this.getFrameworkName(framework);
                // Use OpenAI to generate the analysis
                const openaiAnalysis = await this.openaiService.analyzeContent(contentPath, framework, mediaType, frameworkName);
                // Increment the usage counter
                this.settings.openaiUsageCount++;
                // Adjust analysis based on depth setting
                switch (this.settings.analysisDepth) {
                    case 'brief':
                        // Return first two sentences
                        return openaiAnalysis.split('. ').slice(0, 2).join('. ') + '.';
                    case 'detailed':
                        // Return the full analysis plus additional detail
                        return openaiAnalysis + ` Further exploration of this ${mediaType} through the ${frameworkName} framework would reveal additional layers of meaning and significance, particularly in relation to the specific cultural and historical contexts in which it was created and is being interpreted.`;
                    case 'standard':
                    default:
                        // Return the full analysis as is
                        return openaiAnalysis;
                }
            }
            catch (error) {
                console.error('Error using OpenAI for analysis:', error);
                new obsidian.Notice('Error using OpenAI for analysis. Falling back to predefined analysis.');
                // Fall back to predefined analysis
                return this.getFallbackAnalysis(contentPath, framework, mediaType);
            }
        }
        else if (shouldUseOpenAI && reachedUsageLimit) {
            // If we've reached the usage limit, show a notice and fall back to predefined analysis
            new obsidian.Notice(`You've reached your monthly OpenAI usage limit (${this.settings.openaiUsageLimit}). Falling back to predefined analysis.`);
            return this.getFallbackAnalysis(contentPath, framework, mediaType);
        }
        else {
            // Use predefined analysis
            return this.getFallbackAnalysis(contentPath, framework, mediaType);
        }
    }
    // Get fallback analysis (predefined or generic)
    getFallbackAnalysis(contentPath, framework, mediaType) {
        const fileName = contentPath.split('/').pop() || contentPath;
        // Try to get a predefined analysis from the predefined-analyses directory
        const predefinedAnalysis = getPredefinedAnalysis(framework, mediaType);
        // If a predefined analysis is found, use it; otherwise, generate a generic analysis
        let analysisText = predefinedAnalysis ||
            generateGenericAnalysis(framework, mediaType, fileName, this.getFrameworkName(framework));
        // Adjust analysis based on depth setting
        switch (this.settings.analysisDepth) {
            case 'brief':
                // Return first two sentences
                return analysisText.split('. ').slice(0, 2).join('. ') + '.';
            case 'detailed':
                // Return the full analysis plus additional detail
                return analysisText + ` Further exploration of this ${mediaType} through the ${this.getFrameworkName(framework)} framework would reveal additional layers of meaning and significance, particularly in relation to the specific cultural and historical contexts in which it was created and is being interpreted. The theoretical concepts provide a rich vocabulary for articulating the complex dynamics at play in this work.`;
            case 'standard':
            default:
                // Return the full analysis as is
                return analysisText;
        }
    }
    // Generate recommendations based on analyses
    generateRecommendations(frameworkAnalyses) {
        // Generate general recommendations
        const recommendations = [
            "Reflect on recurring patterns and themes that emerged across different theoretical frameworks.",
            "Consider how different perspectives offer complementary insights into the same content.",
            "Explore the relationship between form and content in your creative expression."
        ];
        // Add framework-specific recommendations
        const frameworkRecommendations = {
            [FRAMEWORKS.DELEUZIAN]: [
                "Explore how Deleuzian concepts of rhizomes and assemblages might inform your creative practice.",
                "Consider how lines of flight in your work could open up new possibilities for expression."
            ],
            [FRAMEWORKS.IRIGARAYIAN]: [
                "Reflect on how Irigaray's concept of sexual difference might inform your understanding of subjectivity.",
                "Consider how fluid logic and non-linear expression could enrich your creative work."
            ],
            [FRAMEWORKS.FREUDIAN]: [
                "Consider how unconscious processes might be influencing your creative work.",
                "Explore the symbolic representations of desire in your content."
            ],
            [FRAMEWORKS.LACANIAN]: [
                "Reflect on how language structures your experience and creative expression.",
                "Consider the role of desire and lack in your work."
            ],
            [FRAMEWORKS.JUNGIAN]: [
                "Explore archetypal patterns in your creative work.",
                "Consider how collective unconscious symbols appear in your content."
            ],
            [FRAMEWORKS.EXISTENTIAL]: [
                "Reflect on themes of freedom, choice, and authenticity in your work.",
                "Consider how your creative practice contributes to meaning-making."
            ],
            [FRAMEWORKS.EPICUREAN]: [
                "Consider how your work relates to the pursuit of tranquility and freedom from disturbance.",
                "Explore the role of pleasure and natural desires in your creative expression."
            ]
            // Additional framework recommendations can be added here
        };
        // Add relevant framework-specific recommendations
        Object.keys(frameworkAnalyses).forEach(framework => {
            if (framework in frameworkRecommendations) {
                recommendations.push(...frameworkRecommendations[framework]);
            }
        });
        return recommendations;
    }
    // Get the display name for a framework ID
    getFrameworkName(frameworkId) {
        const names = {
            [FRAMEWORKS.TACKTICAL]: 'Tacktical Methodology',
            [FRAMEWORKS.FREUDIAN]: 'Freudian Psychoanalysis',
            [FRAMEWORKS.LACANIAN]: 'Lacanian Psychoanalysis',
            [FRAMEWORKS.DELEUZIAN]: 'Deleuzian Schizoanalysis',
            [FRAMEWORKS.IRIGARAYIAN]: 'Irigarayian Feminist Theory',
            [FRAMEWORKS.JUNGIAN]: 'Jungian Analytical Psychology',
            [FRAMEWORKS.ATTACHMENT]: 'Attachment Theory',
            [FRAMEWORKS.POSITIVE]: 'Positive Psychology',
            [FRAMEWORKS.NARRATIVE]: 'Narrative Psychology',
            [FRAMEWORKS.PHENOMENOLOGY]: 'Phenomenology',
            [FRAMEWORKS.EXISTENTIAL]: 'Existential Psychology',
            [FRAMEWORKS.FEMINIST]: 'Feminist Theory',
            [FRAMEWORKS.CRITICAL]: 'Critical Theory',
            [FRAMEWORKS.POSTHUMANISM]: 'Posthumanism',
            [FRAMEWORKS.BUDDHIST]: 'Buddhist Psychology',
            [FRAMEWORKS.NIETZSCHEAN]: 'Nietzschean Philosophy',
            [FRAMEWORKS.GESTALT]: 'Gestalt Psychology',
            [FRAMEWORKS.TRANSPERSONAL]: 'Transpersonal Psychology',
            [FRAMEWORKS.CBT]: 'Cognitive Behavioral Therapy',
            [FRAMEWORKS.HERMENEUTICS]: 'Hermeneutics',
            [FRAMEWORKS.STOICISM]: 'Stoicism',
            [FRAMEWORKS.PSYCHIATRY]: 'Psychiatry',
            [FRAMEWORKS.EPICUREAN]: 'Epicurean Philosophy'
        };
        return names[frameworkId] || frameworkId;
    }
}

class DeleometerSettingTab extends obsidian.PluginSettingTab {
    constructor(app, plugin) {
        super(app, plugin);
        this.plugin = plugin;
    }
    display() {
        // @ts-ignore: containerEl is inherited from PluginSettingTab
        const { containerEl } = this;
        containerEl.empty();
        containerEl.createEl('h2', { text: 'Deleometer Settings' });
        // Framework selection section
        containerEl.createEl('h3', { text: 'Theoretical Frameworks' });
        containerEl.createEl('p', { text: 'Enable or disable theoretical frameworks for analysis.' });
        // Create a toggle for each framework
        Object.keys(FRAMEWORKS).forEach(key => {
            const frameworkId = FRAMEWORKS[key];
            const frameworkName = this.plugin.analysisEngine.getFrameworkName(frameworkId);
            new obsidian.Setting(containerEl)
                .setName(frameworkName)
                .setDesc(`Enable ${frameworkName} for analysis`)
                .addToggle(toggle => toggle
                .setValue(this.plugin.settings.enabledFrameworks[frameworkId])
                .onChange(async (value) => {
                this.plugin.settings.enabledFrameworks[frameworkId] = value;
                await this.plugin.saveSettings();
            }));
        });
        // Analysis options section
        containerEl.createEl('h3', { text: 'Analysis Options' });
        new obsidian.Setting(containerEl)
            .setName('Analysis Depth')
            .setDesc('How detailed should the analysis be?')
            .addDropdown(dropdown => dropdown
            .addOption('brief', 'Brief')
            .addOption('standard', 'Standard')
            .addOption('detailed', 'Detailed')
            .setValue(this.plugin.settings.analysisDepth)
            .onChange(async (value) => {
            this.plugin.settings.analysisDepth = value;
            await this.plugin.saveSettings();
        }));
        // Journaling prompts option
        new obsidian.Setting(containerEl)
            .setName('Journaling Prompts')
            .setDesc('Enable personalized journaling prompts based on analysis')
            .addToggle(toggle => toggle
            .setValue(this.plugin.settings.enableJournalingPrompts)
            .onChange(async (value) => {
            this.plugin.settings.enableJournalingPrompts = value;
            await this.plugin.saveSettings();
        }));
        // Auto-open exported files option
        new obsidian.Setting(containerEl)
            .setName('Auto-open Exported Files')
            .setDesc('Automatically open files after exporting analysis results')
            .addToggle(toggle => toggle
            .setValue(this.plugin.settings.autoOpenExportedFiles)
            .onChange(async (value) => {
            this.plugin.settings.autoOpenExportedFiles = value;
            await this.plugin.saveSettings();
        }));
        // OpenAI Integration section
        containerEl.createEl('h3', { text: 'OpenAI Integration' });
        containerEl.createEl('p', { text: 'Configure OpenAI integration for enhanced analysis.' });
        // Analysis tier selection
        new obsidian.Setting(containerEl)
            .setName('Analysis Tier')
            .setDesc('Select your analysis tier')
            .addDropdown(dropdown => dropdown
            .addOption(AnalysisTier.FREE, 'Free (Predefined Analyses)')
            .addOption(AnalysisTier.PREMIUM, 'Premium (OpenAI-Powered)')
            .setValue(this.plugin.settings.analysisTier)
            .onChange(async (value) => {
            this.plugin.settings.analysisTier = value;
            // If switching to premium, make sure OpenAI is enabled
            if (value === AnalysisTier.PREMIUM) {
                this.plugin.settings.enableOpenAI = true;
                // Check if API key is configured
                if (!this.plugin.settings.openaiApiKey) {
                    new obsidian.Notice('Please enter your OpenAI API key to use the Premium tier');
                }
            }
            await this.plugin.saveSettings();
        }));
        // Enable OpenAI toggle
        new obsidian.Setting(containerEl)
            .setName('Enable OpenAI')
            .setDesc('Use OpenAI for enhanced analysis (requires API key)')
            .addToggle(toggle => toggle
            .setValue(this.plugin.settings.enableOpenAI)
            .onChange(async (value) => {
            this.plugin.settings.enableOpenAI = value;
            // If disabling OpenAI, switch to free tier
            if (!value && this.plugin.settings.analysisTier === AnalysisTier.PREMIUM) {
                this.plugin.settings.analysisTier = AnalysisTier.FREE;
                new obsidian.Notice('Switched to Free tier as OpenAI integration was disabled');
            }
            await this.plugin.saveSettings();
        }));
        // OpenAI API Key
        new obsidian.Setting(containerEl)
            .setName('OpenAI API Key')
            .setDesc('Your OpenAI API key (stored locally)')
            .addText(text => text
            .setPlaceholder('sk-...')
            .setValue(this.plugin.settings.openaiApiKey)
            .onChanged(async (value) => {
            this.plugin.settings.openaiApiKey = value;
            await this.plugin.saveSettings();
            // Update the OpenAI service configuration
            if (this.plugin.openaiService) {
                this.plugin.openaiService.updateConfig(this.plugin.settings);
            }
        }));
        // OpenAI Model selection
        new obsidian.Setting(containerEl)
            .setName('OpenAI Model')
            .setDesc('Select which OpenAI model to use')
            .addDropdown(dropdown => dropdown
            .addOption(OpenAIModel.GPT_3_5, 'GPT-3.5 Turbo (Faster, cheaper)')
            .addOption(OpenAIModel.GPT_4, 'GPT-4 (More advanced, more expensive)')
            .setValue(this.plugin.settings.openaiModel)
            .onChange(async (value) => {
            this.plugin.settings.openaiModel = value;
            await this.plugin.saveSettings();
            // Update the OpenAI service configuration
            if (this.plugin.openaiService) {
                this.plugin.openaiService.updateConfig(this.plugin.settings);
            }
        }));
        // Usage limit
        new obsidian.Setting(containerEl)
            .setName('Monthly Usage Limit')
            .setDesc('Maximum number of OpenAI analyses per month')
            .addSlider(slider => slider
            .setLimits(10, 500, 10)
            .setValue(this.plugin.settings.openaiUsageLimit)
            .onChange(async (value) => {
            this.plugin.settings.openaiUsageLimit = value;
            await this.plugin.saveSettings();
        }));
        // Usage statistics
        const usageCount = this.plugin.settings.openaiUsageCount;
        const usageLimit = this.plugin.settings.openaiUsageLimit;
        const usagePercent = Math.round((usageCount / usageLimit) * 100);
        new obsidian.Setting(containerEl)
            .setName('Usage Statistics')
            .setDesc(`You've used ${usageCount}/${usageLimit} analyses this month (${usagePercent}%)`)
            .addButton(button => button
            .setButtonText('Reset Usage Counter')
            .onClick(async () => {
            this.plugin.settings.openaiUsageCount = 0;
            this.plugin.settings.openaiLastReset = Date.now();
            await this.plugin.saveSettings();
            new obsidian.Notice('Usage counter has been reset');
            this.display(); // Refresh the settings tab
        }));
    }
}

class UnifiedAnalysisModal {
    constructor(app, plugin) {
        this.selectedFrameworks = [];
        this.selectedMediaType = MEDIA_TYPES.TEXT;
        this.content = '';
        this.file = null;
        this.app = app;
        this.plugin = plugin;
        this.modal = new obsidian.Modal(app);
        this.contentEl = this.modal.contentEl;
        // Initialize with enabled frameworks from settings
        this.selectedFrameworks = Object.entries(this.plugin.settings.enabledFrameworks)
            .filter(([_, enabled]) => enabled)
            .map(([framework, _]) => framework);
    }
    open() {
        this.modal.open();
        this.onOpen();
    }
    close() {
        this.onClose();
        this.modal.close();
    }
    onOpen() {
        this.contentEl.empty();
        this.contentEl.createEl('h2', { text: 'Theoretical Analysis' });
        // Media type selection
        new obsidian.Setting(this.contentEl)
            .setName('Media Type')
            .setDesc('Select the type of content to analyze')
            .addDropdown(dropdown => {
            dropdown
                .addOption(MEDIA_TYPES.TEXT, 'Text')
                .addOption(MEDIA_TYPES.IMAGE, 'Image')
                .addOption(MEDIA_TYPES.AUDIO, 'Audio')
                .addOption(MEDIA_TYPES.FILM, 'Film/Video')
                .setValue(this.selectedMediaType)
                .onChange(value => {
                this.selectedMediaType = value;
            });
        });
        // Framework selection
        const frameworksContainer = this.contentEl.createDiv({ cls: 'deleometer-frameworks' });
        frameworksContainer.createEl('h3', { text: 'Select Frameworks' });
        // Create a checkbox for each framework
        Object.keys(FRAMEWORKS).forEach(key => {
            const frameworkId = FRAMEWORKS[key];
            const frameworkName = this.plugin.analysisEngine.getFrameworkName(frameworkId);
            new obsidian.Setting(frameworksContainer)
                .setName(frameworkName)
                .addToggle(toggle => {
                toggle
                    .setValue(this.selectedFrameworks.includes(frameworkId))
                    .onChange(value => {
                    if (value) {
                        // Add to selected frameworks
                        if (!this.selectedFrameworks.includes(frameworkId)) {
                            this.selectedFrameworks.push(frameworkId);
                        }
                    }
                    else {
                        // Remove from selected frameworks
                        this.selectedFrameworks = this.selectedFrameworks.filter(id => id !== frameworkId);
                    }
                });
            });
        });
        // Add buttons
        const buttonContainer = this.contentEl.createDiv({ cls: 'deleometer-buttons' });
        // Select All button
        buttonContainer.createEl('button', { text: 'Select All' })
            .addEventListener('click', () => {
            this.selectedFrameworks = Object.keys(FRAMEWORKS).map(key => FRAMEWORKS[key]);
            this.close();
            this.open();
        });
        // Deselect All button
        buttonContainer.createEl('button', { text: 'Deselect All' })
            .addEventListener('click', () => {
            this.selectedFrameworks = [];
            this.close();
            this.open();
        });
        // Analyze button
        buttonContainer.createEl('button', { text: 'Analyze', cls: 'mod-cta' })
            .addEventListener('click', () => {
            this.analyze();
        });
    }
    onClose() {
        this.contentEl.empty();
    }
    // Analyze the current content
    analyze() {
        var _a, _b;
        if (this.selectedFrameworks.length === 0) {
            // Show error if no frameworks selected
            new obsidian.Notice('Please select at least one framework for analysis.');
            return;
        }
        try {
            // Get the active file or editor content
            const activeFile = this.app.workspace.getActiveFile();
            if (this.selectedMediaType === MEDIA_TYPES.TEXT) {
                // For text, get the content from the editor
                const activeLeaf = this.app.workspace.activeLeaf;
                const editor = (_b = (_a = activeLeaf === null || activeLeaf === void 0 ? void 0 : activeLeaf.view) === null || _a === void 0 ? void 0 : _a.sourceMode) === null || _b === void 0 ? void 0 : _b.cmEditor;
                if (editor) {
                    const content = editor.getValue();
                    this.close();
                    this.plugin.analyzeContent(content, MEDIA_TYPES.TEXT);
                }
                else if (activeFile) {
                    // If no editor but there's an active file, use the file
                    this.close();
                    this.plugin.analyzeContent(activeFile, this.selectedMediaType);
                }
                else {
                    new obsidian.Notice('No content to analyze. Please open a file or enter text.');
                }
            }
            else {
                // For other media types, we need a file
                if (activeFile) {
                    // Check if the file type matches the selected media type
                    const fileExtension = activeFile.extension.toLowerCase();
                    const isValidFile = this.isValidFileForMediaType(fileExtension, this.selectedMediaType);
                    if (isValidFile) {
                        this.close();
                        this.plugin.analyzeContent(activeFile, this.selectedMediaType);
                    }
                    else {
                        new obsidian.Notice(`The current file is not a valid ${this.selectedMediaType} file.`);
                    }
                }
                else {
                    new obsidian.Notice(`Please open a ${this.selectedMediaType} file to analyze.`);
                }
            }
        }
        catch (error) {
            console.error('Error in analyze:', error);
            new obsidian.Notice('An error occurred during analysis. Check the console for details.');
        }
    }
    // Check if a file extension is valid for the selected media type
    isValidFileForMediaType(extension, mediaType) {
        switch (mediaType) {
            case MEDIA_TYPES.IMAGE:
                return ['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'].includes(extension);
            case MEDIA_TYPES.AUDIO:
                return ['mp3', 'wav', 'ogg', 'm4a', 'flac'].includes(extension);
            case MEDIA_TYPES.FILM:
                return ['mp4', 'webm', 'mov', 'avi', 'mkv'].includes(extension);
            case MEDIA_TYPES.TEXT:
                return ['md', 'txt', 'html', 'css', 'js', 'ts', 'json'].includes(extension);
            default:
                return false;
        }
    }
}

/**
 * TypeScript helpers for async/await and other ES features
 */
// Helper for async/await
function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try {
            step(generator.next(value));
        }
        catch (e) {
            reject(e);
        } }
        function rejected(value) { try {
            step(generator["throw"](value));
        }
        catch (e) {
            reject(e);
        } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

class DeleometerPlugin extends obsidian.Plugin {
    constructor() {
        super(...arguments);
        this.openaiService = null;
    }
    onload() {
        return __awaiter(this, void 0, void 0, function* () {
            console.log('Loading Deleometer plugin');
            // Load settings
            yield this.loadSettings();
            // Initialize analysis engine
            this.analysisEngine = new AnalysisEngine(this.app, this.settings);
            // Initialize OpenAI service if enabled
            if (this.settings.enableOpenAI) {
                this.openaiService = new OpenAIService(this.settings);
            }
            // Check if we need to reset the monthly usage counter
            this.checkMonthlyReset();
            // Add ribbon icon
            const ribbonIconEl = this.addRibbonIcon('leaf', 'Deleometer', (_) => {
                // Called when the user clicks the icon.
                this.analyzeCurrentFile();
            });
            // Specify a tooltip for the ribbon icon
            ribbonIconEl.addClass('deleometer-ribbon-class');
            // Add command to analyze current file
            this.addCommand({
                id: 'analyze-current-file',
                name: 'Analyze Current File',
                callback: () => {
                    this.analyzeCurrentFile();
                }
            });
            // Add command to analyze selected text
            this.addCommand({
                id: 'analyze-selected-text',
                name: 'Analyze Selected Text',
                editorCallback: (editor, _) => {
                    const selectedText = editor.getSelection();
                    if (selectedText) {
                        this.analyzeContent(selectedText, MEDIA_TYPES.TEXT);
                    }
                    else {
                        new obsidian.Notice('No text selected');
                    }
                }
            });
            // Add settings tab
            this.addSettingTab(new DeleometerSettingTab(this.app, this));
            // Add command to open the unified analysis modal
            this.addCommand({
                id: 'open-unified-analysis',
                name: 'Open Unified Analysis',
                callback: () => {
                    this.showUnifiedAnalysisModal();
                }
            });
        });
    }
    onunload() {
        console.log('Unloading Deleometer plugin');
    }
    loadSettings() {
        return __awaiter(this, void 0, void 0, function* () {
            const data = yield this.loadData();
            this.settings = Object.assign({}, DEFAULT_SETTINGS, data);
        });
    }
    saveSettings() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.saveData(this.settings);
            // Update the analysis engine with new settings
            this.analysisEngine.updateConfig(this.settings);
            // Update OpenAI service if needed
            if (this.settings.enableOpenAI) {
                if (this.openaiService) {
                    this.openaiService.updateConfig(this.settings);
                }
                else {
                    this.openaiService = new OpenAIService(this.settings);
                }
            }
            else {
                this.openaiService = null;
            }
        });
    }
    // Check if we need to reset the monthly usage counter
    checkMonthlyReset() {
        const now = Date.now();
        const lastReset = this.settings.openaiLastReset;
        const oneMonthMs = 30 * 24 * 60 * 60 * 1000; // 30 days in milliseconds
        // If it's been more than a month since the last reset, reset the counter
        if (now - lastReset > oneMonthMs) {
            this.settings.openaiUsageCount = 0;
            this.settings.openaiLastReset = now;
            this.saveSettings();
        }
    }
    // Analyze the current active file
    analyzeCurrentFile() {
        return __awaiter(this, void 0, void 0, function* () {
            const activeFile = this.app.workspace.getActiveFile();
            if (!activeFile) {
                // No active file
                new obsidian.Notice('No active file to analyze');
                return;
            }
            // Determine media type based on file extension
            const mediaType = this.getMediaTypeFromFile(activeFile);
            if (mediaType === MEDIA_TYPES.TEXT) {
                // For text files, get the content
                const content = yield this.app.vault.read(activeFile);
                this.analyzeContent(content, mediaType, activeFile);
            }
            else {
                // For other media types, pass the file directly
                this.analyzeContent(activeFile, mediaType);
            }
        });
    }
    // Determine media type from file extension
    getMediaTypeFromFile(file) {
        const extension = file.extension.toLowerCase();
        if (['md', 'txt', 'text'].includes(extension)) {
            return MEDIA_TYPES.TEXT;
        }
        else if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg'].includes(extension)) {
            return MEDIA_TYPES.IMAGE;
        }
        else if (['mp3', 'wav', 'ogg', 'flac', 'm4a'].includes(extension)) {
            return MEDIA_TYPES.AUDIO;
        }
        else if (['mp4', 'webm', 'mov', 'avi', 'mkv'].includes(extension)) {
            return MEDIA_TYPES.FILM;
        }
        else {
            // Default to text for unknown types
            return MEDIA_TYPES.TEXT;
        }
    }
    // Analyze content with the analysis engine
    analyzeContent(content, mediaType, file) {
        return __awaiter(this, void 0, void 0, function* () {
            // Get enabled frameworks from settings
            const enabledFrameworks = Object.entries(this.settings.enabledFrameworks)
                .filter(([_, enabled]) => enabled)
                .map(([framework, _]) => framework);
            if (enabledFrameworks.length === 0) {
                new obsidian.Notice('No analysis frameworks are enabled. Please enable at least one framework in settings.');
                return;
            }
            try {
                // Show loading notice
                new obsidian.Notice('Analyzing content...');
                // Analyze the content
                const result = this.analysisEngine.analyzeContent(content, mediaType, enabledFrameworks);
                // Display results
                this.displayAnalysisResults(result, file);
            }
            catch (error) {
                console.error('Error analyzing content:', error);
                new obsidian.Notice('Error analyzing content. Check console for details.');
            }
        });
    }
    // Display analysis results
    displayAnalysisResults(result, file) {
        // Create a markdown string with the analysis results
        let markdown = `# Deleometer Analysis\n\n`;
        // Add file name if available
        if (result.fileName) {
            markdown += `**File:** ${result.fileName}\n\n`;
        }
        else if (file) {
            markdown += `**File:** ${file.path}\n\n`;
        }
        // Add media type
        markdown += `**Media Type:** ${result.mediaType}\n\n`;
        // Add summary
        markdown += `## Summary\n\n${result.summary}\n\n`;
        // Add framework analyses
        markdown += `## Framework Analyses\n\n`;
        for (const [framework, analysis] of Object.entries(result.frameworkAnalyses)) {
            const frameworkName = this.analysisEngine.getFrameworkName(framework);
            markdown += `### ${frameworkName}\n\n${analysis}\n\n`;
        }
        // Add recommendations if available
        if (result.recommendations && result.recommendations.length > 0) {
            markdown += `## Recommendations\n\n`;
            for (const recommendation of result.recommendations) {
                markdown += `- ${recommendation}\n`;
            }
        }
        // Create a new leaf to display the results
        const leaf = this.app.workspace.getLeaf(true);
        // Set the leaf view to markdown
        leaf.setViewState({
            type: 'markdown',
            state: {
                mode: 'preview',
                source: markdown
            }
        });
    }
    // Show the unified analysis modal
    showUnifiedAnalysisModal() {
        const modal = new UnifiedAnalysisModal(this.app, this);
        modal.open();
    }
}

module.exports = DeleometerPlugin;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFpbi5qcyIsInNvdXJjZXMiOlsiLi4vc3JjL2NvbnN0YW50cy50cyIsIi4uL3NyYy9mcmFtZXdvcmtzL2RlbGV1emlhbi50cyIsIi4uL3NyYy9mcmFtZXdvcmtzL2lyaWdhcmF5aWFuLnRzIiwiLi4vc3JjL2ZyYW1ld29ya3MvdGFja3RpY2FsLnRzIiwiLi4vc3JjL2ZyYW1ld29ya3MvZnJldWRpYW4udHMiLCIuLi9zcmMvZnJhbWV3b3Jrcy9sYWNhbmlhbi50cyIsIi4uL3NyYy9mcmFtZXdvcmtzL2p1bmdpYW4udHMiLCIuLi9zcmMvZnJhbWV3b3Jrcy9hdHRhY2htZW50LnRzIiwiLi4vc3JjL2ZyYW1ld29ya3MvcG9zaXRpdmUudHMiLCIuLi9zcmMvZnJhbWV3b3Jrcy9uYXJyYXRpdmUudHMiLCIuLi9zcmMvZnJhbWV3b3Jrcy9waGVub21lbm9sb2d5LnRzIiwiLi4vc3JjL2ZyYW1ld29ya3MvZXhpc3RlbnRpYWwudHMiLCIuLi9zcmMvZnJhbWV3b3Jrcy9mZW1pbmlzdC50cyIsIi4uL3NyYy9mcmFtZXdvcmtzL2NyaXRpY2FsLnRzIiwiLi4vc3JjL2ZyYW1ld29ya3MvcG9zdGh1bWFuaXNtLnRzIiwiLi4vc3JjL2ZyYW1ld29ya3MvYnVkZGhpc3QudHMiLCIuLi9zcmMvZnJhbWV3b3Jrcy9uaWV0enNjaGVhbi50cyIsIi4uL3NyYy9mcmFtZXdvcmtzL2dlc3RhbHQudHMiLCIuLi9zcmMvZnJhbWV3b3Jrcy90cmFuc3BlcnNvbmFsLnRzIiwiLi4vc3JjL2ZyYW1ld29ya3MvY2J0LnRzIiwiLi4vc3JjL2ZyYW1ld29ya3MvaGVybWVuZXV0aWNzLnRzIiwiLi4vc3JjL2ZyYW1ld29ya3Mvc3RvaWNpc20udHMiLCIuLi9zcmMvZnJhbWV3b3Jrcy9wc3ljaGlhdHJ5LnRzIiwiLi4vc3JjL2ZyYW1ld29ya3MvZXBpY3VyZWFuLnRzIiwiLi4vc3JjL2ZyYW1ld29ya3MvaW5kZXgudHMiLCIuLi9zcmMvcHJlZGVmaW5lZC1hbmFseXNlcy9kZWxldXppYW4udHMiLCIuLi9zcmMvcHJlZGVmaW5lZC1hbmFseXNlcy9pcmlnYXJheWlhbi50cyIsIi4uL3NyYy9wcmVkZWZpbmVkLWFuYWx5c2VzL2ZyZXVkaWFuLnRzIiwiLi4vc3JjL3ByZWRlZmluZWQtYW5hbHlzZXMvbGFjYW5pYW4udHMiLCIuLi9zcmMvcHJlZGVmaW5lZC1hbmFseXNlcy9lcGljdXJlYW4udHMiLCIuLi9zcmMvcHJlZGVmaW5lZC1hbmFseXNlcy9hdHRhY2htZW50LnRzIiwiLi4vc3JjL3ByZWRlZmluZWQtYW5hbHlzZXMvYnVkZGhpc3QudHMiLCIuLi9zcmMvcHJlZGVmaW5lZC1hbmFseXNlcy9jYnQudHMiLCIuLi9zcmMvcHJlZGVmaW5lZC1hbmFseXNlcy9jcml0aWNhbC50cyIsIi4uL3NyYy9wcmVkZWZpbmVkLWFuYWx5c2VzL2V4aXN0ZW50aWFsLnRzIiwiLi4vc3JjL3ByZWRlZmluZWQtYW5hbHlzZXMvZmVtaW5pc3QudHMiLCIuLi9zcmMvcHJlZGVmaW5lZC1hbmFseXNlcy9nZXN0YWx0LnRzIiwiLi4vc3JjL3ByZWRlZmluZWQtYW5hbHlzZXMvaGVybWVuZXV0aWNzLnRzIiwiLi4vc3JjL3ByZWRlZmluZWQtYW5hbHlzZXMvanVuZ2lhbi50cyIsIi4uL3NyYy9wcmVkZWZpbmVkLWFuYWx5c2VzL25hcnJhdGl2ZS50cyIsIi4uL3NyYy9wcmVkZWZpbmVkLWFuYWx5c2VzL25pZXR6c2NoZWFuLnRzIiwiLi4vc3JjL3ByZWRlZmluZWQtYW5hbHlzZXMvcGhlbm9tZW5vbG9neS50cyIsIi4uL3NyYy9wcmVkZWZpbmVkLWFuYWx5c2VzL3Bvc2l0aXZlLnRzIiwiLi4vc3JjL3ByZWRlZmluZWQtYW5hbHlzZXMvcG9zdGh1bWFuaXNtLnRzIiwiLi4vc3JjL3ByZWRlZmluZWQtYW5hbHlzZXMvcHN5Y2hpYXRyeS50cyIsIi4uL3NyYy9wcmVkZWZpbmVkLWFuYWx5c2VzL3N0b2ljaXNtLnRzIiwiLi4vc3JjL3ByZWRlZmluZWQtYW5hbHlzZXMvdGFja3RpY2FsLnRzIiwiLi4vc3JjL3ByZWRlZmluZWQtYW5hbHlzZXMvdHJhbnNwZXJzb25hbC50cyIsIi4uL3NyYy9wcmVkZWZpbmVkLWFuYWx5c2VzL2luZGV4LnRzIiwiLi4vc3JjL3NlcnZpY2VzL29wZW5haS1zZXJ2aWNlLnRzIiwiLi4vc3JjL2FuYWx5c2lzLWVuZ2luZS50cyIsIi4uL3NyYy9zZXR0aW5ncy10YWIudHMiLCIuLi9zcmMvdW5pZmllZC1hbmFseXNpcy1tb2RhbC50cyIsIi4uL3NyYy90c2xpYi50cyIsIi4uL3NyYy9tYWluLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIENvbnN0YW50cyBmb3IgZnJhbWV3b3JrIElEc1xuZXhwb3J0IGNvbnN0IEZSQU1FV09SS1MgPSB7XG4gICAgVEFDS1RJQ0FMOiAndGFja3RpY2FsJyxcbiAgICBGUkVVRElBTjogJ2ZyZXVkaWFuJyxcbiAgICBMQUNBTklBTjogJ2xhY2FuaWFuJyxcbiAgICBERUxFVVpJQU46ICdkZWxldXppYW4nLFxuICAgIElSSUdBUkFZSUFOOiAnaXJpZ2FyYXlpYW4nLFxuICAgIEpVTkdJQU46ICdqdW5naWFuJyxcbiAgICBBVFRBQ0hNRU5UOiAnYXR0YWNobWVudCcsXG4gICAgUE9TSVRJVkU6ICdwb3NpdGl2ZScsXG4gICAgTkFSUkFUSVZFOiAnbmFycmF0aXZlJyxcbiAgICBQSEVOT01FTk9MT0dZOiAncGhlbm9tZW5vbG9neScsXG4gICAgRVhJU1RFTlRJQUw6ICdleGlzdGVudGlhbCcsXG4gICAgRkVNSU5JU1Q6ICdmZW1pbmlzdCcsXG4gICAgQ1JJVElDQUw6ICdjcml0aWNhbCcsXG4gICAgUE9TVEhVTUFOSVNNOiAncG9zdGh1bWFuaXNtJyxcbiAgICBCVURESElTVDogJ2J1ZGRoaXN0JyxcbiAgICBOSUVUWlNDSEVBTjogJ25pZXR6c2NoZWFuJyxcbiAgICBHRVNUQUxUOiAnZ2VzdGFsdCcsXG4gICAgVFJBTlNQRVJTT05BTDogJ3RyYW5zcGVyc29uYWwnLFxuICAgIENCVDogJ2NidCcsXG4gICAgSEVSTUVORVVUSUNTOiAnaGVybWVuZXV0aWNzJyxcbiAgICBTVE9JQ0lTTTogJ3N0b2ljaXNtJyxcbiAgICBQU1lDSElBVFJZOiAncHN5Y2hpYXRyeScsXG4gICAgRVBJQ1VSRUFOOiAnZXBpY3VyZWFuJ1xufTtcbi8vIENvbnN0YW50cyBmb3IgbWVkaWEgdHlwZXNcbmV4cG9ydCBjb25zdCBNRURJQV9UWVBFUyA9IHtcbiAgICBURVhUOiAndGV4dCcsXG4gICAgSU1BR0U6ICdpbWFnZScsXG4gICAgQVVESU86ICdhdWRpbycsXG4gICAgRklMTTogJ2ZpbG0nXG59O1xuLy8gVGllciBvcHRpb25zXG5leHBvcnQgdmFyIEFuYWx5c2lzVGllcjtcbihmdW5jdGlvbiAoQW5hbHlzaXNUaWVyKSB7XG4gICAgQW5hbHlzaXNUaWVyW1wiRlJFRVwiXSA9IFwiZnJlZVwiO1xuICAgIEFuYWx5c2lzVGllcltcIlBSRU1JVU1cIl0gPSBcInByZW1pdW1cIjtcbn0pKEFuYWx5c2lzVGllciB8fCAoQW5hbHlzaXNUaWVyID0ge30pKTtcbi8vIE9wZW5BSSBtb2RlbCBvcHRpb25zXG5leHBvcnQgdmFyIE9wZW5BSU1vZGVsO1xuKGZ1bmN0aW9uIChPcGVuQUlNb2RlbCkge1xuICAgIE9wZW5BSU1vZGVsW1wiR1BUXzNfNVwiXSA9IFwiZ3B0LTMuNS10dXJib1wiO1xuICAgIE9wZW5BSU1vZGVsW1wiR1BUXzRcIl0gPSBcImdwdC00XCI7XG59KShPcGVuQUlNb2RlbCB8fCAoT3BlbkFJTW9kZWwgPSB7fSkpO1xuLy8gRGVmYXVsdCBwbHVnaW4gc2V0dGluZ3NcbmV4cG9ydCBjb25zdCBERUZBVUxUX1NFVFRJTkdTID0ge1xuICAgIGVuYWJsZWRGcmFtZXdvcmtzOiB7XG4gICAgICAgIFtGUkFNRVdPUktTLlRBQ0tUSUNBTF06IHRydWUsXG4gICAgICAgIFtGUkFNRVdPUktTLkZSRVVESUFOXTogdHJ1ZSxcbiAgICAgICAgW0ZSQU1FV09SS1MuTEFDQU5JQU5dOiB0cnVlLFxuICAgICAgICBbRlJBTUVXT1JLUy5ERUxFVVpJQU5dOiB0cnVlLFxuICAgICAgICBbRlJBTUVXT1JLUy5JUklHQVJBWUlBTl06IHRydWUsXG4gICAgICAgIFtGUkFNRVdPUktTLkpVTkdJQU5dOiB0cnVlLFxuICAgICAgICBbRlJBTUVXT1JLUy5BVFRBQ0hNRU5UXTogdHJ1ZSxcbiAgICAgICAgW0ZSQU1FV09SS1MuUE9TSVRJVkVdOiB0cnVlLFxuICAgICAgICBbRlJBTUVXT1JLUy5OQVJSQVRJVkVdOiB0cnVlLFxuICAgICAgICBbRlJBTUVXT1JLUy5QSEVOT01FTk9MT0dZXTogdHJ1ZSxcbiAgICAgICAgW0ZSQU1FV09SS1MuRVhJU1RFTlRJQUxdOiB0cnVlLFxuICAgICAgICBbRlJBTUVXT1JLUy5GRU1JTklTVF06IHRydWUsXG4gICAgICAgIFtGUkFNRVdPUktTLkNSSVRJQ0FMXTogdHJ1ZSxcbiAgICAgICAgW0ZSQU1FV09SS1MuUE9TVEhVTUFOSVNNXTogdHJ1ZSxcbiAgICAgICAgW0ZSQU1FV09SS1MuQlVEREhJU1RdOiB0cnVlLFxuICAgICAgICBbRlJBTUVXT1JLUy5OSUVUWlNDSEVBTl06IHRydWUsXG4gICAgICAgIFtGUkFNRVdPUktTLkdFU1RBTFRdOiB0cnVlLFxuICAgICAgICBbRlJBTUVXT1JLUy5UUkFOU1BFUlNPTkFMXTogdHJ1ZSxcbiAgICAgICAgW0ZSQU1FV09SS1MuQ0JUXTogdHJ1ZSxcbiAgICAgICAgW0ZSQU1FV09SS1MuSEVSTUVORVVUSUNTXTogdHJ1ZSxcbiAgICAgICAgW0ZSQU1FV09SS1MuU1RPSUNJU01dOiB0cnVlLFxuICAgICAgICBbRlJBTUVXT1JLUy5QU1lDSElBVFJZXTogdHJ1ZSxcbiAgICAgICAgW0ZSQU1FV09SS1MuRVBJQ1VSRUFOXTogdHJ1ZVxuICAgIH0sXG4gICAgYW5hbHlzaXNEZXB0aDogJ3N0YW5kYXJkJyxcbiAgICBlbmFibGVKb3VybmFsaW5nUHJvbXB0czogdHJ1ZSxcbiAgICBhdXRvT3BlbkV4cG9ydGVkRmlsZXM6IHRydWUsXG4gICAgYW5hbHlzaXNUaWVyOiBBbmFseXNpc1RpZXIuRlJFRSxcbiAgICBlbmFibGVPcGVuQUk6IGZhbHNlLFxuICAgIG9wZW5haUFwaUtleTogJycsXG4gICAgb3BlbmFpTW9kZWw6IE9wZW5BSU1vZGVsLkdQVF8zXzUsXG4gICAgb3BlbmFpVXNhZ2VMaW1pdDogNTAsXG4gICAgb3BlbmFpVXNhZ2VDb3VudDogMCxcbiAgICBvcGVuYWlMYXN0UmVzZXQ6IERhdGUubm93KClcbn07XG4iLCJpbXBvcnQgeyBNRURJQV9UWVBFUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG5leHBvcnQgY2xhc3MgRGVsZXV6aWFuQW5hbHlzaXMge1xuICAgIC8qKlxuICAgICAqIEFuYWx5emUgY29udGVudCB1c2luZyBEZWxldXppYW4gc2NoaXpvYW5hbHlzaXNcbiAgICAgKi9cbiAgICBhbmFseXplQ29udGVudChjb250ZW50LCBtZWRpYVR5cGUpIHtcbiAgICAgICAgc3dpdGNoIChtZWRpYVR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgTUVESUFfVFlQRVMuVEVYVDpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5hbmFseXplVGV4dChjb250ZW50KTtcbiAgICAgICAgICAgIGNhc2UgTUVESUFfVFlQRVMuSU1BR0U6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuYW5hbHl6ZUltYWdlKGNvbnRlbnQpO1xuICAgICAgICAgICAgY2FzZSBNRURJQV9UWVBFUy5BVURJTzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5hbmFseXplQXVkaW8oY29udGVudCk7XG4gICAgICAgICAgICBjYXNlIE1FRElBX1RZUEVTLkZJTE06XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuYW5hbHl6ZUZpbG0oY29udGVudCk7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5zdXBwb3J0ZWQgbWVkaWEgdHlwZSBmb3IgRGVsZXV6aWFuIGFuYWx5c2lzOiAke21lZGlhVHlwZX1gKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvKipcbiAgICAgKiBBbmFseXplIHRleHQgY29udGVudCB1c2luZyBEZWxldXppYW4gY29uY2VwdHNcbiAgICAgKi9cbiAgICBhbmFseXplVGV4dCh0ZXh0KSB7XG4gICAgICAgIC8vIEV4dHJhY3Qga2V5IHBhdHRlcm5zIGFuZCB0aGVtZXNcbiAgICAgICAgY29uc3QgdGhlbWVzID0gdGhpcy5leHRyYWN0VGhlbWVzKHRleHQpO1xuICAgICAgICBjb25zdCBlbW90aW9uYWxQYXR0ZXJucyA9IHRoaXMuYW5hbHl6ZUVtb3Rpb25hbFBhdHRlcm5zKHRleHQpO1xuICAgICAgICBjb25zdCBuYXJyYXRpdmVTdHJ1Y3R1cmUgPSB0aGlzLmFuYWx5emVOYXJyYXRpdmVTdHJ1Y3R1cmUodGV4dCk7XG4gICAgICAgIC8vIElkZW50aWZ5IHJoaXpvbWF0aWMgY29ubmVjdGlvbnNcbiAgICAgICAgY29uc3Qgcmhpem9tYXRpY0Nvbm5lY3Rpb25zID0gdGhpcy5pZGVudGlmeVJoaXpvbWF0aWNDb25uZWN0aW9ucyh0ZXh0LCB0aGVtZXMpO1xuICAgICAgICAvLyBJZGVudGlmeSBhc3NlbWJsYWdlc1xuICAgICAgICBjb25zdCBhc3NlbWJsYWdlcyA9IHRoaXMuaWRlbnRpZnlBc3NlbWJsYWdlcyh0ZXh0LCB0aGVtZXMsIGVtb3Rpb25hbFBhdHRlcm5zKTtcbiAgICAgICAgLy8gSWRlbnRpZnkgZGV0ZXJyaXRvcmlhbGl6YXRpb25zXG4gICAgICAgIGNvbnN0IGRldGVycml0b3JpYWxpemF0aW9ucyA9IHRoaXMuaWRlbnRpZnlEZXRlcnJpdG9yaWFsaXphdGlvbnModGV4dCk7XG4gICAgICAgIC8vIEFuYWx5emUgbGluZXMgKG1vbGFyLCBtb2xlY3VsYXIsIGZsaWdodClcbiAgICAgICAgY29uc3QgbGluZXMgPSB0aGlzLmFuYWx5emVMaW5lcyh0ZXh0KTtcbiAgICAgICAgLy8gQW5hbHl6ZSBkZXNpcmluZy1wcm9kdWN0aW9uXG4gICAgICAgIGNvbnN0IGRlc2lyaW5nID0gdGhpcy5hbmFseXplRGVzaXJpbmcodGV4dCk7XG4gICAgICAgIC8vIElkZW50aWZ5IHRoZSBib2R5IHdpdGhvdXQgb3JnYW5zXG4gICAgICAgIGNvbnN0IGJvZHlXaXRob3V0T3JnYW5zID0gdGhpcy5pZGVudGlmeUJvZHlXaXRob3V0T3JnYW5zKHRleHQsIG5hcnJhdGl2ZVN0cnVjdHVyZSk7XG4gICAgICAgIC8vIEdlbmVyYXRlIHN1bW1hcnlcbiAgICAgICAgY29uc3Qgc3VtbWFyeSA9IHRoaXMuZ2VuZXJhdGVTdW1tYXJ5KHJoaXpvbWF0aWNDb25uZWN0aW9ucywgYXNzZW1ibGFnZXMsIGRldGVycml0b3JpYWxpemF0aW9ucywgbGluZXMsIGRlc2lyaW5nLCBib2R5V2l0aG91dE9yZ2Fucyk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByaGl6b21hdGljQ29ubmVjdGlvbnMsXG4gICAgICAgICAgICBhc3NlbWJsYWdlcyxcbiAgICAgICAgICAgIGRldGVycml0b3JpYWxpemF0aW9ucyxcbiAgICAgICAgICAgIGxpbmVzLFxuICAgICAgICAgICAgZGVzaXJpbmcsXG4gICAgICAgICAgICBib2R5V2l0aG91dE9yZ2FucyxcbiAgICAgICAgICAgIHN1bW1hcnlcbiAgICAgICAgfTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQW5hbHl6ZSBpbWFnZSBjb250ZW50IHVzaW5nIERlbGV1emlhbiBjb25jZXB0c1xuICAgICAqL1xuICAgIGFuYWx5emVJbWFnZShmaWxlKSB7XG4gICAgICAgIC8vIEZvciBpbWFnZXMsIHdlJ2xsIGNyZWF0ZSBhIHBsYWNlaG9sZGVyIGFuYWx5c2lzIGJhc2VkIG9uIHRoZSBmaWxlbmFtZVxuICAgICAgICAvLyBJbiBhIHJlYWwgaW1wbGVtZW50YXRpb24sIHRoaXMgd291bGQgYW5hbHl6ZSB0aGUgYWN0dWFsIGltYWdlIGNvbnRlbnRcbiAgICAgICAgY29uc3QgZmlsZU5hbWUgPSBmaWxlLm5hbWU7XG4gICAgICAgIGNvbnN0IHJoaXpvbWF0aWNDb25uZWN0aW9ucyA9IFtcbiAgICAgICAgICAgIFwiVmlzdWFsIGVsZW1lbnRzIGZvcm0gbm9uLWhpZXJhcmNoaWNhbCBjb25uZWN0aW9ucyBhY3Jvc3MgdGhlIGltYWdlIHBsYW5lXCIsXG4gICAgICAgICAgICBcIkNvbG9yIHJlbGF0aW9uc2hpcHMgY3JlYXRlIHVuZXhwZWN0ZWQgcGF0aHdheXMgb2YgYXNzb2NpYXRpb25cIixcbiAgICAgICAgICAgIFwiRm9ybWFsIGVsZW1lbnRzIGNvbm5lY3QgdG8gY3VsdHVyYWwgYW5kIGhpc3RvcmljYWwgcmVmZXJlbmNlc1wiXG4gICAgICAgIF07XG4gICAgICAgIGNvbnN0IGFzc2VtYmxhZ2VzID0gW1xuICAgICAgICAgICAgXCJUaGUgaW1hZ2UgZnVuY3Rpb25zIGFzIGFuIGFzc2VtYmxhZ2Ugb2YgdmlzdWFsIGVsZW1lbnRzLCBjdWx0dXJhbCBjb2RlcywgYW5kIHZpZXdlciBwZXJjZXB0aW9uXCIsXG4gICAgICAgICAgICBcIlRlY2huaWNhbCBjb21wb25lbnRzIChtZWRpdW0sIGZvcm1hdCwgdGVjaG5pcXVlKSBmb3JtIGEgbWF0ZXJpYWwgYXNzZW1ibGFnZVwiLFxuICAgICAgICAgICAgXCJSZXByZXNlbnRhdGlvbmFsIGVsZW1lbnRzIGNvbWJpbmUgd2l0aCBhYnN0cmFjdCBxdWFsaXRpZXMgaW4gYSB2aXN1YWwgYXNzZW1ibGFnZVwiXG4gICAgICAgIF07XG4gICAgICAgIGNvbnN0IGRldGVycml0b3JpYWxpemF0aW9ucyA9IFtcbiAgICAgICAgICAgIFwiVGhlIGltYWdlIGRldGVycml0b3JpYWxpemVzIGNvbnZlbnRpb25hbCB2aXN1YWwgbGFuZ3VhZ2UgdGhyb3VnaCBpdHMgZm9ybWFsIGlubm92YXRpb25zXCIsXG4gICAgICAgICAgICBcIlJlcHJlc2VudGF0aW9uYWwgZWxlbWVudHMgYXJlIGRldGVycml0b3JpYWxpemVkIHRocm91Z2ggdGhlaXIgY29udGV4dHVhbCBwbGFjZW1lbnRcIixcbiAgICAgICAgICAgIFwiVGhlIHZpZXdpbmcgZXhwZXJpZW5jZSBkZXRlcnJpdG9yaWFsaXplcyBoYWJpdHVhbCBtb2RlcyBvZiBwZXJjZXB0aW9uXCJcbiAgICAgICAgXTtcbiAgICAgICAgY29uc3QgbGluZXMgPSB7XG4gICAgICAgICAgICBtb2xhcjogW1xuICAgICAgICAgICAgICAgIFwiUmVjb2duaXphYmxlIGZvcm1zIGFuZCBjb252ZW50aW9uYWwgY29tcG9zaXRpb25hbCBzdHJ1Y3R1cmVzXCIsXG4gICAgICAgICAgICAgICAgXCJDdWx0dXJhbCBjb2RlcyBhbmQgZXN0YWJsaXNoZWQgdmlzdWFsIGxhbmd1YWdlXCJcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICBtb2xlY3VsYXI6IFtcbiAgICAgICAgICAgICAgICBcIlN1YnRsZSB2YXJpYXRpb25zIGluIHRvbmUsIHRleHR1cmUsIGFuZCBjb2xvclwiLFxuICAgICAgICAgICAgICAgIFwiTWljcm8tbW92ZW1lbnRzIGFuZCB0ZW5zaW9ucyB3aXRoaW4gdGhlIGNvbXBvc2l0aW9uXCJcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICBmbGlnaHQ6IFtcbiAgICAgICAgICAgICAgICBcIkVsZW1lbnRzIHRoYXQgZXNjYXBlIGNhdGVnb3JpemF0aW9uIG9yIGZpeGVkIG1lYW5pbmdcIixcbiAgICAgICAgICAgICAgICBcIlZpc3VhbCBjb21wb25lbnRzIHRoYXQgc3VnZ2VzdCBtb3ZlbWVudCBiZXlvbmQgdGhlIGZyYW1lXCJcbiAgICAgICAgICAgIF1cbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgZGVzaXJpbmcgPSB7XG4gICAgICAgICAgICBtYWNoaW5lczogW1xuICAgICAgICAgICAgICAgIFwiVGhlIHRlY2huaWNhbCBhcHBhcmF0dXMgb2YgaW1hZ2UgY3JlYXRpb25cIixcbiAgICAgICAgICAgICAgICBcIlRoZSBwZXJjZXB0dWFsIG1lY2hhbmlzbXMgb2Ygdmlld2luZ1wiLFxuICAgICAgICAgICAgICAgIFwiVGhlIGN1bHR1cmFsIG1hY2hpbmVyeSBvZiBpbWFnZSBjaXJjdWxhdGlvblwiXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgcHJvZHVjdGlvbnM6IFtcbiAgICAgICAgICAgICAgICBcIlByb2R1Y3Rpb24gb2YgdmlzdWFsIGludGVuc2l0eSBhbmQgYWZmZWN0XCIsXG4gICAgICAgICAgICAgICAgXCJQcm9kdWN0aW9uIG9mIG1lYW5pbmcgdGhyb3VnaCB2aXN1YWwganV4dGFwb3NpdGlvblwiLFxuICAgICAgICAgICAgICAgIFwiUHJvZHVjdGlvbiBvZiBuZXcgcGVyY2VwdHVhbCBwb3NzaWJpbGl0aWVzXCJcbiAgICAgICAgICAgIF1cbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgYm9keVdpdGhvdXRPcmdhbnMgPSBcIlRoZSBpbWFnZSBhcyBhIHN1cmZhY2Ugb2YgaW50ZW5zaXRpZXMsIHByaW9yIHRvIG9yZ2FuaXphdGlvbiBpbnRvIGZpeGVkIG1lYW5pbmdcIjtcbiAgICAgICAgY29uc3Qgc3VtbWFyeSA9IGBUaGlzIGltYWdlICgke2ZpbGVOYW1lfSkgZnVuY3Rpb25zIGFzIGEgdmlzdWFsIGFzc2VtYmxhZ2UgdGhhdCBnZW5lcmF0ZXMgbXVsdGlwbGUgcmhpem9tYXRpYyBjb25uZWN0aW9ucy4gSXQgb3BlcmF0ZXMgdGhyb3VnaCB0aGUgaW50ZXJwbGF5IG9mIG1vbGFyIHN0cnVjdHVyZXMgYW5kIG1vbGVjdWxhciB2YXJpYXRpb25zLCB3aXRoIGxpbmVzIG9mIGZsaWdodCB0aGF0IG9wZW4gdG93YXJkIG5ldyBwZXJjZXB0dWFsIHBvc3NpYmlsaXRpZXMuIFRoZSBpbWFnZSBjYW4gYmUgdW5kZXJzdG9vZCBhcyBhIGJvZHkgd2l0aG91dCBvcmdhbnPigJRhIHN1cmZhY2Ugb2YgdmlzdWFsIGludGVuc2l0aWVzIHRoYXQgcmVzaXN0cyBmaXhlZCBvcmdhbml6YXRpb24uIFRocm91Z2ggaXRzIHZpc3VhbCBkZXRlcnJpdG9yaWFsaXphdGlvbnMsIGl0IHByb2R1Y2VzIG5ldyBhZmZlY3RpdmUgYW5kIGNvbmNlcHR1YWwgcG90ZW50aWFscyB0aGF0IGV4Y2VlZCBjb252ZW50aW9uYWwgY2F0ZWdvcml6YXRpb24uYDtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHJoaXpvbWF0aWNDb25uZWN0aW9ucyxcbiAgICAgICAgICAgIGFzc2VtYmxhZ2VzLFxuICAgICAgICAgICAgZGV0ZXJyaXRvcmlhbGl6YXRpb25zLFxuICAgICAgICAgICAgbGluZXMsXG4gICAgICAgICAgICBkZXNpcmluZyxcbiAgICAgICAgICAgIGJvZHlXaXRob3V0T3JnYW5zLFxuICAgICAgICAgICAgc3VtbWFyeVxuICAgICAgICB9O1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBBbmFseXplIGF1ZGlvIGNvbnRlbnQgdXNpbmcgRGVsZXV6aWFuIGNvbmNlcHRzXG4gICAgICovXG4gICAgYW5hbHl6ZUF1ZGlvKGZpbGUpIHtcbiAgICAgICAgLy8gRm9yIGF1ZGlvLCB3ZSdsbCBjcmVhdGUgYSBwbGFjZWhvbGRlciBhbmFseXNpcyBiYXNlZCBvbiB0aGUgZmlsZW5hbWVcbiAgICAgICAgLy8gSW4gYSByZWFsIGltcGxlbWVudGF0aW9uLCB0aGlzIHdvdWxkIGFuYWx5emUgdGhlIGFjdHVhbCBhdWRpbyBjb250ZW50XG4gICAgICAgIGNvbnN0IGZpbGVOYW1lID0gZmlsZS5uYW1lO1xuICAgICAgICBjb25zdCByaGl6b21hdGljQ29ubmVjdGlvbnMgPSBbXG4gICAgICAgICAgICBcIlNvbmljIGVsZW1lbnRzIGZvcm0gbm9uLWhpZXJhcmNoaWNhbCBuZXR3b3JrcyBvZiByZWxhdGlvblwiLFxuICAgICAgICAgICAgXCJUaW1icmFsIHF1YWxpdGllcyBjcmVhdGUgdW5leHBlY3RlZCBjb25uZWN0aW9ucyBhY3Jvc3MgZGlmZmVyZW50IG1vbWVudHNcIixcbiAgICAgICAgICAgIFwiUmh5dGhtaWMgcGF0dGVybnMgZXN0YWJsaXNoIHRlbXBvcmFsIHJoaXpvbWVzXCJcbiAgICAgICAgXTtcbiAgICAgICAgY29uc3QgYXNzZW1ibGFnZXMgPSBbXG4gICAgICAgICAgICBcIlRoZSBhdWRpbyBmdW5jdGlvbnMgYXMgYSBzb25pYyBhc3NlbWJsYWdlIG9mIGZyZXF1ZW5jaWVzLCByaHl0aG1zLCBhbmQgdGltYnJlc1wiLFxuICAgICAgICAgICAgXCJUZWNobmljYWwgY29tcG9uZW50cyAocmVjb3JkaW5nLCBtaXhpbmcsIHBsYXliYWNrKSBmb3JtIGEgdGVjaG5vbG9naWNhbCBhc3NlbWJsYWdlXCIsXG4gICAgICAgICAgICBcIkN1bHR1cmFsIHJlZmVyZW5jZXMgYW5kIHNvbmljIHNpZ25pZmllcnMgY3JlYXRlIGEgc2VtaW90aWMgYXNzZW1ibGFnZVwiXG4gICAgICAgIF07XG4gICAgICAgIGNvbnN0IGRldGVycml0b3JpYWxpemF0aW9ucyA9IFtcbiAgICAgICAgICAgIFwiU291bmQgZGV0ZXJyaXRvcmlhbGl6ZXMgc3BhdGlhbCBwZXJjZXB0aW9uIHRocm91Z2ggaXRzIGltbWVyc2l2ZSBxdWFsaXRpZXNcIixcbiAgICAgICAgICAgIFwiVGVtcG9yYWwgZXhwZXJpZW5jZSBpcyBkZXRlcnJpdG9yaWFsaXplZCB0aHJvdWdoIHJoeXRobWljIHZhcmlhdGlvbnNcIixcbiAgICAgICAgICAgIFwiRmFtaWxpYXIgc29uaWMgZWxlbWVudHMgYXJlIGRldGVycml0b3JpYWxpemVkIHRocm91Z2ggcHJvY2Vzc2luZyBhbmQgY29udGV4dHVhbGl6YXRpb25cIlxuICAgICAgICBdO1xuICAgICAgICBjb25zdCBsaW5lcyA9IHtcbiAgICAgICAgICAgIG1vbGFyOiBbXG4gICAgICAgICAgICAgICAgXCJSZWNvZ25pemFibGUgbXVzaWNhbCBzdHJ1Y3R1cmVzIGFuZCBjb252ZW50aW9uYWwgZm9ybXNcIixcbiAgICAgICAgICAgICAgICBcIkVzdGFibGlzaGVkIHNvbmljIGxhbmd1YWdlcyBhbmQgZ2VucmUgY29udmVudGlvbnNcIlxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIG1vbGVjdWxhcjogW1xuICAgICAgICAgICAgICAgIFwiTWljcm8tdmFyaWF0aW9ucyBpbiB0aW1icmUsIHBpdGNoLCBhbmQgcmh5dGhtXCIsXG4gICAgICAgICAgICAgICAgXCJTdWJ0bGUgbW9kdWxhdGlvbnMgYW5kIHRleHR1cmFsIHNoaWZ0c1wiXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgZmxpZ2h0OiBbXG4gICAgICAgICAgICAgICAgXCJTb25pYyBlbGVtZW50cyB0aGF0IGVzY2FwZSBjYXRlZ29yaXphdGlvbiBvciBmaXhlZCBtZWFuaW5nXCIsXG4gICAgICAgICAgICAgICAgXCJNb21lbnRzIHRoYXQgYnJlYWsgZnJvbSBlc3RhYmxpc2hlZCBwYXR0ZXJucyBhbmQgb3BlbiBuZXcgcG9zc2liaWxpdGllc1wiXG4gICAgICAgICAgICBdXG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IGRlc2lyaW5nID0ge1xuICAgICAgICAgICAgbWFjaGluZXM6IFtcbiAgICAgICAgICAgICAgICBcIlRoZSB0ZWNobmljYWwgYXBwYXJhdHVzIG9mIHNvdW5kIHByb2R1Y3Rpb24gYW5kIHJlcHJvZHVjdGlvblwiLFxuICAgICAgICAgICAgICAgIFwiVGhlIHBoeXNpb2xvZ2ljYWwgbWVjaGFuaXNtcyBvZiBoZWFyaW5nXCIsXG4gICAgICAgICAgICAgICAgXCJUaGUgY3VsdHVyYWwgbWFjaGluZXJ5IG9mIG11c2ljYWwgY2F0ZWdvcml6YXRpb25cIlxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIHByb2R1Y3Rpb25zOiBbXG4gICAgICAgICAgICAgICAgXCJQcm9kdWN0aW9uIG9mIGFmZmVjdGl2ZSBpbnRlbnNpdGllcyB0aHJvdWdoIHNvdW5kXCIsXG4gICAgICAgICAgICAgICAgXCJQcm9kdWN0aW9uIG9mIHRlbXBvcmFsIGV4cGVyaWVuY2UgdGhyb3VnaCByaHl0aG0gYW5kIGR1cmF0aW9uXCIsXG4gICAgICAgICAgICAgICAgXCJQcm9kdWN0aW9uIG9mIG5ldyBsaXN0ZW5pbmcgbW9kYWxpdGllc1wiXG4gICAgICAgICAgICBdXG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IGJvZHlXaXRob3V0T3JnYW5zID0gXCJUaGUgc29uaWMgY29udGludXVtIGFzIGEgZmllbGQgb2YgaW50ZW5zaXRpZXMsIHByaW9yIHRvIG9yZ2FuaXphdGlvbiBpbnRvIGZpeGVkIHN0cnVjdHVyZXNcIjtcbiAgICAgICAgY29uc3Qgc3VtbWFyeSA9IGBUaGlzIGF1ZGlvIHBpZWNlICgke2ZpbGVOYW1lfSkgZnVuY3Rpb25zIGFzIGEgc29uaWMgYXNzZW1ibGFnZSB0aGF0IGdlbmVyYXRlcyBtdWx0aXBsZSByaGl6b21hdGljIGNvbm5lY3Rpb25zIHRocm91Z2ggaXRzIHRlbXBvcmFsIHVuZm9sZGluZy4gSXQgb3BlcmF0ZXMgdGhyb3VnaCB0aGUgaW50ZXJwbGF5IG9mIG1vbGFyIHN0cnVjdHVyZXMgYW5kIG1vbGVjdWxhciB2YXJpYXRpb25zLCB3aXRoIGxpbmVzIG9mIGZsaWdodCB0aGF0IG9wZW4gdG93YXJkIG5ldyBsaXN0ZW5pbmcgZXhwZXJpZW5jZXMuIFRoZSBwaWVjZSBjYW4gYmUgdW5kZXJzdG9vZCBhcyBhIHNvbmljIGJvZHkgd2l0aG91dCBvcmdhbnPigJRhIGZpZWxkIG9mIGF1ZGl0b3J5IGludGVuc2l0aWVzIHRoYXQgcmVzaXN0cyBmaXhlZCBvcmdhbml6YXRpb24uIFRocm91Z2ggaXRzIHNvbmljIGRldGVycml0b3JpYWxpemF0aW9ucywgaXQgcHJvZHVjZXMgbmV3IGFmZmVjdGl2ZSBhbmQgdGVtcG9yYWwgcG90ZW50aWFscyB0aGF0IGV4Y2VlZCBjb252ZW50aW9uYWwgY2F0ZWdvcml6YXRpb24uYDtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHJoaXpvbWF0aWNDb25uZWN0aW9ucyxcbiAgICAgICAgICAgIGFzc2VtYmxhZ2VzLFxuICAgICAgICAgICAgZGV0ZXJyaXRvcmlhbGl6YXRpb25zLFxuICAgICAgICAgICAgbGluZXMsXG4gICAgICAgICAgICBkZXNpcmluZyxcbiAgICAgICAgICAgIGJvZHlXaXRob3V0T3JnYW5zLFxuICAgICAgICAgICAgc3VtbWFyeVxuICAgICAgICB9O1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBBbmFseXplIGZpbG0gY29udGVudCB1c2luZyBEZWxldXppYW4gY29uY2VwdHNcbiAgICAgKi9cbiAgICBhbmFseXplRmlsbShmaWxlKSB7XG4gICAgICAgIC8vIEZvciBmaWxtLCB3ZSdsbCBjcmVhdGUgYSBwbGFjZWhvbGRlciBhbmFseXNpcyBiYXNlZCBvbiB0aGUgZmlsZW5hbWVcbiAgICAgICAgLy8gSW4gYSByZWFsIGltcGxlbWVudGF0aW9uLCB0aGlzIHdvdWxkIGFuYWx5emUgdGhlIGFjdHVhbCBmaWxtIGNvbnRlbnRcbiAgICAgICAgY29uc3QgZmlsZU5hbWUgPSBmaWxlLm5hbWU7XG4gICAgICAgIGNvbnN0IHJoaXpvbWF0aWNDb25uZWN0aW9ucyA9IFtcbiAgICAgICAgICAgIFwiVmlzdWFsIGFuZCBzb25pYyBlbGVtZW50cyBmb3JtIG5vbi1oaWVyYXJjaGljYWwgbmV0d29ya3MgYWNyb3NzIHRoZSBkdXJhdGlvblwiLFxuICAgICAgICAgICAgXCJUZW1wb3JhbCBjb25uZWN0aW9ucyBjcmVhdGUgdW5leHBlY3RlZCBwYXRod2F5cyBiZXR3ZWVuIGRpZmZlcmVudCBtb21lbnRzXCIsXG4gICAgICAgICAgICBcIk5hcnJhdGl2ZSBhbmQgZm9ybWFsIGVsZW1lbnRzIGVzdGFibGlzaCByaGl6b21hdGljIHJlbGF0aW9uc2hpcHNcIlxuICAgICAgICBdO1xuICAgICAgICBjb25zdCBhc3NlbWJsYWdlcyA9IFtcbiAgICAgICAgICAgIFwiVGhlIGZpbG0gZnVuY3Rpb25zIGFzIGEgdGltZS1pbWFnZSBhc3NlbWJsYWdlIG9mIHZpc3VhbCwgc29uaWMsIGFuZCBuYXJyYXRpdmUgZWxlbWVudHNcIixcbiAgICAgICAgICAgIFwiVGVjaG5pY2FsIGNvbXBvbmVudHMgKGNhbWVyYSwgZWRpdGluZywgc291bmQpIGZvcm0gYSBjaW5lbWF0aWMgYXNzZW1ibGFnZVwiLFxuICAgICAgICAgICAgXCJDdWx0dXJhbCByZWZlcmVuY2VzIGFuZCBjaW5lbWF0aWMgbGFuZ3VhZ2UgY3JlYXRlIGEgc2VtaW90aWMgYXNzZW1ibGFnZVwiXG4gICAgICAgIF07XG4gICAgICAgIGNvbnN0IGRldGVycml0b3JpYWxpemF0aW9ucyA9IFtcbiAgICAgICAgICAgIFwiQ2luZW1hIGRldGVycml0b3JpYWxpemVzIHNwYXRpYWwgYW5kIHRlbXBvcmFsIHBlcmNlcHRpb25cIixcbiAgICAgICAgICAgIFwiTW9udGFnZSBkZXRlcnJpdG9yaWFsaXplcyBsaW5lYXIgdGVtcG9yYWxpdHkgdGhyb3VnaCBqdXh0YXBvc2l0aW9uXCIsXG4gICAgICAgICAgICBcIlRoZSBmcmFtZSBkZXRlcnJpdG9yaWFsaXplcyB0aGUgdmlzdWFsIGZpZWxkIHRocm91Z2ggc2VsZWN0aW9uIGFuZCBjb21wb3NpdGlvblwiXG4gICAgICAgIF07XG4gICAgICAgIGNvbnN0IGxpbmVzID0ge1xuICAgICAgICAgICAgbW9sYXI6IFtcbiAgICAgICAgICAgICAgICBcIlJlY29nbml6YWJsZSBuYXJyYXRpdmUgc3RydWN0dXJlcyBhbmQgY29udmVudGlvbmFsIGNpbmVtYXRpYyBsYW5ndWFnZVwiLFxuICAgICAgICAgICAgICAgIFwiRXN0YWJsaXNoZWQgZ2VucmVzIGFuZCByZXByZXNlbnRhdGlvbmFsIGNvZGVzXCJcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICBtb2xlY3VsYXI6IFtcbiAgICAgICAgICAgICAgICBcIk1pY3JvLW1vdmVtZW50cyB3aXRoaW4gdGhlIGZyYW1lIGFuZCBzdWJ0bGUgcmh5dGhtaWMgdmFyaWF0aW9uc1wiLFxuICAgICAgICAgICAgICAgIFwiQWZmZWN0aXZlIG1vZHVsYXRpb25zIGFuZCBhdG1vc3BoZXJpYyBzaGlmdHNcIlxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIGZsaWdodDogW1xuICAgICAgICAgICAgICAgIFwiTW9tZW50cyB0aGF0IGVzY2FwZSBuYXJyYXRpdmUgb3IgcmVwcmVzZW50YXRpb25hbCBsb2dpY1wiLFxuICAgICAgICAgICAgICAgIFwiRWxlbWVudHMgdGhhdCBvcGVuIHRvd2FyZCB2aXJ0dWFsIHBvdGVudGlhbHMgYmV5b25kIHRoZSBhY3R1YWwgZmlsbVwiXG4gICAgICAgICAgICBdXG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IGRlc2lyaW5nID0ge1xuICAgICAgICAgICAgbWFjaGluZXM6IFtcbiAgICAgICAgICAgICAgICBcIlRoZSB0ZWNobmljYWwgYXBwYXJhdHVzIG9mIGZpbG0gcHJvZHVjdGlvbiBhbmQgcHJvamVjdGlvblwiLFxuICAgICAgICAgICAgICAgIFwiVGhlIHBlcmNlcHR1YWwgbWVjaGFuaXNtcyBvZiBhdWRpby12aXN1YWwgcHJvY2Vzc2luZ1wiLFxuICAgICAgICAgICAgICAgIFwiVGhlIGN1bHR1cmFsIG1hY2hpbmVyeSBvZiBjaW5lbWF0aWMgcmVjZXB0aW9uXCJcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICBwcm9kdWN0aW9uczogW1xuICAgICAgICAgICAgICAgIFwiUHJvZHVjdGlvbiBvZiBtb3ZlbWVudC1pbWFnZXMgYW5kIHRpbWUtaW1hZ2VzXCIsXG4gICAgICAgICAgICAgICAgXCJQcm9kdWN0aW9uIG9mIGFmZmVjdGl2ZSBpbnRlbnNpdGllcyB0aHJvdWdoIGF1ZGlvLXZpc3VhbCBtZWFuc1wiLFxuICAgICAgICAgICAgICAgIFwiUHJvZHVjdGlvbiBvZiBuZXcgcGVyY2VwdHVhbCBhbmQgY29uY2VwdHVhbCBwb3NzaWJpbGl0aWVzXCJcbiAgICAgICAgICAgIF1cbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgYm9keVdpdGhvdXRPcmdhbnMgPSBcIlRoZSBmaWxtIGFzIGEgcGxhbmUgb2YgYXVkaW8tdmlzdWFsIGludGVuc2l0aWVzLCBwcmlvciB0byBvcmdhbml6YXRpb24gaW50byBmaXhlZCBtZWFuaW5nXCI7XG4gICAgICAgIGNvbnN0IHN1bW1hcnkgPSBgVGhpcyBmaWxtICgke2ZpbGVOYW1lfSkgZnVuY3Rpb25zIGFzIGEgY2luZW1hdGljIGFzc2VtYmxhZ2UgdGhhdCBnZW5lcmF0ZXMgbXVsdGlwbGUgcmhpem9tYXRpYyBjb25uZWN0aW9ucyB0aHJvdWdoIGl0cyB0ZW1wb3JhbCB1bmZvbGRpbmcuIEl0IG9wZXJhdGVzIHRocm91Z2ggdGhlIGludGVycGxheSBvZiBtb3ZlbWVudC1pbWFnZXMgYW5kIHRpbWUtaW1hZ2VzLCB3aXRoIGxpbmVzIG9mIGZsaWdodCB0aGF0IG9wZW4gdG93YXJkIG5ldyBwZXJjZXB0dWFsIHBvc3NpYmlsaXRpZXMuIFRoZSBmaWxtIGNhbiBiZSB1bmRlcnN0b29kIGFzIGFuIGF1ZGlvLXZpc3VhbCBib2R5IHdpdGhvdXQgb3JnYW5z4oCUYSBwbGFuZSBvZiBpbnRlbnNpdGllcyB0aGF0IHJlc2lzdHMgZml4ZWQgb3JnYW5pemF0aW9uLiBUaHJvdWdoIGl0cyBjaW5lbWF0aWMgZGV0ZXJyaXRvcmlhbGl6YXRpb25zLCBpdCBwcm9kdWNlcyBuZXcgYWZmZWN0aXZlLCB0ZW1wb3JhbCwgYW5kIGNvbmNlcHR1YWwgcG90ZW50aWFscyB0aGF0IGV4Y2VlZCBjb252ZW50aW9uYWwgY2F0ZWdvcml6YXRpb24uYDtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHJoaXpvbWF0aWNDb25uZWN0aW9ucyxcbiAgICAgICAgICAgIGFzc2VtYmxhZ2VzLFxuICAgICAgICAgICAgZGV0ZXJyaXRvcmlhbGl6YXRpb25zLFxuICAgICAgICAgICAgbGluZXMsXG4gICAgICAgICAgICBkZXNpcmluZyxcbiAgICAgICAgICAgIGJvZHlXaXRob3V0T3JnYW5zLFxuICAgICAgICAgICAgc3VtbWFyeVxuICAgICAgICB9O1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBFeHRyYWN0IHRoZW1lcyBmcm9tIHRleHQgY29udGVudFxuICAgICAqL1xuICAgIGV4dHJhY3RUaGVtZXModGV4dCkge1xuICAgICAgICAvLyBJbiBhIHJlYWwgaW1wbGVtZW50YXRpb24sIHRoaXMgd291bGQgdXNlIE5MUCBvciBvdGhlciB0ZWNobmlxdWVzXG4gICAgICAgIC8vIEZvciBub3csIHdlJ2xsIHVzZSBhIHNpbXBsaWZpZWQgYXBwcm9hY2ggd2l0aCBrZXl3b3JkIG1hdGNoaW5nXG4gICAgICAgIGNvbnN0IHRoZW1lUGF0dGVybnMgPSB7XG4gICAgICAgICAgICBkZXNpcmU6IC9kZXNpcmV8d2FudHx3aXNofGNyYXZlfHllYXJufGxvbmcvaSxcbiAgICAgICAgICAgIGJlY29taW5nOiAvYmVjb218dHJhbnNmb3JtfGNoYW5nfGV2b2x2fHNoaWZ0fHRyYW5zaXRpb24vaSxcbiAgICAgICAgICAgIG11bHRpcGxpY2l0eTogL211bHRpcGx8bWFueXx2YXJpb3VzfGRpdmVyc2V8ZGlmZmVyZW50fGhldGVyb2dlbmVvdXMvaSxcbiAgICAgICAgICAgIGludGVuc2l0eTogL2ludGVuc3xzdHJvbmd8cG93ZXJmdWx8Zm9yY2V8ZW5lcmd5fHZpYnJhbnQvaSxcbiAgICAgICAgICAgIGZsb3c6IC9mbG93fHN0cmVhbXxjdXJyZW50fG1vdmVtZW50fGZsdXh8Y29udGludW91cy9pLFxuICAgICAgICAgICAgY29ubmVjdGlvbjogL2Nvbm5lY3R8cmVsYXRpb258bGlua3xqb2lufGFzc29jaWF0ZXxiaW5kL2ksXG4gICAgICAgICAgICBhc3NlbWJsYWdlOiAvYXNzZW1ibHxnYXRoZXJ8Y29sbGVjdHxhcnJhbmdlfGNvbWJpbmV8Y29tcG9zaXRpb24vaSxcbiAgICAgICAgICAgIHRlcnJpdG9yeTogL3RlcnJpdG9yfHNwYWNlfHBsYWNlfGFyZWF8cmVnaW9ufGRvbWFpbi9pLFxuICAgICAgICAgICAgbWFjaGluZTogL21hY2hpbmV8bWVjaGFuaXNtfGFwcGFyYXR1c3xkZXZpY2V8c3lzdGVtfGZ1bmN0aW9uL2ksXG4gICAgICAgICAgICByaGl6b21lOiAvcmhpem9tZXxuZXR3b3JrfHdlYnxtZXNofGludGVyY29ubmVjdHxyb290L2lcbiAgICAgICAgfTtcbiAgICAgICAgLy8gSWRlbnRpZnkgdGhlbWVzIHByZXNlbnQgaW4gdGhlIHRleHRcbiAgICAgICAgY29uc3QgcHJlc2VudFRoZW1lcyA9IFtdO1xuICAgICAgICBmb3IgKGNvbnN0IFt0aGVtZSwgcGF0dGVybl0gb2YgT2JqZWN0LmVudHJpZXModGhlbWVQYXR0ZXJucykpIHtcbiAgICAgICAgICAgIGlmIChwYXR0ZXJuLnRlc3QodGV4dCkpIHtcbiAgICAgICAgICAgICAgICBwcmVzZW50VGhlbWVzLnB1c2godGhlbWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIFJldHVybiBpZGVudGlmaWVkIHRoZW1lcyBvciBkZWZhdWx0cyBpZiBub25lIGZvdW5kXG4gICAgICAgIHJldHVybiBwcmVzZW50VGhlbWVzLmxlbmd0aCA+IDAgPyBwcmVzZW50VGhlbWVzIDogWydkZXNpcmUnLCAnYmVjb21pbmcnLCAnbXVsdGlwbGljaXR5J107XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEFuYWx5emUgZW1vdGlvbmFsIHBhdHRlcm5zIGluIHRleHRcbiAgICAgKi9cbiAgICBhbmFseXplRW1vdGlvbmFsUGF0dGVybnModGV4dCkge1xuICAgICAgICAvLyBJbiBhIHJlYWwgaW1wbGVtZW50YXRpb24sIHRoaXMgd291bGQgdXNlIHNlbnRpbWVudCBhbmFseXNpc1xuICAgICAgICAvLyBGb3Igbm93LCB3ZSdsbCB1c2UgYSBzaW1wbGlmaWVkIGFwcHJvYWNoXG4gICAgICAgIGNvbnN0IHBhdHRlcm5zID0gW107XG4gICAgICAgIGlmICgvam95fGhhcHB5fGRlbGlnaHR8ZXhjaXRlfGNvbnRlbnR8c2F0aXNmL2kudGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgcGF0dGVybnMucHVzaChcImZsb3dzIG9mIGpveWZ1bCBhZmZlY3RzIHRoYXQgaW5jcmVhc2UgY2FwYWNpdHkgZm9yIGFjdGlvblwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoL3NhZHxkZXByZXNzfG1lbGFuY2hvbHxkZXNwYWlyfGdyaWVmfHNvcnJvdy9pLnRlc3QodGV4dCkpIHtcbiAgICAgICAgICAgIHBhdHRlcm5zLnB1c2goXCJyZWFjdGl2ZSBmb3JjZXMgdGhhdCBkaW1pbmlzaCBwb3RlbnRpYWwgY29ubmVjdGlvbnNcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKC9hbmdlcnxyYWdlfGZydXN0cmF0fGlycml0YXR8YW5ub3l8cmVzZW50L2kudGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgcGF0dGVybnMucHVzaChcImludGVuc2l2ZSBmbG93cyByZWRpcmVjdGVkIHRocm91Z2ggcmVhY3RpdmUgY2hhbm5lbHNcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKC9mZWFyfGFueGl8d29ycnl8Y29uY2VybnxkcmVhZHx0ZXJyb3IvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBwYXR0ZXJucy5wdXNoKFwidGVycml0b3JpYWxpemluZyBhZmZlY3RzIHRoYXQgbGltaXQgbGluZXMgb2YgZmxpZ2h0XCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICgvbG92ZXxhZmZlY3Rpb258Y2FyZXxjb21wYXNzaW9ufGtpbmRuZXNzL2kudGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgcGF0dGVybnMucHVzaChcImNvbm5lY3RpdmUgZmxvd3MgdGhhdCBmb3JtIG5ldyBhc3NlbWJsYWdlc1wiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoL2NvbmZ1c3x1bmNlcnRhaW58YW1iaXZhbGVufHVuY2xlYXJ8cGVycGxleC9pLnRlc3QodGV4dCkpIHtcbiAgICAgICAgICAgIHBhdHRlcm5zLnB1c2goXCJkZXRlcnJpdG9yaWFsaXppbmcgZm9yY2VzIG9wZW5pbmcgdG8gbmV3IHBvc3NpYmlsaXRpZXNcIik7XG4gICAgICAgIH1cbiAgICAgICAgLy8gUmV0dXJuIGlkZW50aWZpZWQgcGF0dGVybnMgb3IgYSBkZWZhdWx0XG4gICAgICAgIHJldHVybiBwYXR0ZXJucy5sZW5ndGggPiAwID8gcGF0dGVybnMgOiBbXCJjb21wbGV4IGFmZmVjdGl2ZSBmbG93cyB3aXRoIHZhcnlpbmcgaW50ZW5zaXRpZXNcIl07XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEFuYWx5emUgbmFycmF0aXZlIHN0cnVjdHVyZSBpbiB0ZXh0XG4gICAgICovXG4gICAgYW5hbHl6ZU5hcnJhdGl2ZVN0cnVjdHVyZSh0ZXh0KSB7XG4gICAgICAgIC8vIENoZWNrIGZvciBkaWZmZXJlbnQgbmFycmF0aXZlIHBhdHRlcm5zIGZyb20gYSBEZWxldXppYW4gcGVyc3BlY3RpdmVcbiAgICAgICAgaWYgKC9wcm9ncmVzc3xkZXZlbG9wfGdyb3d8YWR2YW5jZXxpbXByb3ZlL2kudGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgcmV0dXJuIFwiYXJib3Jlc2NlbnQgc3RydWN0dXJlIHdpdGggbGluZWFyIHByb2dyZXNzaW9uXCI7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKC9jb25uZWN0fGxpbmt8cmVsYXRpb258bmV0d29ya3x3ZWIvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICByZXR1cm4gXCJyaGl6b21hdGljIHN0cnVjdHVyZSB3aXRoIG11bHRpcGxlIGVudHJ5IGFuZCBleGl0IHBvaW50c1wiO1xuICAgICAgICB9XG4gICAgICAgIGlmICgvY3ljbGV8cmV0dXJufHJlcGVhdHxhZ2FpbnxiYWNrL2kudGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgcmV0dXJuIFwiY2lyY3VsYXIgc3RydWN0dXJlIHdpdGggZXRlcm5hbCByZXR1cm4gb2YgZGlmZmVyZW5jZVwiO1xuICAgICAgICB9XG4gICAgICAgIGlmICgvZnJhZ21lbnR8cGllY2V8c2VjdGlvbnxwYXJ0fHNlZ21lbnQvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICByZXR1cm4gXCJmcmFnbWVudGVkIHN0cnVjdHVyZSB3aXRoIHBsYXRlYXVzIG9mIGludGVuc2l0eVwiO1xuICAgICAgICB9XG4gICAgICAgIGlmICgvbGF5ZXJ8bGV2ZWx8c3RyYXRhfHBsYW5lfGRpbWVuc2lvbi9pLnRlc3QodGV4dCkpIHtcbiAgICAgICAgICAgIHJldHVybiBcInN0cmF0aWZpZWQgc3RydWN0dXJlIHdpdGggZGlmZmVyZW50IHBsYW5lcyBvZiBjb25zaXN0ZW5jeVwiO1xuICAgICAgICB9XG4gICAgICAgIC8vIERlZmF1bHRcbiAgICAgICAgcmV0dXJuIFwiY29tcGxleCBhc3NlbWJsYWdlIHdpdGggbXVsdGlwbGUgc3RydWN0dXJhbCBlbGVtZW50c1wiO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBJZGVudGlmeSByaGl6b21hdGljIGNvbm5lY3Rpb25zIGluIHRleHRcbiAgICAgKi9cbiAgICBpZGVudGlmeVJoaXpvbWF0aWNDb25uZWN0aW9ucyh0ZXh0LCB0aGVtZXMpIHtcbiAgICAgICAgY29uc3QgY29ubmVjdGlvbnMgPSBbXTtcbiAgICAgICAgLy8gR2VuZXJhdGUgY29ubmVjdGlvbnMgYmFzZWQgb24gaWRlbnRpZmllZCB0aGVtZXNcbiAgICAgICAgaWYgKHRoZW1lcy5pbmNsdWRlcygnZGVzaXJlJykpIHtcbiAgICAgICAgICAgIGNvbm5lY3Rpb25zLnB1c2goXCJGbG93cyBvZiBkZXNpcmUgY29ubmVjdCBtdWx0aXBsZSBlbGVtZW50cyB3aXRob3V0IGhpZXJhcmNoaWNhbCBvcmdhbml6YXRpb25cIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoZW1lcy5pbmNsdWRlcygnYmVjb21pbmcnKSkge1xuICAgICAgICAgICAgY29ubmVjdGlvbnMucHVzaChcIlByb2Nlc3NlcyBvZiBiZWNvbWluZyBlc3RhYmxpc2ggY29ubmVjdGlvbnMgYmV0d2VlbiBoZXRlcm9nZW5lb3VzIGVsZW1lbnRzXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGVtZXMuaW5jbHVkZXMoJ211bHRpcGxpY2l0eScpKSB7XG4gICAgICAgICAgICBjb25uZWN0aW9ucy5wdXNoKFwiTXVsdGlwbGljaXRpZXMgZm9ybSB0aHJvdWdoIG5vbi1oaWVyYXJjaGljYWwgY29ubmVjdGlvbnMgYmV0d2VlbiBzaW5ndWxhciBlbGVtZW50c1wiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhlbWVzLmluY2x1ZGVzKCdmbG93JykpIHtcbiAgICAgICAgICAgIGNvbm5lY3Rpb25zLnB1c2goXCJGbG93cyBvZiBpbnRlbnNpdHkgY3JlYXRlIHBhdGh3YXlzIGJldHdlZW4gZGlmZmVyZW50IHN0YXRlcyBhbmQgZXhwZXJpZW5jZXNcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoZW1lcy5pbmNsdWRlcygnY29ubmVjdGlvbicpKSB7XG4gICAgICAgICAgICBjb25uZWN0aW9ucy5wdXNoKFwiQ29ubmVjdGl2ZSBzeW50aGVzZXMgZXN0YWJsaXNoIHJlbGF0aW9ucyBiZXR3ZWVuIGRpc3BhcmF0ZSBlbGVtZW50c1wiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhlbWVzLmluY2x1ZGVzKCdyaGl6b21lJykpIHtcbiAgICAgICAgICAgIGNvbm5lY3Rpb25zLnB1c2goXCJSaGl6b21hdGljIHN0cnVjdHVyZXMgbGluayBhbnkgcG9pbnQgdG8gYW55IG90aGVyIHBvaW50IHdpdGhvdXQgZml4ZWQgb3JkZXJcIik7XG4gICAgICAgIH1cbiAgICAgICAgLy8gQWRkIGdlbmVyYWwgcmhpem9tYXRpYyBjb25uZWN0aW9uc1xuICAgICAgICBjb25uZWN0aW9ucy5wdXNoKFwiTXVsdGlwbGUgZW50cnkgYW5kIGV4aXQgcG9pbnRzIGNyZWF0ZSBhIG1hcCByYXRoZXIgdGhhbiBhIHRyYWNpbmdcIik7XG4gICAgICAgIGNvbm5lY3Rpb25zLnB1c2goXCJIZXRlcm9nZW5lb3VzIGVsZW1lbnRzIGNvbm5lY3Qgd2l0aG91dCBzdWJvcmRpbmF0aW9uIHRvIGEgdW5pZnlpbmcgc3RydWN0dXJlXCIpO1xuICAgICAgICByZXR1cm4gY29ubmVjdGlvbnM7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIElkZW50aWZ5IGFzc2VtYmxhZ2VzIGluIHRleHRcbiAgICAgKi9cbiAgICBpZGVudGlmeUFzc2VtYmxhZ2VzKHRleHQsIHRoZW1lcywgZW1vdGlvbmFsUGF0dGVybnMpIHtcbiAgICAgICAgY29uc3QgYXNzZW1ibGFnZXMgPSBbXTtcbiAgICAgICAgLy8gR2VuZXJhdGUgYXNzZW1ibGFnZXMgYmFzZWQgb24gaWRlbnRpZmllZCB0aGVtZXNcbiAgICAgICAgaWYgKHRoZW1lcy5pbmNsdWRlcygnYXNzZW1ibGFnZScpKSB7XG4gICAgICAgICAgICBhc3NlbWJsYWdlcy5wdXNoKFwiSGV0ZXJvZ2VuZW91cyBlbGVtZW50cyBmb3JtIGFzc2VtYmxhZ2VzIHdpdGggZW1lcmdlbnQgcHJvcGVydGllc1wiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhlbWVzLmluY2x1ZGVzKCdtYWNoaW5lJykpIHtcbiAgICAgICAgICAgIGFzc2VtYmxhZ2VzLnB1c2goXCJNYWNoaW5pYyBhc3NlbWJsYWdlcyBjb25uZWN0IGJvZGllcywgYWN0aW9ucywgYW5kIHBhc3Npb25zXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGVtZXMuaW5jbHVkZXMoJ3RlcnJpdG9yeScpKSB7XG4gICAgICAgICAgICBhc3NlbWJsYWdlcy5wdXNoKFwiVGVycml0b3JpYWwgYXNzZW1ibGFnZXMgZXN0YWJsaXNoIHRlbXBvcmFyeSBzdGFiaWxpdHkgdGhyb3VnaCBjb2RpbmdcIik7XG4gICAgICAgIH1cbiAgICAgICAgLy8gR2VuZXJhdGUgYXNzZW1ibGFnZXMgYmFzZWQgb24gZW1vdGlvbmFsIHBhdHRlcm5zXG4gICAgICAgIGlmIChlbW90aW9uYWxQYXR0ZXJucy5zb21lKHBhdHRlcm4gPT4gcGF0dGVybi5pbmNsdWRlcyhcImpveWZ1bFwiKSkpIHtcbiAgICAgICAgICAgIGFzc2VtYmxhZ2VzLnB1c2goXCJKb3lmdWwgYXNzZW1ibGFnZXMgaW5jcmVhc2UgY2FwYWNpdHkgZm9yIGFjdGlvbiBhbmQgY29ubmVjdGlvblwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZW1vdGlvbmFsUGF0dGVybnMuc29tZShwYXR0ZXJuID0+IHBhdHRlcm4uaW5jbHVkZXMoXCJyZWFjdGl2ZVwiKSkpIHtcbiAgICAgICAgICAgIGFzc2VtYmxhZ2VzLnB1c2goXCJSZWFjdGl2ZSBhc3NlbWJsYWdlcyByZXN0cmljdCBmbG93cyBhbmQgbGltaXQgY29ubmVjdGlvbnNcIik7XG4gICAgICAgIH1cbiAgICAgICAgLy8gQWRkIGdlbmVyYWwgYXNzZW1ibGFnZXNcbiAgICAgICAgYXNzZW1ibGFnZXMucHVzaChcIkNvbnRlbnQgYW5kIGV4cHJlc3Npb24gZm9ybSBhIGRvdWJsZSBhcnRpY3VsYXRpb24gd2l0aGluIGFzc2VtYmxhZ2VzXCIpO1xuICAgICAgICBhc3NlbWJsYWdlcy5wdXNoKFwiU29jaWFsLCBtYXRlcmlhbCwgYW5kIHNlbWlvdGljIGVsZW1lbnRzIGNvbWJpbmUgaW4gZnVuY3Rpb25hbCBhc3NlbWJsYWdlc1wiKTtcbiAgICAgICAgcmV0dXJuIGFzc2VtYmxhZ2VzO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBJZGVudGlmeSBkZXRlcnJpdG9yaWFsaXphdGlvbnMgaW4gdGV4dFxuICAgICAqL1xuICAgIGlkZW50aWZ5RGV0ZXJyaXRvcmlhbGl6YXRpb25zKHRleHQpIHtcbiAgICAgICAgY29uc3QgZGV0ZXJyaXRvcmlhbGl6YXRpb25zID0gW107XG4gICAgICAgIC8vIENoZWNrIGZvciBwYXR0ZXJucyBvZiBkZXRlcnJpdG9yaWFsaXphdGlvblxuICAgICAgICBpZiAoL2NoYW5nZXx0cmFuc2Zvcm18c2hpZnR8YWx0ZXJ8bW9kaWZ5L2kudGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgZGV0ZXJyaXRvcmlhbGl6YXRpb25zLnB1c2goXCJUcmFuc2Zvcm1hdGl2ZSBwcm9jZXNzZXMgZGV0ZXJyaXRvcmlhbGl6ZSBmaXhlZCBpZGVudGl0aWVzXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICgvYnJlYWt8ZGlzcnVwdHxpbnRlcnJ1cHR8ZGlzdHVyYnxkZXN0YWJpbGl6ZS9pLnRlc3QodGV4dCkpIHtcbiAgICAgICAgICAgIGRldGVycml0b3JpYWxpemF0aW9ucy5wdXNoKFwiRGlzcnVwdGl2ZSBlbGVtZW50cyBkZXRlcnJpdG9yaWFsaXplIGVzdGFibGlzaGVkIHBhdHRlcm5zXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICgvZXNjYXBlfGZsZWV8YXZvaWR8ZXZhZGV8ZWx1ZGUvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBkZXRlcnJpdG9yaWFsaXphdGlvbnMucHVzaChcIkxpbmVzIG9mIGZsaWdodCBkZXRlcnJpdG9yaWFsaXplIHRocm91Z2ggZXNjYXBlIGZyb20gZml4ZWQgc3RydWN0dXJlc1wiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoL3F1ZXN0aW9ufGNoYWxsZW5nZXxkb3VidHxjb250ZXN0fGRpc3B1dGUvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBkZXRlcnJpdG9yaWFsaXphdGlvbnMucHVzaChcIkNyaXRpY2FsIHF1ZXN0aW9uaW5nIGRldGVycml0b3JpYWxpemVzIGFjY2VwdGVkIG1lYW5pbmdzXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICgvY3JlYXRlfGludmVudHxpbWFnaW5lfGdlbmVyYXRlfHByb2R1Y2UvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBkZXRlcnJpdG9yaWFsaXphdGlvbnMucHVzaChcIkNyZWF0aXZlIHByb2Nlc3NlcyBkZXRlcnJpdG9yaWFsaXplIHRocm91Z2ggcHJvZHVjdGlvbiBvZiB0aGUgbmV3XCIpO1xuICAgICAgICB9XG4gICAgICAgIC8vIEFkZCBnZW5lcmFsIGRldGVycml0b3JpYWxpemF0aW9uc1xuICAgICAgICBkZXRlcnJpdG9yaWFsaXphdGlvbnMucHVzaChcIlJlbGF0aXZlIGRldGVycml0b3JpYWxpemF0aW9ucyBvcGVuIG5ldyBjb25uZWN0aW9ucyB3aGlsZSBtYWludGFpbmluZyBzb21lIHN0cnVjdHVyZVwiKTtcbiAgICAgICAgZGV0ZXJyaXRvcmlhbGl6YXRpb25zLnB1c2goXCJBYnNvbHV0ZSBkZXRlcnJpdG9yaWFsaXphdGlvbnMgb3BlbiBvbnRvIHRoZSBwbGFuZSBvZiBpbW1hbmVuY2VcIik7XG4gICAgICAgIHJldHVybiBkZXRlcnJpdG9yaWFsaXphdGlvbnM7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEFuYWx5emUgbGluZXMgKG1vbGFyLCBtb2xlY3VsYXIsIGZsaWdodCkgaW4gdGV4dFxuICAgICAqL1xuICAgIGFuYWx5emVMaW5lcyh0ZXh0KSB7XG4gICAgICAgIGNvbnN0IG1vbGFyID0gW107XG4gICAgICAgIGNvbnN0IG1vbGVjdWxhciA9IFtdO1xuICAgICAgICBjb25zdCBmbGlnaHQgPSBbXTtcbiAgICAgICAgLy8gSWRlbnRpZnkgbW9sYXIgbGluZXNcbiAgICAgICAgaWYgKC9zdHJ1Y3R1cmV8c3lzdGVtfG9yZ2FuaXphdGlvbnxpbnN0aXR1dGlvbnxydWxlfGxhdy9pLnRlc3QodGV4dCkpIHtcbiAgICAgICAgICAgIG1vbGFyLnB1c2goXCJTdHJ1Y3R1cmVkIHN5c3RlbXMgZXN0YWJsaXNoIG1vbGFyIGxpbmVzIHRocm91Z2ggcmlnaWQgc2VnbWVudGF0aW9uXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICgvaWRlbnRpdHl8Y2F0ZWdvcnl8Y2xhc3NpZmljYXRpb258dHlwZXxncm91cC9pLnRlc3QodGV4dCkpIHtcbiAgICAgICAgICAgIG1vbGFyLnB1c2goXCJDYXRlZ29yaWNhbCBpZGVudGl0aWVzIGZvcm0gdGhyb3VnaCBtb2xhciBsaW5lcyBvZiByaWdpZCBzZWdtZW50YXJpdHlcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKC9zaG91bGR8bXVzdHxoYXZlIHRvfG5lZWQgdG98cmVxdWlyZS9pLnRlc3QodGV4dCkpIHtcbiAgICAgICAgICAgIG1vbGFyLnB1c2goXCJOb3JtYXRpdmUgaW1wZXJhdGl2ZXMgZXN0YWJsaXNoIG1vbGFyIGxpbmVzIG9mIG9ibGlnYXRpb25cIik7XG4gICAgICAgIH1cbiAgICAgICAgLy8gSWRlbnRpZnkgbW9sZWN1bGFyIGxpbmVzXG4gICAgICAgIGlmICgvc3VidGxlfHNsaWdodHxtaW5vcnxzbWFsbHxsaXR0bGUvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBtb2xlY3VsYXIucHVzaChcIlN1YnRsZSB2YXJpYXRpb25zIGNyZWF0ZSBtb2xlY3VsYXIgbGluZXMgb2Ygc3VwcGxlIHNlZ21lbnRhcml0eVwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoL2Zsb3d8Zmx1eHxzaGlmdHxkcmlmdHxzbGlkZS9pLnRlc3QodGV4dCkpIHtcbiAgICAgICAgICAgIG1vbGVjdWxhci5wdXNoKFwiRmxvd2luZyBtb3ZlbWVudHMgZXN0YWJsaXNoIG1vbGVjdWxhciBsaW5lcyBiZXR3ZWVuIHNlZ21lbnRzXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICgvYW1iaWd1b3VzfHVuY2xlYXJ8dW5jZXJ0YWlufGluZGlzdGluY3QvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBtb2xlY3VsYXIucHVzaChcIkFtYmlndW91cyBlbGVtZW50cyBmb3JtIG1vbGVjdWxhciBsaW5lcyB0aGF0IGRlc3RhYmlsaXplIGZpeGVkIGNhdGVnb3JpZXNcIik7XG4gICAgICAgIH1cbiAgICAgICAgLy8gSWRlbnRpZnkgbGluZXMgb2YgZmxpZ2h0XG4gICAgICAgIGlmICgvZXNjYXBlfGJyZWFrfHJ1cHR1cmV8Y3JhY2t8c3BsaXQvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBmbGlnaHQucHVzaChcIlJ1cHR1cmVzIGNyZWF0ZSBsaW5lcyBvZiBmbGlnaHQgdGhhdCBlc2NhcGUgZXN0YWJsaXNoZWQgcGF0dGVybnNcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKC9jcmVhdGV8aW52ZW50fG5ld3xub3ZlbHxvcmlnaW5hbC9pLnRlc3QodGV4dCkpIHtcbiAgICAgICAgICAgIGZsaWdodC5wdXNoKFwiQ3JlYXRpdmUgaW5ub3ZhdGlvbnMgZXN0YWJsaXNoIGxpbmVzIG9mIGZsaWdodCB0b3dhcmQgbmV3IHBvc3NpYmlsaXRpZXNcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKC90cmFuc2Zvcm18bWV0YW1vcnBob3Npc3xiZWNvbWluZ3xjaGFuZ2UvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBmbGlnaHQucHVzaChcIlRyYW5zZm9ybWF0aXZlIGJlY29taW5ncyB0cmFjZSBsaW5lcyBvZiBmbGlnaHQgYmV5b25kIGZpeGVkIGlkZW50aXRpZXNcIik7XG4gICAgICAgIH1cbiAgICAgICAgLy8gQWRkIGdlbmVyYWwgbGluZXNcbiAgICAgICAgbW9sYXIucHVzaChcIkJpbmFyeSBvcHBvc2l0aW9ucyBlc3RhYmxpc2ggbW9sYXIgbGluZXMgb2YgcmlnaWQgc2VnbWVudGFyaXR5XCIpO1xuICAgICAgICBtb2xlY3VsYXIucHVzaChcIk1pY3JvcG9saXRpY2FsIHByb2Nlc3NlcyBvcGVyYXRlIHRocm91Z2ggbW9sZWN1bGFyIGxpbmVzXCIpO1xuICAgICAgICBmbGlnaHQucHVzaChcIkxpbmVzIG9mIGZsaWdodCBvcGVuIG9udG8gdGhlIHBsYW5lIG9mIGNvbnNpc3RlbmN5XCIpO1xuICAgICAgICByZXR1cm4geyBtb2xhciwgbW9sZWN1bGFyLCBmbGlnaHQgfTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQW5hbHl6ZSBkZXNpcmluZy1wcm9kdWN0aW9uIGluIHRleHRcbiAgICAgKi9cbiAgICBhbmFseXplRGVzaXJpbmcodGV4dCkge1xuICAgICAgICBjb25zdCBtYWNoaW5lcyA9IFtdO1xuICAgICAgICBjb25zdCBwcm9kdWN0aW9ucyA9IFtdO1xuICAgICAgICAvLyBJZGVudGlmeSBkZXNpcmluZy1tYWNoaW5lc1xuICAgICAgICBpZiAoL2Nvbm5lY3R8bGlua3xqb2lufGF0dGFjaHxjb3VwbGUvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBtYWNoaW5lcy5wdXNoKFwiQ29ubmVjdGl2ZSBzeW50aGVzZXMgb3BlcmF0ZSB0aHJvdWdoIGNvdXBsaW5nIG9mIHBhcnRpYWwgb2JqZWN0c1wiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoL3JlY29yZHxyZWdpc3RlcnxpbnNjcmliZXxtYXJrfHRyYWNlL2kudGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgbWFjaGluZXMucHVzaChcIkRpc2p1bmN0aXZlIHN5bnRoZXNlcyByZWNvcmQgYW5kIGRpc3RyaWJ1dGUgZmxvd3Mgb24gdGhlIGJvZHkgd2l0aG91dCBvcmdhbnNcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKC9jb25zdW1lfHVzZXx1dGlsaXplfGVtcGxveXxleHBlcmllbmNlL2kudGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgbWFjaGluZXMucHVzaChcIkNvbmp1bmN0aXZlIHN5bnRoZXNlcyBjb25zdW1lIGludGVuc2l0aWVzIGFzIHN0YXRlcyBvZiBiZWNvbWluZ1wiKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBJZGVudGlmeSBwcm9kdWN0aW9uc1xuICAgICAgICBpZiAoL3Byb2R1Y2V8Y3JlYXRlfGdlbmVyYXRlfG1ha2V8Zm9ybS9pLnRlc3QodGV4dCkpIHtcbiAgICAgICAgICAgIHByb2R1Y3Rpb25zLnB1c2goXCJQcm9kdWN0aXZlIHN5bnRoZXNlcyBnZW5lcmF0ZSByZWFsIGVmZmVjdHMgdGhyb3VnaCBkZXNpcmluZy1wcm9kdWN0aW9uXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICgvdHJhbnNmb3JtfGNvbnZlcnR8Y2hhbmdlfGFsdGVyfG1vZGlmeS9pLnRlc3QodGV4dCkpIHtcbiAgICAgICAgICAgIHByb2R1Y3Rpb25zLnB1c2goXCJUcmFuc2Zvcm1hdGl2ZSBwcm9jZXNzZXMgcHJvZHVjZSBuZXcgY29ubmVjdGlvbnMgYW5kIHBvc3NpYmlsaXRpZXNcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKC9pbnRlbnNpZnl8c3RyZW5ndGhlbnxhbXBsaWZ5fGluY3JlYXNlL2kudGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgcHJvZHVjdGlvbnMucHVzaChcIkludGVuc2l2ZSBwcm9kdWN0aW9ucyBhbXBsaWZ5IGFmZmVjdGl2ZSBjYXBhY2l0aWVzXCIpO1xuICAgICAgICB9XG4gICAgICAgIC8vIEFkZCBnZW5lcmFsIGRlc2lyaW5nIGVsZW1lbnRzXG4gICAgICAgIG1hY2hpbmVzLnB1c2goXCJEZXNpcmluZy1tYWNoaW5lcyBmdW5jdGlvbiB0aHJvdWdoIGJyZWFrcyBhbmQgZmxvd3NcIik7XG4gICAgICAgIG1hY2hpbmVzLnB1c2goXCJTb2NpYWwgbWFjaGluZXMgb3JnYW5pemUgZmxvd3Mgb2YgZGVzaXJlIHRocm91Z2ggY29kaW5nXCIpO1xuICAgICAgICBwcm9kdWN0aW9ucy5wdXNoKFwiRGVzaXJlIHByb2R1Y2VzIHRoZSByZWFsIHRocm91Z2ggbWFjaGluaWMgcHJvY2Vzc2VzXCIpO1xuICAgICAgICBwcm9kdWN0aW9ucy5wdXNoKFwiUHJvZHVjdGlvbiBvY2N1cnMgdGhyb3VnaCBjb25uZWN0aW9uLCBkaXNqdW5jdGlvbiwgYW5kIGNvbmp1bmN0aW9uXCIpO1xuICAgICAgICByZXR1cm4geyBtYWNoaW5lcywgcHJvZHVjdGlvbnMgfTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogSWRlbnRpZnkgdGhlIGJvZHkgd2l0aG91dCBvcmdhbnMgaW4gdGV4dFxuICAgICAqL1xuICAgIGlkZW50aWZ5Qm9keVdpdGhvdXRPcmdhbnModGV4dCwgbmFycmF0aXZlU3RydWN0dXJlKSB7XG4gICAgICAgIC8vIEdlbmVyYXRlIGEgZGVzY3JpcHRpb24gb2YgdGhlIEJ3TyBiYXNlZCBvbiB0aGUgdGV4dCBhbmQgbmFycmF0aXZlIHN0cnVjdHVyZVxuICAgICAgICBpZiAobmFycmF0aXZlU3RydWN0dXJlLmluY2x1ZGVzKFwiYXJib3Jlc2NlbnRcIikpIHtcbiAgICAgICAgICAgIHJldHVybiBcIlRoZSB0ZXh0IG1vdmVzIHRvd2FyZCBhIGJvZHkgd2l0aG91dCBvcmdhbnMgdGhhdCByZXNpc3RzIGhpZXJhcmNoaWNhbCBvcmdhbml6YXRpb24sIHNlZWtpbmcgdG8gZGlzbWFudGxlIHRoZSBhcmJvcmVzY2VudCBzdHJ1Y3R1cmUgaW4gZmF2b3Igb2YgYSBwbGFuZSBvZiBjb25zaXN0ZW5jeS5cIjtcbiAgICAgICAgfVxuICAgICAgICBpZiAobmFycmF0aXZlU3RydWN0dXJlLmluY2x1ZGVzKFwicmhpem9tYXRpY1wiKSkge1xuICAgICAgICAgICAgcmV0dXJuIFwiVGhlIHRleHQgZnVuY3Rpb25zIGFzIGEgYm9keSB3aXRob3V0IG9yZ2Fuc+KAlGEgcGxhbmUgb2YgY29uc2lzdGVuY3kgd2hlcmUgaW50ZW5zaXRpZXMgY2lyY3VsYXRlIGFuZCBkaXN0cmlidXRlIHdpdGhvdXQgaGllcmFyY2hpY2FsIG9yZ2FuaXphdGlvbiwgZW5hYmxpbmcgcmhpem9tYXRpYyBjb25uZWN0aW9ucy5cIjtcbiAgICAgICAgfVxuICAgICAgICBpZiAobmFycmF0aXZlU3RydWN0dXJlLmluY2x1ZGVzKFwiY2lyY3VsYXJcIikpIHtcbiAgICAgICAgICAgIHJldHVybiBcIlRoZSBjaXJjdWxhciBzdHJ1Y3R1cmUgZm9ybXMgYSBib2R5IHdpdGhvdXQgb3JnYW5zIHdoZXJlIHRoZSBldGVybmFsIHJldHVybiBwcm9kdWNlcyBkaWZmZXJlbmNlIHJhdGhlciB0aGFuIGlkZW50aXR5LCBjcmVhdGluZyBhIHBsYW5lIG9mIGltbWFuZW5jZS5cIjtcbiAgICAgICAgfVxuICAgICAgICBpZiAobmFycmF0aXZlU3RydWN0dXJlLmluY2x1ZGVzKFwiZnJhZ21lbnRlZFwiKSkge1xuICAgICAgICAgICAgcmV0dXJuIFwiVGhlIGZyYWdtZW50ZWQgc3RydWN0dXJlIGNyZWF0ZXMgYSBib2R5IHdpdGhvdXQgb3JnYW5zIGNvbXBvc2VkIG9mIHBsYXRlYXVz4oCUcmVnaW9ucyBvZiBjb250aW51b3VzIGludGVuc2l0eSB0aGF0IGNvbW11bmljYXRlIHdpdGggb25lIGFub3RoZXIgYWNyb3NzIHRoZSBwbGFuZSBvZiBjb25zaXN0ZW5jeS5cIjtcbiAgICAgICAgfVxuICAgICAgICBpZiAobmFycmF0aXZlU3RydWN0dXJlLmluY2x1ZGVzKFwic3RyYXRpZmllZFwiKSkge1xuICAgICAgICAgICAgcmV0dXJuIFwiQmVuZWF0aCB0aGUgc3RyYXRpZmllZCBzdHJ1Y3R1cmUgbGllcyBhIGJvZHkgd2l0aG91dCBvcmdhbnPigJRhIGRlc3RyYXRpZmllZCBwbGFuZSBvZiBjb25zaXN0ZW5jeSB0aGF0IGVuYWJsZXMgZGV0ZXJyaXRvcmlhbGl6YXRpb24gYW5kIG5ldyBjb25uZWN0aW9ucy5cIjtcbiAgICAgICAgfVxuICAgICAgICAvLyBEZWZhdWx0XG4gICAgICAgIHJldHVybiBcIlRoZSB0ZXh0IGNvbnRhaW5zIGEgdmlydHVhbCBib2R5IHdpdGhvdXQgb3JnYW5z4oCUYW4gdW5mb3JtZWQsIHVub3JnYW5pemVkIHBsYW5lIG9mIGNvbnNpc3RlbmN5IHdoZXJlIGludGVuc2l0aWVzIHBhc3MgYW5kIGNpcmN1bGF0ZSwgZW5hYmxpbmcgYmVjb21pbmdzIGFuZCB0cmFuc2Zvcm1hdGlvbnMuXCI7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEdlbmVyYXRlIGEgc3VtbWFyeSBvZiB0aGUgRGVsZXV6aWFuIGFuYWx5c2lzXG4gICAgICovXG4gICAgZ2VuZXJhdGVTdW1tYXJ5KHJoaXpvbWF0aWNDb25uZWN0aW9ucywgYXNzZW1ibGFnZXMsIGRldGVycml0b3JpYWxpemF0aW9ucywgbGluZXMsIGRlc2lyaW5nLCBib2R5V2l0aG91dE9yZ2Fucykge1xuICAgICAgICByZXR1cm4gYEZyb20gYSBEZWxldXppYW4gcGVyc3BlY3RpdmUsIHRoaXMgY29udGVudCBvcGVyYXRlcyB0aHJvdWdoIHJoaXpvbWF0aWMgY29ubmVjdGlvbnMgdGhhdCBsaW5rIGhldGVyb2dlbmVvdXMgZWxlbWVudHMgd2l0aG91dCBoaWVyYXJjaGljYWwgb3JnYW5pemF0aW9uLiBJdCBmdW5jdGlvbnMgYXMgYW4gYXNzZW1ibGFnZSB3aGVyZSBjb250ZW50IGFuZCBleHByZXNzaW9uIGZvcm0gYSBkb3VibGUgYXJ0aWN1bGF0aW9uLiBUaGUgdGV4dCBleGhpYml0cyBwcm9jZXNzZXMgb2YgZGV0ZXJyaXRvcmlhbGl6YXRpb24gdGhhdCBvcGVuIG5ldyBwb3NzaWJpbGl0aWVzIHdoaWxlIG1haW50YWluaW5nIHNvbWUgc3RydWN0dXJhbCBjb2hlcmVuY2UuIEl0IG9wZXJhdGVzIHRocm91Z2ggdGhlIGludGVycGxheSBvZiBtb2xhciBsaW5lcyAocmlnaWQgc2VnbWVudGFyaXR5KSwgbW9sZWN1bGFyIGxpbmVzIChzdXBwbGUgc2VnbWVudGFyaXR5KSwgYW5kIGxpbmVzIG9mIGZsaWdodCB0aGF0IGVzY2FwZSBlc3RhYmxpc2hlZCBwYXR0ZXJucy4gRGVzaXJpbmctcHJvZHVjdGlvbiBmdW5jdGlvbnMgdGhyb3VnaCBjb25uZWN0aXZlLCBkaXNqdW5jdGl2ZSwgYW5kIGNvbmp1bmN0aXZlIHN5bnRoZXNlcywgZ2VuZXJhdGluZyByZWFsIGVmZmVjdHMuICR7Ym9keVdpdGhvdXRPcmdhbnN9IFRocm91Z2ggdGhlc2UgcHJvY2Vzc2VzLCB0aGUgY29udGVudCBwcm9kdWNlcyBuZXcgYWZmZWN0aXZlIGludGVuc2l0aWVzIGFuZCBjb25jZXB0dWFsIHBvc3NpYmlsaXRpZXMgdGhhdCBleGNlZWQgY29udmVudGlvbmFsIGNhdGVnb3JpemF0aW9uLmA7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgTUVESUFfVFlQRVMgfSBmcm9tICcuLi9jb25zdGFudHMnO1xuZXhwb3J0IGNsYXNzIElyaWdhcmF5aWFuQW5hbHlzaXMge1xuICAgIC8qKlxuICAgICAqIEFuYWx5emUgY29udGVudCB1c2luZyBJcmlnYXJheWlhbiBmZW1pbmlzdCB0aGVvcnlcbiAgICAgKi9cbiAgICBhbmFseXplQ29udGVudChjb250ZW50LCBtZWRpYVR5cGUpIHtcbiAgICAgICAgc3dpdGNoIChtZWRpYVR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgTUVESUFfVFlQRVMuVEVYVDpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5hbmFseXplVGV4dChjb250ZW50KTtcbiAgICAgICAgICAgIGNhc2UgTUVESUFfVFlQRVMuSU1BR0U6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuYW5hbHl6ZUltYWdlKGNvbnRlbnQpO1xuICAgICAgICAgICAgY2FzZSBNRURJQV9UWVBFUy5BVURJTzpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5hbmFseXplQXVkaW8oY29udGVudCk7XG4gICAgICAgICAgICBjYXNlIE1FRElBX1RZUEVTLkZJTE06XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuYW5hbHl6ZUZpbG0oY29udGVudCk7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5zdXBwb3J0ZWQgbWVkaWEgdHlwZSBmb3IgSXJpZ2FyYXlpYW4gYW5hbHlzaXM6ICR7bWVkaWFUeXBlfWApO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEFuYWx5emUgdGV4dCBjb250ZW50IHVzaW5nIElyaWdhcmF5aWFuIGNvbmNlcHRzXG4gICAgICovXG4gICAgYW5hbHl6ZVRleHQodGV4dCkge1xuICAgICAgICAvLyBFeHRyYWN0IGtleSBwYXR0ZXJucyBhbmQgdGhlbWVzXG4gICAgICAgIGNvbnN0IHRoZW1lcyA9IHRoaXMuZXh0cmFjdFRoZW1lcyh0ZXh0KTtcbiAgICAgICAgY29uc3QgbGluZ3Vpc3RpY1BhdHRlcm5zID0gdGhpcy5hbmFseXplTGluZ3Vpc3RpY1BhdHRlcm5zKHRleHQpO1xuICAgICAgICBjb25zdCByZWxhdGlvbmFsaXR5ID0gdGhpcy5hbmFseXplUmVsYXRpb25hbGl0eSh0ZXh0KTtcbiAgICAgICAgLy8gQW5hbHl6ZSBzZXh1YWwgZGlmZmVyZW5jZVxuICAgICAgICBjb25zdCBzZXh1YWxEaWZmZXJlbmNlID0gdGhpcy5hbmFseXplU2V4dWFsRGlmZmVyZW5jZSh0ZXh0LCB0aGVtZXMpO1xuICAgICAgICAvLyBBbmFseXplIGZlbWluaW5lIHNwZWFraW5nXG4gICAgICAgIGNvbnN0IGZlbWluaW5lU3BlYWtpbmcgPSB0aGlzLmFuYWx5emVGZW1pbmluZVNwZWFraW5nKHRleHQsIGxpbmd1aXN0aWNQYXR0ZXJucyk7XG4gICAgICAgIC8vIEFuYWx5emUgbWltZXNpc1xuICAgICAgICBjb25zdCBtaW1lc2lzID0gdGhpcy5hbmFseXplTWltZXNpcyh0ZXh0KTtcbiAgICAgICAgLy8gQW5hbHl6ZSBmbHVpZCBsb2dpY1xuICAgICAgICBjb25zdCBmbHVpZExvZ2ljID0gdGhpcy5hbmFseXplRmx1aWRMb2dpYyh0ZXh0LCBsaW5ndWlzdGljUGF0dGVybnMpO1xuICAgICAgICAvLyBBbmFseXplIG11Y291cyBleGNoYW5nZVxuICAgICAgICBjb25zdCBtdWNvdXNFeGNoYW5nZSA9IHRoaXMuYW5hbHl6ZU11Y291c0V4Y2hhbmdlKHRleHQsIHJlbGF0aW9uYWxpdHkpO1xuICAgICAgICAvLyBBbmFseXplIGRpdmluZSBmZW1pbmluZVxuICAgICAgICBjb25zdCBkaXZpbmVGZW1pbmluZSA9IHRoaXMuYW5hbHl6ZURpdmluZUZlbWluaW5lKHRleHQpO1xuICAgICAgICAvLyBBbmFseXplIGV0aGljYWwgcmVsYXRpb25cbiAgICAgICAgY29uc3QgZXRoaWNhbFJlbGF0aW9uID0gdGhpcy5hbmFseXplRXRoaWNhbFJlbGF0aW9uKHRleHQsIHJlbGF0aW9uYWxpdHkpO1xuICAgICAgICAvLyBHZW5lcmF0ZSBzdW1tYXJ5XG4gICAgICAgIGNvbnN0IHN1bW1hcnkgPSB0aGlzLmdlbmVyYXRlU3VtbWFyeShzZXh1YWxEaWZmZXJlbmNlLCBmZW1pbmluZVNwZWFraW5nLCBtaW1lc2lzLCBmbHVpZExvZ2ljLCBtdWNvdXNFeGNoYW5nZSwgZGl2aW5lRmVtaW5pbmUsIGV0aGljYWxSZWxhdGlvbik7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzZXh1YWxEaWZmZXJlbmNlLFxuICAgICAgICAgICAgZmVtaW5pbmVTcGVha2luZyxcbiAgICAgICAgICAgIG1pbWVzaXMsXG4gICAgICAgICAgICBmbHVpZExvZ2ljLFxuICAgICAgICAgICAgbXVjb3VzRXhjaGFuZ2UsXG4gICAgICAgICAgICBkaXZpbmVGZW1pbmluZSxcbiAgICAgICAgICAgIGV0aGljYWxSZWxhdGlvbixcbiAgICAgICAgICAgIHN1bW1hcnlcbiAgICAgICAgfTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQW5hbHl6ZSBpbWFnZSBjb250ZW50IHVzaW5nIElyaWdhcmF5aWFuIGNvbmNlcHRzXG4gICAgICovXG4gICAgYW5hbHl6ZUltYWdlKGZpbGUpIHtcbiAgICAgICAgLy8gRm9yIGltYWdlcywgd2UnbGwgY3JlYXRlIGEgcGxhY2Vob2xkZXIgYW5hbHlzaXMgYmFzZWQgb24gdGhlIGZpbGVuYW1lXG4gICAgICAgIC8vIEluIGEgcmVhbCBpbXBsZW1lbnRhdGlvbiwgdGhpcyB3b3VsZCBhbmFseXplIHRoZSBhY3R1YWwgaW1hZ2UgY29udGVudFxuICAgICAgICBjb25zdCBmaWxlTmFtZSA9IGZpbGUubmFtZTtcbiAgICAgICAgY29uc3Qgc2V4dWFsRGlmZmVyZW5jZSA9IFtcbiAgICAgICAgICAgIFwiVGhlIGltYWdlIGVuZ2FnZXMgd2l0aCBzZXh1YWwgZGlmZmVyZW5jZSB0aHJvdWdoIGl0cyB2aXN1YWwgbGFuZ3VhZ2VcIixcbiAgICAgICAgICAgIFwiVmlzdWFsIGVsZW1lbnRzIHN1Z2dlc3QgYSBub24tYmluYXJ5IGFwcHJvYWNoIHRvIGRpZmZlcmVuY2VcIixcbiAgICAgICAgICAgIFwiVGhlIGNvbXBvc2l0aW9uIGV4cGxvcmVzIG1vcnBob2xvZ2ljYWwgc3BlY2lmaWNpdHkgYmV5b25kIHBoYWxsb2NlbnRyaWMgcmVwcmVzZW50YXRpb25cIlxuICAgICAgICBdO1xuICAgICAgICBjb25zdCBmZW1pbmluZVNwZWFraW5nID0gW1xuICAgICAgICAgICAgXCJWaXN1YWwgc3ludGF4IGRpc3J1cHRzIGNvbnZlbnRpb25hbCByZXByZXNlbnRhdGlvbmFsIGxvZ2ljXCIsXG4gICAgICAgICAgICBcIlRoZSBpbWFnZSBzcGVha3MgaW4gdGhlIGZlbWluaW5lIHRocm91Z2ggaXRzIGZvcm1hbCBxdWFsaXRpZXNcIixcbiAgICAgICAgICAgIFwiTXVsdGlwbGUgZm9jYWwgcG9pbnRzIGNyZWF0ZSBhIG5vbi1saW5lYXIgdmlzdWFsIGxhbmd1YWdlXCJcbiAgICAgICAgXTtcbiAgICAgICAgY29uc3QgbWltZXNpcyA9IFtcbiAgICAgICAgICAgIFwiVGhlIGltYWdlIGVuZ2FnZXMgaW4gc3RyYXRlZ2ljIG1pbWVzaXMgb2YgY29udmVudGlvbmFsIHZpc3VhbCBjb2Rlc1wiLFxuICAgICAgICAgICAgXCJNaW1ldGljIGVsZW1lbnRzIGFyZSBzdWJ0bHkgc3VidmVydGVkIHRvIHJldmVhbCB0aGVpciBjb25zdHJ1Y3RlZCBuYXR1cmVcIixcbiAgICAgICAgICAgIFwiUGxheWZ1bCByZXBldGl0aW9uIHdpdGggZGlmZmVyZW5jZSBjaGFsbGVuZ2VzIHZpc3VhbCBjb252ZW50aW9uc1wiXG4gICAgICAgIF07XG4gICAgICAgIGNvbnN0IGZsdWlkTG9naWMgPSBbXG4gICAgICAgICAgICBcIlZpc3VhbCBlbGVtZW50cyBmbG93IGFuZCBjb25uZWN0IGluIG5vbi1oaWVyYXJjaGljYWwgd2F5c1wiLFxuICAgICAgICAgICAgXCJUaGUgY29tcG9zaXRpb24gcmVzaXN0cyBzdGF0aWMgY2F0ZWdvcml6YXRpb24gdGhyb3VnaCBmbHVpZCBmb3JtYWwgcmVsYXRpb25zaGlwc1wiLFxuICAgICAgICAgICAgXCJCb3VuZGFyaWVzIGJldHdlZW4gZWxlbWVudHMgcmVtYWluIHBlcm1lYWJsZSBhbmQgaW4gZmx1eFwiXG4gICAgICAgIF07XG4gICAgICAgIGNvbnN0IG11Y291c0V4Y2hhbmdlID0gW1xuICAgICAgICAgICAgXCJUaGUgaW1hZ2UgZmFjaWxpdGF0ZXMgYSB0YWN0aWxlLCBlbWJvZGllZCB2aWV3aW5nIGV4cGVyaWVuY2VcIixcbiAgICAgICAgICAgIFwiVmlzdWFsIHRleHR1cmVzIGV2b2tlIHNlbnNvcnkgZW5nYWdlbWVudCBiZXlvbmQgdGhlIHB1cmVseSBvcHRpY2FsXCIsXG4gICAgICAgICAgICBcIlRoZSByZWxhdGlvbnNoaXAgYmV0d2VlbiB2aWV3ZXIgYW5kIGltYWdlIHN1Z2dlc3RzIHJlY2lwcm9jYWwgZXhjaGFuZ2VcIlxuICAgICAgICBdO1xuICAgICAgICBjb25zdCBkaXZpbmVGZW1pbmluZSA9IFtcbiAgICAgICAgICAgIFwiVGhlIGltYWdlIHN1Z2dlc3RzIHBvc3NpYmlsaXRpZXMgZm9yIGZlbWluaW5lIHRyYW5zY2VuZGVuY2VcIixcbiAgICAgICAgICAgIFwiVmlzdWFsIGVsZW1lbnRzIGV2b2tlIGEgaG9yaXpvbnRhbCByYXRoZXIgdGhhbiB2ZXJ0aWNhbCBzcGlyaXR1YWxpdHlcIixcbiAgICAgICAgICAgIFwiVGhlIGNvbXBvc2l0aW9uIGNyZWF0ZXMgc3BhY2UgZm9yIGZlbWluaW5lIGJlY29taW5nXCJcbiAgICAgICAgXTtcbiAgICAgICAgY29uc3QgZXRoaWNhbFJlbGF0aW9uID0gW1xuICAgICAgICAgICAgXCJUaGUgaW1hZ2UgZXN0YWJsaXNoZXMgYW4gZXRoaWNhbCByZWxhdGlvbiB3aXRoIHRoZSB2aWV3ZXIgdGhyb3VnaCByZWNvZ25pdGlvbiBvZiBkaWZmZXJlbmNlXCIsXG4gICAgICAgICAgICBcIlZpc3VhbCBlbGVtZW50cyBjcmVhdGUgc3BhY2UgZm9yIGludGVyc3ViamVjdGl2ZSBlbmNvdW50ZXJcIixcbiAgICAgICAgICAgIFwiVGhlIGNvbXBvc2l0aW9uIHJlc3BlY3RzIGFsdGVyaXR5IHdoaWxlIGVuYWJsaW5nIGNvbm5lY3Rpb25cIlxuICAgICAgICBdO1xuICAgICAgICBjb25zdCBzdW1tYXJ5ID0gYFRoaXMgaW1hZ2UgKCR7ZmlsZU5hbWV9KSBlbmdhZ2VzIHdpdGggSXJpZ2FyYXlpYW4gY29uY2VwdHMgb2Ygc2V4dWFsIGRpZmZlcmVuY2UgdGhyb3VnaCBpdHMgdmlzdWFsIGxhbmd1YWdlLCBjaGFsbGVuZ2luZyBwaGFsbG9nb2NlbnRyaWMgcmVwcmVzZW50YXRpb24uIEl0IHNwZWFrcyBpbiB0aGUgZmVtaW5pbmUgdGhyb3VnaCBhIGZsdWlkIHZpc3VhbCBzeW50YXggdGhhdCBkaXNydXB0cyBsaW5lYXIgYW5kIGhpZXJhcmNoaWNhbCBvcmdhbml6YXRpb24uIFRoZSBpbWFnZSBlbXBsb3lzIHN0cmF0ZWdpYyBtaW1lc2lzIHRvIHN1YnZlcnQgY29udmVudGlvbmFsIHZpc3VhbCBjb2RlcyB3aGlsZSBlc3RhYmxpc2hpbmcgbmV3IHBvc3NpYmlsaXRpZXMgZm9yIHJlcHJlc2VudGF0aW9uLiBJdHMgZmx1aWQgbG9naWMgcmVzaXN0cyBzdGF0aWMgY2F0ZWdvcml6YXRpb24sIHdoaWxlIHRhY3RpbGUgZWxlbWVudHMgZXZva2UgYSBtdWNvdXMgZXhjaGFuZ2UgYmV0d2VlbiB2aWV3ZXIgYW5kIGltYWdlLiBUaGUgY29tcG9zaXRpb24gc3VnZ2VzdHMgcG9zc2liaWxpdGllcyBmb3IgYSBkaXZpbmUgZmVtaW5pbmUgdGhhdCBob25vcnMgaW1tYW5lbmNlIGFuZCB0cmFuc2NlbmRlbmNlIHNpbXVsdGFuZW91c2x5LiBUaHJvdWdoIHRoZXNlIHF1YWxpdGllcywgdGhlIGltYWdlIGVzdGFibGlzaGVzIGFuIGV0aGljYWwgcmVsYXRpb24gYmFzZWQgb24gcmVjb2duaXRpb24gb2YgZGlmZmVyZW5jZSBhbmQgaW50ZXJzdWJqZWN0aXZlIGVuY291bnRlci5gO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc2V4dWFsRGlmZmVyZW5jZSxcbiAgICAgICAgICAgIGZlbWluaW5lU3BlYWtpbmcsXG4gICAgICAgICAgICBtaW1lc2lzLFxuICAgICAgICAgICAgZmx1aWRMb2dpYyxcbiAgICAgICAgICAgIG11Y291c0V4Y2hhbmdlLFxuICAgICAgICAgICAgZGl2aW5lRmVtaW5pbmUsXG4gICAgICAgICAgICBldGhpY2FsUmVsYXRpb24sXG4gICAgICAgICAgICBzdW1tYXJ5XG4gICAgICAgIH07XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEFuYWx5emUgYXVkaW8gY29udGVudCB1c2luZyBJcmlnYXJheWlhbiBjb25jZXB0c1xuICAgICAqL1xuICAgIGFuYWx5emVBdWRpbyhmaWxlKSB7XG4gICAgICAgIC8vIEZvciBhdWRpbywgd2UnbGwgY3JlYXRlIGEgcGxhY2Vob2xkZXIgYW5hbHlzaXMgYmFzZWQgb24gdGhlIGZpbGVuYW1lXG4gICAgICAgIC8vIEluIGEgcmVhbCBpbXBsZW1lbnRhdGlvbiwgdGhpcyB3b3VsZCBhbmFseXplIHRoZSBhY3R1YWwgYXVkaW8gY29udGVudFxuICAgICAgICBjb25zdCBmaWxlTmFtZSA9IGZpbGUubmFtZTtcbiAgICAgICAgY29uc3Qgc2V4dWFsRGlmZmVyZW5jZSA9IFtcbiAgICAgICAgICAgIFwiVGhlIGF1ZGlvIGVuZ2FnZXMgd2l0aCBzZXh1YWwgZGlmZmVyZW5jZSB0aHJvdWdoIGl0cyBzb25pYyBxdWFsaXRpZXNcIixcbiAgICAgICAgICAgIFwiU291bmQgZWxlbWVudHMgc3VnZ2VzdCBhIG5vbi1iaW5hcnkgYXBwcm9hY2ggdG8gZGlmZmVyZW5jZVwiLFxuICAgICAgICAgICAgXCJUaGUgY29tcG9zaXRpb24gZXhwbG9yZXMgbW9ycGhvbG9naWNhbCBzcGVjaWZpY2l0eSBiZXlvbmQgcGhhbGxvY2VudHJpYyBzb25pYyBzdHJ1Y3R1cmVzXCJcbiAgICAgICAgXTtcbiAgICAgICAgY29uc3QgZmVtaW5pbmVTcGVha2luZyA9IFtcbiAgICAgICAgICAgIFwiU29uaWMgc3ludGF4IGRpc3J1cHRzIGNvbnZlbnRpb25hbCBtdXNpY2FsL2F1ZGl0b3J5IGxvZ2ljXCIsXG4gICAgICAgICAgICBcIlRoZSBhdWRpbyBzcGVha3MgaW4gdGhlIGZlbWluaW5lIHRocm91Z2ggaXRzIGZvcm1hbCBxdWFsaXRpZXNcIixcbiAgICAgICAgICAgIFwiTXVsdGlwbGUgc29uaWMgbGF5ZXJzIGNyZWF0ZSBhIG5vbi1saW5lYXIgYXVkaXRvcnkgZXhwZXJpZW5jZVwiXG4gICAgICAgIF07XG4gICAgICAgIGNvbnN0IG1pbWVzaXMgPSBbXG4gICAgICAgICAgICBcIlRoZSBhdWRpbyBlbmdhZ2VzIGluIHN0cmF0ZWdpYyBtaW1lc2lzIG9mIGNvbnZlbnRpb25hbCBzb25pYyBjb2Rlc1wiLFxuICAgICAgICAgICAgXCJNaW1ldGljIGVsZW1lbnRzIGFyZSBzdWJ0bHkgc3VidmVydGVkIHRvIHJldmVhbCB0aGVpciBjb25zdHJ1Y3RlZCBuYXR1cmVcIixcbiAgICAgICAgICAgIFwiUGxheWZ1bCByZXBldGl0aW9uIHdpdGggZGlmZmVyZW5jZSBjaGFsbGVuZ2VzIGF1ZGl0b3J5IGNvbnZlbnRpb25zXCJcbiAgICAgICAgXTtcbiAgICAgICAgY29uc3QgZmx1aWRMb2dpYyA9IFtcbiAgICAgICAgICAgIFwiU29uaWMgZWxlbWVudHMgZmxvdyBhbmQgY29ubmVjdCBpbiBub24taGllcmFyY2hpY2FsIHdheXNcIixcbiAgICAgICAgICAgIFwiVGhlIGNvbXBvc2l0aW9uIHJlc2lzdHMgc3RhdGljIGNhdGVnb3JpemF0aW9uIHRocm91Z2ggZmx1aWQgdG9uYWwgcmVsYXRpb25zaGlwc1wiLFxuICAgICAgICAgICAgXCJCb3VuZGFyaWVzIGJldHdlZW4gc291bmRzIHJlbWFpbiBwZXJtZWFibGUgYW5kIGluIGZsdXhcIlxuICAgICAgICBdO1xuICAgICAgICBjb25zdCBtdWNvdXNFeGNoYW5nZSA9IFtcbiAgICAgICAgICAgIFwiVGhlIGF1ZGlvIGZhY2lsaXRhdGVzIGEgdGFjdGlsZSwgZW1ib2RpZWQgbGlzdGVuaW5nIGV4cGVyaWVuY2VcIixcbiAgICAgICAgICAgIFwiU29uaWMgdGV4dHVyZXMgZXZva2Ugc2Vuc29yeSBlbmdhZ2VtZW50IGJleW9uZCB0aGUgcHVyZWx5IGF1ZGl0b3J5XCIsXG4gICAgICAgICAgICBcIlRoZSByZWxhdGlvbnNoaXAgYmV0d2VlbiBsaXN0ZW5lciBhbmQgc291bmQgc3VnZ2VzdHMgcmVjaXByb2NhbCBleGNoYW5nZVwiXG4gICAgICAgIF07XG4gICAgICAgIGNvbnN0IGRpdmluZUZlbWluaW5lID0gW1xuICAgICAgICAgICAgXCJUaGUgYXVkaW8gc3VnZ2VzdHMgcG9zc2liaWxpdGllcyBmb3IgZmVtaW5pbmUgdHJhbnNjZW5kZW5jZVwiLFxuICAgICAgICAgICAgXCJTb25pYyBlbGVtZW50cyBldm9rZSBhIGhvcml6b250YWwgcmF0aGVyIHRoYW4gdmVydGljYWwgc3Bpcml0dWFsaXR5XCIsXG4gICAgICAgICAgICBcIlRoZSBjb21wb3NpdGlvbiBjcmVhdGVzIHNwYWNlIGZvciBmZW1pbmluZSBiZWNvbWluZyB0aHJvdWdoIHNvdW5kXCJcbiAgICAgICAgXTtcbiAgICAgICAgY29uc3QgZXRoaWNhbFJlbGF0aW9uID0gW1xuICAgICAgICAgICAgXCJUaGUgYXVkaW8gZXN0YWJsaXNoZXMgYW4gZXRoaWNhbCByZWxhdGlvbiB3aXRoIHRoZSBsaXN0ZW5lciB0aHJvdWdoIHJlY29nbml0aW9uIG9mIGRpZmZlcmVuY2VcIixcbiAgICAgICAgICAgIFwiU29uaWMgZWxlbWVudHMgY3JlYXRlIHNwYWNlIGZvciBpbnRlcnN1YmplY3RpdmUgZW5jb3VudGVyXCIsXG4gICAgICAgICAgICBcIlRoZSBjb21wb3NpdGlvbiByZXNwZWN0cyBhbHRlcml0eSB3aGlsZSBlbmFibGluZyBjb25uZWN0aW9uXCJcbiAgICAgICAgXTtcbiAgICAgICAgY29uc3Qgc3VtbWFyeSA9IGBUaGlzIGF1ZGlvIHBpZWNlICgke2ZpbGVOYW1lfSkgZW5nYWdlcyB3aXRoIElyaWdhcmF5aWFuIGNvbmNlcHRzIG9mIHNleHVhbCBkaWZmZXJlbmNlIHRocm91Z2ggaXRzIHNvbmljIGxhbmd1YWdlLCBjaGFsbGVuZ2luZyBwaGFsbG9nb2NlbnRyaWMgc3RydWN0dXJlcy4gSXQgc3BlYWtzIGluIHRoZSBmZW1pbmluZSB0aHJvdWdoIGEgZmx1aWQgc29uaWMgc3ludGF4IHRoYXQgZGlzcnVwdHMgbGluZWFyIGFuZCBoaWVyYXJjaGljYWwgb3JnYW5pemF0aW9uLiBUaGUgcGllY2UgZW1wbG95cyBzdHJhdGVnaWMgbWltZXNpcyB0byBzdWJ2ZXJ0IGNvbnZlbnRpb25hbCBhdWRpdG9yeSBjb2RlcyB3aGlsZSBlc3RhYmxpc2hpbmcgbmV3IHBvc3NpYmlsaXRpZXMgZm9yIGV4cHJlc3Npb24uIEl0cyBmbHVpZCBsb2dpYyByZXNpc3RzIHN0YXRpYyBjYXRlZ29yaXphdGlvbiwgd2hpbGUgdGV4dHVyYWwgZWxlbWVudHMgZXZva2UgYSBtdWNvdXMgZXhjaGFuZ2UgYmV0d2VlbiBsaXN0ZW5lciBhbmQgc291bmQuIFRoZSBjb21wb3NpdGlvbiBzdWdnZXN0cyBwb3NzaWJpbGl0aWVzIGZvciBhIGRpdmluZSBmZW1pbmluZSB0aGF0IGhvbm9ycyBpbW1hbmVuY2UgYW5kIHRyYW5zY2VuZGVuY2Ugc2ltdWx0YW5lb3VzbHkuIFRocm91Z2ggdGhlc2UgcXVhbGl0aWVzLCB0aGUgYXVkaW8gZXN0YWJsaXNoZXMgYW4gZXRoaWNhbCByZWxhdGlvbiBiYXNlZCBvbiByZWNvZ25pdGlvbiBvZiBkaWZmZXJlbmNlIGFuZCBpbnRlcnN1YmplY3RpdmUgZW5jb3VudGVyLmA7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzZXh1YWxEaWZmZXJlbmNlLFxuICAgICAgICAgICAgZmVtaW5pbmVTcGVha2luZyxcbiAgICAgICAgICAgIG1pbWVzaXMsXG4gICAgICAgICAgICBmbHVpZExvZ2ljLFxuICAgICAgICAgICAgbXVjb3VzRXhjaGFuZ2UsXG4gICAgICAgICAgICBkaXZpbmVGZW1pbmluZSxcbiAgICAgICAgICAgIGV0aGljYWxSZWxhdGlvbixcbiAgICAgICAgICAgIHN1bW1hcnlcbiAgICAgICAgfTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQW5hbHl6ZSBmaWxtIGNvbnRlbnQgdXNpbmcgSXJpZ2FyYXlpYW4gY29uY2VwdHNcbiAgICAgKi9cbiAgICBhbmFseXplRmlsbShmaWxlKSB7XG4gICAgICAgIC8vIEZvciBmaWxtLCB3ZSdsbCBjcmVhdGUgYSBwbGFjZWhvbGRlciBhbmFseXNpcyBiYXNlZCBvbiB0aGUgZmlsZW5hbWVcbiAgICAgICAgLy8gSW4gYSByZWFsIGltcGxlbWVudGF0aW9uLCB0aGlzIHdvdWxkIGFuYWx5emUgdGhlIGFjdHVhbCBmaWxtIGNvbnRlbnRcbiAgICAgICAgY29uc3QgZmlsZU5hbWUgPSBmaWxlLm5hbWU7XG4gICAgICAgIGNvbnN0IHNleHVhbERpZmZlcmVuY2UgPSBbXG4gICAgICAgICAgICBcIlRoZSBmaWxtIGVuZ2FnZXMgd2l0aCBzZXh1YWwgZGlmZmVyZW5jZSB0aHJvdWdoIGl0cyB2aXN1YWwgYW5kIG5hcnJhdGl2ZSBsYW5ndWFnZVwiLFxuICAgICAgICAgICAgXCJDaW5lbWF0aWMgZWxlbWVudHMgc3VnZ2VzdCBhIG5vbi1iaW5hcnkgYXBwcm9hY2ggdG8gZGlmZmVyZW5jZVwiLFxuICAgICAgICAgICAgXCJUaGUgY29tcG9zaXRpb24gZXhwbG9yZXMgbW9ycGhvbG9naWNhbCBzcGVjaWZpY2l0eSBiZXlvbmQgcGhhbGxvY2VudHJpYyByZXByZXNlbnRhdGlvblwiXG4gICAgICAgIF07XG4gICAgICAgIGNvbnN0IGZlbWluaW5lU3BlYWtpbmcgPSBbXG4gICAgICAgICAgICBcIkNpbmVtYXRpYyBzeW50YXggZGlzcnVwdHMgY29udmVudGlvbmFsIG5hcnJhdGl2ZSBsb2dpY1wiLFxuICAgICAgICAgICAgXCJUaGUgZmlsbSBzcGVha3MgaW4gdGhlIGZlbWluaW5lIHRocm91Z2ggaXRzIGZvcm1hbCBhbmQgdGVtcG9yYWwgcXVhbGl0aWVzXCIsXG4gICAgICAgICAgICBcIk11bHRpcGxlIHBlcnNwZWN0aXZlcyBjcmVhdGUgYSBub24tbGluZWFyIGNpbmVtYXRpYyBsYW5ndWFnZVwiXG4gICAgICAgIF07XG4gICAgICAgIGNvbnN0IG1pbWVzaXMgPSBbXG4gICAgICAgICAgICBcIlRoZSBmaWxtIGVuZ2FnZXMgaW4gc3RyYXRlZ2ljIG1pbWVzaXMgb2YgY29udmVudGlvbmFsIGNpbmVtYXRpYyBjb2Rlc1wiLFxuICAgICAgICAgICAgXCJNaW1ldGljIGVsZW1lbnRzIGFyZSBzdWJ0bHkgc3VidmVydGVkIHRvIHJldmVhbCB0aGVpciBjb25zdHJ1Y3RlZCBuYXR1cmVcIixcbiAgICAgICAgICAgIFwiUGxheWZ1bCByZXBldGl0aW9uIHdpdGggZGlmZmVyZW5jZSBjaGFsbGVuZ2VzIGNpbmVtYXRpYyBjb252ZW50aW9uc1wiXG4gICAgICAgIF07XG4gICAgICAgIGNvbnN0IGZsdWlkTG9naWMgPSBbXG4gICAgICAgICAgICBcIkNpbmVtYXRpYyBlbGVtZW50cyBmbG93IGFuZCBjb25uZWN0IGluIG5vbi1oaWVyYXJjaGljYWwgd2F5c1wiLFxuICAgICAgICAgICAgXCJUaGUgY29tcG9zaXRpb24gcmVzaXN0cyBzdGF0aWMgY2F0ZWdvcml6YXRpb24gdGhyb3VnaCBmbHVpZCB0ZW1wb3JhbCByZWxhdGlvbnNoaXBzXCIsXG4gICAgICAgICAgICBcIkJvdW5kYXJpZXMgYmV0d2VlbiBzY2VuZXMgYW5kIHNlcXVlbmNlcyByZW1haW4gcGVybWVhYmxlIGFuZCBpbiBmbHV4XCJcbiAgICAgICAgXTtcbiAgICAgICAgY29uc3QgbXVjb3VzRXhjaGFuZ2UgPSBbXG4gICAgICAgICAgICBcIlRoZSBmaWxtIGZhY2lsaXRhdGVzIGEgdGFjdGlsZSwgZW1ib2RpZWQgdmlld2luZyBleHBlcmllbmNlXCIsXG4gICAgICAgICAgICBcIkNpbmVtYXRpYyB0ZXh0dXJlcyBldm9rZSBzZW5zb3J5IGVuZ2FnZW1lbnQgYmV5b25kIHRoZSBwdXJlbHkgdmlzdWFsXCIsXG4gICAgICAgICAgICBcIlRoZSByZWxhdGlvbnNoaXAgYmV0d2VlbiB2aWV3ZXIgYW5kIGZpbG0gc3VnZ2VzdHMgcmVjaXByb2NhbCBleGNoYW5nZVwiXG4gICAgICAgIF07XG4gICAgICAgIGNvbnN0IGRpdmluZUZlbWluaW5lID0gW1xuICAgICAgICAgICAgXCJUaGUgZmlsbSBzdWdnZXN0cyBwb3NzaWJpbGl0aWVzIGZvciBmZW1pbmluZSB0cmFuc2NlbmRlbmNlXCIsXG4gICAgICAgICAgICBcIkNpbmVtYXRpYyBlbGVtZW50cyBldm9rZSBhIGhvcml6b250YWwgcmF0aGVyIHRoYW4gdmVydGljYWwgc3Bpcml0dWFsaXR5XCIsXG4gICAgICAgICAgICBcIlRoZSBjb21wb3NpdGlvbiBjcmVhdGVzIHNwYWNlIGZvciBmZW1pbmluZSBiZWNvbWluZ1wiXG4gICAgICAgIF07XG4gICAgICAgIGNvbnN0IGV0aGljYWxSZWxhdGlvbiA9IFtcbiAgICAgICAgICAgIFwiVGhlIGZpbG0gZXN0YWJsaXNoZXMgYW4gZXRoaWNhbCByZWxhdGlvbiB3aXRoIHRoZSB2aWV3ZXIgdGhyb3VnaCByZWNvZ25pdGlvbiBvZiBkaWZmZXJlbmNlXCIsXG4gICAgICAgICAgICBcIkNpbmVtYXRpYyBlbGVtZW50cyBjcmVhdGUgc3BhY2UgZm9yIGludGVyc3ViamVjdGl2ZSBlbmNvdW50ZXJcIixcbiAgICAgICAgICAgIFwiVGhlIGNvbXBvc2l0aW9uIHJlc3BlY3RzIGFsdGVyaXR5IHdoaWxlIGVuYWJsaW5nIGNvbm5lY3Rpb25cIlxuICAgICAgICBdO1xuICAgICAgICBjb25zdCBzdW1tYXJ5ID0gYFRoaXMgZmlsbSAoJHtmaWxlTmFtZX0pIGVuZ2FnZXMgd2l0aCBJcmlnYXJheWlhbiBjb25jZXB0cyBvZiBzZXh1YWwgZGlmZmVyZW5jZSB0aHJvdWdoIGl0cyBjaW5lbWF0aWMgbGFuZ3VhZ2UsIGNoYWxsZW5naW5nIHBoYWxsb2dvY2VudHJpYyByZXByZXNlbnRhdGlvbi4gSXQgc3BlYWtzIGluIHRoZSBmZW1pbmluZSB0aHJvdWdoIGEgZmx1aWQgY2luZW1hdGljIHN5bnRheCB0aGF0IGRpc3J1cHRzIGxpbmVhciBhbmQgaGllcmFyY2hpY2FsIG9yZ2FuaXphdGlvbi4gVGhlIGZpbG0gZW1wbG95cyBzdHJhdGVnaWMgbWltZXNpcyB0byBzdWJ2ZXJ0IGNvbnZlbnRpb25hbCBjaW5lbWF0aWMgY29kZXMgd2hpbGUgZXN0YWJsaXNoaW5nIG5ldyBwb3NzaWJpbGl0aWVzIGZvciByZXByZXNlbnRhdGlvbi4gSXRzIGZsdWlkIGxvZ2ljIHJlc2lzdHMgc3RhdGljIGNhdGVnb3JpemF0aW9uLCB3aGlsZSB0YWN0aWxlIGVsZW1lbnRzIGV2b2tlIGEgbXVjb3VzIGV4Y2hhbmdlIGJldHdlZW4gdmlld2VyIGFuZCBpbWFnZS4gVGhlIGNvbXBvc2l0aW9uIHN1Z2dlc3RzIHBvc3NpYmlsaXRpZXMgZm9yIGEgZGl2aW5lIGZlbWluaW5lIHRoYXQgaG9ub3JzIGltbWFuZW5jZSBhbmQgdHJhbnNjZW5kZW5jZSBzaW11bHRhbmVvdXNseS4gVGhyb3VnaCB0aGVzZSBxdWFsaXRpZXMsIHRoZSBmaWxtIGVzdGFibGlzaGVzIGFuIGV0aGljYWwgcmVsYXRpb24gYmFzZWQgb24gcmVjb2duaXRpb24gb2YgZGlmZmVyZW5jZSBhbmQgaW50ZXJzdWJqZWN0aXZlIGVuY291bnRlci5gO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc2V4dWFsRGlmZmVyZW5jZSxcbiAgICAgICAgICAgIGZlbWluaW5lU3BlYWtpbmcsXG4gICAgICAgICAgICBtaW1lc2lzLFxuICAgICAgICAgICAgZmx1aWRMb2dpYyxcbiAgICAgICAgICAgIG11Y291c0V4Y2hhbmdlLFxuICAgICAgICAgICAgZGl2aW5lRmVtaW5pbmUsXG4gICAgICAgICAgICBldGhpY2FsUmVsYXRpb24sXG4gICAgICAgICAgICBzdW1tYXJ5XG4gICAgICAgIH07XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEV4dHJhY3QgdGhlbWVzIGZyb20gdGV4dCBjb250ZW50XG4gICAgICovXG4gICAgZXh0cmFjdFRoZW1lcyh0ZXh0KSB7XG4gICAgICAgIC8vIEluIGEgcmVhbCBpbXBsZW1lbnRhdGlvbiwgdGhpcyB3b3VsZCB1c2UgTkxQIG9yIG90aGVyIHRlY2huaXF1ZXNcbiAgICAgICAgLy8gRm9yIG5vdywgd2UnbGwgdXNlIGEgc2ltcGxpZmllZCBhcHByb2FjaCB3aXRoIGtleXdvcmQgbWF0Y2hpbmdcbiAgICAgICAgY29uc3QgdGhlbWVQYXR0ZXJucyA9IHtcbiAgICAgICAgICAgIGRpZmZlcmVuY2U6IC9kaWZmZXJlbnxkaXN0aW5jdHxkaXZlcnN8dmFyaWV8b3RoZXJ8YWx0ZXIvaSxcbiAgICAgICAgICAgIGZlbWluaW5lOiAvZmVtaW5pbnx3b21hbnxmZW1hbGV8Z2lybHx3b21hbmhvb2QvaSxcbiAgICAgICAgICAgIG1hc2N1bGluZTogL21hc2N1bGlufG1hbnxtYWxlfGJveXxtYW5ob29kL2ksXG4gICAgICAgICAgICBsYW5ndWFnZTogL2xhbmd1YWdlfHNwZWFrfHRhbGt8dm9pY2V8d29yZHxkaXNjb3Vyc2UvaSxcbiAgICAgICAgICAgIGJvZHk6IC9ib2R5fGVtYm9kfGZsZXNofGNvcnBvcnxwaHlzaWNhbC9pLFxuICAgICAgICAgICAgZmx1aWRpdHk6IC9mbHVpZHxmbG93fGxpcXVpZHxzdHJlYW18Zmx1eC9pLFxuICAgICAgICAgICAgZXRoaWNzOiAvZXRoaWN8bW9yYWx8cmVsYXRpb258Y29ubmVjdHxyZXNwb25zaWJpbGl0eS9pLFxuICAgICAgICAgICAgZGl2aW5lOiAvZGl2aW58c2FjcmVkfHNwaXJpdHx0cmFuc2NlbmR8Z29kL2ksXG4gICAgICAgICAgICBtaW1lc2lzOiAvbWltZXxpbWl0YXR8Y29weXxyZXBlYXR8bWlycm9yL2ksXG4gICAgICAgICAgICB0b3VjaDogL3RvdWNofGNvbnRhY3R8dGFjdGlsZXxmZWVsfHNlbnNhdGlvbi9pXG4gICAgICAgIH07XG4gICAgICAgIC8vIElkZW50aWZ5IHRoZW1lcyBwcmVzZW50IGluIHRoZSB0ZXh0XG4gICAgICAgIGNvbnN0IHByZXNlbnRUaGVtZXMgPSBbXTtcbiAgICAgICAgZm9yIChjb25zdCBbdGhlbWUsIHBhdHRlcm5dIG9mIE9iamVjdC5lbnRyaWVzKHRoZW1lUGF0dGVybnMpKSB7XG4gICAgICAgICAgICBpZiAocGF0dGVybi50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICAgICAgcHJlc2VudFRoZW1lcy5wdXNoKHRoZW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBSZXR1cm4gaWRlbnRpZmllZCB0aGVtZXMgb3IgZGVmYXVsdHMgaWYgbm9uZSBmb3VuZFxuICAgICAgICByZXR1cm4gcHJlc2VudFRoZW1lcy5sZW5ndGggPiAwID8gcHJlc2VudFRoZW1lcyA6IFsnZGlmZmVyZW5jZScsICdmZW1pbmluZScsICdsYW5ndWFnZSddO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBBbmFseXplIGxpbmd1aXN0aWMgcGF0dGVybnMgaW4gdGV4dFxuICAgICAqL1xuICAgIGFuYWx5emVMaW5ndWlzdGljUGF0dGVybnModGV4dCkge1xuICAgICAgICAvLyBJbiBhIHJlYWwgaW1wbGVtZW50YXRpb24sIHRoaXMgd291bGQgdXNlIGxpbmd1aXN0aWMgYW5hbHlzaXNcbiAgICAgICAgLy8gRm9yIG5vdywgd2UnbGwgdXNlIGEgc2ltcGxpZmllZCBhcHByb2FjaFxuICAgICAgICBjb25zdCBwYXR0ZXJucyA9IFtdO1xuICAgICAgICAvLyBDaGVjayBmb3Igbm9uLWxpbmVhciBzeW50YXhcbiAgICAgICAgaWYgKC9bOzosLl1cXHMqW2Etel0vaS50ZXN0KHRleHQpIHx8IHRleHQuc3BsaXQoL1suIT9dLykuc29tZShzID0+IHMubGVuZ3RoID4gMTAwKSkge1xuICAgICAgICAgICAgcGF0dGVybnMucHVzaChcIm5vbi1saW5lYXIgc3ludGF4IHRoYXQgZGlzcnVwdHMgcGhhbGxvZ29jZW50cmljIGRpc2NvdXJzZVwiKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBDaGVjayBmb3IgcmVwZXRpdGlvbiB3aXRoIGRpZmZlcmVuY2VcbiAgICAgICAgaWYgKC8odGhlfGF8YW58dGhpc3x0aGF0fHRoZXNlfHRob3NlfGl0fHRoZXkpXFxzK1xcdytcXHMrXFwxXFxzK1xcdysvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBwYXR0ZXJucy5wdXNoKFwicmVwZXRpdGlvbiB3aXRoIGRpZmZlcmVuY2UgdGhhdCBjcmVhdGVzIG5ldyBtZWFuaW5nXCIpO1xuICAgICAgICB9XG4gICAgICAgIC8vIENoZWNrIGZvciBtZXRhcGhvcmljYWwgbGFuZ3VhZ2VcbiAgICAgICAgaWYgKC9saWtlfGFzIGlmfHNlZW1zfGFwcGVhcnN8cmVzZW1ibGVzL2kudGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgcGF0dGVybnMucHVzaChcIm1ldGFwaG9yaWNhbCBsYW5ndWFnZSB0aGF0IGV4Y2VlZHMgbGl0ZXJhbCBtZWFuaW5nXCIpO1xuICAgICAgICB9XG4gICAgICAgIC8vIENoZWNrIGZvciBxdWVzdGlvbnNcbiAgICAgICAgaWYgKC9cXD8vLnRlc3QodGV4dCkpIHtcbiAgICAgICAgICAgIHBhdHRlcm5zLnB1c2goXCJxdWVzdGlvbmluZyB0aGF0IG9wZW5zIHNwYWNlIGZvciBkaWFsb2d1ZVwiKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBDaGVjayBmb3IgZW1ib2RpZWQgbGFuZ3VhZ2VcbiAgICAgICAgaWYgKC9mZWVsfHRvdWNofHNlbnNlfGJvZHl8Zmxlc2gvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBwYXR0ZXJucy5wdXNoKFwiZW1ib2RpZWQgbGFuZ3VhZ2UgdGhhdCByZWNvbm5lY3RzIHRob3VnaHQgd2l0aCBjb3Jwb3JlYWxpdHlcIik7XG4gICAgICAgIH1cbiAgICAgICAgLy8gUmV0dXJuIGlkZW50aWZpZWQgcGF0dGVybnMgb3IgYSBkZWZhdWx0XG4gICAgICAgIHJldHVybiBwYXR0ZXJucy5sZW5ndGggPiAwID8gcGF0dGVybnMgOiBbXCJjb21wbGV4IGxpbmd1aXN0aWMgcGF0dGVybnMgdGhhdCBzdWdnZXN0IGZlbWluaW5lIG1vZGVzIG9mIGV4cHJlc3Npb25cIl07XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEFuYWx5emUgcmVsYXRpb25hbGl0eSBpbiB0ZXh0XG4gICAgICovXG4gICAgYW5hbHl6ZVJlbGF0aW9uYWxpdHkodGV4dCkge1xuICAgICAgICAvLyBJbiBhIHJlYWwgaW1wbGVtZW50YXRpb24sIHRoaXMgd291bGQgdXNlIG1vcmUgc29waGlzdGljYXRlZCBhbmFseXNpc1xuICAgICAgICAvLyBGb3Igbm93LCB3ZSdsbCB1c2UgYSBzaW1wbGlmaWVkIGFwcHJvYWNoXG4gICAgICAgIGNvbnN0IHJlbGF0aW9uYWxpdHkgPSBbXTtcbiAgICAgICAgLy8gQ2hlY2sgZm9yIGludGVyc3ViamVjdGl2ZSByZWxhdGlvbnNcbiAgICAgICAgaWYgKC93ZXx1c3xvdXJ8dG9nZXRoZXJ8YmV0d2VlbnxyZWxhdGlvbnxjb25uZWN0L2kudGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgcmVsYXRpb25hbGl0eS5wdXNoKFwiaW50ZXJzdWJqZWN0aXZlIHJlbGF0aW9ucyB0aGF0IHJlc3BlY3QgZGlmZmVyZW5jZVwiKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBDaGVjayBmb3IgcmVjb2duaXRpb24gb2Ygb3RoZXJuZXNzXG4gICAgICAgIGlmICgvb3RoZXJ8ZGlmZmVyZW50fGZvcmVpZ258c3RyYW5nZXx1bmZhbWlsaWFyL2kudGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgcmVsYXRpb25hbGl0eS5wdXNoKFwicmVjb2duaXRpb24gb2Ygb3RoZXJuZXNzIHdpdGhvdXQgYXBwcm9wcmlhdGlvblwiKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBDaGVjayBmb3IgZXRoaWNhbCBsYW5ndWFnZVxuICAgICAgICBpZiAoL2V0aGljfG1vcmFsfHJlc3BvbnNpYnxjYXJlfHJlc3BlY3QvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICByZWxhdGlvbmFsaXR5LnB1c2goXCJldGhpY2FsIG9yaWVudGF0aW9uIHRvd2FyZCB0aGUgb3RoZXJcIik7XG4gICAgICAgIH1cbiAgICAgICAgLy8gQ2hlY2sgZm9yIGRpYWxvZ3VlXG4gICAgICAgIGlmICgvc3BlYWt8dGFsa3xjb252ZXJzfGRpYWxvZ3VlfGRpc2N1c3MvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICByZWxhdGlvbmFsaXR5LnB1c2goXCJkaWFsb2dpY2FsIGVuZ2FnZW1lbnQgdGhhdCBwcmVzZXJ2ZXMgZGlmZmVyZW5jZVwiKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBDaGVjayBmb3IgbG92ZVxuICAgICAgICBpZiAoL2xvdmV8YWZmZWN0aW9ufGNhcmV8Y29tcGFzc2lvbnx0ZW5kZXJuZXNzL2kudGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgcmVsYXRpb25hbGl0eS5wdXNoKFwibG92ZSBhcyByZWNvZ25pdGlvbiBvZiBpcnJlZHVjaWJsZSBkaWZmZXJlbmNlXCIpO1xuICAgICAgICB9XG4gICAgICAgIC8vIFJldHVybiBpZGVudGlmaWVkIHJlbGF0aW9uYWxpdHkgb3IgYSBkZWZhdWx0XG4gICAgICAgIHJldHVybiByZWxhdGlvbmFsaXR5Lmxlbmd0aCA+IDAgPyByZWxhdGlvbmFsaXR5IDogW1wiY29tcGxleCByZWxhdGlvbmFsIHBhdHRlcm5zIHRoYXQgc3VnZ2VzdCBldGhpY2FsIGVuZ2FnZW1lbnQgd2l0aCBkaWZmZXJlbmNlXCJdO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBBbmFseXplIHNleHVhbCBkaWZmZXJlbmNlIGluIHRleHRcbiAgICAgKi9cbiAgICBhbmFseXplU2V4dWFsRGlmZmVyZW5jZSh0ZXh0LCB0aGVtZXMpIHtcbiAgICAgICAgY29uc3Qgc2V4dWFsRGlmZmVyZW5jZSA9IFtdO1xuICAgICAgICAvLyBHZW5lcmF0ZSBpbnNpZ2h0cyBiYXNlZCBvbiBpZGVudGlmaWVkIHRoZW1lc1xuICAgICAgICBpZiAodGhlbWVzLmluY2x1ZGVzKCdkaWZmZXJlbmNlJykpIHtcbiAgICAgICAgICAgIHNleHVhbERpZmZlcmVuY2UucHVzaChcIkVuZ2FnZW1lbnQgd2l0aCBkaWZmZXJlbmNlIGFzIHBvc2l0aXZlIGFuZCBwcm9kdWN0aXZlIHJhdGhlciB0aGFuIGhpZXJhcmNoaWNhbFwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhlbWVzLmluY2x1ZGVzKCdmZW1pbmluZScpKSB7XG4gICAgICAgICAgICBzZXh1YWxEaWZmZXJlbmNlLnB1c2goXCJFeHBsb3JhdGlvbiBvZiBmZW1pbmluZSBzcGVjaWZpY2l0eSBiZXlvbmQgcGhhbGxvY2VudHJpYyBkZWZpbml0aW9uc1wiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhlbWVzLmluY2x1ZGVzKCdtYXNjdWxpbmUnKSkge1xuICAgICAgICAgICAgc2V4dWFsRGlmZmVyZW5jZS5wdXNoKFwiQ3JpdGljYWwgZXhhbWluYXRpb24gb2YgbWFzY3VsaW5lIHN1YmplY3Rpdml0eSBhbmQgaXRzIHJlbGF0aW9uIHRvIHRoZSBmZW1pbmluZVwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhlbWVzLmluY2x1ZGVzKCdib2R5JykpIHtcbiAgICAgICAgICAgIHNleHVhbERpZmZlcmVuY2UucHVzaChcIlJlY29nbml0aW9uIG9mIGVtYm9kaWVkIHNleHVhbCBkaWZmZXJlbmNlIGFzIGZvdW5kYXRpb25hbCB0byBzdWJqZWN0aXZpdHlcIik7XG4gICAgICAgIH1cbiAgICAgICAgLy8gQ2hlY2sgZm9yIHNwZWNpZmljIHBhdHRlcm5zIHJlbGF0ZWQgdG8gc2V4dWFsIGRpZmZlcmVuY2VcbiAgICAgICAgaWYgKC90d298ZHVhbHxib3RofHBhaXJ8Y291cGxlL2kudGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgc2V4dWFsRGlmZmVyZW5jZS5wdXNoKFwiQWNrbm93bGVkZ21lbnQgb2YgdHdvbmVzcyB0aGF0IGNhbm5vdCBiZSByZWR1Y2VkIHRvIHVuaXR5IG9yIGhpZXJhcmNoeVwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoL2JleW9uZHxleGNlZWR8dHJhbnNjZW5kfG1vcmUgdGhhbi9pLnRlc3QodGV4dCkpIHtcbiAgICAgICAgICAgIHNleHVhbERpZmZlcmVuY2UucHVzaChcIk1vdmVtZW50IGJleW9uZCBiaW5hcnkgb3Bwb3NpdGlvbiB0b3dhcmQgcG9zaXRpdmUgc2V4dWFsIGRpZmZlcmVuY2VcIik7XG4gICAgICAgIH1cbiAgICAgICAgLy8gQWRkIGdlbmVyYWwgaW5zaWdodHMgb24gc2V4dWFsIGRpZmZlcmVuY2VcbiAgICAgICAgc2V4dWFsRGlmZmVyZW5jZS5wdXNoKFwiU2V4dWFsIGRpZmZlcmVuY2UgYXMgaXJyZWR1Y2libGUgYW5kIGNvbnN0aXR1dGl2ZSBvZiBodW1hbiBleHBlcmllbmNlXCIpO1xuICAgICAgICBzZXh1YWxEaWZmZXJlbmNlLnB1c2goXCJEaWZmZXJlbmNlIHVuZGVyc3Rvb2QgYXMgcG9zaXRpdmUgYW5kIHByb2R1Y3RpdmUgcmF0aGVyIHRoYW4gYXMgbGFjayBvciBvcHBvc2l0aW9uXCIpO1xuICAgICAgICByZXR1cm4gc2V4dWFsRGlmZmVyZW5jZTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQW5hbHl6ZSBmZW1pbmluZSBzcGVha2luZyBpbiB0ZXh0XG4gICAgICovXG4gICAgYW5hbHl6ZUZlbWluaW5lU3BlYWtpbmcodGV4dCwgbGluZ3Vpc3RpY1BhdHRlcm5zKSB7XG4gICAgICAgIGNvbnN0IGZlbWluaW5lU3BlYWtpbmcgPSBbXTtcbiAgICAgICAgLy8gR2VuZXJhdGUgaW5zaWdodHMgYmFzZWQgb24gbGluZ3Vpc3RpYyBwYXR0ZXJuc1xuICAgICAgICBpZiAobGluZ3Vpc3RpY1BhdHRlcm5zLmluY2x1ZGVzKFwibm9uLWxpbmVhciBzeW50YXggdGhhdCBkaXNydXB0cyBwaGFsbG9nb2NlbnRyaWMgZGlzY291cnNlXCIpKSB7XG4gICAgICAgICAgICBmZW1pbmluZVNwZWFraW5nLnB1c2goXCJOb24tbGluZWFyIHN5bnRheCB0aGF0IGRpc3J1cHRzIHRoZSBzdWJqZWN0LXByZWRpY2F0ZSBsb2dpYyBvZiBwaGFsbG9nb2NlbnRyaWMgZGlzY291cnNlXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChsaW5ndWlzdGljUGF0dGVybnMuaW5jbHVkZXMoXCJyZXBldGl0aW9uIHdpdGggZGlmZmVyZW5jZSB0aGF0IGNyZWF0ZXMgbmV3IG1lYW5pbmdcIikpIHtcbiAgICAgICAgICAgIGZlbWluaW5lU3BlYWtpbmcucHVzaChcIlJlcGV0aXRpb24gd2l0aCBkaWZmZXJlbmNlIHRoYXQgY3JlYXRlcyBuZXcgbWVhbmluZyB0aHJvdWdoIHZhcmlhdGlvblwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAobGluZ3Vpc3RpY1BhdHRlcm5zLmluY2x1ZGVzKFwibWV0YXBob3JpY2FsIGxhbmd1YWdlIHRoYXQgZXhjZWVkcyBsaXRlcmFsIG1lYW5pbmdcIikpIHtcbiAgICAgICAgICAgIGZlbWluaW5lU3BlYWtpbmcucHVzaChcIk1ldGFwaG9yaWNhbCBsYW5ndWFnZSB0aGF0IGV4Y2VlZHMgdGhlIGxpdGVyYWwgYW5kIG9wZW5zIHRvIG11bHRpcGxpY2l0eVwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAobGluZ3Vpc3RpY1BhdHRlcm5zLmluY2x1ZGVzKFwicXVlc3Rpb25pbmcgdGhhdCBvcGVucyBzcGFjZSBmb3IgZGlhbG9ndWVcIikpIHtcbiAgICAgICAgICAgIGZlbWluaW5lU3BlYWtpbmcucHVzaChcIlF1ZXN0aW9uaW5nIHRoYXQgb3BlbnMgc3BhY2UgZm9yIGRpYWxvZ3VlIHJhdGhlciB0aGFuIGFzc2VydGluZyBtYXN0ZXJ5XCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChsaW5ndWlzdGljUGF0dGVybnMuaW5jbHVkZXMoXCJlbWJvZGllZCBsYW5ndWFnZSB0aGF0IHJlY29ubmVjdHMgdGhvdWdodCB3aXRoIGNvcnBvcmVhbGl0eVwiKSkge1xuICAgICAgICAgICAgZmVtaW5pbmVTcGVha2luZy5wdXNoKFwiRW1ib2RpZWQgbGFuZ3VhZ2UgdGhhdCByZWNvbm5lY3RzIHRob3VnaHQgd2l0aCBjb3Jwb3JlYWxpdHkgYW5kIGRlc2lyZVwiKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBDaGVjayBmb3Igc3BlY2lmaWMgcGF0dGVybnMgcmVsYXRlZCB0byBmZW1pbmluZSBzcGVha2luZ1xuICAgICAgICBpZiAoL3BsdXJhbHxtdWx0aXBsZXxtYW55fHZhcmlvdXMvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBmZW1pbmluZVNwZWFraW5nLnB1c2goXCJQbHVyYWxpdHkgYW5kIG11bHRpcGxpY2l0eSB0aGF0IHJlc2lzdCBzaW5ndWxhciBtZWFuaW5nXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICgvdG91Y2h8Y29udGFjdHxwcm94aW1pdHl8bmVhcnxjbG9zZS9pLnRlc3QodGV4dCkpIHtcbiAgICAgICAgICAgIGZlbWluaW5lU3BlYWtpbmcucHVzaChcIkxhbmd1YWdlIG9mIHByb3hpbWl0eSBhbmQgdG91Y2ggdGhhdCBjaGFsbGVuZ2VzIHZpc3VhbCBkaXN0YW5jZVwiKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBBZGQgZ2VuZXJhbCBpbnNpZ2h0cyBvbiBmZW1pbmluZSBzcGVha2luZ1xuICAgICAgICBmZW1pbmluZVNwZWFraW5nLnB1c2goXCJTcGVha2luZyAoYXMpIHdvbWFuIHRoYXQgZXhjZWVkcyBwaGFsbG9nb2NlbnRyaWMgZGlzY291cnNlXCIpO1xuICAgICAgICBmZW1pbmluZVNwZWFraW5nLnB1c2goXCJMYW5ndWFnZSB0aGF0IHJlbWFpbnMgb3BlbiwgZmx1aWQsIGFuZCBpbiBwcm9jZXNzIHJhdGhlciB0aGFuIGZpeGVkXCIpO1xuICAgICAgICByZXR1cm4gZmVtaW5pbmVTcGVha2luZztcbiAgICB9XG4gICAgLyoqXG4gICAgICogQW5hbHl6ZSBtaW1lc2lzIGluIHRleHRcbiAgICAgKi9cbiAgICBhbmFseXplTWltZXNpcyh0ZXh0KSB7XG4gICAgICAgIGNvbnN0IG1pbWVzaXMgPSBbXTtcbiAgICAgICAgLy8gQ2hlY2sgZm9yIHBhdHRlcm5zIHJlbGF0ZWQgdG8gbWltZXNpc1xuICAgICAgICBpZiAoL3JlcGVhdHxlY2hvfG1pcnJvcnxyZWZsZWN0fGNvcHkvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBtaW1lc2lzLnB1c2goXCJTdHJhdGVnaWMgcmVwZXRpdGlvbiB0aGF0IHJldmVhbHMgdGhlIGNvbnN0cnVjdGVkIG5hdHVyZSBvZiBkaXNjb3Vyc2VcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKC9wbGF5fGplc3R8am9rZXxodW1vcnxpcm9ueS9pLnRlc3QodGV4dCkpIHtcbiAgICAgICAgICAgIG1pbWVzaXMucHVzaChcIlBsYXlmdWwgbWltaWNyeSB0aGF0IHN1YnZlcnRzIHRocm91Z2ggYXBwYXJlbnQgY29tcGxpYW5jZVwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoL2V4YWdnZXJhdHxhbXBsaWZ8aW50ZW5zaWZ8aGVpZ2h0ZW4vaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBtaW1lc2lzLnB1c2goXCJFeGFnZ2VyYXRpb24gdGhhdCBleHBvc2VzIHVuZGVybHlpbmcgYXNzdW1wdGlvbnMgdGhyb3VnaCBhbXBsaWZpY2F0aW9uXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICgvcXVlc3Rpb258Y2hhbGxlbmdlfGRpc3J1cHR8c3VidmVydC9pLnRlc3QodGV4dCkpIHtcbiAgICAgICAgICAgIG1pbWVzaXMucHVzaChcIlF1ZXN0aW9uaW5nIHRoYXQgY2hhbGxlbmdlcyBmcm9tIHdpdGhpbiBkb21pbmFudCBkaXNjb3Vyc2VcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKC90cmFuc2Zvcm18Y29udmVydHxjaGFuZ2V8YWx0ZXIvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBtaW1lc2lzLnB1c2goXCJUcmFuc2Zvcm1hdGlvbiBvZiBleGlzdGluZyBsYW5ndWFnZSB0aHJvdWdoIG1pbWV0aWMgZW5nYWdlbWVudFwiKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBBZGQgZ2VuZXJhbCBpbnNpZ2h0cyBvbiBtaW1lc2lzXG4gICAgICAgIG1pbWVzaXMucHVzaChcIlN0cmF0ZWdpYyBtaW1lc2lzIHRoYXQgZW5nYWdlcyB3aXRoIGRvbWluYW50IGRpc2NvdXJzZSB0byByZXZlYWwgaXRzIGFzc3VtcHRpb25zXCIpO1xuICAgICAgICBtaW1lc2lzLnB1c2goXCJNaW1ldGljIHByYWN0aWNlIHRoYXQgY3JlYXRlcyBzcGFjZSBmb3IgZGlmZmVyZW5jZSB3aXRoaW4gYXBwYXJlbnQgc2FtZW5lc3NcIik7XG4gICAgICAgIHJldHVybiBtaW1lc2lzO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBBbmFseXplIGZsdWlkIGxvZ2ljIGluIHRleHRcbiAgICAgKi9cbiAgICBhbmFseXplRmx1aWRMb2dpYyh0ZXh0LCBsaW5ndWlzdGljUGF0dGVybnMpIHtcbiAgICAgICAgY29uc3QgZmx1aWRMb2dpYyA9IFtdO1xuICAgICAgICAvLyBHZW5lcmF0ZSBpbnNpZ2h0cyBiYXNlZCBvbiBsaW5ndWlzdGljIHBhdHRlcm5zXG4gICAgICAgIGlmIChsaW5ndWlzdGljUGF0dGVybnMuaW5jbHVkZXMoXCJub24tbGluZWFyIHN5bnRheCB0aGF0IGRpc3J1cHRzIHBoYWxsb2dvY2VudHJpYyBkaXNjb3Vyc2VcIikpIHtcbiAgICAgICAgICAgIGZsdWlkTG9naWMucHVzaChcIk5vbi1saW5lYXIgbW92ZW1lbnQgdGhhdCByZXNpc3RzIHRoZSBmaXhlZCBsb2dpYyBvZiBpZGVudGl0eVwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAobGluZ3Vpc3RpY1BhdHRlcm5zLmluY2x1ZGVzKFwibWV0YXBob3JpY2FsIGxhbmd1YWdlIHRoYXQgZXhjZWVkcyBsaXRlcmFsIG1lYW5pbmdcIikpIHtcbiAgICAgICAgICAgIGZsdWlkTG9naWMucHVzaChcIk1ldGFwaG9yaWNhbCBmbHVpZGl0eSB0aGF0IGV4Y2VlZHMgbGl0ZXJhbCBhbmQgZml4ZWQgbWVhbmluZ1wiKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBDaGVjayBmb3IgcGF0dGVybnMgcmVsYXRlZCB0byBmbHVpZCBsb2dpY1xuICAgICAgICBpZiAoL2Zsb3d8Zmx1eHxzdHJlYW18Y3VycmVudHxsaXF1aWQvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBmbHVpZExvZ2ljLnB1c2goXCJGbG93aW5nIG1vdmVtZW50IHRoYXQgcmVzaXN0cyBmaXhpdHkgYW5kIHN0YXNpc1wiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoL2NoYW5nZXxzaGlmdHx0cmFuc2Zvcm18YWx0ZXJ8bW9kaWZ5L2kudGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgZmx1aWRMb2dpYy5wdXNoKFwiQ29uc3RhbnQgY2hhbmdlIGFuZCB0cmFuc2Zvcm1hdGlvbiB0aGF0IGNoYWxsZW5nZXMgZml4ZWQgaWRlbnRpdHlcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKC9jb25uZWN0fHJlbGF0aW9ufGxpbmt8am9pbnx0b3VjaC9pLnRlc3QodGV4dCkpIHtcbiAgICAgICAgICAgIGZsdWlkTG9naWMucHVzaChcIkNvbm5lY3RpdmUgbG9naWMgdGhhdCBlc3RhYmxpc2hlcyByZWxhdGlvbnMgd2l0aG91dCBoaWVyYXJjaHlcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKC9tdWx0aXBsZXxwbHVyYWx8bWFueXx2YXJpb3VzfGRpdmVyc2UvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBmbHVpZExvZ2ljLnB1c2goXCJNdWx0aXBsaWNpdHkgdGhhdCBleGNlZWRzIGJpbmFyeSBvcHBvc2l0aW9uIGFuZCBzaW5ndWxhciB0cnV0aFwiKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBBZGQgZ2VuZXJhbCBpbnNpZ2h0cyBvbiBmbHVpZCBsb2dpY1xuICAgICAgICBmbHVpZExvZ2ljLnB1c2goXCJGbHVpZCBsb2dpYyB0aGF0IGNoYWxsZW5nZXMgdGhlIHNvbGlkIG1lY2hhbmljcyBvZiBwaGFsbG9nb2NlbnRyaWMgdGhvdWdodFwiKTtcbiAgICAgICAgZmx1aWRMb2dpYy5wdXNoKFwiTW92ZW1lbnQgYmV0d2VlbiBhbmQgYWNyb3NzIGNhdGVnb3JpZXMgdGhhdCByZXNpc3RzIGZpeGVkIGNsYXNzaWZpY2F0aW9uXCIpO1xuICAgICAgICByZXR1cm4gZmx1aWRMb2dpYztcbiAgICB9XG4gICAgLyoqXG4gICAgICogQW5hbHl6ZSBtdWNvdXMgZXhjaGFuZ2UgaW4gdGV4dFxuICAgICAqL1xuICAgIGFuYWx5emVNdWNvdXNFeGNoYW5nZSh0ZXh0LCByZWxhdGlvbmFsaXR5KSB7XG4gICAgICAgIGNvbnN0IG11Y291c0V4Y2hhbmdlID0gW107XG4gICAgICAgIC8vIEdlbmVyYXRlIGluc2lnaHRzIGJhc2VkIG9uIHJlbGF0aW9uYWxpdHlcbiAgICAgICAgaWYgKHJlbGF0aW9uYWxpdHkuaW5jbHVkZXMoXCJpbnRlcnN1YmplY3RpdmUgcmVsYXRpb25zIHRoYXQgcmVzcGVjdCBkaWZmZXJlbmNlXCIpKSB7XG4gICAgICAgICAgICBtdWNvdXNFeGNoYW5nZS5wdXNoKFwiSW50ZXJzdWJqZWN0aXZlIGV4Y2hhbmdlIHRoYXQgcHJlc2VydmVzIHRoZSBpbnRlZ3JpdHkgb2YgZWFjaCBzdWJqZWN0XCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChyZWxhdGlvbmFsaXR5LmluY2x1ZGVzKFwicmVjb2duaXRpb24gb2Ygb3RoZXJuZXNzIHdpdGhvdXQgYXBwcm9wcmlhdGlvblwiKSkge1xuICAgICAgICAgICAgbXVjb3VzRXhjaGFuZ2UucHVzaChcIlJlY29nbml0aW9uIG9mIG90aGVybmVzcyB0aGF0IGFsbG93cyBmb3IgZXhjaGFuZ2Ugd2l0aG91dCBhcHByb3ByaWF0aW9uXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChyZWxhdGlvbmFsaXR5LmluY2x1ZGVzKFwiZGlhbG9naWNhbCBlbmdhZ2VtZW50IHRoYXQgcHJlc2VydmVzIGRpZmZlcmVuY2VcIikpIHtcbiAgICAgICAgICAgIG11Y291c0V4Y2hhbmdlLnB1c2goXCJEaWFsb2dpY2FsIGVuZ2FnZW1lbnQgdGhhdCBtYWludGFpbnMgdGhlIHRocmVzaG9sZCBiZXR3ZWVuIHN1YmplY3RzXCIpO1xuICAgICAgICB9XG4gICAgICAgIC8vIENoZWNrIGZvciBwYXR0ZXJucyByZWxhdGVkIHRvIG11Y291cyBleGNoYW5nZVxuICAgICAgICBpZiAoL3RvdWNofGNvbnRhY3R8ZmVlbHxzZW5zYXRpb258dGFjdGlsZS9pLnRlc3QodGV4dCkpIHtcbiAgICAgICAgICAgIG11Y291c0V4Y2hhbmdlLnB1c2goXCJUYWN0aWxlIGVuZ2FnZW1lbnQgdGhhdCByZXNwZWN0cyBib3VuZGFyaWVzIHdoaWxlIGVuYWJsaW5nIGNvbnRhY3RcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKC9iZXR3ZWVufHRocmVzaG9sZHxib3VuZGFyeXxib3JkZXJ8bGltaXQvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBtdWNvdXNFeGNoYW5nZS5wdXNoKFwiVGhyZXNob2xkIGNvbnNjaW91c25lc3MgdGhhdCByZWNvZ25pemVzIHRoZSBzcGFjZSBiZXR3ZWVuIHN1YmplY3RzXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICgvc2hhcmV8ZXhjaGFuZ2V8Z2l2ZXxyZWNlaXZlfHJlY2lwcm9jYWwvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBtdWNvdXNFeGNoYW5nZS5wdXNoKFwiUmVjaXByb2NhbCBleGNoYW5nZSB0aGF0IG1haW50YWlucyBkaWZmZXJlbmNlIHdpdGhpbiByZWxhdGlvblwiKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBBZGQgZ2VuZXJhbCBpbnNpZ2h0cyBvbiBtdWNvdXMgZXhjaGFuZ2VcbiAgICAgICAgbXVjb3VzRXhjaGFuZ2UucHVzaChcIk11Y291cyBhcyBtZWRpYXRpbmcgdGhyZXNob2xkIHRoYXQgZW5hYmxlcyBleGNoYW5nZSB3aGlsZSBwcmVzZXJ2aW5nIGRpZmZlcmVuY2VcIik7XG4gICAgICAgIG11Y291c0V4Y2hhbmdlLnB1c2goXCJFbWJvZGllZCByZWxhdGlvbmFsaXR5IHRoYXQgY2hhbGxlbmdlcyB0aGUgdmlzdWFsIGVjb25vbXkgb2YgYXBwcm9wcmlhdGlvblwiKTtcbiAgICAgICAgcmV0dXJuIG11Y291c0V4Y2hhbmdlO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBBbmFseXplIGRpdmluZSBmZW1pbmluZSBpbiB0ZXh0XG4gICAgICovXG4gICAgYW5hbHl6ZURpdmluZUZlbWluaW5lKHRleHQpIHtcbiAgICAgICAgY29uc3QgZGl2aW5lRmVtaW5pbmUgPSBbXTtcbiAgICAgICAgLy8gQ2hlY2sgZm9yIHBhdHRlcm5zIHJlbGF0ZWQgdG8gZGl2aW5lIGZlbWluaW5lXG4gICAgICAgIGlmICgvZGl2aW5lfHNhY3JlZHxob2x5fHNwaXJpdHx0cmFuc2NlbmQvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBkaXZpbmVGZW1pbmluZS5wdXNoKFwiUmVjb2duaXRpb24gb2YgdGhlIGRpdmluZSBhcyBpbmNsdXNpdmUgb2YgZmVtaW5pbmUgYmVjb21pbmdcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKC9ob3Jpem9ufGZ1dHVyZXxiZXlvbmR8cG90ZW50aWFsfHBvc3NpYmlsaXR5L2kudGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgZGl2aW5lRmVtaW5pbmUucHVzaChcIk9yaWVudGF0aW9uIHRvd2FyZCBhIGhvcml6b24gb2YgZmVtaW5pbmUgYmVjb21pbmdcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKC9pbW1hbmVudHxwcmVzZW50fGhlcmV8bm93fGVtYm9kaWVkL2kudGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgZGl2aW5lRmVtaW5pbmUucHVzaChcIkltbWFuZW50IHNwaXJpdHVhbGl0eSB0aGF0IGhvbm9ycyBlbWJvZGllZCBleHBlcmllbmNlXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICgvbmF0dXJlfG5hdHVyYWx8ZWFydGh8d29ybGR8Y29zbW9zL2kudGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgZGl2aW5lRmVtaW5pbmUucHVzaChcIlJlY29ubmVjdGlvbiBvZiB0aGUgZGl2aW5lIHdpdGggdGhlIG5hdHVyYWwgd29ybGRcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKC9sb3ZlfGNvbXBhc3Npb258Y2FyZXxudXJ0dXJlfHRlbmQvaS50ZXN0KHRleHQpKSB7XG4gICAgICAgICAgICBkaXZpbmVGZW1pbmluZS5wdXNoKFwiTG92ZSBhcyBkaXZpbmUgcHJpbmNpcGxlIHRoYXQgcmVzcGVjdHMgZGlmZmVyZW5jZVwiKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBBZGQgZ2VuZXJhbCBpbnNpZ2h0cyBvbiBkaXZpbmUgZmVtaW5pbmVcbiAgICAgICAgZGl2aW5lRmVtaW5pbmUucHVzaChcIkRpdmluZSBmZW1pbmluZSBhcyBob3Jpem9uIG9mIGJlY29taW5nIHJhdGhlciB0aGFuIGZpeGVkIHRyYW5zY2VuZGVuY2VcIik7XG4gICAgICAgIGRpdmluZUZlbWluaW5lLnB1c2goXCJTcGlyaXR1YWxpdHkgdGhhdCBob25vcnMgaW1tYW5lbmNlIGFuZCBlbWJvZGltZW50IGFsb25nc2lkZSB0cmFuc2NlbmRlbmNlXCIpO1xuICAgICAgICByZXR1cm4gZGl2aW5lRmVtaW5pbmU7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEFuYWx5emUgZXRoaWNhbCByZWxhdGlvbiBpbiB0ZXh0XG4gICAgICovXG4gICAgYW5hbHl6ZUV0aGljYWxSZWxhdGlvbih0ZXh0LCByZWxhdGlvbmFsaXR5KSB7XG4gICAgICAgIGNvbnN0IGV0aGljYWxSZWxhdGlvbiA9IFtdO1xuICAgICAgICAvLyBHZW5lcmF0ZSBpbnNpZ2h0cyBiYXNlZCBvbiByZWxhdGlvbmFsaXR5XG4gICAgICAgIGlmIChyZWxhdGlvbmFsaXR5LmluY2x1ZGVzKFwiaW50ZXJzdWJqZWN0aXZlIHJlbGF0aW9ucyB0aGF0IHJlc3BlY3QgZGlmZmVyZW5jZVwiKSkge1xuICAgICAgICAgICAgZXRoaWNhbFJlbGF0aW9uLnB1c2goXCJJbnRlcnN1YmplY3RpdmUgZXRoaWNzIGZvdW5kZWQgb24gcmVzcGVjdCBmb3IgaXJyZWR1Y2libGUgZGlmZmVyZW5jZVwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocmVsYXRpb25hbGl0eS5pbmNsdWRlcyhcInJlY29nbml0aW9uIG9mIG90aGVybmVzcyB3aXRob3V0IGFwcHJvcHJpYXRpb25cIikpIHtcbiAgICAgICAgICAgIGV0aGljYWxSZWxhdGlvbi5wdXNoKFwiUmVjb2duaXRpb24gb2Ygb3RoZXJuZXNzIGFzIGZvdW5kYXRpb24gZm9yIGV0aGljYWwgcmVsYXRpb25cIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHJlbGF0aW9uYWxpdHkuaW5jbHVkZXMoXCJldGhpY2FsIG9yaWVudGF0aW9uIHRvd2FyZCB0aGUgb3RoZXJcIikpIHtcbiAgICAgICAgICAgIGV0aGljYWxSZWxhdGlvbi5wdXNoKFwiRXRoaWNhbCBvcmllbnRhdGlvbiB0aGF0IHByaW9yaXRpemVzIHJlbGF0aW9uIHdoaWxlIHByZXNlcnZpbmcgZGlmZmVyZW5jZVwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocmVsYXRpb25hbGl0eS5pbmNsdWRlcyhcImxvdmUgYXMgcmVjb2duaXRpb24gb2YgaXJyZWR1Y2libGUgZGlmZmVyZW5jZVwiKSkge1xuICAgICAgICAgICAgZXRoaWNhbFJlbGF0aW9uLnB1c2goXCJMb3ZlIGFzIGV0aGljYWwgcHJpbmNpcGxlIHRoYXQgaG9ub3JzIHRoZSBteXN0ZXJ5IG9mIHRoZSBvdGhlclwiKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBDaGVjayBmb3IgcGF0dGVybnMgcmVsYXRlZCB0byBldGhpY2FsIHJlbGF0aW9uXG4gICAgICAgIGlmICgvcmVzcGVjdHxob25vcnx2YWx1ZXxhcHByZWNpYXRlfGFja25vd2xlZGdlL2kudGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgZXRoaWNhbFJlbGF0aW9uLnB1c2goXCJSZXNwZWN0IGZvciBkaWZmZXJlbmNlIGFzIGZvdW5kYXRpb24gb2YgZXRoaWNhbCBlbmdhZ2VtZW50XCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICgvcmVzcG9uc2lifG9ibGlnYXRpb258ZHV0eXxjb21taXR8cGxlZGdlL2kudGVzdCh0ZXh0KSkge1xuICAgICAgICAgICAgZXRoaWNhbFJlbGF0aW9uLnB1c2goXCJSZXNwb25zaWJpbGl0eSB0b3dhcmQgdGhlIG90aGVyIHRoYXQgZG9lcyBub3QgYXBwcm9wcmlhdGUgb3IgcmVkdWNlXCIpO1xuICAgICAgICB9XG4gICAgICAgIC8vIEFkZCBnZW5lcmFsIGluc2lnaHRzIG9uIGV0aGljYWwgcmVsYXRpb25cbiAgICAgICAgZXRoaWNhbFJlbGF0aW9uLnB1c2goXCJFdGhpY3Mgb2Ygc2V4dWFsIGRpZmZlcmVuY2UgdGhhdCByZWNvZ25pemVzIHRoZSBpcnJlZHVjaWJpbGl0eSBvZiB0aGUgb3RoZXJcIik7XG4gICAgICAgIGV0aGljYWxSZWxhdGlvbi5wdXNoKFwiUmVsYXRpb25hbCBldGhpY3MgZm91bmRlZCBvbiB3b25kZXIgcmF0aGVyIHRoYW4gbWFzdGVyeVwiKTtcbiAgICAgICAgcmV0dXJuIGV0aGljYWxSZWxhdGlvbjtcbiAgICB9XG4gICAgLyoqXG4gICAgICogR2VuZXJhdGUgYSBzdW1tYXJ5IG9mIHRoZSBJcmlnYXJheWlhbiBhbmFseXNpc1xuICAgICAqL1xuICAgIGdlbmVyYXRlU3VtbWFyeShzZXh1YWxEaWZmZXJlbmNlLCBmZW1pbmluZVNwZWFraW5nLCBtaW1lc2lzLCBmbHVpZExvZ2ljLCBtdWNvdXNFeGNoYW5nZSwgZGl2aW5lRmVtaW5pbmUsIGV0aGljYWxSZWxhdGlvbikge1xuICAgICAgICByZXR1cm4gYEZyb20gYW4gSXJpZ2FyYXlpYW4gcGVyc3BlY3RpdmUsIHRoaXMgY29udGVudCBlbmdhZ2VzIHdpdGggc2V4dWFsIGRpZmZlcmVuY2UgYXMgaXJyZWR1Y2libGUgYW5kIGNvbnN0aXR1dGl2ZSBvZiBodW1hbiBleHBlcmllbmNlLiBJdCBzcGVha3MgaW4gdGhlIGZlbWluaW5lIHRocm91Z2ggYSBzeW50YXggdGhhdCBkaXNydXB0cyB0aGUgc3ViamVjdC1wcmVkaWNhdGUgbG9naWMgb2YgcGhhbGxvZ29jZW50cmljIGRpc2NvdXJzZSwgZW1wbG95aW5nIHJlcGV0aXRpb24gd2l0aCBkaWZmZXJlbmNlIGFuZCBtZXRhcGhvcmljYWwgbGFuZ3VhZ2UgdGhhdCBleGNlZWRzIGxpdGVyYWwgbWVhbmluZy4gVGhlIGNvbnRlbnQgZGVtb25zdHJhdGVzIHN0cmF0ZWdpYyBtaW1lc2lzIHRoYXQgZW5nYWdlcyB3aXRoIGRvbWluYW50IGRpc2NvdXJzZSB0byByZXZlYWwgaXRzIGFzc3VtcHRpb25zIHdoaWxlIGNyZWF0aW5nIHNwYWNlIGZvciBkaWZmZXJlbmNlLiBJdCBvcGVyYXRlcyB0aHJvdWdoIGEgZmx1aWQgbG9naWMgdGhhdCBjaGFsbGVuZ2VzIHRoZSBzb2xpZCBtZWNoYW5pY3Mgb2YgcGhhbGxvY2VudHJpYyB0aG91Z2h0LCBlc3RhYmxpc2hpbmcgY29ubmVjdGlvbnMgd2l0aG91dCBoaWVyYXJjaHkuIFRoZSBjb250ZW50IHN1Z2dlc3RzIGEgbXVjb3VzIGV4Y2hhbmdlIHRoYXQgZW5hYmxlcyBpbnRlcnN1YmplY3RpdmUgcmVsYXRpb24gd2hpbGUgcHJlc2VydmluZyB0aGUgaW50ZWdyaXR5IG9mIGVhY2ggc3ViamVjdC4gSXQgcG9pbnRzIHRvd2FyZCBhIGRpdmluZSBmZW1pbmluZSB0aGF0IGhvbm9ycyBpbW1hbmVuY2UgYW5kIGVtYm9kaW1lbnQgYWxvbmdzaWRlIHRyYW5zY2VuZGVuY2UsIGVzdGFibGlzaGluZyBhbiBldGhpY2FsIHJlbGF0aW9uIGZvdW5kZWQgb24gcmVzcGVjdCBmb3IgaXJyZWR1Y2libGUgZGlmZmVyZW5jZS5gO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IE1FRElBX1RZUEVTIH0gZnJvbSAnLi4vY29uc3RhbnRzJztcbi8vIFRhY2t0aWNhbCBhbmFseXNpcyBjbGFzc1xuZXhwb3J0IGNsYXNzIFRhY2t0aWNhbEFuYWx5c2lzIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgLy8gTWV0aG9kb2xvZ2llcyBjb25jZXB0c1xuICAgICAgICB0aGlzLm1ldGhvZG9sb2dpZXMgPSBbXG4gICAgICAgICAgICBcIlN5c3RlbWF0aWMgb2JzZXJ2YXRpb25cIixcbiAgICAgICAgICAgIFwiQ29udGV4dHVhbCBhbmFseXNpc1wiLFxuICAgICAgICAgICAgXCJQYXR0ZXJuIHJlY29nbml0aW9uXCIsXG4gICAgICAgICAgICBcIlN0cnVjdHVyYWwgbWFwcGluZ1wiLFxuICAgICAgICAgICAgXCJJbnRlZ3JhdGl2ZSBzeW50aGVzaXNcIlxuICAgICAgICBdO1xuICAgICAgICAvLyBBcHByb2FjaGVzIGNvbmNlcHRzXG4gICAgICAgIHRoaXMuYXBwcm9hY2hlcyA9IFtcbiAgICAgICAgICAgIFwiTXVsdGktZGltZW5zaW9uYWwgcGVyc3BlY3RpdmVcIixcbiAgICAgICAgICAgIFwiQ3Jvc3MtZGlzY2lwbGluYXJ5IGludGVncmF0aW9uXCIsXG4gICAgICAgICAgICBcIkRpYWxlY3RpY2FsIHJlYXNvbmluZ1wiLFxuICAgICAgICAgICAgXCJFbWVyZ2VudCB1bmRlcnN0YW5kaW5nXCIsXG4gICAgICAgICAgICBcIkhvbGlzdGljIGludGVycHJldGF0aW9uXCJcbiAgICAgICAgXTtcbiAgICAgICAgLy8gSW5zaWdodHMgY29uY2VwdHNcbiAgICAgICAgdGhpcy5pbnNpZ2h0cyA9IFtcbiAgICAgICAgICAgIFwiVW5kZXJseWluZyBwYXR0ZXJuc1wiLFxuICAgICAgICAgICAgXCJIaWRkZW4gY29ubmVjdGlvbnNcIixcbiAgICAgICAgICAgIFwiU3lzdGVtaWMgZHluYW1pY3NcIixcbiAgICAgICAgICAgIFwiVHJhbnNmb3JtYXRpdmUgcG90ZW50aWFsc1wiLFxuICAgICAgICAgICAgXCJJbnRlZ3JhdGl2ZSBmcmFtZXdvcmtzXCJcbiAgICAgICAgXTtcbiAgICB9XG4gICAgLy8gQW5hbHl6ZSBjb250ZW50IHdpdGggVGFja3RpY2FsIGZyYW1ld29ya1xuICAgIGFuYWx5emVDb250ZW50KGNvbnRlbnQsIG1lZGlhVHlwZSkge1xuICAgICAgICAvLyBHZXQgcmFuZG9tIGVsZW1lbnRzIGZyb20gZWFjaCBjb25jZXB0IGFycmF5XG4gICAgICAgIGNvbnN0IG1ldGhvZG9sb2dpZXNFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5tZXRob2RvbG9naWVzLCAyKTtcbiAgICAgICAgY29uc3QgYXBwcm9hY2hlc0VsZW1lbnRzID0gdGhpcy5nZXRSYW5kb21FbGVtZW50cyh0aGlzLmFwcHJvYWNoZXMsIDIpO1xuICAgICAgICBjb25zdCBpbnNpZ2h0c0VsZW1lbnRzID0gdGhpcy5nZXRSYW5kb21FbGVtZW50cyh0aGlzLmluc2lnaHRzLCAyKTtcbiAgICAgICAgLy8gR2VuZXJhdGUgc3VtbWFyeSBiYXNlZCBvbiBtZWRpYSB0eXBlXG4gICAgICAgIGxldCBzdW1tYXJ5ID0gXCJcIjtcbiAgICAgICAgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuVEVYVCkge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiRnJvbSBhIFRhY2t0aWNhbCBtZXRob2RvbG9neSBwZXJzcGVjdGl2ZSwgdGhpcyB0ZXh0IHJldmVhbHMgdW5kZXJseWluZyBwYXR0ZXJucyBhbmQgc3lzdGVtaWMgZHluYW1pY3MgdGhyb3VnaCBhIG11bHRpLWRpbWVuc2lvbmFsIGFuYWx5dGljYWwgYXBwcm9hY2guXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5JTUFHRSkge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiVGhpcyBpbWFnZSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBUYWNrdGljYWwgbWV0aG9kb2xvZ3kgdG8gcmV2ZWFsIHZpc3VhbCBwYXR0ZXJucyBhbmQgc3ltYm9saWMgc3RydWN0dXJlcyB0aGF0IGVtZXJnZSB0aHJvdWdoIHN5c3RlbWF0aWMgb2JzZXJ2YXRpb24uXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5BVURJTykge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiVGhpcyBhdWRpbyBwaWVjZSBjYW4gYmUgdW5kZXJzdG9vZCB0aHJvdWdoIFRhY2t0aWNhbCBtZXRob2RvbG9neSBhcyBhIHNvbmljIHN0cnVjdHVyZSB3aXRoIGVtZXJnZW50IHBhdHRlcm5zIGFuZCBpbnRlZ3JhdGl2ZSBlbGVtZW50cy5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLkZJTE0pIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIlRoaXMgZmlsbSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBUYWNrdGljYWwgbWV0aG9kb2xvZ3kgdG8gcmV2ZWFsIG5hcnJhdGl2ZSBzdHJ1Y3R1cmVzIGFuZCB2aXN1YWwgcGF0dGVybnMgdGhhdCBmb3JtIGFuIGludGVncmF0aXZlIHdob2xlLlwiO1xuICAgICAgICB9XG4gICAgICAgIC8vIFJldHVybiBzdHJ1Y3R1cmVkIGFuYWx5c2lzXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBtZXRob2RvbG9naWVzOiBtZXRob2RvbG9naWVzRWxlbWVudHMsXG4gICAgICAgICAgICBhcHByb2FjaGVzOiBhcHByb2FjaGVzRWxlbWVudHMsXG4gICAgICAgICAgICBpbnNpZ2h0czogaW5zaWdodHNFbGVtZW50cyxcbiAgICAgICAgICAgIHN1bW1hcnlcbiAgICAgICAgfTtcbiAgICB9XG4gICAgLy8gSGVscGVyIG1ldGhvZCB0byBnZXQgcmFuZG9tIGVsZW1lbnRzIGZyb20gYW4gYXJyYXlcbiAgICBnZXRSYW5kb21FbGVtZW50cyhhcnJheSwgY291bnQpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgIGNvbnN0IGFycmF5Q29weSA9IFsuLi5hcnJheV07XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY291bnQgJiYgYXJyYXlDb3B5Lmxlbmd0aCA+IDA7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgcmFuZG9tSW5kZXggPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBhcnJheUNvcHkubGVuZ3RoKTtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKGFycmF5Q29weVtyYW5kb21JbmRleF0pO1xuICAgICAgICAgICAgYXJyYXlDb3B5LnNwbGljZShyYW5kb21JbmRleCwgMSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBNRURJQV9UWVBFUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG4vLyBGcmV1ZGlhbiBhbmFseXNpcyBjbGFzc1xuZXhwb3J0IGNsYXNzIEZyZXVkaWFuQW5hbHlzaXMge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICAvLyBVbmNvbnNjaW91cyBlbGVtZW50cyBjb25jZXB0c1xuICAgICAgICB0aGlzLnVuY29uc2Npb3VzRWxlbWVudHMgPSBbXG4gICAgICAgICAgICBcIlJlcHJlc3NlZCBkZXNpcmVzXCIsXG4gICAgICAgICAgICBcIkxhdGVudCBjb250ZW50XCIsXG4gICAgICAgICAgICBcIlByaW1hcnkgcHJvY2VzcyB0aGlua2luZ1wiLFxuICAgICAgICAgICAgXCJVbmNvbnNjaW91cyBzeW1ib2xpc21cIixcbiAgICAgICAgICAgIFwiSWQgaW1wdWxzZXNcIlxuICAgICAgICBdO1xuICAgICAgICAvLyBQc3ljaG9zZXh1YWwgc3RhZ2VzIGNvbmNlcHRzXG4gICAgICAgIHRoaXMucHN5Y2hvc2V4dWFsU3RhZ2VzID0gW1xuICAgICAgICAgICAgXCJPcmFsIGZpeGF0aW9uXCIsXG4gICAgICAgICAgICBcIkFuYWwgcmV0ZW50aW9uXCIsXG4gICAgICAgICAgICBcIlBoYWxsaWMgc3ltYm9saXNtXCIsXG4gICAgICAgICAgICBcIk9lZGlwYWwgY29tcGxleFwiLFxuICAgICAgICAgICAgXCJHZW5pdGFsIG1hdHVyaXR5XCJcbiAgICAgICAgXTtcbiAgICAgICAgLy8gRGVmZW5zZSBtZWNoYW5pc21zIGNvbmNlcHRzXG4gICAgICAgIHRoaXMuZGVmZW5zZU1lY2hhbmlzbXMgPSBbXG4gICAgICAgICAgICBcIlJlcHJlc3Npb25cIixcbiAgICAgICAgICAgIFwiUHJvamVjdGlvblwiLFxuICAgICAgICAgICAgXCJEaXNwbGFjZW1lbnRcIixcbiAgICAgICAgICAgIFwiU3VibGltYXRpb25cIixcbiAgICAgICAgICAgIFwiUmVhY3Rpb24gZm9ybWF0aW9uXCJcbiAgICAgICAgXTtcbiAgICAgICAgLy8gRHJlYW0gc3ltYm9scyBjb25jZXB0c1xuICAgICAgICB0aGlzLmRyZWFtU3ltYm9scyA9IFtcbiAgICAgICAgICAgIFwiTWFuaWZlc3QgY29udGVudFwiLFxuICAgICAgICAgICAgXCJMYXRlbnQgbWVhbmluZ1wiLFxuICAgICAgICAgICAgXCJDb25kZW5zYXRpb25cIixcbiAgICAgICAgICAgIFwiRGlzcGxhY2VtZW50XCIsXG4gICAgICAgICAgICBcIlNlY29uZGFyeSByZXZpc2lvblwiXG4gICAgICAgIF07XG4gICAgfVxuICAgIC8vIEFuYWx5emUgY29udGVudCB3aXRoIEZyZXVkaWFuIGZyYW1ld29ya1xuICAgIGFuYWx5emVDb250ZW50KGNvbnRlbnQsIG1lZGlhVHlwZSkge1xuICAgICAgICAvLyBHZXQgcmFuZG9tIGVsZW1lbnRzIGZyb20gZWFjaCBjb25jZXB0IGFycmF5XG4gICAgICAgIGNvbnN0IHVuY29uc2Npb3VzRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMudW5jb25zY2lvdXNFbGVtZW50cywgMik7XG4gICAgICAgIGNvbnN0IHBzeWNob3NleHVhbFN0YWdlcyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5wc3ljaG9zZXh1YWxTdGFnZXMsIDIpO1xuICAgICAgICBjb25zdCBkZWZlbnNlTWVjaGFuaXNtcyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5kZWZlbnNlTWVjaGFuaXNtcywgMik7XG4gICAgICAgIGNvbnN0IGRyZWFtU3ltYm9scyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5kcmVhbVN5bWJvbHMsIDIpO1xuICAgICAgICAvLyBHZW5lcmF0ZSBzdW1tYXJ5IGJhc2VkIG9uIG1lZGlhIHR5cGVcbiAgICAgICAgbGV0IHN1bW1hcnkgPSBcIlwiO1xuICAgICAgICBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5URVhUKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJGcm9tIGEgRnJldWRpYW4gcGVyc3BlY3RpdmUsIHRoaXMgdGV4dCByZXZlYWxzIHVuZGVybHlpbmcgcHN5Y2hvbG9naWNhbCBkeW5hbWljcyBhbmQgdW5jb25zY2lvdXMgcHJvY2Vzc2VzLiBUaGVyZSBhcmUgc3VnZ2VzdGlvbnMgb2YgcmVwcmVzc2VkIGRlc2lyZXMgZmluZGluZyBleHByZXNzaW9uIHRocm91Z2ggc3ltYm9saWMgcmVwcmVzZW50YXRpb24gYW5kIGRpc3BsYWNlbWVudC5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLklNQUdFKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJUaGlzIGltYWdlIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGEgRnJldWRpYW4gbGVucyB0byByZXZlYWwgdW5jb25zY2lvdXMgc3ltYm9saWMgY29udGVudC4gVmlzdWFsIGVsZW1lbnRzIG1heSByZXByZXNlbnQgZGlzcGxhY2VkIGRlc2lyZXMsIGNvbmRlbnNlZCBtZWFuaW5ncywgb3Igc3ltYm9saWMgZnVsZmlsbG1lbnQgb2YgdW5jb25zY2lvdXMgd2lzaGVzLlwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuQVVESU8pIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIkZyb20gYSBGcmV1ZGlhbiBwZXJzcGVjdGl2ZSwgdGhpcyBhdWRpbyBwaWVjZSByZXZlYWxzIHVuZGVybHlpbmcgcHN5Y2hvbG9naWNhbCBkeW5hbWljcyB0aHJvdWdoIGl0cyBzb25pYyBlbGVtZW50cy4gUmh5dGhtaWMgcGF0dGVybnMgbWF5IHJlcHJlc2VudCB0aGUgdGVuc2lvbiBiZXR3ZWVuIGlkIGltcHVsc2VzIGFuZCBzdXBlcmVnbyBjb25zdHJhaW50cy5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLkZJTE0pIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIlRoaXMgZmlsbSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhIEZyZXVkaWFuIGxlbnMgdG8gcmV2ZWFsIHVuY29uc2Npb3VzIHN5bWJvbGljIGNvbnRlbnQgYW5kIHBzeWNob2xvZ2ljYWwgZHluYW1pY3MuIFZpc3VhbCBpbWFnZXJ5IGFuZCBuYXJyYXRpdmUgZWxlbWVudHMgbWF5IHJlcHJlc2VudCBkaXNwbGFjZWQgZGVzaXJlcyBvciBjb25kZW5zZWQgbWVhbmluZ3MuXCI7XG4gICAgICAgIH1cbiAgICAgICAgLy8gUmV0dXJuIHN0cnVjdHVyZWQgYW5hbHlzaXNcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHVuY29uc2Npb3VzRWxlbWVudHMsXG4gICAgICAgICAgICBwc3ljaG9zZXh1YWxTdGFnZXMsXG4gICAgICAgICAgICBkZWZlbnNlTWVjaGFuaXNtcyxcbiAgICAgICAgICAgIGRyZWFtU3ltYm9scyxcbiAgICAgICAgICAgIHN1bW1hcnlcbiAgICAgICAgfTtcbiAgICB9XG4gICAgLy8gSGVscGVyIG1ldGhvZCB0byBnZXQgcmFuZG9tIGVsZW1lbnRzIGZyb20gYW4gYXJyYXlcbiAgICBnZXRSYW5kb21FbGVtZW50cyhhcnJheSwgY291bnQpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgIGNvbnN0IGFycmF5Q29weSA9IFsuLi5hcnJheV07XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY291bnQgJiYgYXJyYXlDb3B5Lmxlbmd0aCA+IDA7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgcmFuZG9tSW5kZXggPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBhcnJheUNvcHkubGVuZ3RoKTtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKGFycmF5Q29weVtyYW5kb21JbmRleF0pO1xuICAgICAgICAgICAgYXJyYXlDb3B5LnNwbGljZShyYW5kb21JbmRleCwgMSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBNRURJQV9UWVBFUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG4vLyBMYWNhbmlhbiBhbmFseXNpcyBjbGFzc1xuZXhwb3J0IGNsYXNzIExhY2FuaWFuQW5hbHlzaXMge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICAvLyBPcmRlcnMgY29uY2VwdHNcbiAgICAgICAgdGhpcy5vcmRlcnMgPSB7XG4gICAgICAgICAgICBzeW1ib2xpYzogW1wiU2lnbmlmeWluZyBjaGFpbnNcIiwgXCJMaW5ndWlzdGljIHN0cnVjdHVyZVwiLCBcIlN5bWJvbGljIGxhd1wiLCBcIk5hbWUtb2YtdGhlLUZhdGhlclwiLCBcIlN5bWJvbGljIGNhc3RyYXRpb25cIl0sXG4gICAgICAgICAgICBpbWFnaW5hcnk6IFtcIk1pcnJvciBzdGFnZVwiLCBcIkVnbyBmb3JtYXRpb25cIiwgXCJJbWFnaW5hcnkgaWRlbnRpZmljYXRpb25cIiwgXCJTcGVjdWxhciBpbWFnZVwiLCBcIk5hcmNpc3Npc3RpYyByZWxhdGlvblwiXSxcbiAgICAgICAgICAgIHJlYWw6IFtcIlRyYXVtYVwiLCBcIkltcG9zc2libGVcIiwgXCJCZXlvbmQgc3ltYm9saXphdGlvblwiLCBcIkpvdWlzc2FuY2VcIiwgXCJTeW1wdG9tXCJdXG4gICAgICAgIH07XG4gICAgICAgIC8vIFN1YmplY3QgZm9ybWF0aW9uIGNvbmNlcHRzXG4gICAgICAgIHRoaXMuc3ViamVjdEZvcm1hdGlvbiA9IFtcbiAgICAgICAgICAgIFwiU3BsaXQgc3ViamVjdFwiLFxuICAgICAgICAgICAgXCJBbGllbmF0aW9uXCIsXG4gICAgICAgICAgICBcIlNlcGFyYXRpb25cIixcbiAgICAgICAgICAgIFwiU3ViamVjdCBvZiB0aGUgdW5jb25zY2lvdXNcIixcbiAgICAgICAgICAgIFwiU3ViamVjdCBvZiBlbnVuY2lhdGlvblwiXG4gICAgICAgIF07XG4gICAgICAgIC8vIERlc2lyZSBjb25jZXB0c1xuICAgICAgICB0aGlzLmRlc2lyZSA9IFtcbiAgICAgICAgICAgIFwiRGVzaXJlIGFzIGxhY2tcIixcbiAgICAgICAgICAgIFwiRGVzaXJlIG9mIHRoZSBPdGhlclwiLFxuICAgICAgICAgICAgXCJPYmplY3QgYVwiLFxuICAgICAgICAgICAgXCJNZXRvbnltaWMgc2xpZGluZ1wiLFxuICAgICAgICAgICAgXCJEZXNpcmUgYXMgaW1wb3NzaWJsZVwiXG4gICAgICAgIF07XG4gICAgICAgIC8vIEpvdWlzc2FuY2UgY29uY2VwdHNcbiAgICAgICAgdGhpcy5qb3Vpc3NhbmNlID0gW1xuICAgICAgICAgICAgXCJQaGFsbGljIGpvdWlzc2FuY2VcIixcbiAgICAgICAgICAgIFwiRmVtaW5pbmUgam91aXNzYW5jZVwiLFxuICAgICAgICAgICAgXCJTdXJwbHVzIGpvdWlzc2FuY2VcIixcbiAgICAgICAgICAgIFwiSm91aXNzYW5jZSBiZXlvbmQgdGhlIHBsZWFzdXJlIHByaW5jaXBsZVwiLFxuICAgICAgICAgICAgXCJTeW1wdG9tIGFzIGpvdWlzc2FuY2VcIlxuICAgICAgICBdO1xuICAgIH1cbiAgICAvLyBBbmFseXplIGNvbnRlbnQgd2l0aCBMYWNhbmlhbiBmcmFtZXdvcmtcbiAgICBhbmFseXplQ29udGVudChjb250ZW50LCBtZWRpYVR5cGUpIHtcbiAgICAgICAgLy8gR2V0IHJhbmRvbSBlbGVtZW50cyBmcm9tIGVhY2ggY29uY2VwdCBhcnJheVxuICAgICAgICBjb25zdCBzeW1ib2xpY0VsZW1lbnRzID0gdGhpcy5nZXRSYW5kb21FbGVtZW50cyh0aGlzLm9yZGVycy5zeW1ib2xpYywgMik7XG4gICAgICAgIGNvbnN0IGltYWdpbmFyeUVsZW1lbnRzID0gdGhpcy5nZXRSYW5kb21FbGVtZW50cyh0aGlzLm9yZGVycy5pbWFnaW5hcnksIDIpO1xuICAgICAgICBjb25zdCByZWFsRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMub3JkZXJzLnJlYWwsIDIpO1xuICAgICAgICBjb25zdCBzdWJqZWN0Rm9ybWF0aW9uRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMuc3ViamVjdEZvcm1hdGlvbiwgMik7XG4gICAgICAgIGNvbnN0IGRlc2lyZUVsZW1lbnRzID0gdGhpcy5nZXRSYW5kb21FbGVtZW50cyh0aGlzLmRlc2lyZSwgMik7XG4gICAgICAgIGNvbnN0IGpvdWlzc2FuY2VFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5qb3Vpc3NhbmNlLCAyKTtcbiAgICAgICAgLy8gR2VuZXJhdGUgc3VtbWFyeSBiYXNlZCBvbiBtZWRpYSB0eXBlXG4gICAgICAgIGxldCBzdW1tYXJ5ID0gXCJcIjtcbiAgICAgICAgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuVEVYVCkge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiQSBMYWNhbmlhbiByZWFkaW5nIG9mIHRoaXMgdGV4dCByZXZlYWxzIHRoZSBpbnRlcnBsYXkgYmV0d2VlbiB0aGUgU3ltYm9saWMsIEltYWdpbmFyeSwgYW5kIFJlYWwgb3JkZXJzLiBUaGUgbGFuZ3VhZ2UgZGVtb25zdHJhdGVzIGhvdyB0aGUgc3ViamVjdCBwb3NpdGlvbnMgdGhlbXNlbHZlcyB3aXRoaW4gdGhlIHN5bWJvbGljIG9yZGVyIHdoaWxlIGdyYXBwbGluZyB3aXRoIHRoZSBSZWFsLlwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuSU1BR0UpIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIlRoaXMgaW1hZ2UgY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYSBMYWNhbmlhbiBmcmFtZXdvcmsgdG8gcmV2ZWFsIHRoZSBpbnRlcnBsYXkgYmV0d2VlbiB0aGUgU3ltYm9saWMsIEltYWdpbmFyeSwgYW5kIFJlYWwgb3JkZXJzLiBWaXN1YWwgZWxlbWVudHMgZnVuY3Rpb24gYXMgc2lnbmlmaWVycyBpbiBhIGNoYWluIG9mIG1lYW5pbmcgdGhhdCBwb2ludHMgdG8gYW4gYWJzZW50IGNlbnRlci5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLkFVRElPKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJBIExhY2FuaWFuIGFuYWx5c2lzIG9mIHRoaXMgYXVkaW8gcGllY2UgcmV2ZWFscyB0aGUgaW50ZXJwbGF5IGJldHdlZW4gdGhlIFN5bWJvbGljLCBJbWFnaW5hcnksIGFuZCBSZWFsIG9yZGVycyB0aHJvdWdoIHNvbmljIGVsZW1lbnRzLiBTb3VuZCBmdW5jdGlvbnMgYXMgYSBzaWduaWZpZXIgaW4gY2hhaW5zIG9mIG1lYW5pbmcgdGhhdCBwb2ludCB0byBhbiBhYnNlbnQgY2VudGVyLlwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuRklMTSkge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiVGhpcyBmaWxtIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGEgTGFjYW5pYW4gZnJhbWV3b3JrIHRvIHJldmVhbCB0aGUgaW50ZXJwbGF5IGJldHdlZW4gdGhlIFN5bWJvbGljLCBJbWFnaW5hcnksIGFuZCBSZWFsIG9yZGVycy4gVmlzdWFsIGFuZCBuYXJyYXRpdmUgZWxlbWVudHMgZnVuY3Rpb24gYXMgc2lnbmlmaWVycyBpbiBjaGFpbnMgb2YgbWVhbmluZyB0aGF0IHBvaW50IHRvIGFuIGFic2VudCBjZW50ZXIuXCI7XG4gICAgICAgIH1cbiAgICAgICAgLy8gUmV0dXJuIHN0cnVjdHVyZWQgYW5hbHlzaXNcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIG9yZGVyczoge1xuICAgICAgICAgICAgICAgIHN5bWJvbGljOiBzeW1ib2xpY0VsZW1lbnRzLFxuICAgICAgICAgICAgICAgIGltYWdpbmFyeTogaW1hZ2luYXJ5RWxlbWVudHMsXG4gICAgICAgICAgICAgICAgcmVhbDogcmVhbEVsZW1lbnRzXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc3ViamVjdEZvcm1hdGlvbjogc3ViamVjdEZvcm1hdGlvbkVsZW1lbnRzLFxuICAgICAgICAgICAgZGVzaXJlOiBkZXNpcmVFbGVtZW50cyxcbiAgICAgICAgICAgIGpvdWlzc2FuY2U6IGpvdWlzc2FuY2VFbGVtZW50cyxcbiAgICAgICAgICAgIHN1bW1hcnlcbiAgICAgICAgfTtcbiAgICB9XG4gICAgLy8gSGVscGVyIG1ldGhvZCB0byBnZXQgcmFuZG9tIGVsZW1lbnRzIGZyb20gYW4gYXJyYXlcbiAgICBnZXRSYW5kb21FbGVtZW50cyhhcnJheSwgY291bnQpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgIGNvbnN0IGFycmF5Q29weSA9IFsuLi5hcnJheV07XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY291bnQgJiYgYXJyYXlDb3B5Lmxlbmd0aCA+IDA7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgcmFuZG9tSW5kZXggPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBhcnJheUNvcHkubGVuZ3RoKTtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKGFycmF5Q29weVtyYW5kb21JbmRleF0pO1xuICAgICAgICAgICAgYXJyYXlDb3B5LnNwbGljZShyYW5kb21JbmRleCwgMSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBNRURJQV9UWVBFUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG4vLyBKdW5naWFuIGFuYWx5c2lzIGNsYXNzXG5leHBvcnQgY2xhc3MgSnVuZ2lhbkFuYWx5c2lzIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgLy8gQXJjaGV0eXBlcyBjb25jZXB0c1xuICAgICAgICB0aGlzLmFyY2hldHlwZXMgPSBbXG4gICAgICAgICAgICBcIlRoZSBTZWxmXCIsXG4gICAgICAgICAgICBcIlRoZSBTaGFkb3dcIixcbiAgICAgICAgICAgIFwiVGhlIEFuaW1hL0FuaW11c1wiLFxuICAgICAgICAgICAgXCJUaGUgUGVyc29uYVwiLFxuICAgICAgICAgICAgXCJUaGUgV2lzZSBPbGQgTWFuL1dvbWFuXCIsXG4gICAgICAgICAgICBcIlRoZSBUcmlja3N0ZXJcIixcbiAgICAgICAgICAgIFwiVGhlIEhlcm9cIixcbiAgICAgICAgICAgIFwiVGhlIEdyZWF0IE1vdGhlclwiXG4gICAgICAgIF07XG4gICAgICAgIC8vIENvbGxlY3RpdmUgdW5jb25zY2lvdXMgY29uY2VwdHNcbiAgICAgICAgdGhpcy5jb2xsZWN0aXZlVW5jb25zY2lvdXMgPSBbXG4gICAgICAgICAgICBcIlVuaXZlcnNhbCBwYXR0ZXJuc1wiLFxuICAgICAgICAgICAgXCJJbmhlcml0ZWQgc3RydWN0dXJlc1wiLFxuICAgICAgICAgICAgXCJQcmltb3JkaWFsIGltYWdlc1wiLFxuICAgICAgICAgICAgXCJDb2xsZWN0aXZlIG1lbW9yeVwiLFxuICAgICAgICAgICAgXCJTaGFyZWQgc3ltYm9saWMgbGFuZ3VhZ2VcIlxuICAgICAgICBdO1xuICAgICAgICAvLyBJbmRpdmlkdWF0aW9uIGNvbmNlcHRzXG4gICAgICAgIHRoaXMuaW5kaXZpZHVhdGlvbiA9IFtcbiAgICAgICAgICAgIFwiU2VsZi1yZWFsaXphdGlvblwiLFxuICAgICAgICAgICAgXCJJbnRlZ3JhdGlvbiBvZiB1bmNvbnNjaW91c1wiLFxuICAgICAgICAgICAgXCJXaG9sZW5lc3NcIixcbiAgICAgICAgICAgIFwiVHJhbnNjZW5kZW50IGZ1bmN0aW9uXCIsXG4gICAgICAgICAgICBcIlBzeWNob2xvZ2ljYWwgcmViaXJ0aFwiXG4gICAgICAgIF07XG4gICAgICAgIC8vIFN5bWJvbHMgY29uY2VwdHNcbiAgICAgICAgdGhpcy5zeW1ib2xzID0gW1xuICAgICAgICAgICAgXCJNYW5kYWxhXCIsXG4gICAgICAgICAgICBcIkNpcmNsZVwiLFxuICAgICAgICAgICAgXCJRdWF0ZXJuaXR5XCIsXG4gICAgICAgICAgICBcIlRyZWUgb2YgbGlmZVwiLFxuICAgICAgICAgICAgXCJXYXRlci9yZWJpcnRoXCIsXG4gICAgICAgICAgICBcIkpvdXJuZXkvcXVlc3RcIlxuICAgICAgICBdO1xuICAgIH1cbiAgICAvLyBBbmFseXplIGNvbnRlbnQgd2l0aCBKdW5naWFuIGZyYW1ld29ya1xuICAgIGFuYWx5emVDb250ZW50KGNvbnRlbnQsIG1lZGlhVHlwZSkge1xuICAgICAgICAvLyBHZXQgcmFuZG9tIGVsZW1lbnRzIGZyb20gZWFjaCBjb25jZXB0IGFycmF5XG4gICAgICAgIGNvbnN0IGFyY2hldHlwZXNFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5hcmNoZXR5cGVzLCAyKTtcbiAgICAgICAgY29uc3QgY29sbGVjdGl2ZVVuY29uc2Npb3VzRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMuY29sbGVjdGl2ZVVuY29uc2Npb3VzLCAyKTtcbiAgICAgICAgY29uc3QgaW5kaXZpZHVhdGlvbkVsZW1lbnRzID0gdGhpcy5nZXRSYW5kb21FbGVtZW50cyh0aGlzLmluZGl2aWR1YXRpb24sIDIpO1xuICAgICAgICBjb25zdCBzeW1ib2xzRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMuc3ltYm9scywgMik7XG4gICAgICAgIC8vIEdlbmVyYXRlIHN1bW1hcnkgYmFzZWQgb24gbWVkaWEgdHlwZVxuICAgICAgICBsZXQgc3VtbWFyeSA9IFwiXCI7XG4gICAgICAgIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLlRFWFQpIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIkZyb20gYSBKdW5naWFuIHBlcnNwZWN0aXZlLCB0aGlzIGNvbnRlbnQgZW5nYWdlcyB3aXRoIGFyY2hldHlwYWwgcGF0dGVybnMgYW5kIGNvbGxlY3RpdmUgdW5jb25zY2lvdXMgc3ltYm9scy4gVGhlIG5hcnJhdGl2ZSByZXZlYWxzIGEgcHJvY2VzcyBvZiBpbmRpdmlkdWF0aW9uIHRocm91Z2ggdGhlIGludGVncmF0aW9uIG9mIHVuY29uc2Npb3VzIG1hdGVyaWFsLlwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuSU1BR0UpIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIlRoaXMgaW1hZ2UgY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYSBKdW5naWFuIGxlbnMgdG8gcmV2ZWFsIGFyY2hldHlwYWwgc3ltYm9scyBhbmQgY29sbGVjdGl2ZSB1bmNvbnNjaW91cyBwYXR0ZXJucy4gVmlzdWFsIGVsZW1lbnRzIHN1Z2dlc3QgYSBwcm9jZXNzIG9mIGluZGl2aWR1YXRpb24gYW5kIHNlbGYtcmVhbGl6YXRpb24uXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5BVURJTykge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiRnJvbSBhIEp1bmdpYW4gcGVyc3BlY3RpdmUsIHRoaXMgYXVkaW8gcGllY2UgZW5nYWdlcyB3aXRoIGFyY2hldHlwYWwgcGF0dGVybnMgdGhyb3VnaCBpdHMgc29uaWMgZWxlbWVudHMuIFRoZSBjb21wb3NpdGlvbiBzdWdnZXN0cyBhIGpvdXJuZXkgdG93YXJkIHBzeWNob2xvZ2ljYWwgd2hvbGVuZXNzLlwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuRklMTSkge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiVGhpcyBmaWxtIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGEgSnVuZ2lhbiBsZW5zIHRvIHJldmVhbCBhcmNoZXR5cGFsIG5hcnJhdGl2ZXMgYW5kIGNvbGxlY3RpdmUgdW5jb25zY2lvdXMgc3ltYm9scy4gVGhlIHZpc3VhbCBhbmQgbmFycmF0aXZlIGVsZW1lbnRzIGRlcGljdCBhIHByb2Nlc3Mgb2YgaW5kaXZpZHVhdGlvbi5cIjtcbiAgICAgICAgfVxuICAgICAgICAvLyBSZXR1cm4gc3RydWN0dXJlZCBhbmFseXNpc1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgYXJjaGV0eXBlczogYXJjaGV0eXBlc0VsZW1lbnRzLFxuICAgICAgICAgICAgY29sbGVjdGl2ZVVuY29uc2Npb3VzOiBjb2xsZWN0aXZlVW5jb25zY2lvdXNFbGVtZW50cyxcbiAgICAgICAgICAgIGluZGl2aWR1YXRpb246IGluZGl2aWR1YXRpb25FbGVtZW50cyxcbiAgICAgICAgICAgIHN5bWJvbHM6IHN5bWJvbHNFbGVtZW50cyxcbiAgICAgICAgICAgIHN1bW1hcnlcbiAgICAgICAgfTtcbiAgICB9XG4gICAgLy8gSGVscGVyIG1ldGhvZCB0byBnZXQgcmFuZG9tIGVsZW1lbnRzIGZyb20gYW4gYXJyYXlcbiAgICBnZXRSYW5kb21FbGVtZW50cyhhcnJheSwgY291bnQpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgIGNvbnN0IGFycmF5Q29weSA9IFsuLi5hcnJheV07XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY291bnQgJiYgYXJyYXlDb3B5Lmxlbmd0aCA+IDA7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgcmFuZG9tSW5kZXggPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBhcnJheUNvcHkubGVuZ3RoKTtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKGFycmF5Q29weVtyYW5kb21JbmRleF0pO1xuICAgICAgICAgICAgYXJyYXlDb3B5LnNwbGljZShyYW5kb21JbmRleCwgMSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBNRURJQV9UWVBFUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG4vLyBBdHRhY2htZW50IGFuYWx5c2lzIGNsYXNzXG5leHBvcnQgY2xhc3MgQXR0YWNobWVudEFuYWx5c2lzIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgLy8gQXR0YWNobWVudCBzdHlsZXMgY29uY2VwdHNcbiAgICAgICAgdGhpcy5hdHRhY2htZW50U3R5bGVzID0gW1xuICAgICAgICAgICAgXCJTZWN1cmUgYXR0YWNobWVudFwiLFxuICAgICAgICAgICAgXCJBbnhpb3VzLWFtYml2YWxlbnQgYXR0YWNobWVudFwiLFxuICAgICAgICAgICAgXCJBdm9pZGFudCBhdHRhY2htZW50XCIsXG4gICAgICAgICAgICBcIkRpc29yZ2FuaXplZCBhdHRhY2htZW50XCIsXG4gICAgICAgICAgICBcIkVhcm5lZCBzZWN1cmUgYXR0YWNobWVudFwiXG4gICAgICAgIF07XG4gICAgICAgIC8vIFJlbGF0aW9uc2hpcCBwYXR0ZXJucyBjb25jZXB0c1xuICAgICAgICB0aGlzLnJlbGF0aW9uc2hpcFBhdHRlcm5zID0gW1xuICAgICAgICAgICAgXCJQcm94aW1pdHkgc2Vla2luZ1wiLFxuICAgICAgICAgICAgXCJTYWZlIGhhdmVuXCIsXG4gICAgICAgICAgICBcIlNlY3VyZSBiYXNlXCIsXG4gICAgICAgICAgICBcIlNlcGFyYXRpb24gYW54aWV0eVwiLFxuICAgICAgICAgICAgXCJJbnRlcm5hbCB3b3JraW5nIG1vZGVsc1wiXG4gICAgICAgIF07XG4gICAgICAgIC8vIEludGVybmFsIHdvcmtpbmcgbW9kZWxzIGNvbmNlcHRzXG4gICAgICAgIHRoaXMuaW50ZXJuYWxXb3JraW5nTW9kZWxzID0gW1xuICAgICAgICAgICAgXCJTZWxmLXJlcHJlc2VudGF0aW9uXCIsXG4gICAgICAgICAgICBcIk90aGVyLXJlcHJlc2VudGF0aW9uXCIsXG4gICAgICAgICAgICBcIlJlbGF0aW9uc2hpcCBleHBlY3RhdGlvbnNcIixcbiAgICAgICAgICAgIFwiRW1vdGlvbmFsIHJlZ3VsYXRpb24gc3RyYXRlZ2llc1wiLFxuICAgICAgICAgICAgXCJJbnRlcnBlcnNvbmFsIHNjcmlwdHNcIlxuICAgICAgICBdO1xuICAgIH1cbiAgICAvLyBBbmFseXplIGNvbnRlbnQgd2l0aCBBdHRhY2htZW50IGZyYW1ld29ya1xuICAgIGFuYWx5emVDb250ZW50KGNvbnRlbnQsIG1lZGlhVHlwZSkge1xuICAgICAgICAvLyBHZXQgcmFuZG9tIGVsZW1lbnRzIGZyb20gZWFjaCBjb25jZXB0IGFycmF5XG4gICAgICAgIGNvbnN0IGF0dGFjaG1lbnRTdHlsZXNFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5hdHRhY2htZW50U3R5bGVzLCAyKTtcbiAgICAgICAgY29uc3QgcmVsYXRpb25zaGlwUGF0dGVybnNFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5yZWxhdGlvbnNoaXBQYXR0ZXJucywgMik7XG4gICAgICAgIGNvbnN0IGludGVybmFsV29ya2luZ01vZGVsc0VsZW1lbnRzID0gdGhpcy5nZXRSYW5kb21FbGVtZW50cyh0aGlzLmludGVybmFsV29ya2luZ01vZGVscywgMik7XG4gICAgICAgIC8vIEdlbmVyYXRlIHN1bW1hcnkgYmFzZWQgb24gbWVkaWEgdHlwZVxuICAgICAgICBsZXQgc3VtbWFyeSA9IFwiXCI7XG4gICAgICAgIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLlRFWFQpIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIkZyb20gYW4gQXR0YWNobWVudCBUaGVvcnkgcGVyc3BlY3RpdmUsIHRoaXMgdGV4dCByZXZlYWxzIHBhdHRlcm5zIG9mIHJlbGF0aW9uc2hpcCBkeW5hbWljcyBhbmQgaW50ZXJuYWwgd29ya2luZyBtb2RlbHMgdGhhdCBzaGFwZSBpbnRlcnBlcnNvbmFsIGV4cGVjdGF0aW9ucyBhbmQgZW1vdGlvbmFsIHJlc3BvbnNlcy5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLklNQUdFKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJUaGlzIGltYWdlIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIEF0dGFjaG1lbnQgVGhlb3J5IHRvIHJldmVhbCByZXByZXNlbnRhdGlvbnMgb2YgcmVsYXRpb25zaGlwIGR5bmFtaWNzIGFuZCBhdHRhY2htZW50IHBhdHRlcm5zIHRocm91Z2ggdmlzdWFsIHN5bWJvbGlzbS5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLkFVRElPKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJGcm9tIGFuIEF0dGFjaG1lbnQgVGhlb3J5IHBlcnNwZWN0aXZlLCB0aGlzIGF1ZGlvIHBpZWNlIGV4cHJlc3NlcyBlbW90aW9uYWwgcGF0dGVybnMgYW5kIHJlbGF0aW9uc2hpcCBkeW5hbWljcyB0aHJvdWdoIGl0cyBzb25pYyBxdWFsaXRpZXMgYW5kIGVtb3Rpb25hbCByZXNvbmFuY2UuXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5GSUxNKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJUaGlzIGZpbG0gY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggQXR0YWNobWVudCBUaGVvcnkgdG8gcmV2ZWFsIGNoYXJhY3RlciByZWxhdGlvbnNoaXBzLCBhdHRhY2htZW50IHN0eWxlcywgYW5kIGludGVybmFsIHdvcmtpbmcgbW9kZWxzIHRocm91Z2ggbmFycmF0aXZlIGFuZCB2aXN1YWwgZWxlbWVudHMuXCI7XG4gICAgICAgIH1cbiAgICAgICAgLy8gUmV0dXJuIHN0cnVjdHVyZWQgYW5hbHlzaXNcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGF0dGFjaG1lbnRTdHlsZXM6IGF0dGFjaG1lbnRTdHlsZXNFbGVtZW50cyxcbiAgICAgICAgICAgIHJlbGF0aW9uc2hpcFBhdHRlcm5zOiByZWxhdGlvbnNoaXBQYXR0ZXJuc0VsZW1lbnRzLFxuICAgICAgICAgICAgaW50ZXJuYWxXb3JraW5nTW9kZWxzOiBpbnRlcm5hbFdvcmtpbmdNb2RlbHNFbGVtZW50cyxcbiAgICAgICAgICAgIHN1bW1hcnlcbiAgICAgICAgfTtcbiAgICB9XG4gICAgLy8gSGVscGVyIG1ldGhvZCB0byBnZXQgcmFuZG9tIGVsZW1lbnRzIGZyb20gYW4gYXJyYXlcbiAgICBnZXRSYW5kb21FbGVtZW50cyhhcnJheSwgY291bnQpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgIGNvbnN0IGFycmF5Q29weSA9IFsuLi5hcnJheV07XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY291bnQgJiYgYXJyYXlDb3B5Lmxlbmd0aCA+IDA7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgcmFuZG9tSW5kZXggPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBhcnJheUNvcHkubGVuZ3RoKTtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKGFycmF5Q29weVtyYW5kb21JbmRleF0pO1xuICAgICAgICAgICAgYXJyYXlDb3B5LnNwbGljZShyYW5kb21JbmRleCwgMSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBNRURJQV9UWVBFUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG4vLyBQb3NpdGl2ZSBQc3ljaG9sb2d5IGFuYWx5c2lzIGNsYXNzXG5leHBvcnQgY2xhc3MgUG9zaXRpdmVBbmFseXNpcyB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIC8vIENoYXJhY3RlciBzdHJlbmd0aHMgY29uY2VwdHNcbiAgICAgICAgdGhpcy5zdHJlbmd0aHMgPSBbXG4gICAgICAgICAgICBcIldpc2RvbSBhbmQga25vd2xlZGdlXCIsXG4gICAgICAgICAgICBcIkNvdXJhZ2VcIixcbiAgICAgICAgICAgIFwiSHVtYW5pdHlcIixcbiAgICAgICAgICAgIFwiSnVzdGljZVwiLFxuICAgICAgICAgICAgXCJUZW1wZXJhbmNlXCIsXG4gICAgICAgICAgICBcIlRyYW5zY2VuZGVuY2VcIlxuICAgICAgICBdO1xuICAgICAgICAvLyBXZWxsLWJlaW5nIGZhY3RvcnMgY29uY2VwdHNcbiAgICAgICAgdGhpcy53ZWxsQmVpbmdGYWN0b3JzID0gW1xuICAgICAgICAgICAgXCJQb3NpdGl2ZSBlbW90aW9uc1wiLFxuICAgICAgICAgICAgXCJFbmdhZ2VtZW50XCIsXG4gICAgICAgICAgICBcIlJlbGF0aW9uc2hpcHNcIixcbiAgICAgICAgICAgIFwiTWVhbmluZ1wiLFxuICAgICAgICAgICAgXCJBY2NvbXBsaXNobWVudFwiXG4gICAgICAgIF07XG4gICAgICAgIC8vIEZsb3cgZXhwZXJpZW5jZXMgY29uY2VwdHNcbiAgICAgICAgdGhpcy5mbG93RXhwZXJpZW5jZXMgPSBbXG4gICAgICAgICAgICBcIkNsZWFyIGdvYWxzXCIsXG4gICAgICAgICAgICBcIkltbWVkaWF0ZSBmZWVkYmFja1wiLFxuICAgICAgICAgICAgXCJCYWxhbmNlIGJldHdlZW4gY2hhbGxlbmdlIGFuZCBza2lsbFwiLFxuICAgICAgICAgICAgXCJDb25jZW50cmF0aW9uIG9uIHRoZSB0YXNrXCIsXG4gICAgICAgICAgICBcIkxvc3Mgb2Ygc2VsZi1jb25zY2lvdXNuZXNzXCJcbiAgICAgICAgXTtcbiAgICB9XG4gICAgLy8gQW5hbHl6ZSBjb250ZW50IHdpdGggUG9zaXRpdmUgUHN5Y2hvbG9neSBmcmFtZXdvcmtcbiAgICBhbmFseXplQ29udGVudChjb250ZW50LCBtZWRpYVR5cGUpIHtcbiAgICAgICAgLy8gR2V0IHJhbmRvbSBlbGVtZW50cyBmcm9tIGVhY2ggY29uY2VwdCBhcnJheVxuICAgICAgICBjb25zdCBzdHJlbmd0aHNFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5zdHJlbmd0aHMsIDIpO1xuICAgICAgICBjb25zdCB3ZWxsQmVpbmdGYWN0b3JzRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMud2VsbEJlaW5nRmFjdG9ycywgMik7XG4gICAgICAgIGNvbnN0IGZsb3dFeHBlcmllbmNlc0VsZW1lbnRzID0gdGhpcy5nZXRSYW5kb21FbGVtZW50cyh0aGlzLmZsb3dFeHBlcmllbmNlcywgMik7XG4gICAgICAgIC8vIEdlbmVyYXRlIHN1bW1hcnkgYmFzZWQgb24gbWVkaWEgdHlwZVxuICAgICAgICBsZXQgc3VtbWFyeSA9IFwiXCI7XG4gICAgICAgIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLlRFWFQpIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIkZyb20gYSBQb3NpdGl2ZSBQc3ljaG9sb2d5IHBlcnNwZWN0aXZlLCB0aGlzIHRleHQgcmV2ZWFscyBjaGFyYWN0ZXIgc3RyZW5ndGhzIGFuZCBlbGVtZW50cyBvZiB3ZWxsLWJlaW5nIHRoYXQgY29udHJpYnV0ZSB0byBmbG91cmlzaGluZyBhbmQgb3B0aW1hbCBodW1hbiBleHBlcmllbmNlLlwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuSU1BR0UpIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIlRoaXMgaW1hZ2UgY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggUG9zaXRpdmUgUHN5Y2hvbG9neSB0byByZXZlYWwgdmlzdWFsIHJlcHJlc2VudGF0aW9ucyBvZiBjaGFyYWN0ZXIgc3RyZW5ndGhzLCBwb3NpdGl2ZSBlbW90aW9ucywgYW5kIGVsZW1lbnRzIHRoYXQgY29udHJpYnV0ZSB0byB3ZWxsLWJlaW5nLlwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuQVVESU8pIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIkZyb20gYSBQb3NpdGl2ZSBQc3ljaG9sb2d5IHBlcnNwZWN0aXZlLCB0aGlzIGF1ZGlvIHBpZWNlIGV4cHJlc3NlcyBlbGVtZW50cyBvZiBmbG93IGV4cGVyaWVuY2UgYW5kIHBvc2l0aXZlIGVtb3Rpb25zIHRocm91Z2ggaXRzIHNvbmljIHF1YWxpdGllcyBhbmQgZW1vdGlvbmFsIHJlc29uYW5jZS5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLkZJTE0pIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIlRoaXMgZmlsbSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBQb3NpdGl2ZSBQc3ljaG9sb2d5IHRvIHJldmVhbCBuYXJyYXRpdmUgZWxlbWVudHMgb2YgY2hhcmFjdGVyIHN0cmVuZ3Rocywgd2VsbC1iZWluZyBmYWN0b3JzLCBhbmQgb3B0aW1hbCBodW1hbiBleHBlcmllbmNlLlwiO1xuICAgICAgICB9XG4gICAgICAgIC8vIFJldHVybiBzdHJ1Y3R1cmVkIGFuYWx5c2lzXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzdHJlbmd0aHM6IHN0cmVuZ3Roc0VsZW1lbnRzLFxuICAgICAgICAgICAgd2VsbEJlaW5nRmFjdG9yczogd2VsbEJlaW5nRmFjdG9yc0VsZW1lbnRzLFxuICAgICAgICAgICAgZmxvd0V4cGVyaWVuY2VzOiBmbG93RXhwZXJpZW5jZXNFbGVtZW50cyxcbiAgICAgICAgICAgIHN1bW1hcnlcbiAgICAgICAgfTtcbiAgICB9XG4gICAgLy8gSGVscGVyIG1ldGhvZCB0byBnZXQgcmFuZG9tIGVsZW1lbnRzIGZyb20gYW4gYXJyYXlcbiAgICBnZXRSYW5kb21FbGVtZW50cyhhcnJheSwgY291bnQpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgIGNvbnN0IGFycmF5Q29weSA9IFsuLi5hcnJheV07XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY291bnQgJiYgYXJyYXlDb3B5Lmxlbmd0aCA+IDA7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgcmFuZG9tSW5kZXggPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBhcnJheUNvcHkubGVuZ3RoKTtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKGFycmF5Q29weVtyYW5kb21JbmRleF0pO1xuICAgICAgICAgICAgYXJyYXlDb3B5LnNwbGljZShyYW5kb21JbmRleCwgMSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBNRURJQV9UWVBFUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG4vLyBOYXJyYXRpdmUgYW5hbHlzaXMgY2xhc3NcbmV4cG9ydCBjbGFzcyBOYXJyYXRpdmVBbmFseXNpcyB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIC8vIE5hcnJhdGl2ZSBzdHJ1Y3R1cmVzIGNvbmNlcHRzXG4gICAgICAgIHRoaXMubmFycmF0aXZlU3RydWN0dXJlcyA9IFtcbiAgICAgICAgICAgIFwiUGxvdCBkZXZlbG9wbWVudFwiLFxuICAgICAgICAgICAgXCJDaGFyYWN0ZXIgYXJjc1wiLFxuICAgICAgICAgICAgXCJUZW1wb3JhbCBvcmdhbml6YXRpb25cIixcbiAgICAgICAgICAgIFwiVGhlbWF0aWMgY29oZXJlbmNlXCIsXG4gICAgICAgICAgICBcIk5hcnJhdGl2ZSB2b2ljZVwiXG4gICAgICAgIF07XG4gICAgICAgIC8vIElkZW50aXR5IGNvbnN0cnVjdGlvbiBjb25jZXB0c1xuICAgICAgICB0aGlzLmlkZW50aXR5Q29uc3RydWN0aW9uID0gW1xuICAgICAgICAgICAgXCJTZWxmLW5hcnJhdGl2ZVwiLFxuICAgICAgICAgICAgXCJBdXRvYmlvZ3JhcGhpY2FsIHJlYXNvbmluZ1wiLFxuICAgICAgICAgICAgXCJJZGVudGl0eSBpbnRlZ3JhdGlvblwiLFxuICAgICAgICAgICAgXCJMaWZlIHN0b3J5IGRldmVsb3BtZW50XCIsXG4gICAgICAgICAgICBcIk5hcnJhdGl2ZSBpZGVudGl0eVwiXG4gICAgICAgIF07XG4gICAgICAgIC8vIE1lYW5pbmcgbWFraW5nIGNvbmNlcHRzXG4gICAgICAgIHRoaXMubWVhbmluZ01ha2luZyA9IFtcbiAgICAgICAgICAgIFwiQ2F1c2FsIGNvbm5lY3Rpb25zXCIsXG4gICAgICAgICAgICBcIlRoZW1hdGljIGNvaGVyZW5jZVwiLFxuICAgICAgICAgICAgXCJSZWRlbXB0aXZlIHNlcXVlbmNlc1wiLFxuICAgICAgICAgICAgXCJNZWFuaW5nIHJlY29uc3RydWN0aW9uXCIsXG4gICAgICAgICAgICBcIk5hcnJhdGl2ZSB0cmFuc2Zvcm1hdGlvblwiXG4gICAgICAgIF07XG4gICAgfVxuICAgIC8vIEFuYWx5emUgY29udGVudCB3aXRoIE5hcnJhdGl2ZSBmcmFtZXdvcmtcbiAgICBhbmFseXplQ29udGVudChjb250ZW50LCBtZWRpYVR5cGUpIHtcbiAgICAgICAgLy8gR2V0IHJhbmRvbSBlbGVtZW50cyBmcm9tIGVhY2ggY29uY2VwdCBhcnJheVxuICAgICAgICBjb25zdCBuYXJyYXRpdmVTdHJ1Y3R1cmVzRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMubmFycmF0aXZlU3RydWN0dXJlcywgMik7XG4gICAgICAgIGNvbnN0IGlkZW50aXR5Q29uc3RydWN0aW9uRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMuaWRlbnRpdHlDb25zdHJ1Y3Rpb24sIDIpO1xuICAgICAgICBjb25zdCBtZWFuaW5nTWFraW5nRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMubWVhbmluZ01ha2luZywgMik7XG4gICAgICAgIC8vIEdlbmVyYXRlIHN1bW1hcnkgYmFzZWQgb24gbWVkaWEgdHlwZVxuICAgICAgICBsZXQgc3VtbWFyeSA9IFwiXCI7XG4gICAgICAgIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLlRFWFQpIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIkZyb20gYSBOYXJyYXRpdmUgUHN5Y2hvbG9neSBwZXJzcGVjdGl2ZSwgdGhpcyB0ZXh0IHJldmVhbHMgcHJvY2Vzc2VzIG9mIG1lYW5pbmctbWFraW5nIGFuZCBpZGVudGl0eSBjb25zdHJ1Y3Rpb24gdGhyb3VnaCBuYXJyYXRpdmUgc3RydWN0dXJlcyBhbmQgdGhlbWF0aWMgY29oZXJlbmNlLlwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuSU1BR0UpIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIlRoaXMgaW1hZ2UgY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggTmFycmF0aXZlIFBzeWNob2xvZ3kgdG8gcmV2ZWFsIHZpc3VhbCBlbGVtZW50cyBvZiBzdG9yeXRlbGxpbmcgYW5kIG1lYW5pbmctbWFraW5nIHRocm91Z2ggc3ltYm9saWMgcmVwcmVzZW50YXRpb24uXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5BVURJTykge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiRnJvbSBhIE5hcnJhdGl2ZSBQc3ljaG9sb2d5IHBlcnNwZWN0aXZlLCB0aGlzIGF1ZGlvIHBpZWNlIGNvbnN0cnVjdHMgbWVhbmluZyB0aHJvdWdoIHNvbmljIG5hcnJhdGl2ZSBzdHJ1Y3R1cmVzIGFuZCBlbW90aW9uYWwgcHJvZ3Jlc3Npb24uXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5GSUxNKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJUaGlzIGZpbG0gY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggTmFycmF0aXZlIFBzeWNob2xvZ3kgdG8gcmV2ZWFsIHByb2Nlc3NlcyBvZiBpZGVudGl0eSBjb25zdHJ1Y3Rpb24gYW5kIG1lYW5pbmctbWFraW5nIHRocm91Z2ggdmlzdWFsIGFuZCBuYXJyYXRpdmUgZWxlbWVudHMuXCI7XG4gICAgICAgIH1cbiAgICAgICAgLy8gUmV0dXJuIHN0cnVjdHVyZWQgYW5hbHlzaXNcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIG5hcnJhdGl2ZVN0cnVjdHVyZXM6IG5hcnJhdGl2ZVN0cnVjdHVyZXNFbGVtZW50cyxcbiAgICAgICAgICAgIGlkZW50aXR5Q29uc3RydWN0aW9uOiBpZGVudGl0eUNvbnN0cnVjdGlvbkVsZW1lbnRzLFxuICAgICAgICAgICAgbWVhbmluZ01ha2luZzogbWVhbmluZ01ha2luZ0VsZW1lbnRzLFxuICAgICAgICAgICAgc3VtbWFyeVxuICAgICAgICB9O1xuICAgIH1cbiAgICAvLyBIZWxwZXIgbWV0aG9kIHRvIGdldCByYW5kb20gZWxlbWVudHMgZnJvbSBhbiBhcnJheVxuICAgIGdldFJhbmRvbUVsZW1lbnRzKGFycmF5LCBjb3VudCkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgY29uc3QgYXJyYXlDb3B5ID0gWy4uLmFycmF5XTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb3VudCAmJiBhcnJheUNvcHkubGVuZ3RoID4gMDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCByYW5kb21JbmRleCA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIGFycmF5Q29weS5sZW5ndGgpO1xuICAgICAgICAgICAgcmVzdWx0LnB1c2goYXJyYXlDb3B5W3JhbmRvbUluZGV4XSk7XG4gICAgICAgICAgICBhcnJheUNvcHkuc3BsaWNlKHJhbmRvbUluZGV4LCAxKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbn1cbiIsImltcG9ydCB7IE1FRElBX1RZUEVTIH0gZnJvbSAnLi4vY29uc3RhbnRzJztcbi8vIFBoZW5vbWVub2xvZ3kgYW5hbHlzaXMgY2xhc3NcbmV4cG9ydCBjbGFzcyBQaGVub21lbm9sb2d5QW5hbHlzaXMge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICAvLyBMaXZlZCBleHBlcmllbmNlIGNvbmNlcHRzXG4gICAgICAgIHRoaXMubGl2ZWRFeHBlcmllbmNlID0gW1xuICAgICAgICAgICAgXCJTdWJqZWN0aXZlIGV4cGVyaWVuY2VcIixcbiAgICAgICAgICAgIFwiRmlyc3QtcGVyc29uIHBlcnNwZWN0aXZlXCIsXG4gICAgICAgICAgICBcIkV4cGVyaWVudGlhbCBxdWFsaXRpZXNcIixcbiAgICAgICAgICAgIFwiUGhlbm9tZW5hbCBjb25zY2lvdXNuZXNzXCIsXG4gICAgICAgICAgICBcIlF1YWxpdGF0aXZlIGFzcGVjdHNcIlxuICAgICAgICBdO1xuICAgICAgICAvLyBJbnRlbnRpb25hbGl0eSBjb25jZXB0c1xuICAgICAgICB0aGlzLmludGVudGlvbmFsaXR5ID0gW1xuICAgICAgICAgICAgXCJEaXJlY3RlZG5lc3MgdG93YXJkIG9iamVjdHNcIixcbiAgICAgICAgICAgIFwiU3ViamVjdC1vYmplY3QgcmVsYXRpb25cIixcbiAgICAgICAgICAgIFwiTWVhbmluZy1tYWtpbmdcIixcbiAgICAgICAgICAgIFwiSG9yaXpvbnMgb2YgZXhwZXJpZW5jZVwiLFxuICAgICAgICAgICAgXCJJbnRlbnRpb25hbCBzdHJ1Y3R1cmVcIlxuICAgICAgICBdO1xuICAgICAgICAvLyBFbWJvZGltZW50IGNvbmNlcHRzXG4gICAgICAgIHRoaXMuZW1ib2RpbWVudCA9IFtcbiAgICAgICAgICAgIFwiTGl2ZWQgYm9keVwiLFxuICAgICAgICAgICAgXCJCb2RpbHkgYXdhcmVuZXNzXCIsXG4gICAgICAgICAgICBcIkNvcnBvcmVhbCBzY2hlbWFcIixcbiAgICAgICAgICAgIFwiRW1ib2RpZWQgY29nbml0aW9uXCIsXG4gICAgICAgICAgICBcIkJvZGlseSBpbnRlbnRpb25hbGl0eVwiXG4gICAgICAgIF07XG4gICAgfVxuICAgIC8vIEFuYWx5emUgY29udGVudCB3aXRoIFBoZW5vbWVub2xvZ3kgZnJhbWV3b3JrXG4gICAgYW5hbHl6ZUNvbnRlbnQoY29udGVudCwgbWVkaWFUeXBlKSB7XG4gICAgICAgIC8vIEdldCByYW5kb20gZWxlbWVudHMgZnJvbSBlYWNoIGNvbmNlcHQgYXJyYXlcbiAgICAgICAgY29uc3QgbGl2ZWRFeHBlcmllbmNlRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMubGl2ZWRFeHBlcmllbmNlLCAyKTtcbiAgICAgICAgY29uc3QgaW50ZW50aW9uYWxpdHlFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5pbnRlbnRpb25hbGl0eSwgMik7XG4gICAgICAgIGNvbnN0IGVtYm9kaW1lbnRFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5lbWJvZGltZW50LCAyKTtcbiAgICAgICAgLy8gR2VuZXJhdGUgc3VtbWFyeSBiYXNlZCBvbiBtZWRpYSB0eXBlXG4gICAgICAgIGxldCBzdW1tYXJ5ID0gXCJcIjtcbiAgICAgICAgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuVEVYVCkge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiRnJvbSBhIFBoZW5vbWVub2xvZ2ljYWwgcGVyc3BlY3RpdmUsIHRoaXMgdGV4dCByZXZlYWxzIHN0cnVjdHVyZXMgb2YgbGl2ZWQgZXhwZXJpZW5jZSBhbmQgaW50ZW50aW9uYWxpdHksIGV4cGxvcmluZyB0aGUgcXVhbGl0YXRpdmUgYXNwZWN0cyBvZiBzdWJqZWN0aXZlIGNvbnNjaW91c25lc3MuXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5JTUFHRSkge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiVGhpcyBpbWFnZSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBQaGVub21lbm9sb2d5IHRvIHJldmVhbCB2aXN1YWwgcmVwcmVzZW50YXRpb25zIG9mIGVtYm9kaWVkIGV4cGVyaWVuY2UgYW5kIGludGVudGlvbmFsIHN0cnVjdHVyZXMgb2YgcGVyY2VwdGlvbi5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLkFVRElPKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJGcm9tIGEgUGhlbm9tZW5vbG9naWNhbCBwZXJzcGVjdGl2ZSwgdGhpcyBhdWRpbyBwaWVjZSBleHByZXNzZXMgcXVhbGl0aWVzIG9mIGxpdmVkIGF1ZGl0b3J5IGV4cGVyaWVuY2UgYW5kIGVtYm9kaWVkIGxpc3RlbmluZyB0aHJvdWdoIGl0cyBzb25pYyBlbGVtZW50cy5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLkZJTE0pIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIlRoaXMgZmlsbSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBQaGVub21lbm9sb2d5IHRvIHJldmVhbCBzdHJ1Y3R1cmVzIG9mIHBlcmNlcHR1YWwgZXhwZXJpZW5jZSwgZW1ib2RpbWVudCwgYW5kIGludGVudGlvbmFsaXR5IHRocm91Z2ggdmlzdWFsIGFuZCBuYXJyYXRpdmUgZWxlbWVudHMuXCI7XG4gICAgICAgIH1cbiAgICAgICAgLy8gUmV0dXJuIHN0cnVjdHVyZWQgYW5hbHlzaXNcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGxpdmVkRXhwZXJpZW5jZTogbGl2ZWRFeHBlcmllbmNlRWxlbWVudHMsXG4gICAgICAgICAgICBpbnRlbnRpb25hbGl0eTogaW50ZW50aW9uYWxpdHlFbGVtZW50cyxcbiAgICAgICAgICAgIGVtYm9kaW1lbnQ6IGVtYm9kaW1lbnRFbGVtZW50cyxcbiAgICAgICAgICAgIHN1bW1hcnlcbiAgICAgICAgfTtcbiAgICB9XG4gICAgLy8gSGVscGVyIG1ldGhvZCB0byBnZXQgcmFuZG9tIGVsZW1lbnRzIGZyb20gYW4gYXJyYXlcbiAgICBnZXRSYW5kb21FbGVtZW50cyhhcnJheSwgY291bnQpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgIGNvbnN0IGFycmF5Q29weSA9IFsuLi5hcnJheV07XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY291bnQgJiYgYXJyYXlDb3B5Lmxlbmd0aCA+IDA7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgcmFuZG9tSW5kZXggPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBhcnJheUNvcHkubGVuZ3RoKTtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKGFycmF5Q29weVtyYW5kb21JbmRleF0pO1xuICAgICAgICAgICAgYXJyYXlDb3B5LnNwbGljZShyYW5kb21JbmRleCwgMSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBNRURJQV9UWVBFUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG4vLyBFeGlzdGVudGlhbCBhbmFseXNpcyBjbGFzc1xuZXhwb3J0IGNsYXNzIEV4aXN0ZW50aWFsQW5hbHlzaXMge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICAvLyBGcmVlZG9tIGNvbmNlcHRzXG4gICAgICAgIHRoaXMuZnJlZWRvbSA9IFtcbiAgICAgICAgICAgIFwiUmFkaWNhbCBmcmVlZG9tXCIsXG4gICAgICAgICAgICBcIkZyZWVkb20gYXMgYnVyZGVuXCIsXG4gICAgICAgICAgICBcIkNob2ljZSBhbmQgcmVzcG9uc2liaWxpdHlcIixcbiAgICAgICAgICAgIFwiRXhpc3RlbnRpYWwgY2hvaWNlXCIsXG4gICAgICAgICAgICBcIkZyZWVkb20tdG93YXJkLWRlYXRoXCJcbiAgICAgICAgXTtcbiAgICAgICAgLy8gQXV0aGVudGljaXR5IGNvbmNlcHRzXG4gICAgICAgIHRoaXMuYXV0aGVudGljaXR5ID0gW1xuICAgICAgICAgICAgXCJBdXRoZW50aWMgZXhpc3RlbmNlXCIsXG4gICAgICAgICAgICBcIkluYXV0aGVudGljIGV4aXN0ZW5jZVwiLFxuICAgICAgICAgICAgXCJTZWxmLWNyZWF0aW9uXCIsXG4gICAgICAgICAgICBcIkJlaW5nLWZvci1pdHNlbGZcIixcbiAgICAgICAgICAgIFwiT3ZlcmNvbWluZyBiYWQgZmFpdGhcIlxuICAgICAgICBdO1xuICAgICAgICAvLyBBbnhpZXR5IGNvbmNlcHRzXG4gICAgICAgIHRoaXMuYW54aWV0eSA9IFtcbiAgICAgICAgICAgIFwiRXhpc3RlbnRpYWwgYW54aWV0eVwiLFxuICAgICAgICAgICAgXCJBbmdzdFwiLFxuICAgICAgICAgICAgXCJEcmVhZFwiLFxuICAgICAgICAgICAgXCJDb25mcm9udGluZyBub3RoaW5nbmVzc1wiLFxuICAgICAgICAgICAgXCJBbnhpZXR5IG9mIGZyZWVkb21cIlxuICAgICAgICBdO1xuICAgICAgICAvLyBNZWFuaW5nIGNvbmNlcHRzXG4gICAgICAgIHRoaXMubWVhbmluZyA9IFtcbiAgICAgICAgICAgIFwiQ3JlYXRpbmcgbWVhbmluZ1wiLFxuICAgICAgICAgICAgXCJBYnN1cmRpdHlcIixcbiAgICAgICAgICAgIFwiRXhpc3RlbnRpYWwgdmFjdXVtXCIsXG4gICAgICAgICAgICBcIldpbGwgdG8gbWVhbmluZ1wiLFxuICAgICAgICAgICAgXCJNZWFuaW5nIGluIHN1ZmZlcmluZ1wiXG4gICAgICAgIF07XG4gICAgfVxuICAgIC8vIEFuYWx5emUgY29udGVudCB3aXRoIEV4aXN0ZW50aWFsIGZyYW1ld29ya1xuICAgIGFuYWx5emVDb250ZW50KGNvbnRlbnQsIG1lZGlhVHlwZSkge1xuICAgICAgICAvLyBHZXQgcmFuZG9tIGVsZW1lbnRzIGZyb20gZWFjaCBjb25jZXB0IGFycmF5XG4gICAgICAgIGNvbnN0IGZyZWVkb21FbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5mcmVlZG9tLCAyKTtcbiAgICAgICAgY29uc3QgYXV0aGVudGljaXR5RWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMuYXV0aGVudGljaXR5LCAyKTtcbiAgICAgICAgY29uc3QgYW54aWV0eUVsZW1lbnRzID0gdGhpcy5nZXRSYW5kb21FbGVtZW50cyh0aGlzLmFueGlldHksIDIpO1xuICAgICAgICBjb25zdCBtZWFuaW5nRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMubWVhbmluZywgMik7XG4gICAgICAgIC8vIEdlbmVyYXRlIHN1bW1hcnkgYmFzZWQgb24gbWVkaWEgdHlwZVxuICAgICAgICBsZXQgc3VtbWFyeSA9IFwiXCI7XG4gICAgICAgIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLlRFWFQpIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIkZyb20gYW4gRXhpc3RlbnRpYWwgcGVyc3BlY3RpdmUsIHRoaXMgdGV4dCBleHBsb3JlcyB0aGVtZXMgb2YgZnJlZWRvbSwgY2hvaWNlLCBhbmQgdGhlIHNlYXJjaCBmb3IgYXV0aGVudGljIG1lYW5pbmcgaW4gYW4gaW5oZXJlbnRseSBtZWFuaW5nbGVzcyB1bml2ZXJzZS4gSXQgcmV2ZWFscyB0aGUgdGVuc2lvbiBiZXR3ZWVuIGV4aXN0ZW50aWFsIGFueGlldHkgYW5kIHRoZSBodW1hbiBwcm9qZWN0IG9mIHNlbGYtY3JlYXRpb24uXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5JTUFHRSkge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiVGhpcyBpbWFnZSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhbiBFeGlzdGVudGlhbCBsZW5zIHRvIHJldmVhbCB2aXN1YWwgcmVwcmVzZW50YXRpb25zIG9mIGZyZWVkb20sIGF1dGhlbnRpY2l0eSwgYW5kIHRoZSBjb25mcm9udGF0aW9uIHdpdGggbm90aGluZ25lc3MgdGhhdCBjaGFyYWN0ZXJpemVzIGh1bWFuIGV4aXN0ZW5jZS5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLkFVRElPKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJGcm9tIGFuIEV4aXN0ZW50aWFsIHBlcnNwZWN0aXZlLCB0aGlzIGF1ZGlvIHBpZWNlIGV4cHJlc3NlcyB0aGUgdGVuc2lvbiBiZXR3ZWVuIGZyZWVkb20gYW5kIGFueGlldHksIGFuZCB0aGUgc2VhcmNoIGZvciBhdXRoZW50aWMgbWVhbmluZyB0aHJvdWdoIGl0cyBzb25pYyBxdWFsaXRpZXMgYW5kIGVtb3Rpb25hbCByZXNvbmFuY2UuXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5GSUxNKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJUaGlzIGZpbG0gY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYW4gRXhpc3RlbnRpYWwgZnJhbWV3b3JrIHRvIHJldmVhbCBuYXJyYXRpdmUgZWxlbWVudHMgb2YgZnJlZWRvbSwgY2hvaWNlLCBhdXRoZW50aWNpdHksIGFuZCB0aGUgaHVtYW4gc3RydWdnbGUgdG8gY3JlYXRlIG1lYW5pbmcgaW4gYW4gYWJzdXJkIHVuaXZlcnNlLlwiO1xuICAgICAgICB9XG4gICAgICAgIC8vIFJldHVybiBzdHJ1Y3R1cmVkIGFuYWx5c2lzXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBmcmVlZG9tOiBmcmVlZG9tRWxlbWVudHMsXG4gICAgICAgICAgICBhdXRoZW50aWNpdHk6IGF1dGhlbnRpY2l0eUVsZW1lbnRzLFxuICAgICAgICAgICAgYW54aWV0eTogYW54aWV0eUVsZW1lbnRzLFxuICAgICAgICAgICAgbWVhbmluZzogbWVhbmluZ0VsZW1lbnRzLFxuICAgICAgICAgICAgc3VtbWFyeVxuICAgICAgICB9O1xuICAgIH1cbiAgICAvLyBIZWxwZXIgbWV0aG9kIHRvIGdldCByYW5kb20gZWxlbWVudHMgZnJvbSBhbiBhcnJheVxuICAgIGdldFJhbmRvbUVsZW1lbnRzKGFycmF5LCBjb3VudCkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgY29uc3QgYXJyYXlDb3B5ID0gWy4uLmFycmF5XTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb3VudCAmJiBhcnJheUNvcHkubGVuZ3RoID4gMDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCByYW5kb21JbmRleCA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIGFycmF5Q29weS5sZW5ndGgpO1xuICAgICAgICAgICAgcmVzdWx0LnB1c2goYXJyYXlDb3B5W3JhbmRvbUluZGV4XSk7XG4gICAgICAgICAgICBhcnJheUNvcHkuc3BsaWNlKHJhbmRvbUluZGV4LCAxKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbn1cbiIsImltcG9ydCB7IE1FRElBX1RZUEVTIH0gZnJvbSAnLi4vY29uc3RhbnRzJztcbi8vIEZlbWluaXN0IGFuYWx5c2lzIGNsYXNzXG5leHBvcnQgY2xhc3MgRmVtaW5pc3RBbmFseXNpcyB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIC8vIEdlbmRlciBjb25zdHJ1Y3Rpb24gY29uY2VwdHNcbiAgICAgICAgdGhpcy5nZW5kZXJDb25zdHJ1Y3Rpb24gPSBbXG4gICAgICAgICAgICBcIlNvY2lhbCBjb25zdHJ1Y3Rpb24gb2YgZ2VuZGVyXCIsXG4gICAgICAgICAgICBcIkdlbmRlciBwZXJmb3JtYXRpdml0eVwiLFxuICAgICAgICAgICAgXCJHZW5kZXIgYXMgcHJvY2Vzc1wiLFxuICAgICAgICAgICAgXCJHZW5kZXIgc29jaWFsaXphdGlvblwiLFxuICAgICAgICAgICAgXCJHZW5kZXIgYXMgcmVsYXRpb25hbFwiXG4gICAgICAgIF07XG4gICAgICAgIC8vIFBhdHJpYXJjaGFsIHN0cnVjdHVyZXMgY29uY2VwdHNcbiAgICAgICAgdGhpcy5wYXRyaWFyY2hhbFN0cnVjdHVyZXMgPSBbXG4gICAgICAgICAgICBcIlN5c3RlbWljIG9wcHJlc3Npb25cIixcbiAgICAgICAgICAgIFwiTWFsZSBwcml2aWxlZ2VcIixcbiAgICAgICAgICAgIFwiSW5zdGl0dXRpb25hbCBzZXhpc21cIixcbiAgICAgICAgICAgIFwiSGVnZW1vbmljIG1hc2N1bGluaXR5XCIsXG4gICAgICAgICAgICBcIlBoYWxsb2dvY2VudHJpc21cIlxuICAgICAgICBdO1xuICAgICAgICAvLyBGZW1pbmlzdCBwZXJzcGVjdGl2ZXMgY29uY2VwdHNcbiAgICAgICAgdGhpcy5mZW1pbmlzdFBlcnNwZWN0aXZlcyA9IFtcbiAgICAgICAgICAgIFwiTGliZXJhbCBmZW1pbmlzbVwiLFxuICAgICAgICAgICAgXCJSYWRpY2FsIGZlbWluaXNtXCIsXG4gICAgICAgICAgICBcIlNvY2lhbGlzdCBmZW1pbmlzbVwiLFxuICAgICAgICAgICAgXCJQb3N0bW9kZXJuIGZlbWluaXNtXCIsXG4gICAgICAgICAgICBcIkVjb2ZlbWluaXNtXCIsXG4gICAgICAgICAgICBcIlRyYW5zZmVtaW5pc21cIlxuICAgICAgICBdO1xuICAgICAgICAvLyBJbnRlcnNlY3Rpb25hbGl0eSBjb25jZXB0c1xuICAgICAgICB0aGlzLmludGVyc2VjdGlvbmFsaXR5ID0gW1xuICAgICAgICAgICAgXCJJbnRlcmxvY2tpbmcgb3BwcmVzc2lvbnNcIixcbiAgICAgICAgICAgIFwiTXVsdGlwbGUgaWRlbnRpdGllc1wiLFxuICAgICAgICAgICAgXCJJbnRlcnNlY3Rpb25hbCBhbmFseXNpc1wiLFxuICAgICAgICAgICAgXCJNYXRyaXggb2YgZG9taW5hdGlvblwiLFxuICAgICAgICAgICAgXCJTaXR1YXRlZCBrbm93bGVkZ2VcIlxuICAgICAgICBdO1xuICAgIH1cbiAgICAvLyBBbmFseXplIGNvbnRlbnQgd2l0aCBGZW1pbmlzdCBmcmFtZXdvcmtcbiAgICBhbmFseXplQ29udGVudChjb250ZW50LCBtZWRpYVR5cGUpIHtcbiAgICAgICAgLy8gR2V0IHJhbmRvbSBlbGVtZW50cyBmcm9tIGVhY2ggY29uY2VwdCBhcnJheVxuICAgICAgICBjb25zdCBnZW5kZXJDb25zdHJ1Y3Rpb25FbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5nZW5kZXJDb25zdHJ1Y3Rpb24sIDIpO1xuICAgICAgICBjb25zdCBwYXRyaWFyY2hhbFN0cnVjdHVyZXNFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5wYXRyaWFyY2hhbFN0cnVjdHVyZXMsIDIpO1xuICAgICAgICBjb25zdCBmZW1pbmlzdFBlcnNwZWN0aXZlc0VsZW1lbnRzID0gdGhpcy5nZXRSYW5kb21FbGVtZW50cyh0aGlzLmZlbWluaXN0UGVyc3BlY3RpdmVzLCAyKTtcbiAgICAgICAgY29uc3QgaW50ZXJzZWN0aW9uYWxpdHlFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5pbnRlcnNlY3Rpb25hbGl0eSwgMik7XG4gICAgICAgIC8vIEdlbmVyYXRlIHN1bW1hcnkgYmFzZWQgb24gbWVkaWEgdHlwZVxuICAgICAgICBsZXQgc3VtbWFyeSA9IFwiXCI7XG4gICAgICAgIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLlRFWFQpIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIkZyb20gYSBGZW1pbmlzdCBwZXJzcGVjdGl2ZSwgdGhpcyB0ZXh0IHJldmVhbHMgdGhlIHNvY2lhbCBjb25zdHJ1Y3Rpb24gb2YgZ2VuZGVyIGFuZCB0aGUgb3BlcmF0aW9uIG9mIHBhdHJpYXJjaGFsIHN0cnVjdHVyZXMuIEl0IGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIHZhcmlvdXMgZmVtaW5pc3QgbGVuc2VzIHRvIHVuZGVyc3RhbmQgaG93IGdlbmRlciBzaGFwZXMgZXhwZXJpZW5jZSBhbmQgc29jaWFsIHJlbGF0aW9ucy5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLklNQUdFKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJUaGlzIGltYWdlIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGEgRmVtaW5pc3QgZnJhbWV3b3JrIHRvIHJldmVhbCB2aXN1YWwgcmVwcmVzZW50YXRpb25zIG9mIGdlbmRlciBjb25zdHJ1Y3Rpb24sIHBhdHJpYXJjaGFsIHN0cnVjdHVyZXMsIGFuZCB0aGUgcG90ZW50aWFsIGZvciByZXNpc3RhbmNlIGFuZCB0cmFuc2Zvcm1hdGlvbi5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLkFVRElPKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJGcm9tIGEgRmVtaW5pc3QgcGVyc3BlY3RpdmUsIHRoaXMgYXVkaW8gcGllY2UgZXhwcmVzc2VzIGdlbmRlcmVkIGV4cGVyaWVuY2VzIGFuZCB0aGUgcG90ZW50aWFsIGZvciBjaGFsbGVuZ2luZyBwYXRyaWFyY2hhbCBzdHJ1Y3R1cmVzIHRocm91Z2ggaXRzIHNvbmljIHF1YWxpdGllcyBhbmQgZW1vdGlvbmFsIHJlc29uYW5jZS5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLkZJTE0pIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIlRoaXMgZmlsbSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhIEZlbWluaXN0IGZyYW1ld29yayB0byByZXZlYWwgbmFycmF0aXZlIGVsZW1lbnRzIG9mIGdlbmRlciBjb25zdHJ1Y3Rpb24sIHBhdHJpYXJjaGFsIHN0cnVjdHVyZXMsIGFuZCB0aGUgcG90ZW50aWFsIGZvciBmZW1pbmlzdCByZXNpc3RhbmNlIGFuZCB0cmFuc2Zvcm1hdGlvbi5cIjtcbiAgICAgICAgfVxuICAgICAgICAvLyBSZXR1cm4gc3RydWN0dXJlZCBhbmFseXNpc1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgZ2VuZGVyQ29uc3RydWN0aW9uOiBnZW5kZXJDb25zdHJ1Y3Rpb25FbGVtZW50cyxcbiAgICAgICAgICAgIHBhdHJpYXJjaGFsU3RydWN0dXJlczogcGF0cmlhcmNoYWxTdHJ1Y3R1cmVzRWxlbWVudHMsXG4gICAgICAgICAgICBmZW1pbmlzdFBlcnNwZWN0aXZlczogZmVtaW5pc3RQZXJzcGVjdGl2ZXNFbGVtZW50cyxcbiAgICAgICAgICAgIGludGVyc2VjdGlvbmFsaXR5OiBpbnRlcnNlY3Rpb25hbGl0eUVsZW1lbnRzLFxuICAgICAgICAgICAgc3VtbWFyeVxuICAgICAgICB9O1xuICAgIH1cbiAgICAvLyBIZWxwZXIgbWV0aG9kIHRvIGdldCByYW5kb20gZWxlbWVudHMgZnJvbSBhbiBhcnJheVxuICAgIGdldFJhbmRvbUVsZW1lbnRzKGFycmF5LCBjb3VudCkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgY29uc3QgYXJyYXlDb3B5ID0gWy4uLmFycmF5XTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb3VudCAmJiBhcnJheUNvcHkubGVuZ3RoID4gMDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCByYW5kb21JbmRleCA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIGFycmF5Q29weS5sZW5ndGgpO1xuICAgICAgICAgICAgcmVzdWx0LnB1c2goYXJyYXlDb3B5W3JhbmRvbUluZGV4XSk7XG4gICAgICAgICAgICBhcnJheUNvcHkuc3BsaWNlKHJhbmRvbUluZGV4LCAxKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbn1cbiIsImltcG9ydCB7IE1FRElBX1RZUEVTIH0gZnJvbSAnLi4vY29uc3RhbnRzJztcbi8vIENyaXRpY2FsIFRoZW9yeSBhbmFseXNpcyBjbGFzc1xuZXhwb3J0IGNsYXNzIENyaXRpY2FsQW5hbHlzaXMge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICAvLyBQb3dlciBzdHJ1Y3R1cmVzIGNvbmNlcHRzXG4gICAgICAgIHRoaXMucG93ZXJTdHJ1Y3R1cmVzID0gW1xuICAgICAgICAgICAgXCJIZWdlbW9ueVwiLFxuICAgICAgICAgICAgXCJEb21pbmF0aW9uXCIsXG4gICAgICAgICAgICBcIkN1bHR1cmFsIGNhcGl0YWxcIixcbiAgICAgICAgICAgIFwiU3ltYm9saWMgdmlvbGVuY2VcIixcbiAgICAgICAgICAgIFwiRGlzY2lwbGluYXJ5IHBvd2VyXCJcbiAgICAgICAgXTtcbiAgICAgICAgLy8gSWRlb2xvZ2ljYWwgY3JpdGlxdWUgY29uY2VwdHNcbiAgICAgICAgdGhpcy5pZGVvbG9naWNhbENyaXRpcXVlID0gW1xuICAgICAgICAgICAgXCJGYWxzZSBjb25zY2lvdXNuZXNzXCIsXG4gICAgICAgICAgICBcIlJlaWZpY2F0aW9uXCIsXG4gICAgICAgICAgICBcIkNvbW1vZGl0eSBmZXRpc2hpc21cIixcbiAgICAgICAgICAgIFwiQ3VsdHVyZSBpbmR1c3RyeVwiLFxuICAgICAgICAgICAgXCJJZGVvbG9naWNhbCBzdGF0ZSBhcHBhcmF0dXNlc1wiXG4gICAgICAgIF07XG4gICAgICAgIC8vIEVtYW5jaXBhdGlvbiBjb25jZXB0c1xuICAgICAgICB0aGlzLmVtYW5jaXBhdGlvbiA9IFtcbiAgICAgICAgICAgIFwiUHJheGlzXCIsXG4gICAgICAgICAgICBcIkNyaXRpY2FsIGNvbnNjaW91c25lc3NcIixcbiAgICAgICAgICAgIFwiQ29tbXVuaWNhdGl2ZSBhY3Rpb25cIixcbiAgICAgICAgICAgIFwiUmFkaWNhbCBkZW1vY3JhY3lcIixcbiAgICAgICAgICAgIFwiVXRvcGlhbiB0aGlua2luZ1wiXG4gICAgICAgIF07XG4gICAgICAgIC8vIERpYWxlY3RpY3MgY29uY2VwdHNcbiAgICAgICAgdGhpcy5kaWFsZWN0aWNzID0gW1xuICAgICAgICAgICAgXCJEaWFsZWN0aWNhbCB0aGlua2luZ1wiLFxuICAgICAgICAgICAgXCJDb250cmFkaWN0aW9uXCIsXG4gICAgICAgICAgICBcIk5lZ2F0aW9uXCIsXG4gICAgICAgICAgICBcIk1lZGlhdGlvblwiLFxuICAgICAgICAgICAgXCJUb3RhbGl0eVwiXG4gICAgICAgIF07XG4gICAgfVxuICAgIC8vIEFuYWx5emUgY29udGVudCB3aXRoIENyaXRpY2FsIFRoZW9yeSBmcmFtZXdvcmtcbiAgICBhbmFseXplQ29udGVudChjb250ZW50LCBtZWRpYVR5cGUpIHtcbiAgICAgICAgLy8gR2V0IHJhbmRvbSBlbGVtZW50cyBmcm9tIGVhY2ggY29uY2VwdCBhcnJheVxuICAgICAgICBjb25zdCBwb3dlclN0cnVjdHVyZXNFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5wb3dlclN0cnVjdHVyZXMsIDIpO1xuICAgICAgICBjb25zdCBpZGVvbG9naWNhbENyaXRpcXVlRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMuaWRlb2xvZ2ljYWxDcml0aXF1ZSwgMik7XG4gICAgICAgIGNvbnN0IGVtYW5jaXBhdGlvbkVsZW1lbnRzID0gdGhpcy5nZXRSYW5kb21FbGVtZW50cyh0aGlzLmVtYW5jaXBhdGlvbiwgMik7XG4gICAgICAgIGNvbnN0IGRpYWxlY3RpY3NFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5kaWFsZWN0aWNzLCAyKTtcbiAgICAgICAgLy8gR2VuZXJhdGUgc3VtbWFyeSBiYXNlZCBvbiBtZWRpYSB0eXBlXG4gICAgICAgIGxldCBzdW1tYXJ5ID0gXCJcIjtcbiAgICAgICAgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuVEVYVCkge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiRnJvbSBhIENyaXRpY2FsIFRoZW9yeSBwZXJzcGVjdGl2ZSwgdGhpcyB0ZXh0IHJldmVhbHMgdW5kZXJseWluZyBwb3dlciBzdHJ1Y3R1cmVzIGFuZCBpZGVvbG9naWNhbCBmb3JtYXRpb25zLiBJdCBjYW4gYmUgYW5hbHl6ZWQgZGlhbGVjdGljYWxseSB0byB1bmRlcnN0YW5kIGhvdyBpdCBib3RoIHJlcHJvZHVjZXMgYW5kIHBvdGVudGlhbGx5IGNoYWxsZW5nZXMgZG9taW5hbnQgc29jaWFsIHJlbGF0aW9ucy5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLklNQUdFKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJUaGlzIGltYWdlIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIENyaXRpY2FsIFRoZW9yeSB0byByZXZlYWwgdmlzdWFsIHJlcHJlc2VudGF0aW9ucyBvZiBwb3dlciBzdHJ1Y3R1cmVzLCBpZGVvbG9naWNhbCBmb3JtYXRpb25zLCBhbmQgdGhlIHBvdGVudGlhbCBmb3IgZW1hbmNpcGF0b3J5IGNvbnNjaW91c25lc3MuXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5BVURJTykge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiRnJvbSBhIENyaXRpY2FsIFRoZW9yeSBwZXJzcGVjdGl2ZSwgdGhpcyBhdWRpbyBwaWVjZSBleHByZXNzZXMgdGhlIHRlbnNpb24gYmV0d2VlbiBkb21pbmF0aW9uIGFuZCBlbWFuY2lwYXRpb24gdGhyb3VnaCBpdHMgc29uaWMgcXVhbGl0aWVzIGFuZCBzdHJ1Y3R1cmFsIGVsZW1lbnRzLlwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuRklMTSkge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiVGhpcyBmaWxtIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIENyaXRpY2FsIFRoZW9yeSB0byByZXZlYWwgbmFycmF0aXZlIGFuZCB2aXN1YWwgZWxlbWVudHMgb2YgcG93ZXIgc3RydWN0dXJlcywgaWRlb2xvZ2ljYWwgZm9ybWF0aW9ucywgYW5kIHRoZSBkaWFsZWN0aWNhbCByZWxhdGlvbnNoaXAgYmV0d2VlbiBkb21pbmF0aW9uIGFuZCBlbWFuY2lwYXRpb24uXCI7XG4gICAgICAgIH1cbiAgICAgICAgLy8gUmV0dXJuIHN0cnVjdHVyZWQgYW5hbHlzaXNcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHBvd2VyU3RydWN0dXJlczogcG93ZXJTdHJ1Y3R1cmVzRWxlbWVudHMsXG4gICAgICAgICAgICBpZGVvbG9naWNhbENyaXRpcXVlOiBpZGVvbG9naWNhbENyaXRpcXVlRWxlbWVudHMsXG4gICAgICAgICAgICBlbWFuY2lwYXRpb246IGVtYW5jaXBhdGlvbkVsZW1lbnRzLFxuICAgICAgICAgICAgZGlhbGVjdGljczogZGlhbGVjdGljc0VsZW1lbnRzLFxuICAgICAgICAgICAgc3VtbWFyeVxuICAgICAgICB9O1xuICAgIH1cbiAgICAvLyBIZWxwZXIgbWV0aG9kIHRvIGdldCByYW5kb20gZWxlbWVudHMgZnJvbSBhbiBhcnJheVxuICAgIGdldFJhbmRvbUVsZW1lbnRzKGFycmF5LCBjb3VudCkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgY29uc3QgYXJyYXlDb3B5ID0gWy4uLmFycmF5XTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb3VudCAmJiBhcnJheUNvcHkubGVuZ3RoID4gMDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCByYW5kb21JbmRleCA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIGFycmF5Q29weS5sZW5ndGgpO1xuICAgICAgICAgICAgcmVzdWx0LnB1c2goYXJyYXlDb3B5W3JhbmRvbUluZGV4XSk7XG4gICAgICAgICAgICBhcnJheUNvcHkuc3BsaWNlKHJhbmRvbUluZGV4LCAxKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbn1cbiIsImltcG9ydCB7IE1FRElBX1RZUEVTIH0gZnJvbSAnLi4vY29uc3RhbnRzJztcbi8vIFBvc3RodW1hbmlzbSBhbmFseXNpcyBjbGFzc1xuZXhwb3J0IGNsYXNzIFBvc3RodW1hbmlzbUFuYWx5c2lzIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgLy8gQmV5b25kIGh1bWFuaXNtIGNvbmNlcHRzXG4gICAgICAgIHRoaXMuYmV5b25kSHVtYW5pc20gPSBbXG4gICAgICAgICAgICBcIkNyaXRpcXVlIG9mIGFudGhyb3BvY2VudHJpc21cIixcbiAgICAgICAgICAgIFwiUG9zdC1hbnRocm9wb2NlbnRyaWMgcGVyc3BlY3RpdmVcIixcbiAgICAgICAgICAgIFwiRGVjZW50ZXJpbmcgdGhlIGh1bWFuXCIsXG4gICAgICAgICAgICBcIkJleW9uZCBodW1hbiBleGNlcHRpb25hbGlzbVwiLFxuICAgICAgICAgICAgXCJEaXN0cmlidXRlZCBzdWJqZWN0aXZpdHlcIlxuICAgICAgICBdO1xuICAgICAgICAvLyBUZWNobm9sb2dpY2FsIG1lZGlhdGlvbnMgY29uY2VwdHNcbiAgICAgICAgdGhpcy50ZWNobm9sb2dpY2FsTWVkaWF0aW9ucyA9IFtcbiAgICAgICAgICAgIFwiSHVtYW4tdGVjaG5vbG9neSBlbnRhbmdsZW1lbnRcIixcbiAgICAgICAgICAgIFwiVGVjaG5vbG9naWNhbCBlbWJvZGltZW50XCIsXG4gICAgICAgICAgICBcIkRpZ2l0YWwgbWVkaWF0aW9uXCIsXG4gICAgICAgICAgICBcIkN5YmVybmV0aWMgc3lzdGVtc1wiLFxuICAgICAgICAgICAgXCJUZWNobm9sb2dpY2FsIHVuY29uc2Npb3VzXCJcbiAgICAgICAgXTtcbiAgICAgICAgLy8gTm9uaHVtYW4gYWdlbmN5IGNvbmNlcHRzXG4gICAgICAgIHRoaXMubm9uaHVtYW5BZ2VuY3kgPSBbXG4gICAgICAgICAgICBcIk1hdGVyaWFsIGFnZW5jeVwiLFxuICAgICAgICAgICAgXCJOb25odW1hbiBhY3RhbnRzXCIsXG4gICAgICAgICAgICBcIlZpYnJhbnQgbWF0dGVyXCIsXG4gICAgICAgICAgICBcIk9iamVjdC1vcmllbnRlZCBvbnRvbG9neVwiLFxuICAgICAgICAgICAgXCJNb3JlLXRoYW4taHVtYW4gd29ybGRzXCJcbiAgICAgICAgXTtcbiAgICAgICAgLy8gSHlicmlkaXRpZXMgY29uY2VwdHNcbiAgICAgICAgdGhpcy5oeWJyaWRpdGllcyA9IFtcbiAgICAgICAgICAgIFwiQ3lib3JnIHN1YmplY3Rpdml0eVwiLFxuICAgICAgICAgICAgXCJIdW1hbi1hbmltYWwgY29udGludXVtXCIsXG4gICAgICAgICAgICBcIk5hdHVyZWN1bHR1cmVzXCIsXG4gICAgICAgICAgICBcIkh5YnJpZCBhc3NlbWJsYWdlc1wiLFxuICAgICAgICAgICAgXCJCb3VuZGFyeSBjcm9zc2luZ3NcIlxuICAgICAgICBdO1xuICAgIH1cbiAgICAvLyBBbmFseXplIGNvbnRlbnQgd2l0aCBQb3N0aHVtYW5pc20gZnJhbWV3b3JrXG4gICAgYW5hbHl6ZUNvbnRlbnQoY29udGVudCwgbWVkaWFUeXBlKSB7XG4gICAgICAgIC8vIEdldCByYW5kb20gZWxlbWVudHMgZnJvbSBlYWNoIGNvbmNlcHQgYXJyYXlcbiAgICAgICAgY29uc3QgYmV5b25kSHVtYW5pc21FbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5iZXlvbmRIdW1hbmlzbSwgMik7XG4gICAgICAgIGNvbnN0IHRlY2hub2xvZ2ljYWxNZWRpYXRpb25zRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMudGVjaG5vbG9naWNhbE1lZGlhdGlvbnMsIDIpO1xuICAgICAgICBjb25zdCBub25odW1hbkFnZW5jeUVsZW1lbnRzID0gdGhpcy5nZXRSYW5kb21FbGVtZW50cyh0aGlzLm5vbmh1bWFuQWdlbmN5LCAyKTtcbiAgICAgICAgY29uc3QgaHlicmlkaXRpZXNFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5oeWJyaWRpdGllcywgMik7XG4gICAgICAgIC8vIEdlbmVyYXRlIHN1bW1hcnkgYmFzZWQgb24gbWVkaWEgdHlwZVxuICAgICAgICBsZXQgc3VtbWFyeSA9IFwiXCI7XG4gICAgICAgIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLlRFWFQpIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIkZyb20gYSBQb3N0aHVtYW5pc3QgcGVyc3BlY3RpdmUsIHRoaXMgdGV4dCBjaGFsbGVuZ2VzIGFudGhyb3BvY2VudHJpYyBhc3N1bXB0aW9ucyBhbmQgZXhwbG9yZXMgdGhlIGVudGFuZ2xlbWVudHMgYmV0d2VlbiBodW1hbiBhbmQgbm9uaHVtYW4gYWdlbmNpZXMuIEl0IHJldmVhbHMgaG93IHN1YmplY3Rpdml0eSBpcyBkaXN0cmlidXRlZCBhY3Jvc3MgbmV0d29ya3Mgb2YgaHVtYW4sIHRlY2hub2xvZ2ljYWwsIGFuZCBtYXRlcmlhbCBhY3RvcnMuXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5JTUFHRSkge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiVGhpcyBpbWFnZSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhIFBvc3RodW1hbmlzdCBmcmFtZXdvcmsgdG8gcmV2ZWFsIHZpc3VhbCByZXByZXNlbnRhdGlvbnMgb2YgaHVtYW4tbm9uaHVtYW4gZW50YW5nbGVtZW50cywgdGVjaG5vbG9naWNhbCBtZWRpYXRpb25zLCBhbmQgaHlicmlkIGZvcm1zIG9mIGFnZW5jeSBhbmQgc3ViamVjdGl2aXR5LlwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuQVVESU8pIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIkZyb20gYSBQb3N0aHVtYW5pc3QgcGVyc3BlY3RpdmUsIHRoaXMgYXVkaW8gcGllY2UgZXhwcmVzc2VzIHRoZSBkaXN0cmlidXRlZCBuYXR1cmUgb2YgYWdlbmN5IGFuZCBzdWJqZWN0aXZpdHkgYWNyb3NzIGh1bWFuIGFuZCBub25odW1hbiBhY3RvcnMgdGhyb3VnaCBpdHMgc29uaWMgcXVhbGl0aWVzIGFuZCB0ZWNobm9sb2dpY2FsIG1lZGlhdGlvbnMuXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5GSUxNKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJUaGlzIGZpbG0gY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYSBQb3N0aHVtYW5pc3QgZnJhbWV3b3JrIHRvIHJldmVhbCBuYXJyYXRpdmUgYW5kIHZpc3VhbCBlbGVtZW50cyB0aGF0IGNoYWxsZW5nZSBhbnRocm9wb2NlbnRyaXNtIGFuZCBleHBsb3JlIHRoZSBlbnRhbmdsZW1lbnRzIGJldHdlZW4gaHVtYW4sIHRlY2hub2xvZ2ljYWwsIGFuZCBub25odW1hbiBhZ2VuY2llcy5cIjtcbiAgICAgICAgfVxuICAgICAgICAvLyBSZXR1cm4gc3RydWN0dXJlZCBhbmFseXNpc1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgYmV5b25kSHVtYW5pc206IGJleW9uZEh1bWFuaXNtRWxlbWVudHMsXG4gICAgICAgICAgICB0ZWNobm9sb2dpY2FsTWVkaWF0aW9uczogdGVjaG5vbG9naWNhbE1lZGlhdGlvbnNFbGVtZW50cyxcbiAgICAgICAgICAgIG5vbmh1bWFuQWdlbmN5OiBub25odW1hbkFnZW5jeUVsZW1lbnRzLFxuICAgICAgICAgICAgaHlicmlkaXRpZXM6IGh5YnJpZGl0aWVzRWxlbWVudHMsXG4gICAgICAgICAgICBzdW1tYXJ5XG4gICAgICAgIH07XG4gICAgfVxuICAgIC8vIEhlbHBlciBtZXRob2QgdG8gZ2V0IHJhbmRvbSBlbGVtZW50cyBmcm9tIGFuIGFycmF5XG4gICAgZ2V0UmFuZG9tRWxlbWVudHMoYXJyYXksIGNvdW50KSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgICBjb25zdCBhcnJheUNvcHkgPSBbLi4uYXJyYXldO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNvdW50ICYmIGFycmF5Q29weS5sZW5ndGggPiAwOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHJhbmRvbUluZGV4ID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogYXJyYXlDb3B5Lmxlbmd0aCk7XG4gICAgICAgICAgICByZXN1bHQucHVzaChhcnJheUNvcHlbcmFuZG9tSW5kZXhdKTtcbiAgICAgICAgICAgIGFycmF5Q29weS5zcGxpY2UocmFuZG9tSW5kZXgsIDEpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgTUVESUFfVFlQRVMgfSBmcm9tICcuLi9jb25zdGFudHMnO1xuLy8gQnVkZGhpc3QgYW5hbHlzaXMgY2xhc3NcbmV4cG9ydCBjbGFzcyBCdWRkaGlzdEFuYWx5c2lzIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgLy8gRm91ciBOb2JsZSBUcnV0aHMgY29uY2VwdHNcbiAgICAgICAgdGhpcy5mb3VyTm9ibGVUcnV0aHMgPSBbXG4gICAgICAgICAgICBcIlN1ZmZlcmluZyAoZHVra2hhKVwiLFxuICAgICAgICAgICAgXCJPcmlnaW4gb2Ygc3VmZmVyaW5nIChzYW11ZGF5YSlcIixcbiAgICAgICAgICAgIFwiQ2Vzc2F0aW9uIG9mIHN1ZmZlcmluZyAobmlyb2RoYSlcIixcbiAgICAgICAgICAgIFwiUGF0aCB0byBjZXNzYXRpb24gKG1hZ2dhKVwiLFxuICAgICAgICAgICAgXCJFaWdodGZvbGQgcGF0aFwiXG4gICAgICAgIF07XG4gICAgICAgIC8vIEltcGVybWFuZW5jZSBjb25jZXB0c1xuICAgICAgICB0aGlzLmltcGVybWFuZW5jZSA9IFtcbiAgICAgICAgICAgIFwiQW5pY2NhIChpbXBlcm1hbmVuY2UpXCIsXG4gICAgICAgICAgICBcIkNvbnN0YW50IGNoYW5nZVwiLFxuICAgICAgICAgICAgXCJUcmFuc2llbmNlXCIsXG4gICAgICAgICAgICBcIk1vbWVudGFyaW5lc3NcIixcbiAgICAgICAgICAgIFwiRmx1eCBhbmQgZmxvd1wiXG4gICAgICAgIF07XG4gICAgICAgIC8vIE5vbi1zZWxmIGNvbmNlcHRzXG4gICAgICAgIHRoaXMubm9uU2VsZiA9IFtcbiAgICAgICAgICAgIFwiQW5hdHRhIChub24tc2VsZilcIixcbiAgICAgICAgICAgIFwiTm8gcGVybWFuZW50IHNlbGZcIixcbiAgICAgICAgICAgIFwiSW50ZXJkZXBlbmRlbnQgYXJpc2luZ1wiLFxuICAgICAgICAgICAgXCJFbXB0aW5lc3MgKHN1bnlhdGEpXCIsXG4gICAgICAgICAgICBcIkZpdmUgYWdncmVnYXRlc1wiXG4gICAgICAgIF07XG4gICAgICAgIC8vIE1pbmRmdWxuZXNzIGNvbmNlcHRzXG4gICAgICAgIHRoaXMubWluZGZ1bG5lc3MgPSBbXG4gICAgICAgICAgICBcIlByZXNlbnQtbW9tZW50IGF3YXJlbmVzc1wiLFxuICAgICAgICAgICAgXCJCYXJlIGF0dGVudGlvblwiLFxuICAgICAgICAgICAgXCJOb24tanVkZ21lbnRhbCBvYnNlcnZhdGlvblwiLFxuICAgICAgICAgICAgXCJWaXBhc3NhbmEgKGluc2lnaHQpXCIsXG4gICAgICAgICAgICBcIlNhbWF0aGEgKGNhbG0gYWJpZGluZylcIlxuICAgICAgICBdO1xuICAgIH1cbiAgICAvLyBBbmFseXplIGNvbnRlbnQgd2l0aCBCdWRkaGlzdCBmcmFtZXdvcmtcbiAgICBhbmFseXplQ29udGVudChjb250ZW50LCBtZWRpYVR5cGUpIHtcbiAgICAgICAgLy8gR2V0IHJhbmRvbSBlbGVtZW50cyBmcm9tIGVhY2ggY29uY2VwdCBhcnJheVxuICAgICAgICBjb25zdCBmb3VyTm9ibGVUcnV0aHNFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5mb3VyTm9ibGVUcnV0aHMsIDIpO1xuICAgICAgICBjb25zdCBpbXBlcm1hbmVuY2VFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5pbXBlcm1hbmVuY2UsIDIpO1xuICAgICAgICBjb25zdCBub25TZWxmRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMubm9uU2VsZiwgMik7XG4gICAgICAgIGNvbnN0IG1pbmRmdWxuZXNzRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMubWluZGZ1bG5lc3MsIDIpO1xuICAgICAgICAvLyBHZW5lcmF0ZSBzdW1tYXJ5IGJhc2VkIG9uIG1lZGlhIHR5cGVcbiAgICAgICAgbGV0IHN1bW1hcnkgPSBcIlwiO1xuICAgICAgICBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5URVhUKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJGcm9tIGEgQnVkZGhpc3QgcGVyc3BlY3RpdmUsIHRoaXMgdGV4dCByZXZlYWxzIHRoZSBuYXR1cmUgb2YgaW1wZXJtYW5lbmNlIChhbmljY2EpIGFuZCB0aGUgYWJzZW5jZSBvZiBhIHBlcm1hbmVudCBzZWxmIChhbmF0dGEpLiBJdCBjYW4gYmUgdW5kZXJzdG9vZCBpbiB0ZXJtcyBvZiB0aGUgRm91ciBOb2JsZSBUcnV0aHMsIHdoaWNoIGFkZHJlc3MgdGhlIG5hdHVyZSBvZiBzdWZmZXJpbmcgYW5kIHRoZSBwYXRoIHRvIGl0cyBjZXNzYXRpb24uXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5JTUFHRSkge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiVGhpcyBpbWFnZSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhIEJ1ZGRoaXN0IGZyYW1ld29yayB0byByZXZlYWwgdmlzdWFsIHJlcHJlc2VudGF0aW9ucyBvZiBpbXBlcm1hbmVuY2UsIGludGVyZGVwZW5kZW50IGFyaXNpbmcsIGFuZCB0aGUgcG90ZW50aWFsIGZvciBtaW5kZnVsIGF3YXJlbmVzcyBvZiBwcmVzZW50IGV4cGVyaWVuY2UuXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5BVURJTykge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiRnJvbSBhIEJ1ZGRoaXN0IHBlcnNwZWN0aXZlLCB0aGlzIGF1ZGlvIHBpZWNlIGV4cHJlc3NlcyB0aGUgbmF0dXJlIG9mIGltcGVybWFuZW5jZSBhbmQgdGhlIHBvdGVudGlhbCBmb3IgbWluZGZ1bCBhd2FyZW5lc3MgdGhyb3VnaCBpdHMgc29uaWMgcXVhbGl0aWVzIGFuZCB0ZW1wb3JhbCB1bmZvbGRpbmcuXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5GSUxNKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJUaGlzIGZpbG0gY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYSBCdWRkaGlzdCBmcmFtZXdvcmsgdG8gcmV2ZWFsIG5hcnJhdGl2ZSBhbmQgdmlzdWFsIGVsZW1lbnRzIG9mIGltcGVybWFuZW5jZSwgbm9uLXNlbGYsIGFuZCB0aGUgcG90ZW50aWFsIGZvciBhd2FrZW5pbmcgdG8gdGhlIHRydWUgbmF0dXJlIG9mIHJlYWxpdHkuXCI7XG4gICAgICAgIH1cbiAgICAgICAgLy8gUmV0dXJuIHN0cnVjdHVyZWQgYW5hbHlzaXNcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGZvdXJOb2JsZVRydXRoczogZm91ck5vYmxlVHJ1dGhzRWxlbWVudHMsXG4gICAgICAgICAgICBpbXBlcm1hbmVuY2U6IGltcGVybWFuZW5jZUVsZW1lbnRzLFxuICAgICAgICAgICAgbm9uU2VsZjogbm9uU2VsZkVsZW1lbnRzLFxuICAgICAgICAgICAgbWluZGZ1bG5lc3M6IG1pbmRmdWxuZXNzRWxlbWVudHMsXG4gICAgICAgICAgICBzdW1tYXJ5XG4gICAgICAgIH07XG4gICAgfVxuICAgIC8vIEhlbHBlciBtZXRob2QgdG8gZ2V0IHJhbmRvbSBlbGVtZW50cyBmcm9tIGFuIGFycmF5XG4gICAgZ2V0UmFuZG9tRWxlbWVudHMoYXJyYXksIGNvdW50KSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgICBjb25zdCBhcnJheUNvcHkgPSBbLi4uYXJyYXldO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNvdW50ICYmIGFycmF5Q29weS5sZW5ndGggPiAwOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHJhbmRvbUluZGV4ID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogYXJyYXlDb3B5Lmxlbmd0aCk7XG4gICAgICAgICAgICByZXN1bHQucHVzaChhcnJheUNvcHlbcmFuZG9tSW5kZXhdKTtcbiAgICAgICAgICAgIGFycmF5Q29weS5zcGxpY2UocmFuZG9tSW5kZXgsIDEpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgTUVESUFfVFlQRVMgfSBmcm9tICcuLi9jb25zdGFudHMnO1xuLy8gTmlldHpzY2hlYW4gYW5hbHlzaXMgY2xhc3NcbmV4cG9ydCBjbGFzcyBOaWV0enNjaGVhbkFuYWx5c2lzIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgLy8gV2lsbCB0byBQb3dlciBjb25jZXB0c1xuICAgICAgICB0aGlzLndpbGxUb1Bvd2VyID0gW1xuICAgICAgICAgICAgXCJDcmVhdGl2ZSBmb3JjZVwiLFxuICAgICAgICAgICAgXCJTZWxmLW92ZXJjb21pbmdcIixcbiAgICAgICAgICAgIFwiTGlmZS1hZmZpcm1hdGlvblwiLFxuICAgICAgICAgICAgXCJHcm93dGggYW5kIGV4cGFuc2lvblwiLFxuICAgICAgICAgICAgXCJQb3dlciBhcyBpbnRlcnByZXRhdGlvblwiXG4gICAgICAgIF07XG4gICAgICAgIC8vIEV0ZXJuYWwgUmVjdXJyZW5jZSBjb25jZXB0c1xuICAgICAgICB0aGlzLmV0ZXJuYWxSZWN1cnJlbmNlID0gW1xuICAgICAgICAgICAgXCJBZmZpcm1hdGlvbiBvZiBsaWZlXCIsXG4gICAgICAgICAgICBcIkFtb3IgZmF0aSAobG92ZSBvZiBmYXRlKVwiLFxuICAgICAgICAgICAgXCJFdGVybmFsIHJldHVyblwiLFxuICAgICAgICAgICAgXCJFeGlzdGVudGlhbCB3ZWlnaHRcIixcbiAgICAgICAgICAgIFwiSGlnaGVzdCBhZmZpcm1hdGlvblwiXG4gICAgICAgIF07XG4gICAgICAgIC8vIFBlcnNwZWN0aXZpc20gY29uY2VwdHNcbiAgICAgICAgdGhpcy5wZXJzcGVjdGl2aXNtID0gW1xuICAgICAgICAgICAgXCJObyBhYnNvbHV0ZSB0cnV0aFwiLFxuICAgICAgICAgICAgXCJNdWx0aXBsZSBpbnRlcnByZXRhdGlvbnNcIixcbiAgICAgICAgICAgIFwiS25vd2xlZGdlIGFzIHBlcnNwZWN0aXZlXCIsXG4gICAgICAgICAgICBcIkJleW9uZCBvYmplY3Rpdml0eVwiLFxuICAgICAgICAgICAgXCJJbnRlcnByZXRpdmUgcGx1cmFsaXNtXCJcbiAgICAgICAgXTtcbiAgICAgICAgLy8gQmV5b25kIEdvb2QgYW5kIEV2aWwgY29uY2VwdHNcbiAgICAgICAgdGhpcy5iZXlvbmRHb29kRXZpbCA9IFtcbiAgICAgICAgICAgIFwiQ3JpdGlxdWUgb2YgbW9yYWxpdHlcIixcbiAgICAgICAgICAgIFwiTWFzdGVyIHZzLiBzbGF2ZSBtb3JhbGl0eVwiLFxuICAgICAgICAgICAgXCJUcmFuc3ZhbHVhdGlvbiBvZiB2YWx1ZXNcIixcbiAgICAgICAgICAgIFwiR2VuZWFsb2d5IG9mIG1vcmFsc1wiLFxuICAgICAgICAgICAgXCJCZXlvbmQgY29udmVudGlvbmFsIG1vcmFsaXR5XCJcbiAgICAgICAgXTtcbiAgICB9XG4gICAgLy8gQW5hbHl6ZSBjb250ZW50IHdpdGggTmlldHpzY2hlYW4gZnJhbWV3b3JrXG4gICAgYW5hbHl6ZUNvbnRlbnQoY29udGVudCwgbWVkaWFUeXBlKSB7XG4gICAgICAgIC8vIEdldCByYW5kb20gZWxlbWVudHMgZnJvbSBlYWNoIGNvbmNlcHQgYXJyYXlcbiAgICAgICAgY29uc3Qgd2lsbFRvUG93ZXJFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy53aWxsVG9Qb3dlciwgMik7XG4gICAgICAgIGNvbnN0IGV0ZXJuYWxSZWN1cnJlbmNlRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMuZXRlcm5hbFJlY3VycmVuY2UsIDIpO1xuICAgICAgICBjb25zdCBwZXJzcGVjdGl2aXNtRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMucGVyc3BlY3RpdmlzbSwgMik7XG4gICAgICAgIGNvbnN0IGJleW9uZEdvb2RFdmlsRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMuYmV5b25kR29vZEV2aWwsIDIpO1xuICAgICAgICAvLyBHZW5lcmF0ZSBzdW1tYXJ5IGJhc2VkIG9uIG1lZGlhIHR5cGVcbiAgICAgICAgbGV0IHN1bW1hcnkgPSBcIlwiO1xuICAgICAgICBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5URVhUKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJGcm9tIGEgTmlldHpzY2hlYW4gcGVyc3BlY3RpdmUsIHRoaXMgdGV4dCBleHByZXNzZXMgdGhlIHdpbGwgdG8gcG93ZXIgYXMgYSBjcmVhdGl2ZSBmb3JjZSBvZiBzZWxmLW92ZXJjb21pbmcuIEl0IHJldmVhbHMgYSBwZXJzcGVjdGl2YWwgdW5kZXJzdGFuZGluZyBvZiB0cnV0aCB0aGF0IGdvZXMgYmV5b25kIGNvbnZlbnRpb25hbCBtb3JhbCBjYXRlZ29yaWVzIG9mIGdvb2QgYW5kIGV2aWwuXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5JTUFHRSkge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiVGhpcyBpbWFnZSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhIE5pZXR6c2NoZWFuIGZyYW1ld29yayB0byByZXZlYWwgdmlzdWFsIGV4cHJlc3Npb25zIG9mIHRoZSB3aWxsIHRvIHBvd2VyLCBwZXJzcGVjdGl2aXNtLCBhbmQgdGhlIHBvdGVudGlhbCBmb3IgZ29pbmcgYmV5b25kIGNvbnZlbnRpb25hbCBtb3JhbCBpbnRlcnByZXRhdGlvbnMuXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5BVURJTykge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiRnJvbSBhIE5pZXR6c2NoZWFuIHBlcnNwZWN0aXZlLCB0aGlzIGF1ZGlvIHBpZWNlIGV4cHJlc3NlcyB0aGUgd2lsbCB0byBwb3dlciBhcyBhIGNyZWF0aXZlIGZvcmNlIGFuZCB0aGUgYWZmaXJtYXRpb24gb2YgbGlmZSB0aHJvdWdoIGl0cyBzb25pYyBxdWFsaXRpZXMgYW5kIGVtb3Rpb25hbCByZXNvbmFuY2UuXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5GSUxNKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJUaGlzIGZpbG0gY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYSBOaWV0enNjaGVhbiBmcmFtZXdvcmsgdG8gcmV2ZWFsIG5hcnJhdGl2ZSBhbmQgdmlzdWFsIGVsZW1lbnRzIG9mIHRoZSB3aWxsIHRvIHBvd2VyLCBldGVybmFsIHJlY3VycmVuY2UsIGFuZCB0aGUgdHJhbnN2YWx1YXRpb24gb2YgY29udmVudGlvbmFsIG1vcmFsIHZhbHVlcy5cIjtcbiAgICAgICAgfVxuICAgICAgICAvLyBSZXR1cm4gc3RydWN0dXJlZCBhbmFseXNpc1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgd2lsbFRvUG93ZXI6IHdpbGxUb1Bvd2VyRWxlbWVudHMsXG4gICAgICAgICAgICBldGVybmFsUmVjdXJyZW5jZTogZXRlcm5hbFJlY3VycmVuY2VFbGVtZW50cyxcbiAgICAgICAgICAgIHBlcnNwZWN0aXZpc206IHBlcnNwZWN0aXZpc21FbGVtZW50cyxcbiAgICAgICAgICAgIGJleW9uZEdvb2RFdmlsOiBiZXlvbmRHb29kRXZpbEVsZW1lbnRzLFxuICAgICAgICAgICAgc3VtbWFyeVxuICAgICAgICB9O1xuICAgIH1cbiAgICAvLyBIZWxwZXIgbWV0aG9kIHRvIGdldCByYW5kb20gZWxlbWVudHMgZnJvbSBhbiBhcnJheVxuICAgIGdldFJhbmRvbUVsZW1lbnRzKGFycmF5LCBjb3VudCkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgY29uc3QgYXJyYXlDb3B5ID0gWy4uLmFycmF5XTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb3VudCAmJiBhcnJheUNvcHkubGVuZ3RoID4gMDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCByYW5kb21JbmRleCA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIGFycmF5Q29weS5sZW5ndGgpO1xuICAgICAgICAgICAgcmVzdWx0LnB1c2goYXJyYXlDb3B5W3JhbmRvbUluZGV4XSk7XG4gICAgICAgICAgICBhcnJheUNvcHkuc3BsaWNlKHJhbmRvbUluZGV4LCAxKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbn1cbiIsImltcG9ydCB7IE1FRElBX1RZUEVTIH0gZnJvbSAnLi4vY29uc3RhbnRzJztcbi8vIEdlc3RhbHQgYW5hbHlzaXMgY2xhc3NcbmV4cG9ydCBjbGFzcyBHZXN0YWx0QW5hbHlzaXMge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICAvLyBXaG9sZW5lc3MgcHJpbmNpcGxlcyBjb25jZXB0c1xuICAgICAgICB0aGlzLndob2xlbmVzc1ByaW5jaXBsZXMgPSBbXG4gICAgICAgICAgICBcIlRoZSB3aG9sZSBpcyBncmVhdGVyIHRoYW4gdGhlIHN1bSBvZiBwYXJ0c1wiLFxuICAgICAgICAgICAgXCJGaWd1cmUtZ3JvdW5kIHJlbGF0aW9uc2hpcFwiLFxuICAgICAgICAgICAgXCJQcsOkZ25hbnogKGdvb2QgZm9ybSlcIixcbiAgICAgICAgICAgIFwiQ2xvc3VyZSBhbmQgY29tcGxldGlvblwiLFxuICAgICAgICAgICAgXCJIb2xpc3RpYyBwZXJjZXB0aW9uXCJcbiAgICAgICAgXTtcbiAgICAgICAgLy8gQ29udGFjdCBib3VuZGFyeSBjb25jZXB0c1xuICAgICAgICB0aGlzLmNvbnRhY3RCb3VuZGFyeSA9IFtcbiAgICAgICAgICAgIFwiQ29udGFjdCBhbmQgd2l0aGRyYXdhbFwiLFxuICAgICAgICAgICAgXCJCb3VuZGFyeSBkaXN0dXJiYW5jZXNcIixcbiAgICAgICAgICAgIFwiQ29uZmx1ZW5jZSBhbmQgaXNvbGF0aW9uXCIsXG4gICAgICAgICAgICBcIkludHJvamVjdGlvbiBhbmQgcHJvamVjdGlvblwiLFxuICAgICAgICAgICAgXCJSZXRyb2ZsZWN0aW9uIGFuZCBkZWZsZWN0aW9uXCJcbiAgICAgICAgXTtcbiAgICAgICAgLy8gQXdhcmVuZXNzIHByb2Nlc3MgY29uY2VwdHNcbiAgICAgICAgdGhpcy5hd2FyZW5lc3NQcm9jZXNzID0gW1xuICAgICAgICAgICAgXCJIZXJlLWFuZC1ub3cgYXdhcmVuZXNzXCIsXG4gICAgICAgICAgICBcIlBoZW5vbWVub2xvZ2ljYWwgbWV0aG9kXCIsXG4gICAgICAgICAgICBcIk9yZ2FuaXNtaWMgc2VsZi1yZWd1bGF0aW9uXCIsXG4gICAgICAgICAgICBcIlBhcmFkb3hpY2FsIHRoZW9yeSBvZiBjaGFuZ2VcIixcbiAgICAgICAgICAgIFwiQ3JlYXRpdmUgYWRqdXN0bWVudFwiXG4gICAgICAgIF07XG4gICAgICAgIC8vIFBvbGFyaXRpZXMgY29uY2VwdHNcbiAgICAgICAgdGhpcy5wb2xhcml0aWVzID0gW1xuICAgICAgICAgICAgXCJUb3AgZG9nL3VuZGVyZG9nXCIsXG4gICAgICAgICAgICBcIkludGVncmF0aW9uIG9mIG9wcG9zaXRlc1wiLFxuICAgICAgICAgICAgXCJEaWFsZWN0aWNhbCB0aGlua2luZ1wiLFxuICAgICAgICAgICAgXCJQb2xhcml6YXRpb24gYW5kIHN5bnRoZXNpc1wiLFxuICAgICAgICAgICAgXCJDb21wbGVtZW50YXJ5IGFzcGVjdHNcIlxuICAgICAgICBdO1xuICAgIH1cbiAgICAvLyBBbmFseXplIGNvbnRlbnQgd2l0aCBHZXN0YWx0IGZyYW1ld29ya1xuICAgIGFuYWx5emVDb250ZW50KGNvbnRlbnQsIG1lZGlhVHlwZSkge1xuICAgICAgICAvLyBHZXQgcmFuZG9tIGVsZW1lbnRzIGZyb20gZWFjaCBjb25jZXB0IGFycmF5XG4gICAgICAgIGNvbnN0IHdob2xlbmVzc1ByaW5jaXBsZXNFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy53aG9sZW5lc3NQcmluY2lwbGVzLCAyKTtcbiAgICAgICAgY29uc3QgY29udGFjdEJvdW5kYXJ5RWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMuY29udGFjdEJvdW5kYXJ5LCAyKTtcbiAgICAgICAgY29uc3QgYXdhcmVuZXNzUHJvY2Vzc0VsZW1lbnRzID0gdGhpcy5nZXRSYW5kb21FbGVtZW50cyh0aGlzLmF3YXJlbmVzc1Byb2Nlc3MsIDIpO1xuICAgICAgICBjb25zdCBwb2xhcml0aWVzRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMucG9sYXJpdGllcywgMik7XG4gICAgICAgIC8vIEdlbmVyYXRlIHN1bW1hcnkgYmFzZWQgb24gbWVkaWEgdHlwZVxuICAgICAgICBsZXQgc3VtbWFyeSA9IFwiXCI7XG4gICAgICAgIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLlRFWFQpIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIkZyb20gYSBHZXN0YWx0IHBlcnNwZWN0aXZlLCB0aGlzIHRleHQgcmV2ZWFscyB0aGUgcHJpbmNpcGxlcyBvZiB3aG9sZW5lc3MgYW5kIGZpZ3VyZS1ncm91bmQgcmVsYXRpb25zaGlwcy4gSXQgY2FuIGJlIHVuZGVyc3Rvb2QgaW4gdGVybXMgb2YgY29udGFjdCBib3VuZGFyaWVzLCBhd2FyZW5lc3MgcHJvY2Vzc2VzLCBhbmQgdGhlIGludGVncmF0aW9uIG9mIHBvbGFyaXRpZXMuXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5JTUFHRSkge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiVGhpcyBpbWFnZSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhIEdlc3RhbHQgZnJhbWV3b3JrIHRvIHJldmVhbCB2aXN1YWwgcHJpbmNpcGxlcyBvZiB3aG9sZW5lc3MsIGZpZ3VyZS1ncm91bmQgcmVsYXRpb25zaGlwcywgYW5kIHRoZSBpbnRlZ3JhdGlvbiBvZiBwb2xhcml0aWVzLlwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuQVVESU8pIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIkZyb20gYSBHZXN0YWx0IHBlcnNwZWN0aXZlLCB0aGlzIGF1ZGlvIHBpZWNlIGV4cHJlc3NlcyBwcmluY2lwbGVzIG9mIHdob2xlbmVzcyBhbmQgZmlndXJlLWdyb3VuZCByZWxhdGlvbnNoaXBzIHRocm91Z2ggaXRzIHNvbmljIHF1YWxpdGllcyBhbmQgdGVtcG9yYWwgdW5mb2xkaW5nLlwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuRklMTSkge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiVGhpcyBmaWxtIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGEgR2VzdGFsdCBmcmFtZXdvcmsgdG8gcmV2ZWFsIG5hcnJhdGl2ZSBhbmQgdmlzdWFsIGVsZW1lbnRzIG9mIHdob2xlbmVzcywgY29udGFjdCBib3VuZGFyaWVzLCBhd2FyZW5lc3MgcHJvY2Vzc2VzLCBhbmQgdGhlIGludGVncmF0aW9uIG9mIHBvbGFyaXRpZXMuXCI7XG4gICAgICAgIH1cbiAgICAgICAgLy8gUmV0dXJuIHN0cnVjdHVyZWQgYW5hbHlzaXNcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHdob2xlbmVzc1ByaW5jaXBsZXM6IHdob2xlbmVzc1ByaW5jaXBsZXNFbGVtZW50cyxcbiAgICAgICAgICAgIGNvbnRhY3RCb3VuZGFyeTogY29udGFjdEJvdW5kYXJ5RWxlbWVudHMsXG4gICAgICAgICAgICBhd2FyZW5lc3NQcm9jZXNzOiBhd2FyZW5lc3NQcm9jZXNzRWxlbWVudHMsXG4gICAgICAgICAgICBwb2xhcml0aWVzOiBwb2xhcml0aWVzRWxlbWVudHMsXG4gICAgICAgICAgICBzdW1tYXJ5XG4gICAgICAgIH07XG4gICAgfVxuICAgIC8vIEhlbHBlciBtZXRob2QgdG8gZ2V0IHJhbmRvbSBlbGVtZW50cyBmcm9tIGFuIGFycmF5XG4gICAgZ2V0UmFuZG9tRWxlbWVudHMoYXJyYXksIGNvdW50KSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgICBjb25zdCBhcnJheUNvcHkgPSBbLi4uYXJyYXldO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNvdW50ICYmIGFycmF5Q29weS5sZW5ndGggPiAwOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHJhbmRvbUluZGV4ID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogYXJyYXlDb3B5Lmxlbmd0aCk7XG4gICAgICAgICAgICByZXN1bHQucHVzaChhcnJheUNvcHlbcmFuZG9tSW5kZXhdKTtcbiAgICAgICAgICAgIGFycmF5Q29weS5zcGxpY2UocmFuZG9tSW5kZXgsIDEpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgTUVESUFfVFlQRVMgfSBmcm9tICcuLi9jb25zdGFudHMnO1xuLy8gVHJhbnNwZXJzb25hbCBhbmFseXNpcyBjbGFzc1xuZXhwb3J0IGNsYXNzIFRyYW5zcGVyc29uYWxBbmFseXNpcyB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIC8vIEJleW9uZCBlZ28gY29uY2VwdHNcbiAgICAgICAgdGhpcy5iZXlvbmRFZ28gPSBbXG4gICAgICAgICAgICBcIlRyYW5zY2VuZGVuY2Ugb2YgZWdvXCIsXG4gICAgICAgICAgICBcIlRyYW5zcGVyc29uYWwgc2VsZlwiLFxuICAgICAgICAgICAgXCJFeHBhbmRlZCBpZGVudGl0eVwiLFxuICAgICAgICAgICAgXCJFZ28gdHJhbnNjZW5kZW5jZVwiLFxuICAgICAgICAgICAgXCJCZXlvbmQgcGVyc29uYWwgYm91bmRhcmllc1wiXG4gICAgICAgIF07XG4gICAgICAgIC8vIFNwaXJpdHVhbCBleHBlcmllbmNlcyBjb25jZXB0c1xuICAgICAgICB0aGlzLnNwaXJpdHVhbEV4cGVyaWVuY2VzID0gW1xuICAgICAgICAgICAgXCJQZWFrIGV4cGVyaWVuY2VzXCIsXG4gICAgICAgICAgICBcIk15c3RpY2FsIHN0YXRlc1wiLFxuICAgICAgICAgICAgXCJDb3NtaWMgY29uc2Npb3VzbmVzc1wiLFxuICAgICAgICAgICAgXCJVbml0aXZlIGV4cGVyaWVuY2VzXCIsXG4gICAgICAgICAgICBcIlRyYW5zY2VuZGVudCBhd2FyZW5lc3NcIlxuICAgICAgICBdO1xuICAgICAgICAvLyBDb25zY2lvdXNuZXNzIHN0YXRlcyBjb25jZXB0c1xuICAgICAgICB0aGlzLmNvbnNjaW91c25lc3NTdGF0ZXMgPSBbXG4gICAgICAgICAgICBcIk5vbi1vcmRpbmFyeSBzdGF0ZXNcIixcbiAgICAgICAgICAgIFwiSG9sb3Ryb3BpYyBzdGF0ZXNcIixcbiAgICAgICAgICAgIFwiRXhwYW5kZWQgY29uc2Npb3VzbmVzc1wiLFxuICAgICAgICAgICAgXCJBbHRlcmVkIHN0YXRlc1wiLFxuICAgICAgICAgICAgXCJIaWdoZXIgY29uc2Npb3VzbmVzc1wiXG4gICAgICAgIF07XG4gICAgICAgIC8vIFRyYW5zZm9ybWF0aW9uIGNvbmNlcHRzXG4gICAgICAgIHRoaXMudHJhbnNmb3JtYXRpb24gPSBbXG4gICAgICAgICAgICBcIlNwaXJpdHVhbCBlbWVyZ2VuY2VcIixcbiAgICAgICAgICAgIFwiUHN5Y2hvc3Bpcml0dWFsIGRldmVsb3BtZW50XCIsXG4gICAgICAgICAgICBcIlRyYW5zZm9ybWF0aXZlIHByb2Nlc3NcIixcbiAgICAgICAgICAgIFwiRXZvbHV0aW9uYXJ5IGNvbnNjaW91c25lc3NcIixcbiAgICAgICAgICAgIFwiSW50ZWdyYWwgdHJhbnNmb3JtYXRpb25cIlxuICAgICAgICBdO1xuICAgIH1cbiAgICAvLyBBbmFseXplIGNvbnRlbnQgd2l0aCBUcmFuc3BlcnNvbmFsIGZyYW1ld29ya1xuICAgIGFuYWx5emVDb250ZW50KGNvbnRlbnQsIG1lZGlhVHlwZSkge1xuICAgICAgICAvLyBHZXQgcmFuZG9tIGVsZW1lbnRzIGZyb20gZWFjaCBjb25jZXB0IGFycmF5XG4gICAgICAgIGNvbnN0IGJleW9uZEVnb0VsZW1lbnRzID0gdGhpcy5nZXRSYW5kb21FbGVtZW50cyh0aGlzLmJleW9uZEVnbywgMik7XG4gICAgICAgIGNvbnN0IHNwaXJpdHVhbEV4cGVyaWVuY2VzRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMuc3Bpcml0dWFsRXhwZXJpZW5jZXMsIDIpO1xuICAgICAgICBjb25zdCBjb25zY2lvdXNuZXNzU3RhdGVzRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMuY29uc2Npb3VzbmVzc1N0YXRlcywgMik7XG4gICAgICAgIGNvbnN0IHRyYW5zZm9ybWF0aW9uRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMudHJhbnNmb3JtYXRpb24sIDIpO1xuICAgICAgICAvLyBHZW5lcmF0ZSBzdW1tYXJ5IGJhc2VkIG9uIG1lZGlhIHR5cGVcbiAgICAgICAgbGV0IHN1bW1hcnkgPSBcIlwiO1xuICAgICAgICBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5URVhUKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJGcm9tIGEgVHJhbnNwZXJzb25hbCBwZXJzcGVjdGl2ZSwgdGhpcyB0ZXh0IGV4cGxvcmVzIGRpbWVuc2lvbnMgb2YgZXhwZXJpZW5jZSB0aGF0IHRyYW5zY2VuZCB0aGUgYm91bmRhcmllcyBvZiB0aGUgZWdvLiBJdCByZXZlYWxzIHBvdGVudGlhbCBzdGF0ZXMgb2YgY29uc2Npb3VzbmVzcyB0aGF0IGNvbm5lY3QgdGhlIGluZGl2aWR1YWwgdG8gc3Bpcml0dWFsLCBjb3NtaWMsIG9yIHVuaXZlcnNhbCBkaW1lbnNpb25zIG9mIGV4aXN0ZW5jZS5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLklNQUdFKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJUaGlzIGltYWdlIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGEgVHJhbnNwZXJzb25hbCBmcmFtZXdvcmsgdG8gcmV2ZWFsIHZpc3VhbCByZXByZXNlbnRhdGlvbnMgb2YgZXhwZXJpZW5jZXMgdGhhdCB0cmFuc2NlbmQgb3JkaW5hcnkgZWdvIGJvdW5kYXJpZXMgYW5kIGNvbm5lY3QgdG8gc3Bpcml0dWFsIG9yIGNvc21pYyBkaW1lbnNpb25zLlwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuQVVESU8pIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIkZyb20gYSBUcmFuc3BlcnNvbmFsIHBlcnNwZWN0aXZlLCB0aGlzIGF1ZGlvIHBpZWNlIGV4cHJlc3NlcyBzdGF0ZXMgb2YgY29uc2Npb3VzbmVzcyB0aGF0IHRyYW5zY2VuZCBvcmRpbmFyeSBlZ28gYm91bmRhcmllcyB0aHJvdWdoIGl0cyBzb25pYyBxdWFsaXRpZXMgYW5kIGVtb3Rpb25hbCByZXNvbmFuY2UuXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5GSUxNKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJUaGlzIGZpbG0gY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYSBUcmFuc3BlcnNvbmFsIGZyYW1ld29yayB0byByZXZlYWwgbmFycmF0aXZlIGFuZCB2aXN1YWwgZWxlbWVudHMgb2YgZXhwZXJpZW5jZXMgdGhhdCB0cmFuc2NlbmQgb3JkaW5hcnkgZWdvIGJvdW5kYXJpZXMgYW5kIGNvbm5lY3QgdG8gc3Bpcml0dWFsIG9yIGNvc21pYyBkaW1lbnNpb25zLlwiO1xuICAgICAgICB9XG4gICAgICAgIC8vIFJldHVybiBzdHJ1Y3R1cmVkIGFuYWx5c2lzXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBiZXlvbmRFZ286IGJleW9uZEVnb0VsZW1lbnRzLFxuICAgICAgICAgICAgc3Bpcml0dWFsRXhwZXJpZW5jZXM6IHNwaXJpdHVhbEV4cGVyaWVuY2VzRWxlbWVudHMsXG4gICAgICAgICAgICBjb25zY2lvdXNuZXNzU3RhdGVzOiBjb25zY2lvdXNuZXNzU3RhdGVzRWxlbWVudHMsXG4gICAgICAgICAgICB0cmFuc2Zvcm1hdGlvbjogdHJhbnNmb3JtYXRpb25FbGVtZW50cyxcbiAgICAgICAgICAgIHN1bW1hcnlcbiAgICAgICAgfTtcbiAgICB9XG4gICAgLy8gSGVscGVyIG1ldGhvZCB0byBnZXQgcmFuZG9tIGVsZW1lbnRzIGZyb20gYW4gYXJyYXlcbiAgICBnZXRSYW5kb21FbGVtZW50cyhhcnJheSwgY291bnQpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgIGNvbnN0IGFycmF5Q29weSA9IFsuLi5hcnJheV07XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY291bnQgJiYgYXJyYXlDb3B5Lmxlbmd0aCA+IDA7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgcmFuZG9tSW5kZXggPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBhcnJheUNvcHkubGVuZ3RoKTtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKGFycmF5Q29weVtyYW5kb21JbmRleF0pO1xuICAgICAgICAgICAgYXJyYXlDb3B5LnNwbGljZShyYW5kb21JbmRleCwgMSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBNRURJQV9UWVBFUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG4vLyBDb2duaXRpdmUtQmVoYXZpb3JhbCBUaGVyYXB5IGFuYWx5c2lzIGNsYXNzXG5leHBvcnQgY2xhc3MgQ2J0QW5hbHlzaXMge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICAvLyBDb2duaXRpdmUgZGlzdG9ydGlvbnMgY29uY2VwdHNcbiAgICAgICAgdGhpcy5jb2duaXRpdmVEaXN0b3J0aW9ucyA9IFtcbiAgICAgICAgICAgIFwiQWxsLW9yLW5vdGhpbmcgdGhpbmtpbmdcIixcbiAgICAgICAgICAgIFwiT3ZlcmdlbmVyYWxpemF0aW9uXCIsXG4gICAgICAgICAgICBcIk1lbnRhbCBmaWx0ZXJpbmdcIixcbiAgICAgICAgICAgIFwiQ2F0YXN0cm9waGl6aW5nXCIsXG4gICAgICAgICAgICBcIkVtb3Rpb25hbCByZWFzb25pbmdcIixcbiAgICAgICAgICAgIFwiU2hvdWxkIHN0YXRlbWVudHNcIixcbiAgICAgICAgICAgIFwiUGVyc29uYWxpemF0aW9uXCJcbiAgICAgICAgXTtcbiAgICAgICAgLy8gQmVoYXZpb3JhbCBwYXR0ZXJucyBjb25jZXB0c1xuICAgICAgICB0aGlzLmJlaGF2aW9yYWxQYXR0ZXJucyA9IFtcbiAgICAgICAgICAgIFwiQXZvaWRhbmNlIGJlaGF2aW9yc1wiLFxuICAgICAgICAgICAgXCJTYWZldHkgYmVoYXZpb3JzXCIsXG4gICAgICAgICAgICBcIlJlaW5mb3JjZW1lbnQgcGF0dGVybnNcIixcbiAgICAgICAgICAgIFwiQmVoYXZpb3JhbCBhY3RpdmF0aW9uXCIsXG4gICAgICAgICAgICBcIlN0aW11bHVzLXJlc3BvbnNlIHBhdHRlcm5zXCJcbiAgICAgICAgXTtcbiAgICAgICAgLy8gQ29yZSBiZWxpZWZzIGNvbmNlcHRzXG4gICAgICAgIHRoaXMuY29yZUJlbGllZnMgPSBbXG4gICAgICAgICAgICBcIlNjaGVtYXMgYWJvdXQgc2VsZlwiLFxuICAgICAgICAgICAgXCJTY2hlbWFzIGFib3V0IG90aGVyc1wiLFxuICAgICAgICAgICAgXCJTY2hlbWFzIGFib3V0IHRoZSB3b3JsZFwiLFxuICAgICAgICAgICAgXCJJbnRlcm1lZGlhdGUgYmVsaWVmc1wiLFxuICAgICAgICAgICAgXCJBdXRvbWF0aWMgdGhvdWdodHNcIlxuICAgICAgICBdO1xuICAgICAgICAvLyBBZGFwdGl2ZSBzdHJhdGVnaWVzIGNvbmNlcHRzXG4gICAgICAgIHRoaXMuYWRhcHRpdmVTdHJhdGVnaWVzID0gW1xuICAgICAgICAgICAgXCJDb2duaXRpdmUgcmVzdHJ1Y3R1cmluZ1wiLFxuICAgICAgICAgICAgXCJCZWhhdmlvcmFsIGV4cGVyaW1lbnRzXCIsXG4gICAgICAgICAgICBcIkV4cG9zdXJlIHRlY2huaXF1ZXNcIixcbiAgICAgICAgICAgIFwiUHJvYmxlbS1zb2x2aW5nIHNraWxsc1wiLFxuICAgICAgICAgICAgXCJNaW5kZnVsbmVzcyBpbnRlZ3JhdGlvblwiXG4gICAgICAgIF07XG4gICAgfVxuICAgIC8vIEFuYWx5emUgY29udGVudCB3aXRoIENCVCBmcmFtZXdvcmtcbiAgICBhbmFseXplQ29udGVudChjb250ZW50LCBtZWRpYVR5cGUpIHtcbiAgICAgICAgLy8gR2V0IHJhbmRvbSBlbGVtZW50cyBmcm9tIGVhY2ggY29uY2VwdCBhcnJheVxuICAgICAgICBjb25zdCBjb2duaXRpdmVEaXN0b3J0aW9uc0VsZW1lbnRzID0gdGhpcy5nZXRSYW5kb21FbGVtZW50cyh0aGlzLmNvZ25pdGl2ZURpc3RvcnRpb25zLCAyKTtcbiAgICAgICAgY29uc3QgYmVoYXZpb3JhbFBhdHRlcm5zRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMuYmVoYXZpb3JhbFBhdHRlcm5zLCAyKTtcbiAgICAgICAgY29uc3QgY29yZUJlbGllZnNFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5jb3JlQmVsaWVmcywgMik7XG4gICAgICAgIGNvbnN0IGFkYXB0aXZlU3RyYXRlZ2llc0VsZW1lbnRzID0gdGhpcy5nZXRSYW5kb21FbGVtZW50cyh0aGlzLmFkYXB0aXZlU3RyYXRlZ2llcywgMik7XG4gICAgICAgIC8vIEdlbmVyYXRlIHN1bW1hcnkgYmFzZWQgb24gbWVkaWEgdHlwZVxuICAgICAgICBsZXQgc3VtbWFyeSA9IFwiXCI7XG4gICAgICAgIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLlRFWFQpIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIkZyb20gYSBDb2duaXRpdmUtQmVoYXZpb3JhbCBwZXJzcGVjdGl2ZSwgdGhpcyB0ZXh0IHJldmVhbHMgcGF0dGVybnMgb2YgdGhpbmtpbmcgdGhhdCBtYXkgaW5jbHVkZSBjb2duaXRpdmUgZGlzdG9ydGlvbnMgYW5kIHVuZGVybHlpbmcgY29yZSBiZWxpZWZzLiBJdCBjYW4gYmUgYW5hbHl6ZWQgaW4gdGVybXMgb2YgdGhlIHJlbGF0aW9uc2hpcCBiZXR3ZWVuIHRob3VnaHRzLCBlbW90aW9ucywgYW5kIGJlaGF2aW9ycy5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLklNQUdFKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJUaGlzIGltYWdlIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGEgQ29nbml0aXZlLUJlaGF2aW9yYWwgZnJhbWV3b3JrIHRvIHJldmVhbCB2aXN1YWwgcmVwcmVzZW50YXRpb25zIG9mIGNvZ25pdGl2ZSBwYXR0ZXJucywgZW1vdGlvbmFsIHJlc3BvbnNlcywgYW5kIGJlaGF2aW9yYWwgdGVuZGVuY2llcy5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLkFVRElPKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJGcm9tIGEgQ29nbml0aXZlLUJlaGF2aW9yYWwgcGVyc3BlY3RpdmUsIHRoaXMgYXVkaW8gcGllY2UgZXhwcmVzc2VzIHBhdHRlcm5zIG9mIHRoaW5raW5nLCBlbW90aW9uYWwgcmVzcG9uc2VzLCBhbmQgYmVoYXZpb3JhbCB0ZW5kZW5jaWVzIHRocm91Z2ggaXRzIHNvbmljIHF1YWxpdGllcyBhbmQgZW1vdGlvbmFsIHJlc29uYW5jZS5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLkZJTE0pIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIlRoaXMgZmlsbSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhIENvZ25pdGl2ZS1CZWhhdmlvcmFsIGZyYW1ld29yayB0byByZXZlYWwgbmFycmF0aXZlIGFuZCB2aXN1YWwgZWxlbWVudHMgb2YgY29nbml0aXZlIHBhdHRlcm5zLCBlbW90aW9uYWwgcmVzcG9uc2VzLCBhbmQgYmVoYXZpb3JhbCB0ZW5kZW5jaWVzLlwiO1xuICAgICAgICB9XG4gICAgICAgIC8vIFJldHVybiBzdHJ1Y3R1cmVkIGFuYWx5c2lzXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBjb2duaXRpdmVEaXN0b3J0aW9uczogY29nbml0aXZlRGlzdG9ydGlvbnNFbGVtZW50cyxcbiAgICAgICAgICAgIGJlaGF2aW9yYWxQYXR0ZXJuczogYmVoYXZpb3JhbFBhdHRlcm5zRWxlbWVudHMsXG4gICAgICAgICAgICBjb3JlQmVsaWVmczogY29yZUJlbGllZnNFbGVtZW50cyxcbiAgICAgICAgICAgIGFkYXB0aXZlU3RyYXRlZ2llczogYWRhcHRpdmVTdHJhdGVnaWVzRWxlbWVudHMsXG4gICAgICAgICAgICBzdW1tYXJ5XG4gICAgICAgIH07XG4gICAgfVxuICAgIC8vIEhlbHBlciBtZXRob2QgdG8gZ2V0IHJhbmRvbSBlbGVtZW50cyBmcm9tIGFuIGFycmF5XG4gICAgZ2V0UmFuZG9tRWxlbWVudHMoYXJyYXksIGNvdW50KSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgICBjb25zdCBhcnJheUNvcHkgPSBbLi4uYXJyYXldO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNvdW50ICYmIGFycmF5Q29weS5sZW5ndGggPiAwOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHJhbmRvbUluZGV4ID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogYXJyYXlDb3B5Lmxlbmd0aCk7XG4gICAgICAgICAgICByZXN1bHQucHVzaChhcnJheUNvcHlbcmFuZG9tSW5kZXhdKTtcbiAgICAgICAgICAgIGFycmF5Q29weS5zcGxpY2UocmFuZG9tSW5kZXgsIDEpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgTUVESUFfVFlQRVMgfSBmcm9tICcuLi9jb25zdGFudHMnO1xuLy8gSGVybWVuZXV0aWNzIGFuYWx5c2lzIGNsYXNzXG5leHBvcnQgY2xhc3MgSGVybWVuZXV0aWNzQW5hbHlzaXMge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICAvLyBJbnRlcnByZXRpdmUgY2lyY2xlIGNvbmNlcHRzXG4gICAgICAgIHRoaXMuaW50ZXJwcmV0aXZlQ2lyY2xlID0gW1xuICAgICAgICAgICAgXCJQYXJ0LXdob2xlIHJlbGF0aW9uc2hpcFwiLFxuICAgICAgICAgICAgXCJIZXJtZW5ldXRpYyBjaXJjbGVcIixcbiAgICAgICAgICAgIFwiQ2lyY3VsYXIgdW5kZXJzdGFuZGluZ1wiLFxuICAgICAgICAgICAgXCJJbnRlcnByZXRpdmUgcHJvY2Vzc1wiLFxuICAgICAgICAgICAgXCJEaWFsZWN0aWNhbCBtb3ZlbWVudFwiXG4gICAgICAgIF07XG4gICAgICAgIC8vIEhpc3RvcmljYWwgY29udGV4dCBjb25jZXB0c1xuICAgICAgICB0aGlzLmhpc3RvcmljYWxDb250ZXh0ID0gW1xuICAgICAgICAgICAgXCJIaXN0b3JpY2FsIHNpdHVhdGVkbmVzc1wiLFxuICAgICAgICAgICAgXCJFZmZlY3RpdmUgaGlzdG9yeVwiLFxuICAgICAgICAgICAgXCJUcmFkaXRpb24gYW5kIHByZWp1ZGljZVwiLFxuICAgICAgICAgICAgXCJIaXN0b3JpY2FsIGNvbnNjaW91c25lc3NcIixcbiAgICAgICAgICAgIFwiVGVtcG9yYWwgZGlzdGFuY2VcIlxuICAgICAgICBdO1xuICAgICAgICAvLyBMaW5ndWlzdGljIG1lYW5pbmcgY29uY2VwdHNcbiAgICAgICAgdGhpcy5saW5ndWlzdGljTWVhbmluZyA9IFtcbiAgICAgICAgICAgIFwiTGFuZ3VhZ2UgYXMgbWVkaXVtXCIsXG4gICAgICAgICAgICBcIlRleHR1YWwgaW50ZXJwcmV0YXRpb25cIixcbiAgICAgICAgICAgIFwiU2VtYW50aWMgZGVwdGhcIixcbiAgICAgICAgICAgIFwiUG9seXNlbXlcIixcbiAgICAgICAgICAgIFwiTGluZ3Vpc3RpYyB3b3JsZC1kaXNjbG9zdXJlXCJcbiAgICAgICAgXTtcbiAgICAgICAgLy8gSG9yaXpvbiBmdXNpb24gY29uY2VwdHNcbiAgICAgICAgdGhpcy5ob3Jpem9uRnVzaW9uID0gW1xuICAgICAgICAgICAgXCJGdXNpb24gb2YgaG9yaXpvbnNcIixcbiAgICAgICAgICAgIFwiRGlhbG9naWNhbCB1bmRlcnN0YW5kaW5nXCIsXG4gICAgICAgICAgICBcIkludGVycHJldGl2ZSBvcGVubmVzc1wiLFxuICAgICAgICAgICAgXCJBcHBsaWNhdGlvblwiLFxuICAgICAgICAgICAgXCJQcm9kdWN0aXZlIHVuZGVyc3RhbmRpbmdcIlxuICAgICAgICBdO1xuICAgIH1cbiAgICAvLyBBbmFseXplIGNvbnRlbnQgd2l0aCBIZXJtZW5ldXRpY3MgZnJhbWV3b3JrXG4gICAgYW5hbHl6ZUNvbnRlbnQoY29udGVudCwgbWVkaWFUeXBlKSB7XG4gICAgICAgIC8vIEdldCByYW5kb20gZWxlbWVudHMgZnJvbSBlYWNoIGNvbmNlcHQgYXJyYXlcbiAgICAgICAgY29uc3QgaW50ZXJwcmV0aXZlQ2lyY2xlRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMuaW50ZXJwcmV0aXZlQ2lyY2xlLCAyKTtcbiAgICAgICAgY29uc3QgaGlzdG9yaWNhbENvbnRleHRFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5oaXN0b3JpY2FsQ29udGV4dCwgMik7XG4gICAgICAgIGNvbnN0IGxpbmd1aXN0aWNNZWFuaW5nRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMubGluZ3Vpc3RpY01lYW5pbmcsIDIpO1xuICAgICAgICBjb25zdCBob3Jpem9uRnVzaW9uRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMuaG9yaXpvbkZ1c2lvbiwgMik7XG4gICAgICAgIC8vIEdlbmVyYXRlIHN1bW1hcnkgYmFzZWQgb24gbWVkaWEgdHlwZVxuICAgICAgICBsZXQgc3VtbWFyeSA9IFwiXCI7XG4gICAgICAgIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLlRFWFQpIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIkZyb20gYSBIZXJtZW5ldXRpYyBwZXJzcGVjdGl2ZSwgdGhpcyB0ZXh0IHJldmVhbHMgbGF5ZXJzIG9mIG1lYW5pbmcgdGhhdCBlbWVyZ2UgdGhyb3VnaCB0aGUgaW50ZXJwcmV0aXZlIGNpcmNsZSBvZiBwYXJ0IGFuZCB3aG9sZS4gSXQgY2FuIGJlIHVuZGVyc3Rvb2QgaW4gdGVybXMgb2YgaXRzIGhpc3RvcmljYWwgY29udGV4dCwgbGluZ3Vpc3RpYyBkaW1lbnNpb25zLCBhbmQgdGhlIGZ1c2lvbiBvZiBob3Jpem9ucyBiZXR3ZWVuIHRleHQgYW5kIGludGVycHJldGVyLlwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuSU1BR0UpIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIlRoaXMgaW1hZ2UgY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYSBIZXJtZW5ldXRpYyBmcmFtZXdvcmsgdG8gcmV2ZWFsIHZpc3VhbCBtZWFuaW5ncyB0aGF0IGVtZXJnZSB0aHJvdWdoIHRoZSBpbnRlcnByZXRpdmUgY2lyY2xlIG9mIHBhcnQgYW5kIHdob2xlLCBoaXN0b3JpY2FsIGNvbnRleHQsIGFuZCB0aGUgZnVzaW9uIG9mIGhvcml6b25zIGJldHdlZW4gaW1hZ2UgYW5kIHZpZXdlci5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLkFVRElPKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJGcm9tIGEgSGVybWVuZXV0aWMgcGVyc3BlY3RpdmUsIHRoaXMgYXVkaW8gcGllY2UgZXhwcmVzc2VzIG1lYW5pbmdzIHRoYXQgZW1lcmdlIHRocm91Z2ggdGhlIGludGVycHJldGl2ZSBjaXJjbGUgb2YgcGFydCBhbmQgd2hvbGUsIGhpc3RvcmljYWwgY29udGV4dCwgYW5kIHRoZSBmdXNpb24gb2YgaG9yaXpvbnMgYmV0d2VlbiBzb3VuZCBhbmQgbGlzdGVuZXIuXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5GSUxNKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJUaGlzIGZpbG0gY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYSBIZXJtZW5ldXRpYyBmcmFtZXdvcmsgdG8gcmV2ZWFsIG5hcnJhdGl2ZSBhbmQgdmlzdWFsIG1lYW5pbmdzIHRoYXQgZW1lcmdlIHRocm91Z2ggdGhlIGludGVycHJldGl2ZSBjaXJjbGUgb2YgcGFydCBhbmQgd2hvbGUsIGhpc3RvcmljYWwgY29udGV4dCwgYW5kIHRoZSBmdXNpb24gb2YgaG9yaXpvbnMgYmV0d2VlbiBmaWxtIGFuZCB2aWV3ZXIuXCI7XG4gICAgICAgIH1cbiAgICAgICAgLy8gUmV0dXJuIHN0cnVjdHVyZWQgYW5hbHlzaXNcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGludGVycHJldGl2ZUNpcmNsZTogaW50ZXJwcmV0aXZlQ2lyY2xlRWxlbWVudHMsXG4gICAgICAgICAgICBoaXN0b3JpY2FsQ29udGV4dDogaGlzdG9yaWNhbENvbnRleHRFbGVtZW50cyxcbiAgICAgICAgICAgIGxpbmd1aXN0aWNNZWFuaW5nOiBsaW5ndWlzdGljTWVhbmluZ0VsZW1lbnRzLFxuICAgICAgICAgICAgaG9yaXpvbkZ1c2lvbjogaG9yaXpvbkZ1c2lvbkVsZW1lbnRzLFxuICAgICAgICAgICAgc3VtbWFyeVxuICAgICAgICB9O1xuICAgIH1cbiAgICAvLyBIZWxwZXIgbWV0aG9kIHRvIGdldCByYW5kb20gZWxlbWVudHMgZnJvbSBhbiBhcnJheVxuICAgIGdldFJhbmRvbUVsZW1lbnRzKGFycmF5LCBjb3VudCkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgY29uc3QgYXJyYXlDb3B5ID0gWy4uLmFycmF5XTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb3VudCAmJiBhcnJheUNvcHkubGVuZ3RoID4gMDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCByYW5kb21JbmRleCA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIGFycmF5Q29weS5sZW5ndGgpO1xuICAgICAgICAgICAgcmVzdWx0LnB1c2goYXJyYXlDb3B5W3JhbmRvbUluZGV4XSk7XG4gICAgICAgICAgICBhcnJheUNvcHkuc3BsaWNlKHJhbmRvbUluZGV4LCAxKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbn1cbiIsImltcG9ydCB7IE1FRElBX1RZUEVTIH0gZnJvbSAnLi4vY29uc3RhbnRzJztcbi8vIFN0b2ljaXNtIGFuYWx5c2lzIGNsYXNzXG5leHBvcnQgY2xhc3MgU3RvaWNpc21BbmFseXNpcyB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIC8vIFZpcnR1ZSBldGhpY3MgY29uY2VwdHNcbiAgICAgICAgdGhpcy52aXJ0dWVFdGhpY3MgPSBbXG4gICAgICAgICAgICBcIkNhcmRpbmFsIHZpcnR1ZXNcIixcbiAgICAgICAgICAgIFwiV2lzZG9tIChzb3BoaWEpXCIsXG4gICAgICAgICAgICBcIkNvdXJhZ2UgKGFuZHJlaWEpXCIsXG4gICAgICAgICAgICBcIkp1c3RpY2UgKGRpa2Fpb3N5bmUpXCIsXG4gICAgICAgICAgICBcIlRlbXBlcmFuY2UgKHNvcGhyb3N5bmUpXCJcbiAgICAgICAgXTtcbiAgICAgICAgLy8gRGljaG90b215IG9mIGNvbnRyb2wgY29uY2VwdHNcbiAgICAgICAgdGhpcy5kaWNob3RvbXlPZkNvbnRyb2wgPSBbXG4gICAgICAgICAgICBcIldoYXQgaXMgdXAgdG8gdXNcIixcbiAgICAgICAgICAgIFwiV2hhdCBpcyBub3QgdXAgdG8gdXNcIixcbiAgICAgICAgICAgIFwiRm9jdXNpbmcgb24gd2hhdCB3ZSBjYW4gY29udHJvbFwiLFxuICAgICAgICAgICAgXCJBY2NlcHRpbmcgd2hhdCB3ZSBjYW5ub3QgY29udHJvbFwiLFxuICAgICAgICAgICAgXCJBcHByb3ByaWF0ZSBhY3Rpb25cIlxuICAgICAgICBdO1xuICAgICAgICAvLyBSYXRpb25hbCBuYXR1cmUgY29uY2VwdHNcbiAgICAgICAgdGhpcy5yYXRpb25hbE5hdHVyZSA9IFtcbiAgICAgICAgICAgIFwiTGl2aW5nIGFjY29yZGluZyB0byBuYXR1cmVcIixcbiAgICAgICAgICAgIFwiUmF0aW9uYWwgZmFjdWx0eVwiLFxuICAgICAgICAgICAgXCJMb2dvc1wiLFxuICAgICAgICAgICAgXCJBc3NlbnQgdG8gaW1wcmVzc2lvbnNcIixcbiAgICAgICAgICAgIFwiQ29nbml0aXZlIGRpc3RhbmNpbmdcIlxuICAgICAgICBdO1xuICAgICAgICAvLyBDb3NtaWMgcGVyc3BlY3RpdmUgY29uY2VwdHNcbiAgICAgICAgdGhpcy5jb3NtaWNQZXJzcGVjdGl2ZSA9IFtcbiAgICAgICAgICAgIFwiVmlldyBmcm9tIGFib3ZlXCIsXG4gICAgICAgICAgICBcIkFtb3IgZmF0aVwiLFxuICAgICAgICAgICAgXCJNZW1lbnRvIG1vcmlcIixcbiAgICAgICAgICAgIFwiQ29zbW9wb2xpdGFuaXNtXCIsXG4gICAgICAgICAgICBcIlVuaXZlcnNhbCBuYXR1cmVcIlxuICAgICAgICBdO1xuICAgIH1cbiAgICAvLyBBbmFseXplIGNvbnRlbnQgd2l0aCBTdG9pY2lzbSBmcmFtZXdvcmtcbiAgICBhbmFseXplQ29udGVudChjb250ZW50LCBtZWRpYVR5cGUpIHtcbiAgICAgICAgLy8gR2V0IHJhbmRvbSBlbGVtZW50cyBmcm9tIGVhY2ggY29uY2VwdCBhcnJheVxuICAgICAgICBjb25zdCB2aXJ0dWVFdGhpY3NFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy52aXJ0dWVFdGhpY3MsIDIpO1xuICAgICAgICBjb25zdCBkaWNob3RvbXlPZkNvbnRyb2xFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5kaWNob3RvbXlPZkNvbnRyb2wsIDIpO1xuICAgICAgICBjb25zdCByYXRpb25hbE5hdHVyZUVsZW1lbnRzID0gdGhpcy5nZXRSYW5kb21FbGVtZW50cyh0aGlzLnJhdGlvbmFsTmF0dXJlLCAyKTtcbiAgICAgICAgY29uc3QgY29zbWljUGVyc3BlY3RpdmVFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5jb3NtaWNQZXJzcGVjdGl2ZSwgMik7XG4gICAgICAgIC8vIEdlbmVyYXRlIHN1bW1hcnkgYmFzZWQgb24gbWVkaWEgdHlwZVxuICAgICAgICBsZXQgc3VtbWFyeSA9IFwiXCI7XG4gICAgICAgIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLlRFWFQpIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIkZyb20gYSBTdG9pYyBwZXJzcGVjdGl2ZSwgdGhpcyB0ZXh0IHJldmVhbHMgdGhlbWVzIHJlbGF0ZWQgdG8gdmlydHVlLCB0aGUgZGljaG90b215IG9mIGNvbnRyb2wsIGFuZCBsaXZpbmcgYWNjb3JkaW5nIHRvIHJhdGlvbmFsIG5hdHVyZS4gSXQgY2FuIGJlIHVuZGVyc3Rvb2QgaW4gdGVybXMgb2YgdGhlIFN0b2ljIGVtcGhhc2lzIG9uIGZvY3VzaW5nIG9uIHdoYXQgaXMgd2l0aGluIG91ciBjb250cm9sIGFuZCBtYWludGFpbmluZyBhIGNvc21pYyBwZXJzcGVjdGl2ZS5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLklNQUdFKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJUaGlzIGltYWdlIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGEgU3RvaWMgZnJhbWV3b3JrIHRvIHJldmVhbCB2aXN1YWwgcmVwcmVzZW50YXRpb25zIG9mIHZpcnR1ZSwgdGhlIGRpY2hvdG9teSBvZiBjb250cm9sLCBhbmQgdGhlIGNvc21pYyBwZXJzcGVjdGl2ZSB0aGF0IGNoYXJhY3Rlcml6ZXMgU3RvaWMgcGhpbG9zb3BoeS5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLkFVRElPKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJGcm9tIGEgU3RvaWMgcGVyc3BlY3RpdmUsIHRoaXMgYXVkaW8gcGllY2UgZXhwcmVzc2VzIHRoZW1lcyByZWxhdGVkIHRvIHZpcnR1ZSwgdGhlIGRpY2hvdG9teSBvZiBjb250cm9sLCBhbmQgbGl2aW5nIGFjY29yZGluZyB0byByYXRpb25hbCBuYXR1cmUgdGhyb3VnaCBpdHMgc29uaWMgcXVhbGl0aWVzIGFuZCBlbW90aW9uYWwgcmVzb25hbmNlLlwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuRklMTSkge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiVGhpcyBmaWxtIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGEgU3RvaWMgZnJhbWV3b3JrIHRvIHJldmVhbCBuYXJyYXRpdmUgYW5kIHZpc3VhbCBlbGVtZW50cyBvZiB2aXJ0dWUsIHRoZSBkaWNob3RvbXkgb2YgY29udHJvbCwgYW5kIHRoZSBjb3NtaWMgcGVyc3BlY3RpdmUgdGhhdCBjaGFyYWN0ZXJpemVzIFN0b2ljIHBoaWxvc29waHkuXCI7XG4gICAgICAgIH1cbiAgICAgICAgLy8gUmV0dXJuIHN0cnVjdHVyZWQgYW5hbHlzaXNcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHZpcnR1ZUV0aGljczogdmlydHVlRXRoaWNzRWxlbWVudHMsXG4gICAgICAgICAgICBkaWNob3RvbXlPZkNvbnRyb2w6IGRpY2hvdG9teU9mQ29udHJvbEVsZW1lbnRzLFxuICAgICAgICAgICAgcmF0aW9uYWxOYXR1cmU6IHJhdGlvbmFsTmF0dXJlRWxlbWVudHMsXG4gICAgICAgICAgICBjb3NtaWNQZXJzcGVjdGl2ZTogY29zbWljUGVyc3BlY3RpdmVFbGVtZW50cyxcbiAgICAgICAgICAgIHN1bW1hcnlcbiAgICAgICAgfTtcbiAgICB9XG4gICAgLy8gSGVscGVyIG1ldGhvZCB0byBnZXQgcmFuZG9tIGVsZW1lbnRzIGZyb20gYW4gYXJyYXlcbiAgICBnZXRSYW5kb21FbGVtZW50cyhhcnJheSwgY291bnQpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICAgIGNvbnN0IGFycmF5Q29weSA9IFsuLi5hcnJheV07XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY291bnQgJiYgYXJyYXlDb3B5Lmxlbmd0aCA+IDA7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgcmFuZG9tSW5kZXggPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBhcnJheUNvcHkubGVuZ3RoKTtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKGFycmF5Q29weVtyYW5kb21JbmRleF0pO1xuICAgICAgICAgICAgYXJyYXlDb3B5LnNwbGljZShyYW5kb21JbmRleCwgMSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBNRURJQV9UWVBFUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG4vLyBQc3ljaGlhdHJ5IGFuYWx5c2lzIGNsYXNzXG5leHBvcnQgY2xhc3MgUHN5Y2hpYXRyeUFuYWx5c2lzIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgLy8gRGlhZ25vc3RpYyBjYXRlZ29yaWVzIGNvbmNlcHRzXG4gICAgICAgIHRoaXMuZGlhZ25vc3RpY0NhdGVnb3JpZXMgPSBbXG4gICAgICAgICAgICBcIk1vb2QgZGlzb3JkZXJzXCIsXG4gICAgICAgICAgICBcIkFueGlldHkgZGlzb3JkZXJzXCIsXG4gICAgICAgICAgICBcIlBzeWNob3RpYyBkaXNvcmRlcnNcIixcbiAgICAgICAgICAgIFwiUGVyc29uYWxpdHkgZGlzb3JkZXJzXCIsXG4gICAgICAgICAgICBcIk5ldXJvZGV2ZWxvcG1lbnRhbCBkaXNvcmRlcnNcIixcbiAgICAgICAgICAgIFwiVHJhdW1hLXJlbGF0ZWQgZGlzb3JkZXJzXCJcbiAgICAgICAgXTtcbiAgICAgICAgLy8gTmV1cm9iaW9sb2dpY2FsIGZhY3RvcnMgY29uY2VwdHNcbiAgICAgICAgdGhpcy5uZXVyb2Jpb2xvZ2ljYWxGYWN0b3JzID0gW1xuICAgICAgICAgICAgXCJOZXVyb3RyYW5zbWl0dGVyIHN5c3RlbXNcIixcbiAgICAgICAgICAgIFwiQnJhaW4gc3RydWN0dXJlIGFuZCBmdW5jdGlvblwiLFxuICAgICAgICAgICAgXCJHZW5ldGljIGZhY3RvcnNcIixcbiAgICAgICAgICAgIFwiTmV1cm9wbGFzdGljaXR5XCIsXG4gICAgICAgICAgICBcIk5ldXJvZW5kb2NyaW5lIHByb2Nlc3Nlc1wiXG4gICAgICAgIF07XG4gICAgICAgIC8vIFBzeWNob3NvY2lhbCBmYWN0b3JzIGNvbmNlcHRzXG4gICAgICAgIHRoaXMucHN5Y2hvc29jaWFsRmFjdG9ycyA9IFtcbiAgICAgICAgICAgIFwiRW52aXJvbm1lbnRhbCBzdHJlc3NvcnNcIixcbiAgICAgICAgICAgIFwiU29jaWFsIGRldGVybWluYW50c1wiLFxuICAgICAgICAgICAgXCJEZXZlbG9wbWVudGFsIGZhY3RvcnNcIixcbiAgICAgICAgICAgIFwiSW50ZXJwZXJzb25hbCByZWxhdGlvbnNoaXBzXCIsXG4gICAgICAgICAgICBcIkN1bHR1cmFsIGZhY3RvcnNcIlxuICAgICAgICBdO1xuICAgICAgICAvLyBUcmVhdG1lbnQgYXBwcm9hY2hlcyBjb25jZXB0c1xuICAgICAgICB0aGlzLnRyZWF0bWVudEFwcHJvYWNoZXMgPSBbXG4gICAgICAgICAgICBcIlBzeWNob3BoYXJtYWNvbG9neVwiLFxuICAgICAgICAgICAgXCJQc3ljaG90aGVyYXB5XCIsXG4gICAgICAgICAgICBcIkludGVncmF0ZWQgdHJlYXRtZW50XCIsXG4gICAgICAgICAgICBcIkJpb3BzeWNob3NvY2lhbCBhcHByb2FjaFwiLFxuICAgICAgICAgICAgXCJSZWNvdmVyeSBtb2RlbFwiXG4gICAgICAgIF07XG4gICAgfVxuICAgIC8vIEFuYWx5emUgY29udGVudCB3aXRoIFBzeWNoaWF0cnkgZnJhbWV3b3JrXG4gICAgYW5hbHl6ZUNvbnRlbnQoY29udGVudCwgbWVkaWFUeXBlKSB7XG4gICAgICAgIC8vIEdldCByYW5kb20gZWxlbWVudHMgZnJvbSBlYWNoIGNvbmNlcHQgYXJyYXlcbiAgICAgICAgY29uc3QgZGlhZ25vc3RpY0NhdGVnb3JpZXNFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5kaWFnbm9zdGljQ2F0ZWdvcmllcywgMik7XG4gICAgICAgIGNvbnN0IG5ldXJvYmlvbG9naWNhbEZhY3RvcnNFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5uZXVyb2Jpb2xvZ2ljYWxGYWN0b3JzLCAyKTtcbiAgICAgICAgY29uc3QgcHN5Y2hvc29jaWFsRmFjdG9yc0VsZW1lbnRzID0gdGhpcy5nZXRSYW5kb21FbGVtZW50cyh0aGlzLnBzeWNob3NvY2lhbEZhY3RvcnMsIDIpO1xuICAgICAgICBjb25zdCB0cmVhdG1lbnRBcHByb2FjaGVzRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMudHJlYXRtZW50QXBwcm9hY2hlcywgMik7XG4gICAgICAgIC8vIEdlbmVyYXRlIHN1bW1hcnkgYmFzZWQgb24gbWVkaWEgdHlwZVxuICAgICAgICBsZXQgc3VtbWFyeSA9IFwiXCI7XG4gICAgICAgIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLlRFWFQpIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIkZyb20gYSBQc3ljaGlhdHJpYyBwZXJzcGVjdGl2ZSwgdGhpcyB0ZXh0IHJldmVhbHMgdGhlbWVzIHRoYXQgY2FuIGJlIHVuZGVyc3Rvb2QgaW4gdGVybXMgb2YgZGlhZ25vc3RpYyBjYXRlZ29yaWVzLCBuZXVyb2Jpb2xvZ2ljYWwgZmFjdG9ycywgYW5kIHBzeWNob3NvY2lhbCBkZXRlcm1pbmFudHMuIEl0IGNhbiBiZSBhbmFseXplZCB1c2luZyB0aGUgYmlvcHN5Y2hvc29jaWFsIG1vZGVsIHRoYXQgaW50ZWdyYXRlcyBtdWx0aXBsZSBsZXZlbHMgb2YgZXhwbGFuYXRpb24uXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5JTUFHRSkge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiVGhpcyBpbWFnZSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhIFBzeWNoaWF0cmljIGZyYW1ld29yayB0byByZXZlYWwgdmlzdWFsIHJlcHJlc2VudGF0aW9ucyBvZiBwc3ljaG9sb2dpY2FsIHN0YXRlcywgbmV1cm9iaW9sb2dpY2FsIHByb2Nlc3NlcywgYW5kIHBzeWNob3NvY2lhbCBmYWN0b3JzIHRoYXQgY29udHJpYnV0ZSB0byBtZW50YWwgaGVhbHRoIGFuZCBpbGxuZXNzLlwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuQVVESU8pIHtcbiAgICAgICAgICAgIHN1bW1hcnkgPSBcIkZyb20gYSBQc3ljaGlhdHJpYyBwZXJzcGVjdGl2ZSwgdGhpcyBhdWRpbyBwaWVjZSBleHByZXNzZXMgdGhlbWVzIHJlbGF0ZWQgdG8gcHN5Y2hvbG9naWNhbCBzdGF0ZXMsIG5ldXJvYmlvbG9naWNhbCBwcm9jZXNzZXMsIGFuZCBwc3ljaG9zb2NpYWwgZmFjdG9ycyB0aHJvdWdoIGl0cyBzb25pYyBxdWFsaXRpZXMgYW5kIGVtb3Rpb25hbCByZXNvbmFuY2UuXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5GSUxNKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJUaGlzIGZpbG0gY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYSBQc3ljaGlhdHJpYyBmcmFtZXdvcmsgdG8gcmV2ZWFsIG5hcnJhdGl2ZSBhbmQgdmlzdWFsIGVsZW1lbnRzIG9mIHBzeWNob2xvZ2ljYWwgc3RhdGVzLCBuZXVyb2Jpb2xvZ2ljYWwgcHJvY2Vzc2VzLCBhbmQgcHN5Y2hvc29jaWFsIGZhY3RvcnMgdGhhdCBjb250cmlidXRlIHRvIG1lbnRhbCBoZWFsdGggYW5kIGlsbG5lc3MuXCI7XG4gICAgICAgIH1cbiAgICAgICAgLy8gUmV0dXJuIHN0cnVjdHVyZWQgYW5hbHlzaXNcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGRpYWdub3N0aWNDYXRlZ29yaWVzOiBkaWFnbm9zdGljQ2F0ZWdvcmllc0VsZW1lbnRzLFxuICAgICAgICAgICAgbmV1cm9iaW9sb2dpY2FsRmFjdG9yczogbmV1cm9iaW9sb2dpY2FsRmFjdG9yc0VsZW1lbnRzLFxuICAgICAgICAgICAgcHN5Y2hvc29jaWFsRmFjdG9yczogcHN5Y2hvc29jaWFsRmFjdG9yc0VsZW1lbnRzLFxuICAgICAgICAgICAgdHJlYXRtZW50QXBwcm9hY2hlczogdHJlYXRtZW50QXBwcm9hY2hlc0VsZW1lbnRzLFxuICAgICAgICAgICAgc3VtbWFyeVxuICAgICAgICB9O1xuICAgIH1cbiAgICAvLyBIZWxwZXIgbWV0aG9kIHRvIGdldCByYW5kb20gZWxlbWVudHMgZnJvbSBhbiBhcnJheVxuICAgIGdldFJhbmRvbUVsZW1lbnRzKGFycmF5LCBjb3VudCkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgY29uc3QgYXJyYXlDb3B5ID0gWy4uLmFycmF5XTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb3VudCAmJiBhcnJheUNvcHkubGVuZ3RoID4gMDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCByYW5kb21JbmRleCA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIGFycmF5Q29weS5sZW5ndGgpO1xuICAgICAgICAgICAgcmVzdWx0LnB1c2goYXJyYXlDb3B5W3JhbmRvbUluZGV4XSk7XG4gICAgICAgICAgICBhcnJheUNvcHkuc3BsaWNlKHJhbmRvbUluZGV4LCAxKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbn1cbiIsImltcG9ydCB7IE1FRElBX1RZUEVTIH0gZnJvbSAnLi4vY29uc3RhbnRzJztcbi8vIEVwaWN1cmVhbiBhbmFseXNpcyBjbGFzc1xuZXhwb3J0IGNsYXNzIEVwaWN1cmVhbkFuYWx5c2lzIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgLy8gUGxlYXN1cmUgY29uY2VwdHNcbiAgICAgICAgdGhpcy5wbGVhc3VyZSA9IFtcbiAgICAgICAgICAgIFwiQWJzZW5jZSBvZiBwYWluIChhcG9uaWEpXCIsXG4gICAgICAgICAgICBcIlRyYW5xdWlsaXR5IChhdGFyYXhpYSlcIixcbiAgICAgICAgICAgIFwiU3RhdGljIHBsZWFzdXJlc1wiLFxuICAgICAgICAgICAgXCJLaW5ldGljIHBsZWFzdXJlc1wiLFxuICAgICAgICAgICAgXCJQbGVhc3VyZSBhcyB0aGUgaGlnaGVzdCBnb29kXCJcbiAgICAgICAgXTtcbiAgICAgICAgLy8gQXRhcmF4aWEgY29uY2VwdHNcbiAgICAgICAgdGhpcy5hdGFyYXhpYSA9IFtcbiAgICAgICAgICAgIFwiRnJlZWRvbSBmcm9tIGRpc3R1cmJhbmNlXCIsXG4gICAgICAgICAgICBcIk1lbnRhbCB0cmFucXVpbGl0eVwiLFxuICAgICAgICAgICAgXCJQZWFjZSBvZiBtaW5kXCIsXG4gICAgICAgICAgICBcIkFic2VuY2Ugb2YgZmVhclwiLFxuICAgICAgICAgICAgXCJFcXVhbmltaXR5XCJcbiAgICAgICAgXTtcbiAgICAgICAgLy8gTmF0dXJhbCBkZXNpcmVzIGNvbmNlcHRzXG4gICAgICAgIHRoaXMubmF0dXJhbERlc2lyZXMgPSBbXG4gICAgICAgICAgICBcIk5hdHVyYWwgYW5kIG5lY2Vzc2FyeSBkZXNpcmVzXCIsXG4gICAgICAgICAgICBcIk5hdHVyYWwgYnV0IHVubmVjZXNzYXJ5IGRlc2lyZXNcIixcbiAgICAgICAgICAgIFwiVmFpbiBhbmQgZW1wdHkgZGVzaXJlc1wiLFxuICAgICAgICAgICAgXCJMaW1pdGluZyBkZXNpcmVzXCIsXG4gICAgICAgICAgICBcIlNpbXBsZSBsaXZpbmdcIlxuICAgICAgICBdO1xuICAgICAgICAvLyBGcmllbmRzaGlwIGNvbmNlcHRzXG4gICAgICAgIHRoaXMuZnJpZW5kc2hpcCA9IFtcbiAgICAgICAgICAgIFwiRnJpZW5kc2hpcCBhcyBlc3NlbnRpYWwgZ29vZFwiLFxuICAgICAgICAgICAgXCJDb21tdW5pdHkgb2YgbGlrZS1taW5kZWQgaW5kaXZpZHVhbHNcIixcbiAgICAgICAgICAgIFwiUGhpbG9zb3BoaWNhbCBmcmllbmRzaGlwXCIsXG4gICAgICAgICAgICBcIlNlY3VyaXR5IHRocm91Z2ggc29jaWFsIGJvbmRzXCIsXG4gICAgICAgICAgICBcIlNoYXJlZCBwbGVhc3VyZSBpbiBjb21wYW55XCJcbiAgICAgICAgXTtcbiAgICB9XG4gICAgLy8gQW5hbHl6ZSBjb250ZW50IHdpdGggRXBpY3VyZWFuIGZyYW1ld29ya1xuICAgIGFuYWx5emVDb250ZW50KGNvbnRlbnQsIG1lZGlhVHlwZSkge1xuICAgICAgICAvLyBHZXQgcmFuZG9tIGVsZW1lbnRzIGZyb20gZWFjaCBjb25jZXB0IGFycmF5XG4gICAgICAgIGNvbnN0IHBsZWFzdXJlRWxlbWVudHMgPSB0aGlzLmdldFJhbmRvbUVsZW1lbnRzKHRoaXMucGxlYXN1cmUsIDIpO1xuICAgICAgICBjb25zdCBhdGFyYXhpYUVsZW1lbnRzID0gdGhpcy5nZXRSYW5kb21FbGVtZW50cyh0aGlzLmF0YXJheGlhLCAyKTtcbiAgICAgICAgY29uc3QgbmF0dXJhbERlc2lyZXNFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5uYXR1cmFsRGVzaXJlcywgMik7XG4gICAgICAgIGNvbnN0IGZyaWVuZHNoaXBFbGVtZW50cyA9IHRoaXMuZ2V0UmFuZG9tRWxlbWVudHModGhpcy5mcmllbmRzaGlwLCAyKTtcbiAgICAgICAgLy8gR2VuZXJhdGUgc3VtbWFyeSBiYXNlZCBvbiBtZWRpYSB0eXBlXG4gICAgICAgIGxldCBzdW1tYXJ5ID0gXCJcIjtcbiAgICAgICAgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuVEVYVCkge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiRnJvbSBhbiBFcGljdXJlYW4gcGVyc3BlY3RpdmUsIHRoaXMgdGV4dCBleHBsb3JlcyB0aGVtZXMgcmVsYXRlZCB0byB0aGUgcHVyc3VpdCBvZiBwbGVhc3VyZSB1bmRlcnN0b29kIGFzIGZyZWVkb20gZnJvbSBwYWluIGFuZCBtZW50YWwgZGlzdHVyYmFuY2UuIEl0IHJldmVhbHMgaW5zaWdodHMgYWJvdXQgbmF0dXJhbCBkZXNpcmVzLCB0aGUgdmFsdWUgb2YgZnJpZW5kc2hpcCwgYW5kIHRoZSBwYXRoIHRvIHRyYW5xdWlsaXR5IChhdGFyYXhpYSkuXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5JTUFHRSkge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiVGhpcyBpbWFnZSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhbiBFcGljdXJlYW4gbGVucyB0byByZXZlYWwgdmlzdWFsIHJlcHJlc2VudGF0aW9ucyBvZiBwbGVhc3VyZSwgdHJhbnF1aWxpdHksIG5hdHVyYWwgZGVzaXJlcywgYW5kIHRoZSBpbXBvcnRhbmNlIG9mIGZyaWVuZHNoaXAgYW5kIGNvbW11bml0eS5cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtZWRpYVR5cGUgPT09IE1FRElBX1RZUEVTLkFVRElPKSB7XG4gICAgICAgICAgICBzdW1tYXJ5ID0gXCJGcm9tIGFuIEVwaWN1cmVhbiBwZXJzcGVjdGl2ZSwgdGhpcyBhdWRpbyBwaWVjZSBleHByZXNzZXMgdGhlbWVzIHJlbGF0ZWQgdG8gcGxlYXN1cmUsIHRyYW5xdWlsaXR5LCBhbmQgdGhlIHNhdGlzZmFjdGlvbiBvZiBuYXR1cmFsIGRlc2lyZXMgdGhyb3VnaCBpdHMgc29uaWMgcXVhbGl0aWVzIGFuZCBlbW90aW9uYWwgcmVzb25hbmNlLlwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1lZGlhVHlwZSA9PT0gTUVESUFfVFlQRVMuRklMTSkge1xuICAgICAgICAgICAgc3VtbWFyeSA9IFwiVGhpcyBmaWxtIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGFuIEVwaWN1cmVhbiBmcmFtZXdvcmsgdG8gcmV2ZWFsIG5hcnJhdGl2ZSBlbGVtZW50cyBvZiBwbGVhc3VyZSwgdHJhbnF1aWxpdHksIG5hdHVyYWwgZGVzaXJlcywgYW5kIHRoZSBpbXBvcnRhbmNlIG9mIGZyaWVuZHNoaXAgYW5kIGNvbW11bml0eS5cIjtcbiAgICAgICAgfVxuICAgICAgICAvLyBSZXR1cm4gc3RydWN0dXJlZCBhbmFseXNpc1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcGxlYXN1cmU6IHBsZWFzdXJlRWxlbWVudHMsXG4gICAgICAgICAgICBhdGFyYXhpYTogYXRhcmF4aWFFbGVtZW50cyxcbiAgICAgICAgICAgIG5hdHVyYWxEZXNpcmVzOiBuYXR1cmFsRGVzaXJlc0VsZW1lbnRzLFxuICAgICAgICAgICAgZnJpZW5kc2hpcDogZnJpZW5kc2hpcEVsZW1lbnRzLFxuICAgICAgICAgICAgc3VtbWFyeVxuICAgICAgICB9O1xuICAgIH1cbiAgICAvLyBIZWxwZXIgbWV0aG9kIHRvIGdldCByYW5kb20gZWxlbWVudHMgZnJvbSBhbiBhcnJheVxuICAgIGdldFJhbmRvbUVsZW1lbnRzKGFycmF5LCBjb3VudCkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgICAgY29uc3QgYXJyYXlDb3B5ID0gWy4uLmFycmF5XTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb3VudCAmJiBhcnJheUNvcHkubGVuZ3RoID4gMDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCByYW5kb21JbmRleCA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIGFycmF5Q29weS5sZW5ndGgpO1xuICAgICAgICAgICAgcmVzdWx0LnB1c2goYXJyYXlDb3B5W3JhbmRvbUluZGV4XSk7XG4gICAgICAgICAgICBhcnJheUNvcHkuc3BsaWNlKHJhbmRvbUluZGV4LCAxKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbn1cbiIsImltcG9ydCB7IERlbGV1emlhbkFuYWx5c2lzIH0gZnJvbSAnLi9kZWxldXppYW4nO1xuaW1wb3J0IHsgSXJpZ2FyYXlpYW5BbmFseXNpcyB9IGZyb20gJy4vaXJpZ2FyYXlpYW4nO1xuaW1wb3J0IHsgVGFja3RpY2FsQW5hbHlzaXMgfSBmcm9tICcuL3RhY2t0aWNhbCc7XG5pbXBvcnQgeyBGcmV1ZGlhbkFuYWx5c2lzIH0gZnJvbSAnLi9mcmV1ZGlhbic7XG5pbXBvcnQgeyBMYWNhbmlhbkFuYWx5c2lzIH0gZnJvbSAnLi9sYWNhbmlhbic7XG5pbXBvcnQgeyBKdW5naWFuQW5hbHlzaXMgfSBmcm9tICcuL2p1bmdpYW4nO1xuaW1wb3J0IHsgQXR0YWNobWVudEFuYWx5c2lzIH0gZnJvbSAnLi9hdHRhY2htZW50JztcbmltcG9ydCB7IFBvc2l0aXZlQW5hbHlzaXMgfSBmcm9tICcuL3Bvc2l0aXZlJztcbmltcG9ydCB7IE5hcnJhdGl2ZUFuYWx5c2lzIH0gZnJvbSAnLi9uYXJyYXRpdmUnO1xuaW1wb3J0IHsgUGhlbm9tZW5vbG9neUFuYWx5c2lzIH0gZnJvbSAnLi9waGVub21lbm9sb2d5JztcbmltcG9ydCB7IEV4aXN0ZW50aWFsQW5hbHlzaXMgfSBmcm9tICcuL2V4aXN0ZW50aWFsJztcbmltcG9ydCB7IEZlbWluaXN0QW5hbHlzaXMgfSBmcm9tICcuL2ZlbWluaXN0JztcbmltcG9ydCB7IENyaXRpY2FsQW5hbHlzaXMgfSBmcm9tICcuL2NyaXRpY2FsJztcbmltcG9ydCB7IFBvc3RodW1hbmlzbUFuYWx5c2lzIH0gZnJvbSAnLi9wb3N0aHVtYW5pc20nO1xuaW1wb3J0IHsgQnVkZGhpc3RBbmFseXNpcyB9IGZyb20gJy4vYnVkZGhpc3QnO1xuaW1wb3J0IHsgTmlldHpzY2hlYW5BbmFseXNpcyB9IGZyb20gJy4vbmlldHpzY2hlYW4nO1xuaW1wb3J0IHsgR2VzdGFsdEFuYWx5c2lzIH0gZnJvbSAnLi9nZXN0YWx0JztcbmltcG9ydCB7IFRyYW5zcGVyc29uYWxBbmFseXNpcyB9IGZyb20gJy4vdHJhbnNwZXJzb25hbCc7XG5pbXBvcnQgeyBDYnRBbmFseXNpcyB9IGZyb20gJy4vY2J0JztcbmltcG9ydCB7IEhlcm1lbmV1dGljc0FuYWx5c2lzIH0gZnJvbSAnLi9oZXJtZW5ldXRpY3MnO1xuaW1wb3J0IHsgU3RvaWNpc21BbmFseXNpcyB9IGZyb20gJy4vc3RvaWNpc20nO1xuaW1wb3J0IHsgUHN5Y2hpYXRyeUFuYWx5c2lzIH0gZnJvbSAnLi9wc3ljaGlhdHJ5JztcbmltcG9ydCB7IEVwaWN1cmVhbkFuYWx5c2lzIH0gZnJvbSAnLi9lcGljdXJlYW4nO1xuLy8gRXhwb3J0IGNsYXNzZXNcbmV4cG9ydCB7IERlbGV1emlhbkFuYWx5c2lzLCBJcmlnYXJheWlhbkFuYWx5c2lzLCBUYWNrdGljYWxBbmFseXNpcywgRnJldWRpYW5BbmFseXNpcywgTGFjYW5pYW5BbmFseXNpcywgSnVuZ2lhbkFuYWx5c2lzLCBBdHRhY2htZW50QW5hbHlzaXMsIFBvc2l0aXZlQW5hbHlzaXMsIE5hcnJhdGl2ZUFuYWx5c2lzLCBQaGVub21lbm9sb2d5QW5hbHlzaXMsIEV4aXN0ZW50aWFsQW5hbHlzaXMsIEZlbWluaXN0QW5hbHlzaXMsIENyaXRpY2FsQW5hbHlzaXMsIFBvc3RodW1hbmlzbUFuYWx5c2lzLCBCdWRkaGlzdEFuYWx5c2lzLCBOaWV0enNjaGVhbkFuYWx5c2lzLCBHZXN0YWx0QW5hbHlzaXMsIFRyYW5zcGVyc29uYWxBbmFseXNpcywgQ2J0QW5hbHlzaXMsIEhlcm1lbmV1dGljc0FuYWx5c2lzLCBTdG9pY2lzbUFuYWx5c2lzLCBQc3ljaGlhdHJ5QW5hbHlzaXMsIEVwaWN1cmVhbkFuYWx5c2lzIH07XG4vLyBGcmFtZXdvcmsgZmFjdG9yeSB0byBnZXQgdGhlIGFwcHJvcHJpYXRlIGFuYWx5c2lzIGNsYXNzXG5leHBvcnQgZnVuY3Rpb24gZ2V0RnJhbWV3b3JrQW5hbHlzaXMoZnJhbWV3b3JrSWQpIHtcbiAgICBzd2l0Y2ggKGZyYW1ld29ya0lkKSB7XG4gICAgICAgIGNhc2UgJ2RlbGV1emlhbic6XG4gICAgICAgICAgICByZXR1cm4gbmV3IERlbGV1emlhbkFuYWx5c2lzKCk7XG4gICAgICAgIGNhc2UgJ2lyaWdhcmF5aWFuJzpcbiAgICAgICAgICAgIHJldHVybiBuZXcgSXJpZ2FyYXlpYW5BbmFseXNpcygpO1xuICAgICAgICBjYXNlICd0YWNrdGljYWwnOlxuICAgICAgICAgICAgcmV0dXJuIG5ldyBUYWNrdGljYWxBbmFseXNpcygpO1xuICAgICAgICBjYXNlICdmcmV1ZGlhbic6XG4gICAgICAgICAgICByZXR1cm4gbmV3IEZyZXVkaWFuQW5hbHlzaXMoKTtcbiAgICAgICAgY2FzZSAnbGFjYW5pYW4nOlxuICAgICAgICAgICAgcmV0dXJuIG5ldyBMYWNhbmlhbkFuYWx5c2lzKCk7XG4gICAgICAgIGNhc2UgJ2p1bmdpYW4nOlxuICAgICAgICAgICAgcmV0dXJuIG5ldyBKdW5naWFuQW5hbHlzaXMoKTtcbiAgICAgICAgY2FzZSAnYXR0YWNobWVudCc6XG4gICAgICAgICAgICByZXR1cm4gbmV3IEF0dGFjaG1lbnRBbmFseXNpcygpO1xuICAgICAgICBjYXNlICdwb3NpdGl2ZSc6XG4gICAgICAgICAgICByZXR1cm4gbmV3IFBvc2l0aXZlQW5hbHlzaXMoKTtcbiAgICAgICAgY2FzZSAnbmFycmF0aXZlJzpcbiAgICAgICAgICAgIHJldHVybiBuZXcgTmFycmF0aXZlQW5hbHlzaXMoKTtcbiAgICAgICAgY2FzZSAncGhlbm9tZW5vbG9neSc6XG4gICAgICAgICAgICByZXR1cm4gbmV3IFBoZW5vbWVub2xvZ3lBbmFseXNpcygpO1xuICAgICAgICBjYXNlICdleGlzdGVudGlhbCc6XG4gICAgICAgICAgICByZXR1cm4gbmV3IEV4aXN0ZW50aWFsQW5hbHlzaXMoKTtcbiAgICAgICAgY2FzZSAnZmVtaW5pc3QnOlxuICAgICAgICAgICAgcmV0dXJuIG5ldyBGZW1pbmlzdEFuYWx5c2lzKCk7XG4gICAgICAgIGNhc2UgJ2NyaXRpY2FsJzpcbiAgICAgICAgICAgIHJldHVybiBuZXcgQ3JpdGljYWxBbmFseXNpcygpO1xuICAgICAgICBjYXNlICdwb3N0aHVtYW5pc20nOlxuICAgICAgICAgICAgcmV0dXJuIG5ldyBQb3N0aHVtYW5pc21BbmFseXNpcygpO1xuICAgICAgICBjYXNlICdidWRkaGlzdCc6XG4gICAgICAgICAgICByZXR1cm4gbmV3IEJ1ZGRoaXN0QW5hbHlzaXMoKTtcbiAgICAgICAgY2FzZSAnbmlldHpzY2hlYW4nOlxuICAgICAgICAgICAgcmV0dXJuIG5ldyBOaWV0enNjaGVhbkFuYWx5c2lzKCk7XG4gICAgICAgIGNhc2UgJ2dlc3RhbHQnOlxuICAgICAgICAgICAgcmV0dXJuIG5ldyBHZXN0YWx0QW5hbHlzaXMoKTtcbiAgICAgICAgY2FzZSAndHJhbnNwZXJzb25hbCc6XG4gICAgICAgICAgICByZXR1cm4gbmV3IFRyYW5zcGVyc29uYWxBbmFseXNpcygpO1xuICAgICAgICBjYXNlICdjYnQnOlxuICAgICAgICAgICAgcmV0dXJuIG5ldyBDYnRBbmFseXNpcygpO1xuICAgICAgICBjYXNlICdoZXJtZW5ldXRpY3MnOlxuICAgICAgICAgICAgcmV0dXJuIG5ldyBIZXJtZW5ldXRpY3NBbmFseXNpcygpO1xuICAgICAgICBjYXNlICdzdG9pY2lzbSc6XG4gICAgICAgICAgICByZXR1cm4gbmV3IFN0b2ljaXNtQW5hbHlzaXMoKTtcbiAgICAgICAgY2FzZSAncHN5Y2hpYXRyeSc6XG4gICAgICAgICAgICByZXR1cm4gbmV3IFBzeWNoaWF0cnlBbmFseXNpcygpO1xuICAgICAgICBjYXNlICdlcGljdXJlYW4nOlxuICAgICAgICAgICAgcmV0dXJuIG5ldyBFcGljdXJlYW5BbmFseXNpcygpO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBGcmFtZXdvcmsgbm90IGltcGxlbWVudGVkOiAke2ZyYW1ld29ya0lkfWApO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IE1FRElBX1RZUEVTIH0gZnJvbSAnLi4vY29uc3RhbnRzJztcbmV4cG9ydCBjb25zdCBkZWxldXppYW5BbmFseXNlcyA9IHtcbiAgICBbTUVESUFfVFlQRVMuVEVYVF06IFwiRnJvbSBhIERlbGV1emlhbiBwZXJzcGVjdGl2ZSwgdGhpcyB0ZXh0IG9wZXJhdGVzIGFzIGFuIGFzc2VtYmxhZ2Ugb2YgaGV0ZXJvZ2VuZW91cyBlbGVtZW50cywgY3JlYXRpbmcgcmhpem9tYXRpYyBjb25uZWN0aW9ucyByYXRoZXIgdGhhbiBoaWVyYXJjaGljYWwgc3RydWN0dXJlcy4gVGhlIGNvbnRlbnQgcmV2ZWFscyBsaW5lcyBvZiBmbGlnaHQgdGhhdCBkZXRlcnJpdG9yaWFsaXplIGZpeGVkIG1lYW5pbmdzIGFuZCBpZGVudGl0aWVzLCBvcGVuaW5nIHVwIG5ldyBwb3NzaWJpbGl0aWVzIGZvciBiZWNvbWluZy4gVGhlIHdyaXRpbmcgZGVtb25zdHJhdGVzIHRoZSBwcm9kdWN0aXZlIG5hdHVyZSBvZiBkZXNpcmUgYXMgYSBmb3JjZSBvZiBjcmVhdGlvbiByYXRoZXIgdGhhbiBsYWNrLiBNdWx0aXBsZSB2b2ljZXMgYW5kIHBlcnNwZWN0aXZlcyBzdWdnZXN0IGEgbm9tYWRpYyBzdWJqZWN0aXZpdHkgdGhhdCByZXNpc3RzIGZpeGVkIGlkZW50aXR5IHBvc2l0aW9ucy4gVGhlIHRleHQgZnVuY3Rpb25zIGFzIGEgYm9keSB3aXRob3V0IG9yZ2FucywgYSBzdXJmYWNlIG9mIGludGVuc2l0aWVzIHJhdGhlciB0aGFuIG9yZ2FuaXplZCBtZWFuaW5nLiBSZWN1cnJpbmcgbW90aWZzIG9wZXJhdGUgYXMgcmVmcmFpbnMgdGhhdCB0ZW1wb3JhcmlseSBvcmdhbml6ZSB0ZXJyaXRvcmllcyBvZiBtZWFuaW5nIGJlZm9yZSBkaXNzb2x2aW5nIGludG8gbmV3IGNvbmZpZ3VyYXRpb25zLlwiLFxuICAgIFtNRURJQV9UWVBFUy5JTUFHRV06IFwiVGhpcyBpbWFnZSBjYW4gYmUgYW5hbHl6ZWQgYXMgYSBEZWxldXppYW4gYXNzZW1ibGFnZSBvZiB2aXN1YWwgZWxlbWVudHMgdGhhdCBjcmVhdGUgcmhpem9tYXRpYyBjb25uZWN0aW9ucyByYXRoZXIgdGhhbiBoaWVyYXJjaGljYWwgc3RydWN0dXJlcy4gVmlzdWFsIGNvbXBvbmVudHMgZnVuY3Rpb24gYXMgaW50ZW5zaXRpZXMgb24gYSBwbGFuZSBvZiBjb25zaXN0ZW5jeSwgY3JlYXRpbmcgYWZmZWN0cyB0aGF0IG9wZXJhdGUgYmVsb3cgdGhlIGxldmVsIG9mIHJlcHJlc2VudGF0aW9uLiBUaGUgY29tcG9zaXRpb24gc3VnZ2VzdHMgbGluZXMgb2YgZmxpZ2h0IHRoYXQgZGV0ZXJyaXRvcmlhbGl6ZSBmaXhlZCBtZWFuaW5ncyBhbmQgb3BlbiB1cCBuZXcgcG9zc2liaWxpdGllcyBmb3IgYmVjb21pbmcuIENvbG9yIHJlbGF0aW9uc2hpcHMgYW5kIHNwYXRpYWwgYXJyYW5nZW1lbnRzIGNhbiBiZSB1bmRlcnN0b29kIGFzIGV4cHJlc3Npb25zIG9mIGRlc2lyZSBhcyBhIHByb2R1Y3RpdmUgZm9yY2UgcmF0aGVyIHRoYW4gbGFjay4gVGhlIGltYWdlIHBvdGVudGlhbGx5IGZ1bmN0aW9ucyBhcyBhIGJvZHkgd2l0aG91dCBvcmdhbnMsIGEgc3VyZmFjZSBvZiBpbnRlbnNpdGllcyByYXRoZXIgdGhhbiBvcmdhbml6ZWQgbWVhbmluZy4gVGhlIHZpZXdlcidzIGVuY291bnRlciB3aXRoIHRoZSBpbWFnZSBjcmVhdGVzIGEgYmVjb21pbmctb3RoZXIgdGhhdCB0cmFuc2Zvcm1zIGJvdGggdmlld2VyIGFuZCBpbWFnZS5cIixcbiAgICBbTUVESUFfVFlQRVMuQVVESU9dOiBcIkZyb20gYSBEZWxldXppYW4gcGVyc3BlY3RpdmUsIHRoaXMgYXVkaW8gcGllY2UgZnVuY3Rpb25zIGFzIGFuIGFzc2VtYmxhZ2Ugb2Ygc29uaWMgZWxlbWVudHMgdGhhdCBjcmVhdGUgcmhpem9tYXRpYyBjb25uZWN0aW9ucyByYXRoZXIgdGhhbiBoaWVyYXJjaGljYWwgc3RydWN0dXJlcy4gU291bmQgb3BlcmF0ZXMgYXMgaW50ZW5zaXRpZXMgb24gYSBwbGFuZSBvZiBjb25zaXN0ZW5jeSwgY3JlYXRpbmcgYWZmZWN0cyB0aGF0IHdvcmsgYmVsb3cgdGhlIGxldmVsIG9mIHJlcHJlc2VudGF0aW9uLiBSaHl0aG1pYyBhbmQgdG9uYWwgcGF0dGVybnMgc3VnZ2VzdCBsaW5lcyBvZiBmbGlnaHQgdGhhdCBkZXRlcnJpdG9yaWFsaXplIGZpeGVkIG1lYW5pbmdzIGFuZCBvcGVuIHVwIG5ldyBwb3NzaWJpbGl0aWVzIGZvciBiZWNvbWluZy4gVGhlIHN0cnVjdHVyZSBvZiB0aGUgcGllY2UgZGVtb25zdHJhdGVzIHRoZSBwcm9kdWN0aXZlIG5hdHVyZSBvZiBkZXNpcmUgYXMgYSBmb3JjZSBvZiBjcmVhdGlvbiByYXRoZXIgdGhhbiBsYWNrLiBSZWN1cnJpbmcgbW90aWZzIG9wZXJhdGUgYXMgcmVmcmFpbnMgdGhhdCB0ZW1wb3JhcmlseSBvcmdhbml6ZSB0ZXJyaXRvcmllcyBvZiBtZWFuaW5nIGJlZm9yZSBkaXNzb2x2aW5nIGludG8gbmV3IGNvbmZpZ3VyYXRpb25zLiBUaGUgbGlzdGVuZXIncyBlbmNvdW50ZXIgd2l0aCB0aGUgc291bmQgY3JlYXRlcyBhIGJlY29taW5nLW90aGVyIHRoYXQgdHJhbnNmb3JtcyBib3RoIGxpc3RlbmVyIGFuZCBzb3VuZC5cIixcbiAgICBbTUVESUFfVFlQRVMuRklMTV06IFwiVGhpcyBmaWxtIGNhbiBiZSBhbmFseXplZCBhcyBhIERlbGV1emlhbiBhc3NlbWJsYWdlIG9mIHZpc3VhbCwgbmFycmF0aXZlLCBhbmQgc29uaWMgZWxlbWVudHMgdGhhdCBjcmVhdGUgcmhpem9tYXRpYyBjb25uZWN0aW9ucyByYXRoZXIgdGhhbiBoaWVyYXJjaGljYWwgc3RydWN0dXJlcy4gVGhlIGZpbG0gb3BlcmF0ZXMgdGhyb3VnaCBtb3ZlbWVudC1pbWFnZXMgYW5kIHRpbWUtaW1hZ2VzIHRoYXQgZGlyZWN0bHkgcHJlc2VudCBkdXJhdGlvbiByYXRoZXIgdGhhbiByZXByZXNlbnRpbmcgaXQuIFZpc3VhbCBjb21wb25lbnRzIGZ1bmN0aW9uIGFzIGludGVuc2l0aWVzIG9uIGEgcGxhbmUgb2YgY29uc2lzdGVuY3ksIGNyZWF0aW5nIGFmZmVjdHMgdGhhdCBvcGVyYXRlIGJlbG93IHRoZSBsZXZlbCBvZiByZXByZXNlbnRhdGlvbi4gVGhlIG5hcnJhdGl2ZSBzdWdnZXN0cyBsaW5lcyBvZiBmbGlnaHQgdGhhdCBkZXRlcnJpdG9yaWFsaXplIGZpeGVkIG1lYW5pbmdzIGFuZCBpZGVudGl0aWVzLCBvcGVuaW5nIHVwIG5ldyBwb3NzaWJpbGl0aWVzIGZvciBiZWNvbWluZy4gQ2hhcmFjdGVyIHJlbGF0aW9uc2hpcHMgZGVtb25zdHJhdGUgbm9tYWRpYyBzdWJqZWN0aXZpdHkgdGhhdCByZXNpc3RzIGZpeGVkIGlkZW50aXR5IHBvc2l0aW9ucy4gRWRpdGluZyB0ZWNobmlxdWVzIGFuZCB2aXN1YWwgdHJhbnNpdGlvbnMgY2FuIGJlIHVuZGVyc3Rvb2QgYXMgZXhwcmVzc2lvbnMgb2YgZGVzaXJlIGFzIGEgcHJvZHVjdGl2ZSBmb3JjZSByYXRoZXIgdGhhbiBsYWNrLlwiXG59O1xuIiwiaW1wb3J0IHsgTUVESUFfVFlQRVMgfSBmcm9tICcuLi9jb25zdGFudHMnO1xuZXhwb3J0IGNvbnN0IGlyaWdhcmF5aWFuQW5hbHlzZXMgPSB7XG4gICAgW01FRElBX1RZUEVTLlRFWFRdOiBcIkFuIElyaWdhcmF5aWFuIHJlYWRpbmcgb2YgdGhpcyB0ZXh0IHJldmVhbHMgaG93IGl0IGVuZ2FnZXMgd2l0aCBvciBjaGFsbGVuZ2VzIHBoYWxsb2dvY2VudHJpYyBkaXNjb3Vyc2UuIFRoZSB3cml0aW5nIHBvdGVudGlhbGx5IGRlbW9uc3RyYXRlcyBhIGZlbWluaW5lIHN5bnRheCB0aGF0IHByaXZpbGVnZXMgbXVsdGlwbGljaXR5LCBmbHVpZGl0eSwgYW5kIHByb3hpbWl0eSBvdmVyIGxpbmVhciBsb2dpYyBhbmQgZml4ZWQgbWVhbmluZ3MuIFRoZXJlIGFyZSBtb21lbnRzIHdoZXJlIHRoZSB0ZXh0IGFwcHJvYWNoZXMgZmVtaW5pbmUgam91aXNzYW5jZeKAlGEgcGxlYXN1cmUgYmV5b25kIHRoZSBwaGFsbGljIGVjb25vbXkgb2YgZGVzaXJlLiBUaGUgY29udGVudCBleHBsb3JlcyBzZXh1YWwgZGlmZmVyZW5jZSBub3QgYXMgYmluYXJ5IG9wcG9zaXRpb24gYnV0IGFzIHJhZGljYWwgYWx0ZXJpdHkuIFRoZSB3cml0aW5nIHN0eWxlIG1heSByZWZsZWN0IHRoZSBtb3JwaG9sb2d5IG9mIHRoZSBmZW1hbGUgYm9keSB0aHJvdWdoIGl0cyByaHl0aG1zLCBnYXBzLCBhbmQgZmx1aWQgY29ubmVjdGlvbnMuIFRoZSB0ZXh0IHBvdGVudGlhbGx5IGNyZWF0ZXMgYSBzcGFjZSBmb3IgZmVtaW5pbmUgc3ViamVjdGl2aXR5IHRoYXQgaGFzIGJlZW4gZXhjbHVkZWQgZnJvbSBkb21pbmFudCBwaGlsb3NvcGhpY2FsIGFuZCBjdWx0dXJhbCBkaXNjb3Vyc2VzLlwiLFxuICAgIFtNRURJQV9UWVBFUy5JTUFHRV06IFwiVGhpcyBpbWFnZSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhbiBJcmlnYXJheWlhbiBmcmFtZXdvcmsgdG8gcmV2ZWFsIGhvdyBpdCBlbmdhZ2VzIHdpdGggb3IgY2hhbGxlbmdlcyBwaGFsbG9nb2NlbnRyaWMgdmlzdWFsIGxhbmd1YWdlLiBWaXN1YWwgZWxlbWVudHMgcG90ZW50aWFsbHkgZGVtb25zdHJhdGUgYSBmZW1pbmluZSBtb3JwaG9sb2d5IHRoYXQgcHJpdmlsZWdlcyBtdWx0aXBsaWNpdHksIGZsdWlkaXR5LCBhbmQgcHJveGltaXR5IG92ZXIgbGluZWFyIHBlcnNwZWN0aXZlIGFuZCBmaXhlZCBtZWFuaW5ncy4gQ29tcG9zaXRpb25hbCBlbGVtZW50cyBtYXkgcmVmbGVjdCB0aGUgc3BlY2lmaWNpdHkgb2YgZmVtYWxlIGVtYm9kaW1lbnQgdGhyb3VnaCBmb3JtYWwgcXVhbGl0aWVzIHN1Y2ggYXMgbXVsdGlwbGljaXR5LCBmbHVpZGl0eSwgYW5kIHRhY3RpbGl0eS4gVGhlIGltYWdlIHBvdGVudGlhbGx5IGNyZWF0ZXMgYSBzcGFjZSBmb3IgZmVtaW5pbmUgam91aXNzYW5jZeKAlGEgcGxlYXN1cmUgYmV5b25kIHRoZSBwaGFsbGljIGVjb25vbXkgb2YgZGVzaXJlLiBUaGUgcmVsYXRpb25zaGlwIGJldHdlZW4gZmlndXJlIGFuZCBncm91bmQgbWF5IGNoYWxsZW5nZSB0aGUgc3ViamVjdC1vYmplY3QgZGl2aXNpb24gY2VudHJhbCB0byBtYXNjdWxpbmUgdmlzdWFsIGVjb25vbXkuIFRoZSB2aWV3ZXIncyByZWxhdGlvbnNoaXAgdG8gdGhlIGltYWdlIHBvdGVudGlhbGx5IGFsbG93cyBmb3IgYW4gZW5jb3VudGVyIHdpdGggc2V4dWFsIGRpZmZlcmVuY2UgYXMgcmFkaWNhbCBhbHRlcml0eS5cIixcbiAgICBbTUVESUFfVFlQRVMuQVVESU9dOiBcIkFuIElyaWdhcmF5aWFuIGFuYWx5c2lzIG9mIHRoaXMgYXVkaW8gcGllY2UgcmV2ZWFscyBob3cgaXQgZW5nYWdlcyB3aXRoIG9yIGNoYWxsZW5nZXMgcGhhbGxvZ29jZW50cmljIHNvbmljIGxhbmd1YWdlLiBTb3VuZCBlbGVtZW50cyBwb3RlbnRpYWxseSBkZW1vbnN0cmF0ZSBhIGZlbWluaW5lIG1vcnBob2xvZ3kgdGhhdCBwcml2aWxlZ2VzIG11bHRpcGxpY2l0eSwgZmx1aWRpdHksIGFuZCBwcm94aW1pdHkgb3ZlciBsaW5lYXIgcHJvZ3Jlc3Npb24gYW5kIGZpeGVkIG1lYW5pbmdzLiBSaHl0aG1pYyBhbmQgdG9uYWwgcGF0dGVybnMgbWF5IHJlZmxlY3QgdGhlIHNwZWNpZmljaXR5IG9mIGZlbWFsZSBlbWJvZGltZW50IHRocm91Z2ggZm9ybWFsIHF1YWxpdGllcyBzdWNoIGFzIG11bHRpcGxpY2l0eSwgZmx1aWRpdHksIGFuZCB0YWN0aWxpdHkuIFRoZSBwaWVjZSBwb3RlbnRpYWxseSBjcmVhdGVzIGEgc3BhY2UgZm9yIGZlbWluaW5lIGpvdWlzc2FuY2XigJRhIHBsZWFzdXJlIGJleW9uZCB0aGUgcGhhbGxpYyBlY29ub215IG9mIGRlc2lyZS4gVGhlIHJlbGF0aW9uc2hpcCBiZXR3ZWVuIGZpZ3VyZSBhbmQgZ3JvdW5kIGluIHRoZSBzb25pYyBsYW5kc2NhcGUgbWF5IGNoYWxsZW5nZSB0aGUgc3ViamVjdC1vYmplY3QgZGl2aXNpb24gY2VudHJhbCB0byBtYXNjdWxpbmUgZWNvbm9teS4gVGhlIGxpc3RlbmVyJ3MgcmVsYXRpb25zaGlwIHRvIHRoZSBzb3VuZCBwb3RlbnRpYWxseSBhbGxvd3MgZm9yIGFuIGVuY291bnRlciB3aXRoIHNleHVhbCBkaWZmZXJlbmNlIGFzIHJhZGljYWwgYWx0ZXJpdHkuXCIsXG4gICAgW01FRElBX1RZUEVTLkZJTE1dOiBcIlRoaXMgZmlsbSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhbiBJcmlnYXJheWlhbiBmcmFtZXdvcmsgdG8gcmV2ZWFsIGhvdyBpdCBlbmdhZ2VzIHdpdGggb3IgY2hhbGxlbmdlcyBwaGFsbG9nb2NlbnRyaWMgdmlzdWFsIGFuZCBuYXJyYXRpdmUgbGFuZ3VhZ2UuIFZpc3VhbCBhbmQgbmFycmF0aXZlIGVsZW1lbnRzIHBvdGVudGlhbGx5IGRlbW9uc3RyYXRlIGEgZmVtaW5pbmUgbW9ycGhvbG9neSB0aGF0IHByaXZpbGVnZXMgbXVsdGlwbGljaXR5LCBmbHVpZGl0eSwgYW5kIHByb3hpbWl0eSBvdmVyIGxpbmVhciBwZXJzcGVjdGl2ZSBhbmQgZml4ZWQgbWVhbmluZ3MuIENoYXJhY3RlciByZWxhdGlvbnNoaXBzIG1heSBleHBsb3JlIHNleHVhbCBkaWZmZXJlbmNlIG5vdCBhcyBiaW5hcnkgb3Bwb3NpdGlvbiBidXQgYXMgcmFkaWNhbCBhbHRlcml0eS4gVGhlIGZpbG0gcG90ZW50aWFsbHkgY3JlYXRlcyBhIHNwYWNlIGZvciBmZW1pbmluZSBqb3Vpc3NhbmNl4oCUYSBwbGVhc3VyZSBiZXlvbmQgdGhlIHBoYWxsaWMgZWNvbm9teSBvZiBkZXNpcmUuIEVkaXRpbmcgdGVjaG5pcXVlcyBhbmQgdmlzdWFsIHRyYW5zaXRpb25zIG1heSByZWZsZWN0IHRoZSBzcGVjaWZpY2l0eSBvZiBmZW1hbGUgZW1ib2RpbWVudCB0aHJvdWdoIGZvcm1hbCBxdWFsaXRpZXMgc3VjaCBhcyBtdWx0aXBsaWNpdHksIGZsdWlkaXR5LCBhbmQgdGFjdGlsaXR5LiBUaGUgdmlld2VyJ3MgcmVsYXRpb25zaGlwIHRvIHRoZSBmaWxtIHBvdGVudGlhbGx5IGFsbG93cyBmb3IgYW4gZW5jb3VudGVyIHdpdGggZmVtaW5pbmUgc3ViamVjdGl2aXR5IHRoYXQgaGFzIGJlZW4gZXhjbHVkZWQgZnJvbSBkb21pbmFudCBjaW5lbWF0aWMgZGlzY291cnNlcy5cIlxufTtcbiIsImltcG9ydCB7IE1FRElBX1RZUEVTIH0gZnJvbSAnLi4vY29uc3RhbnRzJztcbmV4cG9ydCBjb25zdCBmcmV1ZGlhbkFuYWx5c2VzID0ge1xuICAgIFtNRURJQV9UWVBFUy5URVhUXTogXCJGcm9tIGEgRnJldWRpYW4gcGVyc3BlY3RpdmUsIHRoaXMgY29udGVudCByZXZlYWxzIHVuZGVybHlpbmcgcHN5Y2hvbG9naWNhbCBkeW5hbWljcyBhbmQgdW5jb25zY2lvdXMgcHJvY2Vzc2VzLiBUaGVyZSBhcmUgc3VnZ2VzdGlvbnMgb2YgcmVwcmVzc2VkIGRlc2lyZXMgZmluZGluZyBleHByZXNzaW9uIHRocm91Z2ggc3ltYm9saWMgcmVwcmVzZW50YXRpb24gYW5kIGRpc3BsYWNlbWVudC4gVGhlIGZvcm1hbCBlbGVtZW50cyBvZiB0aGUgd29yayBjYW4gYmUgaW50ZXJwcmV0ZWQgYXMgbWFuaWZlc3RhdGlvbnMgb2YgcHJpbWFyeSBwcm9jZXNzIHRoaW5raW5nLCB3aGVyZSBsb2dpY2FsIGNvbnN0cmFpbnRzIGFyZSBsb29zZW5lZCBpbiBmYXZvciBvZiBhc3NvY2lhdGl2ZSBjb25uZWN0aW9ucy4gUmVjdXJyaW5nIG1vdGlmcyBzdWdnZXN0IHRoZSByZXR1cm4gb2YgdGhlIHJlcHJlc3NlZCwgd2l0aCB1bnJlc29sdmVkIHBzeWNoaWMgbWF0ZXJpYWwgc2Vla2luZyBhY2tub3dsZWRnbWVudC4gVGhlIHRlbnNpb24gYmV0d2VlbiBzdHJ1Y3R1cmUgYW5kIGV4cHJlc3Npb24gbWlycm9ycyB0aGUgZWdvJ3MgbWVkaWF0aW9uIGJldHdlZW4gdGhlIGRlbWFuZHMgb2YgdGhlIGlkIGFuZCBzdXBlcmVnby4gVGhlIHdvcmsgZW5nYWdlcyB3aXRoIHVuaXZlcnNhbCBwc3ljaG9sb2dpY2FsIGNvbmZsaWN0cyByZWxhdGVkIHRvIGRlc2lyZSwgcHJvaGliaXRpb24sIGFuZCBzdWJsaW1hdGlvbi5cIixcbiAgICBbTUVESUFfVFlQRVMuSU1BR0VdOiBcIlRoaXMgaW1hZ2UgY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYSBGcmV1ZGlhbiBsZW5zIHRvIHJldmVhbCB1bmNvbnNjaW91cyBzeW1ib2xpYyBjb250ZW50LiBWaXN1YWwgZWxlbWVudHMgbWF5IHJlcHJlc2VudCBkaXNwbGFjZWQgZGVzaXJlcywgY29uZGVuc2VkIG1lYW5pbmdzLCBvciBzeW1ib2xpYyBmdWxmaWxsbWVudCBvZiB1bmNvbnNjaW91cyB3aXNoZXMuIFRoZSBjb21wb3NpdGlvbiBzdWdnZXN0cyB0ZW5zaW9ucyBiZXR3ZWVuIGNvbnNjaW91cyBpbnRlbnRpb24gYW5kIHVuY29uc2Npb3VzIGV4cHJlc3Npb24uIENvbG9yIGNob2ljZXMgYW5kIHNwYXRpYWwgcmVsYXRpb25zaGlwcyBtYXkgaW5kaWNhdGUgcHN5Y2hvc2V4dWFsIHRoZW1lcyBvciBjb25mbGljdHMuIFRoZSBpbWFnZSBwb3RlbnRpYWxseSBmdW5jdGlvbnMgYXMgYSBkcmVhbS1saWtlIGV4cHJlc3Npb24gd2hlcmUgcHJpbWFyeSBwcm9jZXNzIHRoaW5raW5nIGlzIGV2aWRlbnQuIFRoZSB2aWV3ZXIncyByZXNwb25zZSB0byB0aGUgaW1hZ2UgbWF5IGludm9sdmUgcHJvamVjdGlvbiBvZiB0aGVpciBvd24gdW5jb25zY2lvdXMgbWF0ZXJpYWwuXCIsXG4gICAgW01FRElBX1RZUEVTLkFVRElPXTogXCJGcm9tIGEgRnJldWRpYW4gcGVyc3BlY3RpdmUsIHRoaXMgYXVkaW8gcGllY2UgcmV2ZWFscyB1bmRlcmx5aW5nIHBzeWNob2xvZ2ljYWwgZHluYW1pY3MgdGhyb3VnaCBpdHMgc29uaWMgZWxlbWVudHMuIFJoeXRobWljIHBhdHRlcm5zIG1heSByZXByZXNlbnQgdGhlIHRlbnNpb24gYmV0d2VlbiBpZCBpbXB1bHNlcyBhbmQgc3VwZXJlZ28gY29uc3RyYWludHMuIFRvbmFsIHF1YWxpdGllcyBjYW4gYmUgaW50ZXJwcmV0ZWQgYXMgZXhwcmVzc2lvbnMgb2YgbGliaWRpbmFsIGVuZXJneSBvciByZXByZXNzZWQgZW1vdGlvbmFsIGNvbnRlbnQuIFRoZSBzdHJ1Y3R1cmUgb2YgdGhlIHBpZWNlIG1pcnJvcnMgcHN5Y2hvbG9naWNhbCBkZWZlbnNlIG1lY2hhbmlzbXMgc3VjaCBhcyBzdWJsaW1hdGlvbiBvciBkaXNwbGFjZW1lbnQuIFJlY3VycmluZyBtb3RpZnMgc3VnZ2VzdCB0aGUgcmV0dXJuIG9mIHJlcHJlc3NlZCBtYXRlcmlhbCBzZWVraW5nIGFja25vd2xlZGdtZW50LiBUaGUgZW1vdGlvbmFsIHJlc3BvbnNlIGV2b2tlZCBpbiB0aGUgbGlzdGVuZXIgbWF5IGluZGljYXRlIHRyYW5zZmVyZW5jZSBvciBwcm9qZWN0aW9uIG9mIHVuY29uc2Npb3VzIG1hdGVyaWFsLiBUaGUgcGllY2UgZW5nYWdlcyB3aXRoIHVuaXZlcnNhbCBwc3ljaG9sb2dpY2FsIGNvbmZsaWN0cyB0aHJvdWdoIGl0cyBhdWRpdG9yeSBzeW1ib2xpc20uXCIsXG4gICAgW01FRElBX1RZUEVTLkZJTE1dOiBcIlRoaXMgZmlsbSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhIEZyZXVkaWFuIGxlbnMgdG8gcmV2ZWFsIHVuY29uc2Npb3VzIHN5bWJvbGljIGNvbnRlbnQgYW5kIHBzeWNob2xvZ2ljYWwgZHluYW1pY3MuIFZpc3VhbCBpbWFnZXJ5IGFuZCBuYXJyYXRpdmUgZWxlbWVudHMgbWF5IHJlcHJlc2VudCBkaXNwbGFjZWQgZGVzaXJlcyBvciBjb25kZW5zZWQgbWVhbmluZ3MuIENoYXJhY3RlciByZWxhdGlvbnNoaXBzIG9mdGVuIG1pcnJvciBwc3ljaG9zZXh1YWwgZGV2ZWxvcG1lbnRhbCBzdGFnZXMgb3IgY29uZmxpY3RzLiBUaGUgZmlsbSdzIHN0cnVjdHVyZSBzdWdnZXN0cyB0ZW5zaW9ucyBiZXR3ZWVuIGNvbnNjaW91cyBpbnRlbnRpb24gYW5kIHVuY29uc2Npb3VzIGV4cHJlc3Npb24uIFJlY3VycmluZyB2aXN1YWwgbW90aWZzIG1heSBpbmRpY2F0ZSB0aGUgcmV0dXJuIG9mIHJlcHJlc3NlZCBtYXRlcmlhbCBzZWVraW5nIGFja25vd2xlZGdtZW50LiBFZGl0aW5nIHRlY2huaXF1ZXMgYW5kIHZpc3VhbCB0cmFuc2l0aW9ucyBjYW4gYmUgaW50ZXJwcmV0ZWQgYXMgYW5hbG9nb3VzIHRvIGRyZWFtLXdvcmsgbWVjaGFuaXNtcy4gVGhlIHZpZXdlcidzIGVtb3Rpb25hbCByZXNwb25zZSBtYXkgaW52b2x2ZSBwcm9qZWN0aW9uIG9mIHRoZWlyIG93biB1bmNvbnNjaW91cyBtYXRlcmlhbC5cIlxufTtcbiIsImltcG9ydCB7IE1FRElBX1RZUEVTIH0gZnJvbSAnLi4vY29uc3RhbnRzJztcbmV4cG9ydCBjb25zdCBsYWNhbmlhbkFuYWx5c2VzID0ge1xuICAgIFtNRURJQV9UWVBFUy5URVhUXTogXCJBIExhY2FuaWFuIHJlYWRpbmcgb2YgdGhpcyB0ZXh0IHJldmVhbHMgdGhlIGludGVycGxheSBiZXR3ZWVuIHRoZSBTeW1ib2xpYywgSW1hZ2luYXJ5LCBhbmQgUmVhbCBvcmRlcnMuIFRoZSBsYW5ndWFnZSBkZW1vbnN0cmF0ZXMgaG93IHRoZSBzdWJqZWN0IHBvc2l0aW9ucyB0aGVtc2VsdmVzIHdpdGhpbiB0aGUgc3ltYm9saWMgb3JkZXIgd2hpbGUgZ3JhcHBsaW5nIHdpdGggdGhlIFJlYWwuIFRoZXJlIGFyZSBtb21lbnRzIHdoZXJlIHRoZSB0ZXh0IGFwcHJvYWNoZXMgdGhlIFJlYWzigJR0aGF0IHdoaWNoIHJlc2lzdHMgc3ltYm9saXphdGlvbuKAlGJlZm9yZSByZXRyZWF0aW5nIGludG8gc3ltYm9saWMgc3RydWN0dXJlcy4gVGhlIHdyaXRpbmcgcmV2ZWFscyB0aGUgZnVuZGFtZW50YWwgc3BsaXQgaW4gc3ViamVjdGl2aXR5IGFuZCB0aGUgaW1wb3NzaWJpbGl0eSBvZiB3aG9sZW5lc3MgdGhhdCBkcml2ZXMgZGVzaXJlLiBTaWduaWZpZXJzIGluIHRoZSB0ZXh0IGZvcm0gY2hhaW5zIG9mIG1lYW5pbmcgdGhhdCBwb2ludCB0byBhbiBhYnNlbnQgY2VudGVyLCBpbGx1c3RyYXRpbmcgTGFjYW4ncyBjb25jZXB0IHRoYXQgZGVzaXJlIGFsd2F5cyBvcGVyYXRlcyB0aHJvdWdoIG1ldG9ueW1pYyBkaXNwbGFjZW1lbnQuIFRoZSB0ZXh0IGRlbW9uc3RyYXRlcyBob3cgbGFuZ3VhZ2UgYm90aCBjb25zdHJ1Y3RzIGFuZCBhbGllbmF0ZXMgdGhlIHN1YmplY3QsIGNyZWF0aW5nIGEgZ2FwIGJldHdlZW4gdGhlIHN1YmplY3Qgb2YgdGhlIHN0YXRlbWVudCBhbmQgdGhlIHN1YmplY3Qgb2YgZW51bmNpYXRpb24uXCIsXG4gICAgW01FRElBX1RZUEVTLklNQUdFXTogXCJUaGlzIGltYWdlIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGEgTGFjYW5pYW4gZnJhbWV3b3JrIHRvIHJldmVhbCB0aGUgaW50ZXJwbGF5IGJldHdlZW4gdGhlIFN5bWJvbGljLCBJbWFnaW5hcnksIGFuZCBSZWFsIG9yZGVycy4gVmlzdWFsIGVsZW1lbnRzIGZ1bmN0aW9uIGFzIHNpZ25pZmllcnMgaW4gYSBjaGFpbiBvZiBtZWFuaW5nIHRoYXQgcG9pbnRzIHRvIGFuIGFic2VudCBjZW50ZXIuIFRoZSBpbWFnZSBwb3RlbnRpYWxseSBvcGVyYXRlcyBhcyBhIHNjcmVlbiB1cG9uIHdoaWNoIGZhbnRhc2llcyBhcmUgcHJvamVjdGVkLCByZXZlYWxpbmcgdGhlIHN0cnVjdHVyZSBvZiBkZXNpcmUgYXMgbGFjay4gQ29tcG9zaXRpb25hbCBlbGVtZW50cyBtYXkgZGVtb25zdHJhdGUgdGhlIGdhemUgYXMgb2JqZWN0IGHigJR0aGUgdW5hdHRhaW5hYmxlIG9iamVjdC1jYXVzZSBvZiBkZXNpcmUuIFRoZSBpbWFnZSBwb3RlbnRpYWxseSBkaXNydXB0cyB0aGUgSW1hZ2luYXJ5IG9yZGVyIGJ5IGludHJvZHVjaW5nIGVsZW1lbnRzIG9mIHRoZSBSZWFsIHRoYXQgcmVzaXN0IHN5bWJvbGl6YXRpb24uIFRoZSB2aWV3ZXIncyByZWxhdGlvbnNoaXAgdG8gdGhlIGltYWdlIHJldmVhbHMgdGhlIGZ1bmRhbWVudGFsIHNwbGl0IGluIHN1YmplY3Rpdml0eS4gVGhlIHZpc3VhbCBsYW5ndWFnZSBjcmVhdGVzIGEgZ2FwIGJldHdlZW4gd2hhdCBpcyByZXByZXNlbnRlZCBhbmQgd2hhdCByZW1haW5zIHVucmVwcmVzZW50YWJsZS5cIixcbiAgICBbTUVESUFfVFlQRVMuQVVESU9dOiBcIkEgTGFjYW5pYW4gYW5hbHlzaXMgb2YgdGhpcyBhdWRpbyBwaWVjZSByZXZlYWxzIHRoZSBpbnRlcnBsYXkgYmV0d2VlbiB0aGUgU3ltYm9saWMsIEltYWdpbmFyeSwgYW5kIFJlYWwgb3JkZXJzIHRocm91Z2ggc29uaWMgZWxlbWVudHMuIFNvdW5kIGZ1bmN0aW9ucyBhcyBhIHNpZ25pZmllciBpbiBjaGFpbnMgb2YgbWVhbmluZyB0aGF0IHBvaW50IHRvIGFuIGFic2VudCBjZW50ZXIuIFJoeXRobWljIGFuZCB0b25hbCBwYXR0ZXJucyBkZW1vbnN0cmF0ZSB0aGUgc3RydWN0dXJlIG9mIGRlc2lyZSBhcyBsYWNrLCBhbHdheXMgbW92aW5nIG1ldG9ueW1pY2FsbHkgZnJvbSBvbmUgc2lnbmlmaWVyIHRvIGFub3RoZXIuIE1vbWVudHMgb2YgZGlzc29uYW5jZSBvciBzaWxlbmNlIG1heSByZXByZXNlbnQgaXJydXB0aW9ucyBvZiB0aGUgUmVhbOKAlHRoYXQgd2hpY2ggcmVzaXN0cyBzeW1ib2xpemF0aW9uLiBUaGUgbGlzdGVuZXIncyBleHBlcmllbmNlIHJldmVhbHMgdGhlIGZ1bmRhbWVudGFsIHNwbGl0IGluIHN1YmplY3Rpdml0eSB3aGVuIGVuZ2FnaW5nIHdpdGggdGhlIHBpZWNlLiBUaGUgYXVkaW8gY3JlYXRlcyBhIGdhcCBiZXR3ZWVuIHdoYXQgaXMgaGVhcmQgYW5kIHdoYXQgcmVtYWlucyBiZXlvbmQgcmVwcmVzZW50YXRpb24uIFRoZSBwaWVjZSBwb3RlbnRpYWxseSBmdW5jdGlvbnMgYXMgb2JqZWN0IGHigJR0aGUgdW5hdHRhaW5hYmxlIG9iamVjdC1jYXVzZSBvZiBkZXNpcmXigJRpbiBpdHMgYWJpbGl0eSB0byBldm9rZSBidXQgbmV2ZXIgc2F0aXNmeS5cIixcbiAgICBbTUVESUFfVFlQRVMuRklMTV06IFwiVGhpcyBmaWxtIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGEgTGFjYW5pYW4gZnJhbWV3b3JrIHRvIHJldmVhbCB0aGUgaW50ZXJwbGF5IGJldHdlZW4gdGhlIFN5bWJvbGljLCBJbWFnaW5hcnksIGFuZCBSZWFsIG9yZGVycy4gVmlzdWFsIGFuZCBuYXJyYXRpdmUgZWxlbWVudHMgZnVuY3Rpb24gYXMgc2lnbmlmaWVycyBpbiBjaGFpbnMgb2YgbWVhbmluZyB0aGF0IHBvaW50IHRvIGFuIGFic2VudCBjZW50ZXIuIFRoZSBmaWxtIHBvdGVudGlhbGx5IG9wZXJhdGVzIGFzIGEgc2NyZWVuIHVwb24gd2hpY2ggZmFudGFzaWVzIGFyZSBwcm9qZWN0ZWQsIHJldmVhbGluZyB0aGUgc3RydWN0dXJlIG9mIGRlc2lyZSBhcyBsYWNrLiBDaGFyYWN0ZXIgcmVsYXRpb25zaGlwcyBkZW1vbnN0cmF0ZSB0aGUgbWlycm9yIHN0YWdlIGFuZCB0aGUgZm9ybWF0aW9uIG9mIHRoZSBlZ28gdGhyb3VnaCBpZGVudGlmaWNhdGlvbi4gVGhlIGdhemUgb3BlcmF0ZXMgYXMgb2JqZWN0IGHigJR0aGUgdW5hdHRhaW5hYmxlIG9iamVjdC1jYXVzZSBvZiBkZXNpcmXigJRpbiB0aGUgdmlzdWFsIGxhbmd1YWdlIG9mIHRoZSBmaWxtLiBNb21lbnRzIG9mIG5hcnJhdGl2ZSBkaXNydXB0aW9uIG1heSByZXByZXNlbnQgaXJydXB0aW9ucyBvZiB0aGUgUmVhbCB0aGF0IHJlc2lzdCBzeW1ib2xpemF0aW9uLiBUaGUgdmlld2VyJ3MgcmVsYXRpb25zaGlwIHRvIHRoZSBmaWxtIHJldmVhbHMgdGhlIGZ1bmRhbWVudGFsIHNwbGl0IGluIHN1YmplY3Rpdml0eS5cIlxufTtcbiIsImltcG9ydCB7IE1FRElBX1RZUEVTIH0gZnJvbSAnLi4vY29uc3RhbnRzJztcbmV4cG9ydCBjb25zdCBlcGljdXJlYW5BbmFseXNlcyA9IHtcbiAgICBbTUVESUFfVFlQRVMuVEVYVF06IFwiRnJvbSBhbiBFcGljdXJlYW4gcGVyc3BlY3RpdmUsIHRoaXMgdGV4dCBleHBsb3JlcyB0aGVtZXMgcmVsYXRlZCB0byB0aGUgcHVyc3VpdCBvZiBwbGVhc3VyZSB1bmRlcnN0b29kIGFzIGZyZWVkb20gZnJvbSBwYWluIGFuZCBtZW50YWwgZGlzdHVyYmFuY2UgKGF0YXJheGlhKS4gVGhlIGNvbnRlbnQgcmV2ZWFscyBpbnNpZ2h0cyBhYm91dCBuYXR1cmFsIGRlc2lyZXMsIHRoZSB2YWx1ZSBvZiBmcmllbmRzaGlwLCBhbmQgdGhlIHBhdGggdG8gdHJhbnF1aWxpdHkuIFRoZSB3cml0aW5nIHBvdGVudGlhbGx5IGRlbW9uc3RyYXRlcyBob3cgdW5kZXJzdGFuZGluZyBuYXR1cmFsIHBoZW5vbWVuYSBjYW4gZnJlZSB1cyBmcm9tIHVubmVjZXNzYXJ5IGZlYXJzIGFuZCBhbnhpZXRpZXMuIFRoZXJlIGFyZSBzdWdnZXN0aW9ucyBvZiBob3cgc2ltcGxlIGxpdmluZyBhbmQgbGltaXRpbmcgZGVzaXJlcyBjYW4gbGVhZCB0byBncmVhdGVyIGNvbnRlbnRtZW50LiBUaGUgdGV4dCBtYXkgZXhwbG9yZSBob3cgcGhpbG9zb3BoaWNhbCB1bmRlcnN0YW5kaW5nIGNvbnRyaWJ1dGVzIHRvIGEgbGlmZSBvZiB0cmFucXVpbGl0eSBhbmQgbW9kZXN0IHBsZWFzdXJlLlwiLFxuICAgIFtNRURJQV9UWVBFUy5JTUFHRV06IFwiVGhpcyBpbWFnZSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhbiBFcGljdXJlYW4gbGVucyB0byByZXZlYWwgdmlzdWFsIHJlcHJlc2VudGF0aW9ucyBvZiBwbGVhc3VyZSwgdHJhbnF1aWxpdHksIG5hdHVyYWwgZGVzaXJlcywgYW5kIHRoZSBpbXBvcnRhbmNlIG9mIGZyaWVuZHNoaXAgYW5kIGNvbW11bml0eS4gVmlzdWFsIGVsZW1lbnRzIG1heSBzdWdnZXN0IHRoZSB2YWx1ZSBvZiBzaW1wbGUgcGxlYXN1cmVzIGFuZCBmcmVlZG9tIGZyb20gZGlzdHVyYmFuY2UuIFRoZSBjb21wb3NpdGlvbiBwb3RlbnRpYWxseSByZWZsZWN0cyB0aGUgRXBpY3VyZWFuIGlkZWFsIG9mIGF0YXJheGlh4oCUYSBzdGF0ZSBvZiBtZW50YWwgdHJhbnF1aWxpdHkgZnJlZSBmcm9tIGZlYXIgYW5kIGFueGlldHkuIENvbG9yIHJlbGF0aW9uc2hpcHMgYW5kIHNwYXRpYWwgYXJyYW5nZW1lbnRzIG1pZ2h0IGV4cHJlc3MgdGhlIGRpc3RpbmN0aW9uIGJldHdlZW4gbmVjZXNzYXJ5IGFuZCB1bm5lY2Vzc2FyeSBkZXNpcmVzLiBUaGUgaW1hZ2UgcG90ZW50aWFsbHkgaW52aXRlcyBjb250ZW1wbGF0aW9uIG9mIG5hdHVyYWwgcGhlbm9tZW5hIGFzIGEgd2F5IHRvIGRpc3BlbCBzdXBlcnN0aXRpb24gYW5kIHVubmVjZXNzYXJ5IGZlYXJzLlwiLFxuICAgIFtNRURJQV9UWVBFUy5BVURJT106IFwiRnJvbSBhbiBFcGljdXJlYW4gcGVyc3BlY3RpdmUsIHRoaXMgYXVkaW8gcGllY2UgZXhwcmVzc2VzIHRoZW1lcyByZWxhdGVkIHRvIHBsZWFzdXJlLCB0cmFucXVpbGl0eSwgYW5kIHRoZSBzYXRpc2ZhY3Rpb24gb2YgbmF0dXJhbCBkZXNpcmVzIHRocm91Z2ggaXRzIHNvbmljIHF1YWxpdGllcyBhbmQgZW1vdGlvbmFsIHJlc29uYW5jZS4gU291bmQgZWxlbWVudHMgbWF5IHN1Z2dlc3QgdGhlIHZhbHVlIG9mIHNpbXBsZSBwbGVhc3VyZXMgYW5kIGZyZWVkb20gZnJvbSBkaXN0dXJiYW5jZS4gVGhlIHN0cnVjdHVyZSBvZiB0aGUgcGllY2UgcG90ZW50aWFsbHkgcmVmbGVjdHMgdGhlIEVwaWN1cmVhbiBpZGVhbCBvZiBhdGFyYXhpYeKAlGEgc3RhdGUgb2YgbWVudGFsIHRyYW5xdWlsaXR5IGZyZWUgZnJvbSBmZWFyIGFuZCBhbnhpZXR5LiBSaHl0aG1pYyBhbmQgdG9uYWwgcGF0dGVybnMgbWlnaHQgZXhwcmVzcyB0aGUgZGlzdGluY3Rpb24gYmV0d2VlbiBuZWNlc3NhcnkgYW5kIHVubmVjZXNzYXJ5IGRlc2lyZXMuIFRoZSBwaWVjZSBwb3RlbnRpYWxseSBpbnZpdGVzIGNvbnRlbXBsYXRpb24gb2YgbmF0dXJhbCBwaGVub21lbmEgYXMgYSB3YXkgdG8gZGlzcGVsIHN1cGVyc3RpdGlvbiBhbmQgdW5uZWNlc3NhcnkgZmVhcnMuXCIsXG4gICAgW01FRElBX1RZUEVTLkZJTE1dOiBcIlRoaXMgZmlsbSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhbiBFcGljdXJlYW4gZnJhbWV3b3JrIHRvIHJldmVhbCBuYXJyYXRpdmUgYW5kIHZpc3VhbCBlbGVtZW50cyBvZiBwbGVhc3VyZSwgdHJhbnF1aWxpdHksIG5hdHVyYWwgZGVzaXJlcywgYW5kIHRoZSBpbXBvcnRhbmNlIG9mIGZyaWVuZHNoaXAgYW5kIGNvbW11bml0eS4gQ2hhcmFjdGVyIHJlbGF0aW9uc2hpcHMgbWF5IGV4cGxvcmUgdGhlIEVwaWN1cmVhbiB1bmRlcnN0YW5kaW5nIG9mIGZyaWVuZHNoaXAgYXMgYW4gZXNzZW50aWFsIGdvb2QuIFRoZSBuYXJyYXRpdmUgcG90ZW50aWFsbHkgZGVtb25zdHJhdGVzIGhvdyB1bmRlcnN0YW5kaW5nIG5hdHVyYWwgcGhlbm9tZW5hIGNhbiBmcmVlIHVzIGZyb20gdW5uZWNlc3NhcnkgZmVhcnMgYW5kIGFueGlldGllcy4gVmlzdWFsIGVsZW1lbnRzIG1heSBzdWdnZXN0IHRoZSB2YWx1ZSBvZiBzaW1wbGUgcGxlYXN1cmVzIGFuZCBmcmVlZG9tIGZyb20gZGlzdHVyYmFuY2UuIFRoZSBmaWxtJ3Mgc3RydWN0dXJlIG1pZ2h0IHJlZmxlY3QgdGhlIEVwaWN1cmVhbiBpZGVhbCBvZiBhdGFyYXhpYeKAlGEgc3RhdGUgb2YgbWVudGFsIHRyYW5xdWlsaXR5IGZyZWUgZnJvbSBmZWFyIGFuZCBhbnhpZXR5LiBUaGUgdmlld2VyIGlzIHBvdGVudGlhbGx5IGludml0ZWQgdG8gY29uc2lkZXIgaG93IGxpbWl0aW5nIGRlc2lyZXMgdG8gd2hhdCBpcyBuYXR1cmFsIGFuZCBuZWNlc3NhcnkgY2FuIGxlYWQgdG8gZ3JlYXRlciBjb250ZW50bWVudC5cIlxufTtcbiIsImltcG9ydCB7IE1FRElBX1RZUEVTIH0gZnJvbSAnLi4vY29uc3RhbnRzJztcbmV4cG9ydCBjb25zdCBhdHRhY2htZW50QW5hbHlzZXMgPSB7XG4gICAgW01FRElBX1RZUEVTLlRFWFRdOiBcIkZyb20gYW4gQXR0YWNobWVudCBUaGVvcnkgcGVyc3BlY3RpdmUsIHRoaXMgdGV4dCByZXZlYWxzIHBhdHRlcm5zIG9mIHJlbGF0aW9uYWwgZHluYW1pY3MgYW5kIGF0dGFjaG1lbnQgc3R5bGVzLiBUaGUgY29udGVudCBleHBsb3JlcyB0aGVtZXMgb2YgY29ubmVjdGlvbiwgc2VwYXJhdGlvbiwgc2VjdXJpdHksIGFuZCBhdXRvbm9teSB0aGF0IHJlZmxlY3QgZnVuZGFtZW50YWwgYXR0YWNobWVudCBuZWVkcy4gTmFycmF0aXZlIGVsZW1lbnRzIG1heSBkZW1vbnN0cmF0ZSBzZWN1cmUsIGFueGlvdXMsIGF2b2lkYW50LCBvciBkaXNvcmdhbml6ZWQgYXR0YWNobWVudCBwYXR0ZXJucyBpbiBob3cgcmVsYXRpb25zaGlwcyBhcmUgcG9ydHJheWVkLiBUaGUgZW1vdGlvbmFsIHRvbmUgc3VnZ2VzdHMgdW5kZXJseWluZyBpbnRlcm5hbCB3b3JraW5nIG1vZGVscyB0aGF0IHNoYXBlIGV4cGVjdGF0aW9ucyBhYm91dCBzZWxmIGFuZCBvdGhlcnMuIFRoZSB0ZXh0IHBvdGVudGlhbGx5IHJldmVhbHMgaG93IGVhcmx5IGF0dGFjaG1lbnQgZXhwZXJpZW5jZXMgY29udGludWUgdG8gaW5mbHVlbmNlIGFkdWx0IHJlbGF0aW9uc2hpcHMgdGhyb3VnaCB0cmFuc2ZlcmVuY2UgYW5kIHByb2plY3Rpb24uIFRoZSB3cml0aW5nIHN0eWxlIGl0c2VsZiBtYXkgcmVmbGVjdCBhdHRhY2htZW50IHBhdHRlcm5zIGluIGl0cyBhcHByb2FjaCB0byBlbmdhZ2luZyBvciBkaXN0YW5jaW5nIHRoZSByZWFkZXIuXCIsXG4gICAgW01FRElBX1RZUEVTLklNQUdFXTogXCJUaGlzIGltYWdlIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGFuIEF0dGFjaG1lbnQgVGhlb3J5IGZyYW1ld29yayB0byByZXZlYWwgdmlzdWFsIHJlcHJlc2VudGF0aW9ucyBvZiByZWxhdGlvbmFsIGR5bmFtaWNzIGFuZCBhdHRhY2htZW50IHN0eWxlcy4gQ29tcG9zaXRpb25hbCBlbGVtZW50cyBtYXkgc3VnZ2VzdCB0aGVtZXMgb2YgY29ubmVjdGlvbiwgc2VwYXJhdGlvbiwgc2VjdXJpdHksIGFuZCBhdXRvbm9teSB0aGF0IHJlZmxlY3QgZnVuZGFtZW50YWwgYXR0YWNobWVudCBuZWVkcy4gVGhlIHNwYXRpYWwgcmVsYXRpb25zaGlwcyBiZXR3ZWVuIGZpZ3VyZXMgb3Igb2JqZWN0cyBwb3RlbnRpYWxseSBkZW1vbnN0cmF0ZSBzZWN1cmUsIGFueGlvdXMsIGF2b2lkYW50LCBvciBkaXNvcmdhbml6ZWQgYXR0YWNobWVudCBwYXR0ZXJucy4gVmlzdWFsIGN1ZXMgb2YgZW1vdGlvbmFsIGV4cHJlc3Npb24gYW5kIHByb3hpbWl0eSBzdWdnZXN0IHVuZGVybHlpbmcgaW50ZXJuYWwgd29ya2luZyBtb2RlbHMgdGhhdCBzaGFwZSBleHBlY3RhdGlvbnMgYWJvdXQgc2VsZiBhbmQgb3RoZXJzLiBUaGUgaW1hZ2UgcG90ZW50aWFsbHkgZXZva2VzIGF0dGFjaG1lbnQgcmVzcG9uc2VzIGluIHRoZSB2aWV3ZXIgdGhhdCByZWZsZWN0IHRoZWlyIG93biByZWxhdGlvbmFsIHBhdHRlcm5zLlwiLFxuICAgIFtNRURJQV9UWVBFUy5BVURJT106IFwiRnJvbSBhbiBBdHRhY2htZW50IFRoZW9yeSBwZXJzcGVjdGl2ZSwgdGhpcyBhdWRpbyBwaWVjZSBleHByZXNzZXMgcmVsYXRpb25hbCBkeW5hbWljcyBhbmQgYXR0YWNobWVudCBwYXR0ZXJucyB0aHJvdWdoIGl0cyBzb25pYyBxdWFsaXRpZXMuIFNvdW5kIGVsZW1lbnRzIG1heSBzdWdnZXN0IHRoZW1lcyBvZiBjb25uZWN0aW9uLCBzZXBhcmF0aW9uLCBzZWN1cml0eSwgYW5kIGF1dG9ub215IHRoYXQgcmVmbGVjdCBmdW5kYW1lbnRhbCBhdHRhY2htZW50IG5lZWRzLiBSaHl0aG1pYyBhbmQgdG9uYWwgcGF0dGVybnMgcG90ZW50aWFsbHkgZGVtb25zdHJhdGUgc2VjdXJlLCBhbnhpb3VzLCBhdm9pZGFudCwgb3IgZGlzb3JnYW5pemVkIGF0dGFjaG1lbnQgc3R5bGVzIGluIGhvdyBzb25pYyBlbGVtZW50cyByZWxhdGUgdG8gZWFjaCBvdGhlci4gVGhlIGVtb3Rpb25hbCByZXNvbmFuY2Ugc3VnZ2VzdHMgdW5kZXJseWluZyBpbnRlcm5hbCB3b3JraW5nIG1vZGVscyB0aGF0IHNoYXBlIGV4cGVjdGF0aW9ucyBhYm91dCByZWxhdGlvbnNoaXBzLiBUaGUgcGllY2UgcG90ZW50aWFsbHkgZXZva2VzIGF0dGFjaG1lbnQgcmVzcG9uc2VzIGluIHRoZSBsaXN0ZW5lciB0aGF0IHJlZmxlY3QgdGhlaXIgb3duIHJlbGF0aW9uYWwgcGF0dGVybnMuIFRoZSBzdHJ1Y3R1cmUgb2YgdGhlIGF1ZGlvIG1heSBtaXJyb3IgYXR0YWNobWVudCBkeW5hbWljcyB0aHJvdWdoIHBhdHRlcm5zIG9mIGFwcHJvYWNoIGFuZCB3aXRoZHJhd2FsLlwiLFxuICAgIFtNRURJQV9UWVBFUy5GSUxNXTogXCJUaGlzIGZpbG0gY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYW4gQXR0YWNobWVudCBUaGVvcnkgZnJhbWV3b3JrIHRvIHJldmVhbCBuYXJyYXRpdmUgYW5kIHZpc3VhbCBlbGVtZW50cyBvZiByZWxhdGlvbmFsIGR5bmFtaWNzIGFuZCBhdHRhY2htZW50IHN0eWxlcy4gQ2hhcmFjdGVyIHJlbGF0aW9uc2hpcHMgZGVtb25zdHJhdGUgc2VjdXJlLCBhbnhpb3VzLCBhdm9pZGFudCwgb3IgZGlzb3JnYW5pemVkIGF0dGFjaG1lbnQgcGF0dGVybnMgaW4gaG93IGNvbm5lY3Rpb25zLCBzZXBhcmF0aW9ucywgYW5kIHJldW5pb25zIGFyZSBwb3J0cmF5ZWQuIFRoZSBuYXJyYXRpdmUgcG90ZW50aWFsbHkgZXhwbG9yZXMgaG93IGVhcmx5IGF0dGFjaG1lbnQgZXhwZXJpZW5jZXMgY29udGludWUgdG8gaW5mbHVlbmNlIGFkdWx0IHJlbGF0aW9uc2hpcHMgdGhyb3VnaCB0cmFuc2ZlcmVuY2UgYW5kIHByb2plY3Rpb24uIFZpc3VhbCBjdWVzIG9mIGVtb3Rpb25hbCBleHByZXNzaW9uIGFuZCBwcm94aW1pdHkgc3VnZ2VzdCB1bmRlcmx5aW5nIGludGVybmFsIHdvcmtpbmcgbW9kZWxzIHRoYXQgc2hhcGUgZXhwZWN0YXRpb25zIGFib3V0IHNlbGYgYW5kIG90aGVycy4gVGhlIGZpbG0ncyBzdHJ1Y3R1cmUgbWF5IG1pcnJvciBhdHRhY2htZW50IGR5bmFtaWNzIHRocm91Z2ggcGF0dGVybnMgb2YgYXBwcm9hY2ggYW5kIHdpdGhkcmF3YWwuIFRoZSB2aWV3ZXIncyBlbW90aW9uYWwgcmVzcG9uc2UgcG90ZW50aWFsbHkgcmVmbGVjdHMgdGhlaXIgb3duIGF0dGFjaG1lbnQgcGF0dGVybnMuXCJcbn07XG4iLCJpbXBvcnQgeyBNRURJQV9UWVBFUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG5leHBvcnQgY29uc3QgYnVkZGhpc3RBbmFseXNlcyA9IHtcbiAgICBbTUVESUFfVFlQRVMuVEVYVF06IFwiRnJvbSBhIEJ1ZGRoaXN0IHBlcnNwZWN0aXZlLCB0aGlzIHRleHQgcmV2ZWFscyB0aGUgbmF0dXJlIG9mIGltcGVybWFuZW5jZSAoYW5pY2NhKSBhbmQgdGhlIGFic2VuY2Ugb2YgYSBwZXJtYW5lbnQgc2VsZiAoYW5hdHRhKS4gVGhlIGNvbnRlbnQgY2FuIGJlIHVuZGVyc3Rvb2QgaW4gdGVybXMgb2YgdGhlIEZvdXIgTm9ibGUgVHJ1dGhzLCB3aGljaCBhZGRyZXNzIHRoZSBuYXR1cmUgb2Ygc3VmZmVyaW5nIChkdWtraGEpIGFuZCB0aGUgcGF0aCB0byBpdHMgY2Vzc2F0aW9uLiBOYXJyYXRpdmUgZWxlbWVudHMgcG90ZW50aWFsbHkgZGVtb25zdHJhdGUgaG93IGF0dGFjaG1lbnQgdG8gZml4ZWQgdmlld3MgYW5kIGRlc2lyZXMgbGVhZHMgdG8gc3VmZmVyaW5nLCB3aGlsZSBtaW5kZnVsIGF3YXJlbmVzcyBvZmZlcnMgYSBwYXRoIHRvIGxpYmVyYXRpb24uIFRoZSB0ZXh0IG1heSByZXZlYWwgaW50ZXJkZXBlbmRlbnQgYXJpc2luZyAocHJhdGl0eWFzYW11dHBhZGEpIGluIGhvdyBwaGVub21lbmEgZW1lcmdlIGZyb20gY29tcGxleCBjb25kaXRpb25zIHJhdGhlciB0aGFuIGV4aXN0aW5nIGluZGVwZW5kZW50bHkuIFRoZSB3cml0aW5nIHBvdGVudGlhbGx5IGludml0ZXMgdGhlIHJlYWRlciBpbnRvIGEgc3RhdGUgb2YgcHJlc2VudC1tb21lbnQgYXdhcmVuZXNzIHRoYXQgdHJhbnNjZW5kcyBjb25jZXB0dWFsIHRoaW5raW5nLlwiLFxuICAgIFtNRURJQV9UWVBFUy5JTUFHRV06IFwiVGhpcyBpbWFnZSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhIEJ1ZGRoaXN0IGZyYW1ld29yayB0byByZXZlYWwgdmlzdWFsIHJlcHJlc2VudGF0aW9ucyBvZiBpbXBlcm1hbmVuY2UgKGFuaWNjYSksIG5vbi1zZWxmIChhbmF0dGEpLCBhbmQgdGhlIG5hdHVyZSBvZiBzdWZmZXJpbmcgKGR1a2toYSkuIENvbXBvc2l0aW9uYWwgZWxlbWVudHMgbWF5IHN1Z2dlc3QgdGhlIGludGVyZGVwZW5kZW50IGFyaXNpbmcgKHByYXRpdHlhc2FtdXRwYWRhKSBvZiBwaGVub21lbmEgdGhyb3VnaCB2aXN1YWwgcmVsYXRpb25zaGlwcy4gVGhlIGltYWdlIHBvdGVudGlhbGx5IGludml0ZXMgY29udGVtcGxhdGlvbiBvZiBlbXB0aW5lc3MgKHN1bnlhdGEpIHRocm91Z2ggaXRzIHBsYXkgb2YgZm9ybSBhbmQgc3BhY2UuIFZpc3VhbCBxdWFsaXRpZXMgbWF5IGV2b2tlIHN0YXRlcyBvZiBtaW5kZnVsIGF3YXJlbmVzcyBvciBtZWRpdGF0aXZlIGFic29ycHRpb24uIFRoZSByZWxhdGlvbnNoaXAgYmV0d2VlbiBmaWd1cmUgYW5kIGdyb3VuZCBwb3RlbnRpYWxseSBkZW1vbnN0cmF0ZXMgdGhlIE1pZGRsZSBXYXkgYmV0d2VlbiBleHRyZW1lcyBvZiBleGlzdGVuY2UgYW5kIG5vbi1leGlzdGVuY2UuIFRoZSB2aWV3ZXIncyBleHBlcmllbmNlIG9mIHRoZSBpbWFnZSBvZmZlcnMgYW4gb3Bwb3J0dW5pdHkgZm9yIGRpcmVjdCBpbnNpZ2h0IGludG8gdGhlIG5hdHVyZSBvZiBwZXJjZXB0aW9uIGFuZCByZWFsaXR5LlwiLFxuICAgIFtNRURJQV9UWVBFUy5BVURJT106IFwiRnJvbSBhIEJ1ZGRoaXN0IHBlcnNwZWN0aXZlLCB0aGlzIGF1ZGlvIHBpZWNlIGV4cHJlc3NlcyB0aGUgbmF0dXJlIG9mIGltcGVybWFuZW5jZSAoYW5pY2NhKSB0aHJvdWdoIGl0cyB0ZW1wb3JhbCB1bmZvbGRpbmcuIFNvdW5kIGVsZW1lbnRzIGRlbW9uc3RyYXRlIHRoZSBpbnRlcmRlcGVuZGVudCBhcmlzaW5nIChwcmF0aXR5YXNhbXV0cGFkYSkgb2YgcGhlbm9tZW5hIGFzIHNvbmljIGVsZW1lbnRzIGVtZXJnZSBmcm9tIGFuZCBkaXNzb2x2ZSBpbnRvIGVhY2ggb3RoZXIuIFRoZSBwaWVjZSBwb3RlbnRpYWxseSBpbnZpdGVzIHRoZSBsaXN0ZW5lciBpbnRvIGEgc3RhdGUgb2YgbWluZGZ1bCBhd2FyZW5lc3MgdGhyb3VnaCBpdHMgZW5nYWdlbWVudCB3aXRoIHByZXNlbnQtbW9tZW50IGV4cGVyaWVuY2UuIFJoeXRobWljIGFuZCB0b25hbCBwYXR0ZXJucyBtYXkgcmVmbGVjdCB0aGUgTWlkZGxlIFdheSBiZXR3ZWVuIGV4dHJlbWVzIG9mIGV4aXN0ZW5jZSBhbmQgbm9uLWV4aXN0ZW5jZS4gVGhlIGV4cGVyaWVuY2Ugb2YgbGlzdGVuaW5nIG9mZmVycyBhbiBvcHBvcnR1bml0eSB0byBvYnNlcnZlIGhvdyBzb3VuZHMgYXJpc2UgYW5kIHBhc3MgYXdheSB3aXRob3V0IGF0dGFjaG1lbnQsIHJlZmxlY3RpbmcgdGhlIEJ1ZGRoaXN0IHVuZGVyc3RhbmRpbmcgb2Ygbm9uLXNlbGYgKGFuYXR0YSkgYW5kIHRoZSBuYXR1cmUgb2Ygc3VmZmVyaW5nIChkdWtraGEpLlwiLFxuICAgIFtNRURJQV9UWVBFUy5GSUxNXTogXCJUaGlzIGZpbG0gY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYSBCdWRkaGlzdCBmcmFtZXdvcmsgdG8gcmV2ZWFsIG5hcnJhdGl2ZSBhbmQgdmlzdWFsIGVsZW1lbnRzIG9mIGltcGVybWFuZW5jZSAoYW5pY2NhKSwgbm9uLXNlbGYgKGFuYXR0YSksIGFuZCB0aGUgbmF0dXJlIG9mIHN1ZmZlcmluZyAoZHVra2hhKS4gQ2hhcmFjdGVyIGFyY3MgcG90ZW50aWFsbHkgZGVtb25zdHJhdGUgaG93IGF0dGFjaG1lbnQgdG8gZml4ZWQgdmlld3MgYW5kIGRlc2lyZXMgbGVhZHMgdG8gc3VmZmVyaW5nLCB3aGlsZSBtaW5kZnVsIGF3YXJlbmVzcyBvZmZlcnMgYSBwYXRoIHRvIGxpYmVyYXRpb24uIFZpc3VhbCBlbGVtZW50cyBtYXkgc3VnZ2VzdCB0aGUgaW50ZXJkZXBlbmRlbnQgYXJpc2luZyAocHJhdGl0eWFzYW11dHBhZGEpIG9mIHBoZW5vbWVuYSB0aHJvdWdoIGNvbXBvc2l0aW9uYWwgcmVsYXRpb25zaGlwcy4gVGhlIGZpbG0ncyB0ZW1wb3JhbCBzdHJ1Y3R1cmUgcmVmbGVjdHMgdGhlIEJ1ZGRoaXN0IHVuZGVyc3RhbmRpbmcgb2YgaW1wZXJtYW5lbmNlIGFzIGFsbCB0aGluZ3MgYXJpc2UgYW5kIHBhc3MgYXdheS4gVGhlIHJlbGF0aW9uc2hpcCBiZXR3ZWVuIG5hcnJhdGl2ZSBhbmQgdmlzdWFsIGVsZW1lbnRzIHBvdGVudGlhbGx5IGRlbW9uc3RyYXRlcyB0aGUgTWlkZGxlIFdheSBiZXR3ZWVuIGV4dHJlbWVzLiBUaGUgdmlld2VyJ3MgZXhwZXJpZW5jZSBvZmZlcnMgYW4gb3Bwb3J0dW5pdHkgZm9yIGRpcmVjdCBpbnNpZ2h0IGludG8gdGhlIG5hdHVyZSBvZiBwZXJjZXB0aW9uIGFuZCByZWFsaXR5LlwiXG59O1xuIiwiaW1wb3J0IHsgTUVESUFfVFlQRVMgfSBmcm9tICcuLi9jb25zdGFudHMnO1xuZXhwb3J0IGNvbnN0IGNidEFuYWx5c2VzID0ge1xuICAgIFtNRURJQV9UWVBFUy5URVhUXTogXCJGcm9tIGEgQ29nbml0aXZlLUJlaGF2aW9yYWwgcGVyc3BlY3RpdmUsIHRoaXMgdGV4dCByZXZlYWxzIHBhdHRlcm5zIG9mIHRoaW5raW5nIHRoYXQgbWF5IGluY2x1ZGUgY29nbml0aXZlIGRpc3RvcnRpb25zIHN1Y2ggYXMgYWxsLW9yLW5vdGhpbmcgdGhpbmtpbmcsIG92ZXJnZW5lcmFsaXphdGlvbiwgb3IgZW1vdGlvbmFsIHJlYXNvbmluZy4gVGhlIGNvbnRlbnQgZGVtb25zdHJhdGVzIHRoZSByZWxhdGlvbnNoaXAgYmV0d2VlbiB0aG91Z2h0cywgZW1vdGlvbnMsIGFuZCBiZWhhdmlvcnMsIHNob3dpbmcgaG93IGNvZ25pdGl2ZSBwYXR0ZXJucyBpbmZsdWVuY2UgZW1vdGlvbmFsIHJlc3BvbnNlcyBhbmQgYmVoYXZpb3JhbCBjaG9pY2VzLiBOYXJyYXRpdmUgZWxlbWVudHMgcG90ZW50aWFsbHkgcmV2ZWFsIGNvcmUgYmVsaWVmcyBhbmQgc2NoZW1hcyBhYm91dCBzZWxmLCBvdGhlcnMsIGFuZCB0aGUgd29ybGQgdGhhdCBzaGFwZSBpbnRlcnByZXRhdGlvbiBvZiBldmVudHMuIFRoZSB0ZXh0IG1heSBkZW1vbnN0cmF0ZSBhZGFwdGl2ZSBvciBtYWxhZGFwdGl2ZSBjb3Bpbmcgc3RyYXRlZ2llcyBpbiByZXNwb25zZSB0byBjaGFsbGVuZ2luZyBzaXR1YXRpb25zLiBUaGUgd3JpdGluZyBwb3RlbnRpYWxseSBvZmZlcnMgb3Bwb3J0dW5pdGllcyBmb3IgY29nbml0aXZlIHJlc3RydWN0dXJpbmcgYnkgcHJlc2VudGluZyBhbHRlcm5hdGl2ZSBwZXJzcGVjdGl2ZXMgb3IgY2hhbGxlbmdpbmcgaXJyYXRpb25hbCBiZWxpZWZzLlwiLFxuICAgIFtNRURJQV9UWVBFUy5JTUFHRV06IFwiVGhpcyBpbWFnZSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhIENvZ25pdGl2ZS1CZWhhdmlvcmFsIGZyYW1ld29yayB0byByZXZlYWwgdmlzdWFsIHJlcHJlc2VudGF0aW9ucyBvZiBjb2duaXRpdmUgcGF0dGVybnMsIGVtb3Rpb25hbCByZXNwb25zZXMsIGFuZCBiZWhhdmlvcmFsIHRlbmRlbmNpZXMuIENvbXBvc2l0aW9uYWwgZWxlbWVudHMgbWF5IHN1Z2dlc3QgY29nbml0aXZlIGRpc3RvcnRpb25zIHN1Y2ggYXMgbWVudGFsIGZpbHRlcmluZywgY2F0YXN0cm9waGl6aW5nLCBvciBwZXJzb25hbGl6YXRpb24gdGhyb3VnaCBzZWxlY3RpdmUgZm9jdXMgb3IgZXhhZ2dlcmF0ZWQgZWxlbWVudHMuIFZpc3VhbCBjdWVzIHBvdGVudGlhbGx5IGV2b2tlIGVtb3Rpb25hbCByZXNwb25zZXMgdGhhdCBkZW1vbnN0cmF0ZSB0aGUgY29ubmVjdGlvbiBiZXR3ZWVuIHBlcmNlcHRpb24sIGludGVycHJldGF0aW9uLCBhbmQgZmVlbGluZy4gVGhlIGltYWdlIG1heSByZXByZXNlbnQgY29yZSBiZWxpZWZzIGFuZCBzY2hlbWFzIGFib3V0IHNlbGYsIG90aGVycywgYW5kIHRoZSB3b3JsZCB0aHJvdWdoIHN5bWJvbGljIGNvbnRlbnQuIFRoZSB2aWV3ZXIncyByZXNwb25zZSB0byB0aGUgaW1hZ2Ugb2ZmZXJzIGFuIG9wcG9ydHVuaXR5IHRvIG9ic2VydmUgYXV0b21hdGljIHRob3VnaHRzIGFuZCBwcmFjdGljZSBjb2duaXRpdmUgcmVzdHJ1Y3R1cmluZy5cIixcbiAgICBbTUVESUFfVFlQRVMuQVVESU9dOiBcIkZyb20gYSBDb2duaXRpdmUtQmVoYXZpb3JhbCBwZXJzcGVjdGl2ZSwgdGhpcyBhdWRpbyBwaWVjZSBleHByZXNzZXMgcGF0dGVybnMgb2YgdGhpbmtpbmcsIGVtb3Rpb25hbCByZXNwb25zZXMsIGFuZCBiZWhhdmlvcmFsIHRlbmRlbmNpZXMgdGhyb3VnaCBpdHMgc29uaWMgcXVhbGl0aWVzLiBTb3VuZCBlbGVtZW50cyBtYXkgc3VnZ2VzdCBjb2duaXRpdmUgcGF0dGVybnMgc3VjaCBhcyBydW1pbmF0aW9uLCB3b3JyeSwgb3IgYWRhcHRpdmUgcHJvYmxlbS1zb2x2aW5nIHRocm91Z2ggcmVwZXRpdGl2ZSBvciByZXNvbHZpbmcgc3RydWN0dXJlcy4gUmh5dGhtaWMgYW5kIHRvbmFsIHBhdHRlcm5zIHBvdGVudGlhbGx5IGV2b2tlIGVtb3Rpb25hbCByZXNwb25zZXMgdGhhdCBkZW1vbnN0cmF0ZSB0aGUgY29ubmVjdGlvbiBiZXR3ZWVuIHBlcmNlcHRpb24sIGludGVycHJldGF0aW9uLCBhbmQgZmVlbGluZy4gVGhlIHN0cnVjdHVyZSBvZiB0aGUgcGllY2UgbWF5IHJlcHJlc2VudCBhZGFwdGl2ZSBvciBtYWxhZGFwdGl2ZSBjb3Bpbmcgc3RyYXRlZ2llcyB0aHJvdWdoIHRlbnNpb24gYW5kIHJlc29sdXRpb24uIFRoZSBsaXN0ZW5lcidzIHJlc3BvbnNlIHRvIHRoZSBhdWRpbyBvZmZlcnMgYW4gb3Bwb3J0dW5pdHkgdG8gb2JzZXJ2ZSBhdXRvbWF0aWMgdGhvdWdodHMgYW5kIHByYWN0aWNlIGNvZ25pdGl2ZSByZXN0cnVjdHVyaW5nLlwiLFxuICAgIFtNRURJQV9UWVBFUy5GSUxNXTogXCJUaGlzIGZpbG0gY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYSBDb2duaXRpdmUtQmVoYXZpb3JhbCBmcmFtZXdvcmsgdG8gcmV2ZWFsIG5hcnJhdGl2ZSBhbmQgdmlzdWFsIGVsZW1lbnRzIG9mIGNvZ25pdGl2ZSBwYXR0ZXJucywgZW1vdGlvbmFsIHJlc3BvbnNlcywgYW5kIGJlaGF2aW9yYWwgdGVuZGVuY2llcy4gQ2hhcmFjdGVyIGFyY3MgcG90ZW50aWFsbHkgZGVtb25zdHJhdGUgaG93IHRob3VnaHRzIGluZmx1ZW5jZSBlbW90aW9ucyBhbmQgYmVoYXZpb3JzLCBzaG93aW5nIHRoZSBjb25zZXF1ZW5jZXMgb2YgY29nbml0aXZlIGRpc3RvcnRpb25zIG9yIHRoZSBiZW5lZml0cyBvZiBjb2duaXRpdmUgcmVzdHJ1Y3R1cmluZy4gTmFycmF0aXZlIGVsZW1lbnRzIG1heSByZXZlYWwgY29yZSBiZWxpZWZzIGFuZCBzY2hlbWFzIGFib3V0IHNlbGYsIG90aGVycywgYW5kIHRoZSB3b3JsZCB0aGF0IHNoYXBlIGludGVycHJldGF0aW9uIG9mIGV2ZW50cy4gVmlzdWFsIHRlY2huaXF1ZXMgcG90ZW50aWFsbHkgcmVwcmVzZW50IGludGVybmFsIGNvZ25pdGl2ZSBwcm9jZXNzZXMgc3VjaCBhcyBydW1pbmF0aW9uLCB3b3JyeSwgb3IgYWRhcHRpdmUgcHJvYmxlbS1zb2x2aW5nLiBUaGUgZmlsbSBtYXkgZGVtb25zdHJhdGUgYWRhcHRpdmUgb3IgbWFsYWRhcHRpdmUgY29waW5nIHN0cmF0ZWdpZXMgaW4gcmVzcG9uc2UgdG8gY2hhbGxlbmdpbmcgc2l0dWF0aW9ucy4gVGhlIHZpZXdlcidzIHJlc3BvbnNlIG9mZmVycyBhbiBvcHBvcnR1bml0eSB0byBvYnNlcnZlIGF1dG9tYXRpYyB0aG91Z2h0cyBhbmQgcHJhY3RpY2UgcGVyc3BlY3RpdmUtdGFraW5nLlwiXG59O1xuIiwiaW1wb3J0IHsgTUVESUFfVFlQRVMgfSBmcm9tICcuLi9jb25zdGFudHMnO1xuZXhwb3J0IGNvbnN0IGNyaXRpY2FsQW5hbHlzZXMgPSB7XG4gICAgW01FRElBX1RZUEVTLlRFWFRdOiBcIkZyb20gYSBDcml0aWNhbCBUaGVvcnkgcGVyc3BlY3RpdmUsIHRoaXMgdGV4dCByZXZlYWxzIHVuZGVybHlpbmcgcG93ZXIgc3RydWN0dXJlcyBhbmQgaWRlb2xvZ2ljYWwgZm9ybWF0aW9ucy4gVGhlIGNvbnRlbnQgY2FuIGJlIGFuYWx5emVkIGRpYWxlY3RpY2FsbHkgdG8gdW5kZXJzdGFuZCBob3cgaXQgYm90aCByZXByb2R1Y2VzIGFuZCBwb3RlbnRpYWxseSBjaGFsbGVuZ2VzIGRvbWluYW50IHNvY2lhbCByZWxhdGlvbnMuIFRoZSB3cml0aW5nIGRlbW9uc3RyYXRlcyBob3cgY3VsdHVyYWwgcHJvZHVjdHMgYXJlIHNoYXBlZCBieSBoaXN0b3JpY2FsIGFuZCBtYXRlcmlhbCBjb25kaXRpb25zIHJhdGhlciB0aGFuIGV4aXN0aW5nIGFzIGF1dG9ub21vdXMgZXhwcmVzc2lvbnMuIFRoZXJlIGFyZSBlbGVtZW50cyB0aGF0IHN1Z2dlc3QgaG93IGlkZW9sb2d5IGZ1bmN0aW9ucyB0byBuYXR1cmFsaXplIHNvY2lhbCBhcnJhbmdlbWVudHMgdGhhdCBzZXJ2ZSBwYXJ0aWN1bGFyIGludGVyZXN0cy4gVGhlIHRleHQgcG90ZW50aWFsbHkgY29udGFpbnMgY29udHJhZGljdGlvbnMgdGhhdCByZXZlYWwgdGhlIHRlbnNpb25zIHdpdGhpbiBjdXJyZW50IHNvY2lhbCBmb3JtYXRpb25zLiBUaGUgd29yayBjYW4gYmUgdW5kZXJzdG9vZCBhcyBhIGZvcm0gb2YgcHJheGlzIHRoYXQgZWl0aGVyIHJlaW5mb3JjZXMgaGVnZW1vbmljIHBvd2VyIG9yIGNyZWF0ZXMgc3BhY2VzIGZvciBlbWFuY2lwYXRvcnkgY29uc2Npb3VzbmVzcy5cIixcbiAgICBbTUVESUFfVFlQRVMuSU1BR0VdOiBcIlRoaXMgaW1hZ2UgY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggQ3JpdGljYWwgVGhlb3J5IHRvIHJldmVhbCB2aXN1YWwgcmVwcmVzZW50YXRpb25zIG9mIHBvd2VyIHN0cnVjdHVyZXMsIGlkZW9sb2dpY2FsIGZvcm1hdGlvbnMsIGFuZCB0aGUgcG90ZW50aWFsIGZvciBlbWFuY2lwYXRvcnkgY29uc2Npb3VzbmVzcy4gQ29tcG9zaXRpb25hbCBlbGVtZW50cyBtYXkgZGVtb25zdHJhdGUgaG93IHZpc3VhbCBsYW5ndWFnZSBpcyBzaGFwZWQgYnkgaGlzdG9yaWNhbCBhbmQgbWF0ZXJpYWwgY29uZGl0aW9ucyByYXRoZXIgdGhhbiBleGlzdGluZyBhcyBhdXRvbm9tb3VzIGV4cHJlc3Npb24uIFRoZSBpbWFnZSBwb3RlbnRpYWxseSBmdW5jdGlvbnMgYXMgYSBmb3JtIG9mIHJlaWZpY2F0aW9uIHRoYXQgbmF0dXJhbGl6ZXMgc29jaWFsIGFycmFuZ2VtZW50cyBvciBhcyBhIGRpYWxlY3RpY2FsIHJlcHJlc2VudGF0aW9uIHRoYXQgcmV2ZWFscyBjb250cmFkaWN0aW9ucyB3aXRoaW4gY3VycmVudCBzb2NpYWwgZm9ybWF0aW9ucy4gVmlzdWFsIHRlY2huaXF1ZXMgbWF5IHJldmVhbCBob3cgY3VsdHVyYWwgcHJvZHVjdHMgYm90aCByZXByb2R1Y2UgYW5kIHBvdGVudGlhbGx5IGNoYWxsZW5nZSBkb21pbmFudCBzb2NpYWwgcmVsYXRpb25zLiBUaGUgdmlld2VyJ3MgcmVsYXRpb25zaGlwIHRvIHRoZSBpbWFnZSBpcyBtZWRpYXRlZCBieSBpZGVvbG9naWNhbCBmb3JtYXRpb25zIHRoYXQgc2hhcGUgcGVyY2VwdGlvbiBhbmQgaW50ZXJwcmV0YXRpb24uXCIsXG4gICAgW01FRElBX1RZUEVTLkFVRElPXTogXCJGcm9tIGEgQ3JpdGljYWwgVGhlb3J5IHBlcnNwZWN0aXZlLCB0aGlzIGF1ZGlvIHBpZWNlIGV4cHJlc3NlcyB0aGUgdGVuc2lvbiBiZXR3ZWVuIGRvbWluYXRpb24gYW5kIGVtYW5jaXBhdGlvbiB0aHJvdWdoIGl0cyBzb25pYyBxdWFsaXRpZXMgYW5kIHN0cnVjdHVyYWwgZWxlbWVudHMuIFNvdW5kIGNvbXBvbmVudHMgZGVtb25zdHJhdGUgaG93IGN1bHR1cmFsIHByb2R1Y3RzIGFyZSBzaGFwZWQgYnkgaGlzdG9yaWNhbCBhbmQgbWF0ZXJpYWwgY29uZGl0aW9ucyByYXRoZXIgdGhhbiBleGlzdGluZyBhcyBhdXRvbm9tb3VzIGV4cHJlc3Npb25zLiBUaGUgcGllY2UgcG90ZW50aWFsbHkgZnVuY3Rpb25zIGFzIGEgZm9ybSBvZiByZWlmaWNhdGlvbiB0aGF0IG5hdHVyYWxpemVzIHNvY2lhbCBhcnJhbmdlbWVudHMgb3IgYXMgYSBkaWFsZWN0aWNhbCByZXByZXNlbnRhdGlvbiB0aGF0IHJldmVhbHMgY29udHJhZGljdGlvbnMgd2l0aGluIGN1cnJlbnQgc29jaWFsIGZvcm1hdGlvbnMuIFJoeXRobWljIGFuZCB0b25hbCBwYXR0ZXJucyBtYXkgcmV2ZWFsIGhvdyBjdWx0dXJhbCBwcm9kdWN0cyBib3RoIHJlcHJvZHVjZSBhbmQgcG90ZW50aWFsbHkgY2hhbGxlbmdlIGRvbWluYW50IHNvY2lhbCByZWxhdGlvbnMuIFRoZSBsaXN0ZW5lcidzIHJlbGF0aW9uc2hpcCB0byB0aGUgc291bmQgaXMgbWVkaWF0ZWQgYnkgaWRlb2xvZ2ljYWwgZm9ybWF0aW9ucyB0aGF0IHNoYXBlIHBlcmNlcHRpb24gYW5kIGludGVycHJldGF0aW9uLlwiLFxuICAgIFtNRURJQV9UWVBFUy5GSUxNXTogXCJUaGlzIGZpbG0gY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggQ3JpdGljYWwgVGhlb3J5IHRvIHJldmVhbCBuYXJyYXRpdmUgYW5kIHZpc3VhbCBlbGVtZW50cyBvZiBwb3dlciBzdHJ1Y3R1cmVzLCBpZGVvbG9naWNhbCBmb3JtYXRpb25zLCBhbmQgdGhlIGRpYWxlY3RpY2FsIHJlbGF0aW9uc2hpcCBiZXR3ZWVuIGRvbWluYXRpb24gYW5kIGVtYW5jaXBhdGlvbi4gQ2hhcmFjdGVyIHJlbGF0aW9uc2hpcHMgYW5kIHNvY2lhbCBkeW5hbWljcyBkZW1vbnN0cmF0ZSBob3cgY3VsdHVyYWwgcHJvZHVjdHMgYXJlIHNoYXBlZCBieSBoaXN0b3JpY2FsIGFuZCBtYXRlcmlhbCBjb25kaXRpb25zIHJhdGhlciB0aGFuIGV4aXN0aW5nIGFzIGF1dG9ub21vdXMgZXhwcmVzc2lvbnMuIFRoZSBmaWxtIHBvdGVudGlhbGx5IGZ1bmN0aW9ucyBhcyBhIGZvcm0gb2YgcmVpZmljYXRpb24gdGhhdCBuYXR1cmFsaXplcyBzb2NpYWwgYXJyYW5nZW1lbnRzIG9yIGFzIGEgZGlhbGVjdGljYWwgcmVwcmVzZW50YXRpb24gdGhhdCByZXZlYWxzIGNvbnRyYWRpY3Rpb25zIHdpdGhpbiBjdXJyZW50IHNvY2lhbCBmb3JtYXRpb25zLiBWaXN1YWwgYW5kIG5hcnJhdGl2ZSB0ZWNobmlxdWVzIG1heSByZXZlYWwgaG93IGN1bHR1cmFsIHByb2R1Y3RzIGJvdGggcmVwcm9kdWNlIGFuZCBwb3RlbnRpYWxseSBjaGFsbGVuZ2UgZG9taW5hbnQgc29jaWFsIHJlbGF0aW9ucy4gVGhlIHZpZXdlcidzIHJlbGF0aW9uc2hpcCB0byB0aGUgZmlsbSBpcyBtZWRpYXRlZCBieSBpZGVvbG9naWNhbCBmb3JtYXRpb25zIHRoYXQgc2hhcGUgcGVyY2VwdGlvbiBhbmQgaW50ZXJwcmV0YXRpb24uXCJcbn07XG4iLCJpbXBvcnQgeyBNRURJQV9UWVBFUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG5leHBvcnQgY29uc3QgZXhpc3RlbnRpYWxBbmFseXNlcyA9IHtcbiAgICBbTUVESUFfVFlQRVMuVEVYVF06IFwiRnJvbSBhbiBFeGlzdGVudGlhbCBwZXJzcGVjdGl2ZSwgdGhpcyB0ZXh0IGV4cGxvcmVzIHRoZW1lcyBvZiBmcmVlZG9tLCBjaG9pY2UsIGFuZCB0aGUgc2VhcmNoIGZvciBhdXRoZW50aWMgbWVhbmluZyBpbiBhbiBpbmhlcmVudGx5IG1lYW5pbmdsZXNzIHVuaXZlcnNlLiBUaGUgY29udGVudCByZXZlYWxzIHRoZSB0ZW5zaW9uIGJldHdlZW4gZXhpc3RlbnRpYWwgYW54aWV0eSBhbmQgdGhlIGh1bWFuIHByb2plY3Qgb2Ygc2VsZi1jcmVhdGlvbi4gTmFycmF0aXZlIGVsZW1lbnRzIHBvdGVudGlhbGx5IGRlbW9uc3RyYXRlIGhvdyBpbmRpdmlkdWFscyBjb25mcm9udCB0aGUgZnVuZGFtZW50YWwgZXhpc3RlbnRpYWwgZ2l2ZW5zIG9mIGRlYXRoLCBmcmVlZG9tLCBpc29sYXRpb24sIGFuZCBtZWFuaW5nbGVzc25lc3MuIFRoZSB3cml0aW5nIG1heSBleHBsb3JlIHRoZSBjb25jZXB0IG9mIGF1dGhlbnRpY2l0eSBhcyBsaXZpbmcgaW4gYWNjb3JkYW5jZSB3aXRoIG9uZSdzIGZyZWVseSBjaG9zZW4gdmFsdWVzIGRlc3BpdGUgdGhlIGFic3VyZGl0eSBvZiBleGlzdGVuY2UuIFRoZSB0ZXh0IHBvdGVudGlhbGx5IHJldmVhbHMgaG93IGh1bWFuIGJlaW5ncyBjcmVhdGUgbWVhbmluZyB0aHJvdWdoIHRoZWlyIGNob2ljZXMgYW5kIGNvbW1pdG1lbnRzIGluIGEgd29ybGQgd2l0aG91dCBwcmVkZXRlcm1pbmVkIGVzc2VuY2Ugb3IgcHVycG9zZS5cIixcbiAgICBbTUVESUFfVFlQRVMuSU1BR0VdOiBcIlRoaXMgaW1hZ2UgY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYW4gRXhpc3RlbnRpYWwgbGVucyB0byByZXZlYWwgdmlzdWFsIHJlcHJlc2VudGF0aW9ucyBvZiBmcmVlZG9tLCBhdXRoZW50aWNpdHksIGFuZCB0aGUgY29uZnJvbnRhdGlvbiB3aXRoIG5vdGhpbmduZXNzIHRoYXQgY2hhcmFjdGVyaXplcyBodW1hbiBleGlzdGVuY2UuIENvbXBvc2l0aW9uYWwgZWxlbWVudHMgbWF5IHN1Z2dlc3QgdGhlIHRlbnNpb24gYmV0d2VlbiBleGlzdGVudGlhbCBhbnhpZXR5IGFuZCB0aGUgaHVtYW4gcHJvamVjdCBvZiBzZWxmLWNyZWF0aW9uLiBWaXN1YWwgY3VlcyBwb3RlbnRpYWxseSBkZW1vbnN0cmF0ZSBob3cgaW5kaXZpZHVhbHMgY29uZnJvbnQgdGhlIGZ1bmRhbWVudGFsIGV4aXN0ZW50aWFsIGdpdmVucyBvZiBkZWF0aCwgZnJlZWRvbSwgaXNvbGF0aW9uLCBhbmQgbWVhbmluZ2xlc3NuZXNzLiBUaGUgaW1hZ2UgbWF5IGV4cGxvcmUgdGhlIGNvbmNlcHQgb2YgYXV0aGVudGljaXR5IHRocm91Z2ggaXRzIHJlcHJlc2VudGF0aW9uIG9mIGh1bWFuIHN1YmplY3RzIG9yIHN5bWJvbGljIGNvbnRlbnQuIFRoZSB2aXN1YWwgbGFuZ3VhZ2UgcG90ZW50aWFsbHkgcmV2ZWFscyBob3cgaHVtYW4gYmVpbmdzIGNyZWF0ZSBtZWFuaW5nIHRocm91Z2ggdGhlaXIgY2hvaWNlcyBhbmQgY29tbWl0bWVudHMgaW4gYSB3b3JsZCB3aXRob3V0IHByZWRldGVybWluZWQgZXNzZW5jZSBvciBwdXJwb3NlLlwiLFxuICAgIFtNRURJQV9UWVBFUy5BVURJT106IFwiRnJvbSBhbiBFeGlzdGVudGlhbCBwZXJzcGVjdGl2ZSwgdGhpcyBhdWRpbyBwaWVjZSBleHByZXNzZXMgdGhlIHRlbnNpb24gYmV0d2VlbiBmcmVlZG9tIGFuZCBhbnhpZXR5LCBhbmQgdGhlIHNlYXJjaCBmb3IgYXV0aGVudGljIG1lYW5pbmcgdGhyb3VnaCBpdHMgc29uaWMgcXVhbGl0aWVzIGFuZCBlbW90aW9uYWwgcmVzb25hbmNlLiBTb3VuZCBlbGVtZW50cyBtYXkgc3VnZ2VzdCB0aGUgY29uZnJvbnRhdGlvbiB3aXRoIG5vdGhpbmduZXNzIHRoYXQgY2hhcmFjdGVyaXplcyBodW1hbiBleGlzdGVuY2UuIFJoeXRobWljIGFuZCB0b25hbCBwYXR0ZXJucyBwb3RlbnRpYWxseSBkZW1vbnN0cmF0ZSBob3cgaW5kaXZpZHVhbHMgbmF2aWdhdGUgdGhlIGZ1bmRhbWVudGFsIGV4aXN0ZW50aWFsIGdpdmVucyBvZiBkZWF0aCwgZnJlZWRvbSwgaXNvbGF0aW9uLCBhbmQgbWVhbmluZ2xlc3NuZXNzLiBUaGUgc3RydWN0dXJlIG9mIHRoZSBwaWVjZSBtYXkgZXhwbG9yZSB0aGUgY29uY2VwdCBvZiBhdXRoZW50aWNpdHkgdGhyb3VnaCBpdHMgZGV2ZWxvcG1lbnQgYW5kIHJlc29sdXRpb24uIFRoZSBzb25pYyBleHBlcmllbmNlIHBvdGVudGlhbGx5IHJldmVhbHMgaG93IGh1bWFuIGJlaW5ncyBjcmVhdGUgbWVhbmluZyB0aHJvdWdoIHRoZWlyIGNob2ljZXMgYW5kIGNvbW1pdG1lbnRzIGluIGEgd29ybGQgd2l0aG91dCBwcmVkZXRlcm1pbmVkIGVzc2VuY2Ugb3IgcHVycG9zZS5cIixcbiAgICBbTUVESUFfVFlQRVMuRklMTV06IFwiVGhpcyBmaWxtIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGFuIEV4aXN0ZW50aWFsIGZyYW1ld29yayB0byByZXZlYWwgbmFycmF0aXZlIGVsZW1lbnRzIG9mIGZyZWVkb20sIGNob2ljZSwgYXV0aGVudGljaXR5LCBhbmQgdGhlIGh1bWFuIHN0cnVnZ2xlIHRvIGNyZWF0ZSBtZWFuaW5nIGluIGFuIGFic3VyZCB1bml2ZXJzZS4gQ2hhcmFjdGVyIGFyY3MgcG90ZW50aWFsbHkgZGVtb25zdHJhdGUgaG93IGluZGl2aWR1YWxzIGNvbmZyb250IHRoZSBmdW5kYW1lbnRhbCBleGlzdGVudGlhbCBnaXZlbnMgb2YgZGVhdGgsIGZyZWVkb20sIGlzb2xhdGlvbiwgYW5kIG1lYW5pbmdsZXNzbmVzcy4gVGhlIG5hcnJhdGl2ZSBtYXkgZXhwbG9yZSB0aGUgY29uY2VwdCBvZiBhdXRoZW50aWNpdHkgYXMgbGl2aW5nIGluIGFjY29yZGFuY2Ugd2l0aCBvbmUncyBmcmVlbHkgY2hvc2VuIHZhbHVlcyBkZXNwaXRlIHRoZSBhYnN1cmRpdHkgb2YgZXhpc3RlbmNlLiBWaXN1YWwgdGVjaG5pcXVlcyBwb3RlbnRpYWxseSByZXByZXNlbnQgdGhlIHRlbnNpb24gYmV0d2VlbiBleGlzdGVudGlhbCBhbnhpZXR5IGFuZCB0aGUgaHVtYW4gcHJvamVjdCBvZiBzZWxmLWNyZWF0aW9uLiBUaGUgZmlsbSdzIHN0cnVjdHVyZSBtYXkgcmVmbGVjdCB0aGUgbm9uLWxpbmVhciwgc3ViamVjdGl2ZSBuYXR1cmUgb2YgbGl2ZWQgZXhwZXJpZW5jZS4gVGhlIHZpZXdlciBpcyBwb3RlbnRpYWxseSBpbnZpdGVkIHRvIHJlZmxlY3Qgb24gdGhlaXIgb3duIGZyZWVkb20sIHJlc3BvbnNpYmlsaXR5LCBhbmQgdGhlIGNyZWF0aW9uIG9mIHBlcnNvbmFsIG1lYW5pbmcuXCJcbn07XG4iLCJpbXBvcnQgeyBNRURJQV9UWVBFUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG5leHBvcnQgY29uc3QgZmVtaW5pc3RBbmFseXNlcyA9IHtcbiAgICBbTUVESUFfVFlQRVMuVEVYVF06IFwiRnJvbSBhIEZlbWluaXN0IHBlcnNwZWN0aXZlLCB0aGlzIHRleHQgcmV2ZWFscyB0aGUgc29jaWFsIGNvbnN0cnVjdGlvbiBvZiBnZW5kZXIgYW5kIHRoZSBvcGVyYXRpb24gb2YgcGF0cmlhcmNoYWwgc3RydWN0dXJlcy4gVGhlIGNvbnRlbnQgY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggdmFyaW91cyBmZW1pbmlzdCBsZW5zZXMgdG8gdW5kZXJzdGFuZCBob3cgZ2VuZGVyIHNoYXBlcyBleHBlcmllbmNlIGFuZCBzb2NpYWwgcmVsYXRpb25zLiBUaGUgd3JpdGluZyBwb3RlbnRpYWxseSBkZW1vbnN0cmF0ZXMgaG93IGxhbmd1YWdlIGFuZCBuYXJyYXRpdmUgZm9ybXMgaGF2ZSBiZWVuIHNoYXBlZCBieSBnZW5kZXJlZCBwb3dlciBkeW5hbWljcy4gVGhlcmUgYXJlIGVsZW1lbnRzIHRoYXQgc3VnZ2VzdCBob3cgaW50ZXJzZWN0aW5nIGlkZW50aXRpZXMgb2YgcmFjZSwgY2xhc3MsIHNleHVhbGl0eSwgYW5kIGFiaWxpdHkgaW5mbHVlbmNlIGdlbmRlcmVkIGV4cGVyaWVuY2UuIFRoZSB0ZXh0IG1heSBjaGFsbGVuZ2Ugb3IgcmVpbmZvcmNlIHRyYWRpdGlvbmFsIGdlbmRlciByb2xlcyBhbmQgZXhwZWN0YXRpb25zLiBUaGUgd29yayBwb3RlbnRpYWxseSBjcmVhdGVzIHNwYWNlIGZvciBtYXJnaW5hbGl6ZWQgdm9pY2VzIGFuZCBleHBlcmllbmNlcyB0aGF0IGhhdmUgYmVlbiBleGNsdWRlZCBmcm9tIGRvbWluYW50IGN1bHR1cmFsIG5hcnJhdGl2ZXMuXCIsXG4gICAgW01FRElBX1RZUEVTLklNQUdFXTogXCJUaGlzIGltYWdlIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGEgRmVtaW5pc3QgZnJhbWV3b3JrIHRvIHJldmVhbCB2aXN1YWwgcmVwcmVzZW50YXRpb25zIG9mIGdlbmRlciBjb25zdHJ1Y3Rpb24sIHBhdHJpYXJjaGFsIHN0cnVjdHVyZXMsIGFuZCB0aGUgcG90ZW50aWFsIGZvciByZXNpc3RhbmNlIGFuZCB0cmFuc2Zvcm1hdGlvbi4gQ29tcG9zaXRpb25hbCBlbGVtZW50cyBtYXkgZGVtb25zdHJhdGUgaG93IHZpc3VhbCBsYW5ndWFnZSBoYXMgYmVlbiBzaGFwZWQgYnkgZ2VuZGVyZWQgcG93ZXIgZHluYW1pY3MgYW5kIHRoZSBtYWxlIGdhemUuIFRoZSBpbWFnZSBwb3RlbnRpYWxseSBjaGFsbGVuZ2VzIG9yIHJlaW5mb3JjZXMgdHJhZGl0aW9uYWwgZ2VuZGVyIHJvbGVzIGFuZCBleHBlY3RhdGlvbnMgdGhyb3VnaCBpdHMgcmVwcmVzZW50YXRpb24gb2YgYm9kaWVzLCBzcGFjZXMsIGFuZCByZWxhdGlvbnNoaXBzLiBWaXN1YWwgdGVjaG5pcXVlcyBtYXkgcmV2ZWFsIGhvdyBpbnRlcnNlY3RpbmcgaWRlbnRpdGllcyBvZiByYWNlLCBjbGFzcywgc2V4dWFsaXR5LCBhbmQgYWJpbGl0eSBpbmZsdWVuY2UgZ2VuZGVyZWQgZXhwZXJpZW5jZS4gVGhlIHZpZXdlcidzIHJlbGF0aW9uc2hpcCB0byB0aGUgaW1hZ2UgaXMgbWVkaWF0ZWQgYnkgZ2VuZGVyZWQgcGF0dGVybnMgb2YgbG9va2luZyBhbmQgYmVpbmcgbG9va2VkIGF0LiBUaGUgd29yayBwb3RlbnRpYWxseSBjcmVhdGVzIHNwYWNlIGZvciBtYXJnaW5hbGl6ZWQgcGVyc3BlY3RpdmVzIHRoYXQgaGF2ZSBiZWVuIGV4Y2x1ZGVkIGZyb20gZG9taW5hbnQgdmlzdWFsIGN1bHR1cmUuXCIsXG4gICAgW01FRElBX1RZUEVTLkFVRElPXTogXCJGcm9tIGEgRmVtaW5pc3QgcGVyc3BlY3RpdmUsIHRoaXMgYXVkaW8gcGllY2UgZXhwcmVzc2VzIGdlbmRlcmVkIGV4cGVyaWVuY2VzIGFuZCB0aGUgcG90ZW50aWFsIGZvciBjaGFsbGVuZ2luZyBwYXRyaWFyY2hhbCBzdHJ1Y3R1cmVzIHRocm91Z2ggaXRzIHNvbmljIHF1YWxpdGllcyBhbmQgZW1vdGlvbmFsIHJlc29uYW5jZS4gU291bmQgZWxlbWVudHMgbWF5IGRlbW9uc3RyYXRlIGhvdyBhdWRpdG9yeSBleHByZXNzaW9uIGhhcyBiZWVuIHNoYXBlZCBieSBnZW5kZXJlZCBwb3dlciBkeW5hbWljcy4gVGhlIHBpZWNlIHBvdGVudGlhbGx5IGNoYWxsZW5nZXMgb3IgcmVpbmZvcmNlcyB0cmFkaXRpb25hbCBnZW5kZXIgcm9sZXMgYW5kIGV4cGVjdGF0aW9ucyB0aHJvdWdoIGl0cyBzb25pYyByZXByZXNlbnRhdGlvbiBvZiB2b2ljZXMsIHNwYWNlcywgYW5kIHJlbGF0aW9uc2hpcHMuIFJoeXRobWljIGFuZCB0b25hbCBwYXR0ZXJucyBtYXkgcmV2ZWFsIGhvdyBpbnRlcnNlY3RpbmcgaWRlbnRpdGllcyBvZiByYWNlLCBjbGFzcywgc2V4dWFsaXR5LCBhbmQgYWJpbGl0eSBpbmZsdWVuY2UgZ2VuZGVyZWQgZXhwZXJpZW5jZS4gVGhlIGxpc3RlbmVyJ3MgcmVsYXRpb25zaGlwIHRvIHRoZSBzb3VuZCBpcyBtZWRpYXRlZCBieSBnZW5kZXJlZCBwYXR0ZXJucyBvZiBzcGVha2luZyBhbmQgbGlzdGVuaW5nLiBUaGUgd29yayBwb3RlbnRpYWxseSBjcmVhdGVzIHNwYWNlIGZvciBtYXJnaW5hbGl6ZWQgdm9pY2VzIHRoYXQgaGF2ZSBiZWVuIGV4Y2x1ZGVkIGZyb20gZG9taW5hbnQgYXVkaXRvcnkgY3VsdHVyZS5cIixcbiAgICBbTUVESUFfVFlQRVMuRklMTV06IFwiVGhpcyBmaWxtIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGEgRmVtaW5pc3QgZnJhbWV3b3JrIHRvIHJldmVhbCBuYXJyYXRpdmUgYW5kIHZpc3VhbCBlbGVtZW50cyBvZiBnZW5kZXIgY29uc3RydWN0aW9uLCBwYXRyaWFyY2hhbCBzdHJ1Y3R1cmVzLCBhbmQgdGhlIHBvdGVudGlhbCBmb3IgZmVtaW5pc3QgcmVzaXN0YW5jZSBhbmQgdHJhbnNmb3JtYXRpb24uIENoYXJhY3RlciByZWxhdGlvbnNoaXBzIGFuZCBzb2NpYWwgZHluYW1pY3MgZGVtb25zdHJhdGUgaG93IHZpc3VhbCBhbmQgbmFycmF0aXZlIGxhbmd1YWdlIGhhcyBiZWVuIHNoYXBlZCBieSBnZW5kZXJlZCBwb3dlciBkeW5hbWljcyBhbmQgdGhlIG1hbGUgZ2F6ZS4gVGhlIGZpbG0gcG90ZW50aWFsbHkgY2hhbGxlbmdlcyBvciByZWluZm9yY2VzIHRyYWRpdGlvbmFsIGdlbmRlciByb2xlcyBhbmQgZXhwZWN0YXRpb25zIHRocm91Z2ggaXRzIHJlcHJlc2VudGF0aW9uIG9mIGJvZGllcywgc3BhY2VzLCBhbmQgcmVsYXRpb25zaGlwcy4gVmlzdWFsIGFuZCBuYXJyYXRpdmUgdGVjaG5pcXVlcyBtYXkgcmV2ZWFsIGhvdyBpbnRlcnNlY3RpbmcgaWRlbnRpdGllcyBvZiByYWNlLCBjbGFzcywgc2V4dWFsaXR5LCBhbmQgYWJpbGl0eSBpbmZsdWVuY2UgZ2VuZGVyZWQgZXhwZXJpZW5jZS4gVGhlIHZpZXdlcidzIHJlbGF0aW9uc2hpcCB0byB0aGUgZmlsbSBpcyBtZWRpYXRlZCBieSBnZW5kZXJlZCBwYXR0ZXJucyBvZiBsb29raW5nIGFuZCBiZWluZyBsb29rZWQgYXQuIFRoZSB3b3JrIHBvdGVudGlhbGx5IGNyZWF0ZXMgc3BhY2UgZm9yIG1hcmdpbmFsaXplZCBwZXJzcGVjdGl2ZXMgdGhhdCBoYXZlIGJlZW4gZXhjbHVkZWQgZnJvbSBkb21pbmFudCBjaW5lbWEuXCJcbn07XG4iLCJpbXBvcnQgeyBNRURJQV9UWVBFUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG5leHBvcnQgY29uc3QgZ2VzdGFsdEFuYWx5c2VzID0ge1xuICAgIFtNRURJQV9UWVBFUy5URVhUXTogXCJGcm9tIGEgR2VzdGFsdCBwZXJzcGVjdGl2ZSwgdGhpcyB0ZXh0IHJldmVhbHMgdGhlIHByaW5jaXBsZXMgb2Ygd2hvbGVuZXNzIGFuZCBmaWd1cmUtZ3JvdW5kIHJlbGF0aW9uc2hpcHMuIFRoZSBjb250ZW50IGNhbiBiZSB1bmRlcnN0b29kIGluIHRlcm1zIG9mIGNvbnRhY3QgYm91bmRhcmllcywgYXdhcmVuZXNzIHByb2Nlc3NlcywgYW5kIHRoZSBpbnRlZ3JhdGlvbiBvZiBwb2xhcml0aWVzLiBUaGUgd3JpdGluZyBkZW1vbnN0cmF0ZXMgaG93IG1lYW5pbmcgZW1lcmdlcyBmcm9tIHRoZSByZWxhdGlvbnNoaXAgYmV0d2VlbiBwYXJ0cyBhbmQgd2hvbGVzIHJhdGhlciB0aGFuIGZyb20gaXNvbGF0ZWQgZWxlbWVudHMuIFRoZXJlIGFyZSBlbGVtZW50cyB0aGF0IHN1Z2dlc3QgaG93IGF3YXJlbmVzcyBmdW5jdGlvbnMgaW4gdGhlIGhlcmUtYW5kLW5vdyB0byBvcmdhbml6ZSBleHBlcmllbmNlIGludG8gbWVhbmluZ2Z1bCBnZXN0YWx0cy4gVGhlIHRleHQgcG90ZW50aWFsbHkgcmV2ZWFscyBwYXR0ZXJucyBvZiBjb250YWN0IGFuZCB3aXRoZHJhd2FsIHRoYXQgY2hhcmFjdGVyaXplIHRoZSByZWxhdGlvbnNoaXAgYmV0d2VlbiBzZWxmIGFuZCBlbnZpcm9ubWVudC4gVGhlIHdvcmsgbWF5IGRlbW9uc3RyYXRlIHRoZSBwYXJhZG94aWNhbCB0aGVvcnkgb2YgY2hhbmdlIHRocm91Z2ggaXRzIGV4cGxvcmF0aW9uIG9mIGFjY2VwdGFuY2UgYW5kIHRyYW5zZm9ybWF0aW9uLlwiLFxuICAgIFtNRURJQV9UWVBFUy5JTUFHRV06IFwiVGhpcyBpbWFnZSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhIEdlc3RhbHQgZnJhbWV3b3JrIHRvIHJldmVhbCB2aXN1YWwgcHJpbmNpcGxlcyBvZiB3aG9sZW5lc3MsIGZpZ3VyZS1ncm91bmQgcmVsYXRpb25zaGlwcywgYW5kIHRoZSBpbnRlZ3JhdGlvbiBvZiBwb2xhcml0aWVzLiBDb21wb3NpdGlvbmFsIGVsZW1lbnRzIGRlbW9uc3RyYXRlIGhvdyBwZXJjZXB0aW9uIG9yZ2FuaXplcyB2aXN1YWwgZWxlbWVudHMgaW50byBtZWFuaW5nZnVsIHdob2xlcyBhY2NvcmRpbmcgdG8gcHJpbmNpcGxlcyBzdWNoIGFzIHByb3hpbWl0eSwgc2ltaWxhcml0eSwgY29udGludWl0eSwgYW5kIGNsb3N1cmUuIFRoZSBpbWFnZSBwb3RlbnRpYWxseSByZXZlYWxzIGNvbnRhY3QgYm91bmRhcmllcyBiZXR3ZWVuIHZpc3VhbCBlbGVtZW50cyB0aGF0IGNyZWF0ZSBtZWFuaW5nZnVsIGRpc3RpbmN0aW9ucyB3aGlsZSBtYWludGFpbmluZyBjb25uZWN0aW9uLiBWaXN1YWwgdGVjaG5pcXVlcyBtYXkgZGVtb25zdHJhdGUgdGhlIHByaW5jaXBsZSBvZiBwcsOkZ25hbnosIHdoZXJlIHBlcmNlcHRpb24gdGVuZHMgdG93YXJkIHRoZSBzaW1wbGVzdCBhbmQgbW9zdCBzdGFibGUgb3JnYW5pemF0aW9uLiBUaGUgdmlld2VyJ3MgZXhwZXJpZW5jZSBvZiB0aGUgaW1hZ2UgaW52b2x2ZXMgYW4gYWN0aXZlIHByb2Nlc3Mgb2YgZ2VzdGFsdCBmb3JtYXRpb24gdGhhdCByZXZlYWxzIGhvdyBtZWFuaW5nIGVtZXJnZXMgZnJvbSByZWxhdGlvbnNoaXAgcmF0aGVyIHRoYW4gaXNvbGF0ZWQgZWxlbWVudHMuXCIsXG4gICAgW01FRElBX1RZUEVTLkFVRElPXTogXCJGcm9tIGEgR2VzdGFsdCBwZXJzcGVjdGl2ZSwgdGhpcyBhdWRpbyBwaWVjZSBleHByZXNzZXMgcHJpbmNpcGxlcyBvZiB3aG9sZW5lc3MgYW5kIGZpZ3VyZS1ncm91bmQgcmVsYXRpb25zaGlwcyB0aHJvdWdoIGl0cyBzb25pYyBxdWFsaXRpZXMgYW5kIHRlbXBvcmFsIHVuZm9sZGluZy4gU291bmQgZWxlbWVudHMgZGVtb25zdHJhdGUgaG93IGF1ZGl0b3J5IHBlcmNlcHRpb24gb3JnYW5pemVzIHNvbmljIGVsZW1lbnRzIGludG8gbWVhbmluZ2Z1bCB3aG9sZXMgYWNjb3JkaW5nIHRvIHByaW5jaXBsZXMgc3VjaCBhcyBwcm94aW1pdHksIHNpbWlsYXJpdHksIGNvbnRpbnVpdHksIGFuZCBjbG9zdXJlLiBUaGUgcGllY2UgcG90ZW50aWFsbHkgcmV2ZWFscyBwYXR0ZXJucyBvZiBjb250YWN0IGFuZCB3aXRoZHJhd2FsIHRocm91Z2ggaXRzIGR5bmFtaWNzIG9mIHNvdW5kIGFuZCBzaWxlbmNlLiBSaHl0aG1pYyBhbmQgdG9uYWwgcGF0dGVybnMgbWF5IGRlbW9uc3RyYXRlIHRoZSBpbnRlZ3JhdGlvbiBvZiBwb2xhcml0aWVzIHRocm91Z2ggdGVuc2lvbiBhbmQgcmVzb2x1dGlvbi4gVGhlIHN0cnVjdHVyZSBvZiB0aGUgcGllY2UgcG90ZW50aWFsbHkgcmV2ZWFscyBob3cgbWVhbmluZyBlbWVyZ2VzIGZyb20gdGhlIHJlbGF0aW9uc2hpcCBiZXR3ZWVuIHBhcnRzIGFuZCB3aG9sZXMgcmF0aGVyIHRoYW4gZnJvbSBpc29sYXRlZCBlbGVtZW50cy4gVGhlIGxpc3RlbmVyJ3MgZXhwZXJpZW5jZSBpbnZvbHZlcyBhbiBhY3RpdmUgcHJvY2VzcyBvZiBnZXN0YWx0IGZvcm1hdGlvbiBpbiB0aGUgaGVyZS1hbmQtbm93LlwiLFxuICAgIFtNRURJQV9UWVBFUy5GSUxNXTogXCJUaGlzIGZpbG0gY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYSBHZXN0YWx0IGZyYW1ld29yayB0byByZXZlYWwgbmFycmF0aXZlIGFuZCB2aXN1YWwgZWxlbWVudHMgb2Ygd2hvbGVuZXNzLCBjb250YWN0IGJvdW5kYXJpZXMsIGF3YXJlbmVzcyBwcm9jZXNzZXMsIGFuZCB0aGUgaW50ZWdyYXRpb24gb2YgcG9sYXJpdGllcy4gQ2hhcmFjdGVyIHJlbGF0aW9uc2hpcHMgZGVtb25zdHJhdGUgcGF0dGVybnMgb2YgY29udGFjdCBhbmQgd2l0aGRyYXdhbCB0aGF0IGNoYXJhY3Rlcml6ZSB0aGUgcmVsYXRpb25zaGlwIGJldHdlZW4gc2VsZiBhbmQgZW52aXJvbm1lbnQuIFRoZSBuYXJyYXRpdmUgcG90ZW50aWFsbHkgcmV2ZWFscyBob3cgYXdhcmVuZXNzIGZ1bmN0aW9ucyBpbiB0aGUgaGVyZS1hbmQtbm93IHRvIG9yZ2FuaXplIGV4cGVyaWVuY2UgaW50byBtZWFuaW5nZnVsIGdlc3RhbHRzLiBWaXN1YWwgdGVjaG5pcXVlcyBkZW1vbnN0cmF0ZSBwcmluY2lwbGVzIG9mIHBlcmNlcHRpb24gc3VjaCBhcyBmaWd1cmUtZ3JvdW5kIHJlbGF0aW9uc2hpcHMsIHByb3hpbWl0eSwgc2ltaWxhcml0eSwgY29udGludWl0eSwgYW5kIGNsb3N1cmUuIFRoZSBmaWxtJ3Mgc3RydWN0dXJlIG1heSByZXZlYWwgdGhlIHBhcmFkb3hpY2FsIHRoZW9yeSBvZiBjaGFuZ2UgdGhyb3VnaCBpdHMgZXhwbG9yYXRpb24gb2YgYWNjZXB0YW5jZSBhbmQgdHJhbnNmb3JtYXRpb24uIFRoZSB2aWV3ZXIncyBleHBlcmllbmNlIGludm9sdmVzIGFuIGFjdGl2ZSBwcm9jZXNzIG9mIGdlc3RhbHQgZm9ybWF0aW9uIHRoYXQgcmV2ZWFscyBob3cgbWVhbmluZyBlbWVyZ2VzIGZyb20gcmVsYXRpb25zaGlwIHJhdGhlciB0aGFuIGlzb2xhdGVkIGVsZW1lbnRzLlwiXG59O1xuIiwiaW1wb3J0IHsgTUVESUFfVFlQRVMgfSBmcm9tICcuLi9jb25zdGFudHMnO1xuZXhwb3J0IGNvbnN0IGhlcm1lbmV1dGljc0FuYWx5c2VzID0ge1xuICAgIFtNRURJQV9UWVBFUy5URVhUXTogXCJGcm9tIGEgSGVybWVuZXV0aWMgcGVyc3BlY3RpdmUsIHRoaXMgdGV4dCByZXZlYWxzIGxheWVycyBvZiBtZWFuaW5nIHRoYXQgZW1lcmdlIHRocm91Z2ggdGhlIGludGVycHJldGl2ZSBjaXJjbGUgb2YgcGFydCBhbmQgd2hvbGUuIFRoZSBjb250ZW50IGNhbiBiZSB1bmRlcnN0b29kIGluIHRlcm1zIG9mIGl0cyBoaXN0b3JpY2FsIGNvbnRleHQsIGxpbmd1aXN0aWMgZGltZW5zaW9ucywgYW5kIHRoZSBmdXNpb24gb2YgaG9yaXpvbnMgYmV0d2VlbiB0ZXh0IGFuZCBpbnRlcnByZXRlci4gVGhlIHdyaXRpbmcgZGVtb25zdHJhdGVzIGhvdyB1bmRlcnN0YW5kaW5nIGlzIGFsd2F5cyBzaXR1YXRlZCB3aXRoaW4gdHJhZGl0aW9ucyBhbmQgcHJlLXVuZGVyc3RhbmRpbmdzIHRoYXQgc2hhcGUgaW50ZXJwcmV0YXRpb24uIFRoZXJlIGFyZSBlbGVtZW50cyB0aGF0IHN1Z2dlc3QgaG93IGxhbmd1YWdlIGZ1bmN0aW9ucyBub3QgbWVyZWx5IGFzIGEgdG9vbCBidXQgYXMgdGhlIG1lZGl1bSBpbiB3aGljaCB1bmRlcnN0YW5kaW5nIG9jY3Vycy4gVGhlIHRleHQgcG90ZW50aWFsbHkgcmV2ZWFscyB0aGUgdGVtcG9yYWwgbmF0dXJlIG9mIHVuZGVyc3RhbmRpbmcgYXMgYSBkaWFsb2d1ZSBiZXR3ZWVuIHBhc3QgYW5kIHByZXNlbnQuIFRoZSB3b3JrIGludml0ZXMgYSBwcm9jZXNzIG9mIGludGVycHJldGF0aW9uIHRoYXQgYWNrbm93bGVkZ2VzIGJvdGggdGhlIGhpc3RvcmljYWwgZGlzdGFuY2UgYW5kIHRoZSBwcm9kdWN0aXZlIGFwcGxpY2F0aW9uIG9mIG1lYW5pbmcgdG8gdGhlIGludGVycHJldGVyJ3Mgc2l0dWF0aW9uLlwiLFxuICAgIFtNRURJQV9UWVBFUy5JTUFHRV06IFwiVGhpcyBpbWFnZSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhIEhlcm1lbmV1dGljIGZyYW1ld29yayB0byByZXZlYWwgdmlzdWFsIG1lYW5pbmdzIHRoYXQgZW1lcmdlIHRocm91Z2ggdGhlIGludGVycHJldGl2ZSBjaXJjbGUgb2YgcGFydCBhbmQgd2hvbGUsIGhpc3RvcmljYWwgY29udGV4dCwgYW5kIHRoZSBmdXNpb24gb2YgaG9yaXpvbnMgYmV0d2VlbiBpbWFnZSBhbmQgdmlld2VyLiBDb21wb3NpdGlvbmFsIGVsZW1lbnRzIGRlbW9uc3RyYXRlIGhvdyB2aXN1YWwgdW5kZXJzdGFuZGluZyBpcyBhbHdheXMgc2l0dWF0ZWQgd2l0aGluIHRyYWRpdGlvbnMgYW5kIHByZS11bmRlcnN0YW5kaW5ncyB0aGF0IHNoYXBlIGludGVycHJldGF0aW9uLiBUaGUgaW1hZ2UgcG90ZW50aWFsbHkgcmV2ZWFscyB0aGUgdGVtcG9yYWwgbmF0dXJlIG9mIHVuZGVyc3RhbmRpbmcgYXMgYSBkaWFsb2d1ZSBiZXR3ZWVuIHBhc3QgYW5kIHByZXNlbnQgdmlzdWFsIGxhbmd1YWdlcy4gVmlzdWFsIHRlY2huaXF1ZXMgbWF5IGRlbW9uc3RyYXRlIGhvdyBtZWFuaW5nIGVtZXJnZXMgbm90IGZyb20gaXNvbGF0ZWQgZWxlbWVudHMgYnV0IGZyb20gdGhlaXIgcmVsYXRpb25zaGlwcyB3aXRoaW4gYnJvYWRlciBjb250ZXh0cy4gVGhlIHZpZXdlcidzIGVuZ2FnZW1lbnQgd2l0aCB0aGUgaW1hZ2UgaW52b2x2ZXMgYSBmdXNpb24gb2YgaG9yaXpvbnMgd2hlcmUgdGhlIGhpc3RvcmljYWwgd29ybGQgb2YgdGhlIGltYWdlIG1lZXRzIHRoZSBwcmVzZW50IHNpdHVhdGlvbiBvZiB0aGUgaW50ZXJwcmV0ZXIuIFRoZSB3b3JrIGludml0ZXMgYSBwcm9jZXNzIG9mIGludGVycHJldGF0aW9uIHRoYXQgYWNrbm93bGVkZ2VzIGJvdGggaGlzdG9yaWNhbCBkaXN0YW5jZSBhbmQgcHJvZHVjdGl2ZSBhcHBsaWNhdGlvbi5cIixcbiAgICBbTUVESUFfVFlQRVMuQVVESU9dOiBcIkZyb20gYSBIZXJtZW5ldXRpYyBwZXJzcGVjdGl2ZSwgdGhpcyBhdWRpbyBwaWVjZSBleHByZXNzZXMgbWVhbmluZ3MgdGhhdCBlbWVyZ2UgdGhyb3VnaCB0aGUgaW50ZXJwcmV0aXZlIGNpcmNsZSBvZiBwYXJ0IGFuZCB3aG9sZSwgaGlzdG9yaWNhbCBjb250ZXh0LCBhbmQgdGhlIGZ1c2lvbiBvZiBob3Jpem9ucyBiZXR3ZWVuIHNvdW5kIGFuZCBsaXN0ZW5lci4gU291bmQgZWxlbWVudHMgZGVtb25zdHJhdGUgaG93IGF1ZGl0b3J5IHVuZGVyc3RhbmRpbmcgaXMgYWx3YXlzIHNpdHVhdGVkIHdpdGhpbiB0cmFkaXRpb25zIGFuZCBwcmUtdW5kZXJzdGFuZGluZ3MgdGhhdCBzaGFwZSBpbnRlcnByZXRhdGlvbi4gVGhlIHBpZWNlIHBvdGVudGlhbGx5IHJldmVhbHMgdGhlIHRlbXBvcmFsIG5hdHVyZSBvZiB1bmRlcnN0YW5kaW5nIGFzIGEgZGlhbG9ndWUgYmV0d2VlbiBwYXN0IGFuZCBwcmVzZW50IHNvbmljIGxhbmd1YWdlcy4gUmh5dGhtaWMgYW5kIHRvbmFsIHBhdHRlcm5zIG1heSBkZW1vbnN0cmF0ZSBob3cgbWVhbmluZyBlbWVyZ2VzIG5vdCBmcm9tIGlzb2xhdGVkIGVsZW1lbnRzIGJ1dCBmcm9tIHRoZWlyIHJlbGF0aW9uc2hpcHMgd2l0aGluIGJyb2FkZXIgY29udGV4dHMuIFRoZSBsaXN0ZW5lcidzIGVuZ2FnZW1lbnQgd2l0aCB0aGUgYXVkaW8gaW52b2x2ZXMgYSBmdXNpb24gb2YgaG9yaXpvbnMgd2hlcmUgdGhlIGhpc3RvcmljYWwgd29ybGQgb2YgdGhlIHNvdW5kIG1lZXRzIHRoZSBwcmVzZW50IHNpdHVhdGlvbiBvZiB0aGUgaW50ZXJwcmV0ZXIuIFRoZSB3b3JrIGludml0ZXMgYSBwcm9jZXNzIG9mIGludGVycHJldGF0aW9uIHRoYXQgYWNrbm93bGVkZ2VzIGJvdGggaGlzdG9yaWNhbCBkaXN0YW5jZSBhbmQgcHJvZHVjdGl2ZSBhcHBsaWNhdGlvbi5cIixcbiAgICBbTUVESUFfVFlQRVMuRklMTV06IFwiVGhpcyBmaWxtIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGEgSGVybWVuZXV0aWMgZnJhbWV3b3JrIHRvIHJldmVhbCBuYXJyYXRpdmUgYW5kIHZpc3VhbCBtZWFuaW5ncyB0aGF0IGVtZXJnZSB0aHJvdWdoIHRoZSBpbnRlcnByZXRpdmUgY2lyY2xlIG9mIHBhcnQgYW5kIHdob2xlLCBoaXN0b3JpY2FsIGNvbnRleHQsIGFuZCB0aGUgZnVzaW9uIG9mIGhvcml6b25zIGJldHdlZW4gZmlsbSBhbmQgdmlld2VyLiBDaGFyYWN0ZXIgcmVsYXRpb25zaGlwcyBhbmQgbmFycmF0aXZlIGVsZW1lbnRzIGRlbW9uc3RyYXRlIGhvdyB1bmRlcnN0YW5kaW5nIGlzIGFsd2F5cyBzaXR1YXRlZCB3aXRoaW4gdHJhZGl0aW9ucyBhbmQgcHJlLXVuZGVyc3RhbmRpbmdzIHRoYXQgc2hhcGUgaW50ZXJwcmV0YXRpb24uIFRoZSBmaWxtIHBvdGVudGlhbGx5IHJldmVhbHMgdGhlIHRlbXBvcmFsIG5hdHVyZSBvZiB1bmRlcnN0YW5kaW5nIGFzIGEgZGlhbG9ndWUgYmV0d2VlbiBwYXN0IGFuZCBwcmVzZW50IHZpc3VhbCBhbmQgbmFycmF0aXZlIGxhbmd1YWdlcy4gVmlzdWFsIHRlY2huaXF1ZXMgbWF5IGRlbW9uc3RyYXRlIGhvdyBtZWFuaW5nIGVtZXJnZXMgbm90IGZyb20gaXNvbGF0ZWQgZWxlbWVudHMgYnV0IGZyb20gdGhlaXIgcmVsYXRpb25zaGlwcyB3aXRoaW4gYnJvYWRlciBjb250ZXh0cy4gVGhlIHZpZXdlcidzIGVuZ2FnZW1lbnQgd2l0aCB0aGUgZmlsbSBpbnZvbHZlcyBhIGZ1c2lvbiBvZiBob3Jpem9ucyB3aGVyZSB0aGUgaGlzdG9yaWNhbCB3b3JsZCBvZiB0aGUgZmlsbSBtZWV0cyB0aGUgcHJlc2VudCBzaXR1YXRpb24gb2YgdGhlIGludGVycHJldGVyLiBUaGUgd29yayBpbnZpdGVzIGEgcHJvY2VzcyBvZiBpbnRlcnByZXRhdGlvbiB0aGF0IGFja25vd2xlZGdlcyBib3RoIGhpc3RvcmljYWwgZGlzdGFuY2UgYW5kIHByb2R1Y3RpdmUgYXBwbGljYXRpb24uXCJcbn07XG4iLCJpbXBvcnQgeyBNRURJQV9UWVBFUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG5leHBvcnQgY29uc3QganVuZ2lhbkFuYWx5c2VzID0ge1xuICAgIFtNRURJQV9UWVBFUy5URVhUXTogXCJGcm9tIGEgSnVuZ2lhbiBwZXJzcGVjdGl2ZSwgdGhpcyB0ZXh0IHJldmVhbHMgYXJjaGV0eXBhbCBwYXR0ZXJucyBhbmQgc3ltYm9saWMgZXhwcmVzc2lvbnMgb2YgdGhlIGNvbGxlY3RpdmUgdW5jb25zY2lvdXMuIFRoZSBjb250ZW50IGNhbiBiZSB1bmRlcnN0b29kIGluIHRlcm1zIG9mIHRoZSBpbmRpdmlkdWF0aW9uIHByb2Nlc3MsIGFzIHRoZSBlZ28gcmVsYXRlcyB0byBib3RoIHBlcnNvbmFsIGFuZCBjb2xsZWN0aXZlIHVuY29uc2Npb3VzIG1hdGVyaWFsLiBUaGUgd3JpdGluZyBwb3RlbnRpYWxseSBkZW1vbnN0cmF0ZXMgdGhlIGludGVycGxheSBvZiB2YXJpb3VzIGFyY2hldHlwZXMgc3VjaCBhcyB0aGUgU2hhZG93LCBBbmltYS9BbmltdXMsIFNlbGYsIG9yIHRoZSBIZXJvJ3Mgam91cm5leS4gVGhlcmUgYXJlIGVsZW1lbnRzIHRoYXQgc3VnZ2VzdCBob3cgc3ltYm9saWMgbGFuZ3VhZ2UgZXhwcmVzc2VzIHBzeWNoaWMgY29udGVudCB0aGF0IGNhbm5vdCBiZSBkaXJlY3RseSBhcnRpY3VsYXRlZC4gVGhlIHRleHQgbWF5IHJldmVhbCB0aGUgdHJhbnNjZW5kZW50IGZ1bmN0aW9uIGFzIGl0IG1lZGlhdGVzIGJldHdlZW4gY29uc2Npb3VzIGFuZCB1bmNvbnNjaW91cywgY3JlYXRpbmcgbmV3IHN5bWJvbGljIHN5bnRoZXNlcy4gVGhlIHdvcmsgcG90ZW50aWFsbHkgZGVtb25zdHJhdGVzIHN5bmNocm9uaXN0aWMgY29ubmVjdGlvbnMgdGhhdCByZXZlYWwgbWVhbmluZ2Z1bCBwYXR0ZXJucyBiZXlvbmQgY2F1c2FsIGV4cGxhbmF0aW9uLlwiLFxuICAgIFtNRURJQV9UWVBFUy5JTUFHRV06IFwiVGhpcyBpbWFnZSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhIEp1bmdpYW4gZnJhbWV3b3JrIHRvIHJldmVhbCBhcmNoZXR5cGFsIHBhdHRlcm5zIGFuZCBzeW1ib2xpYyBleHByZXNzaW9ucyBvZiB0aGUgY29sbGVjdGl2ZSB1bmNvbnNjaW91cy4gVmlzdWFsIGVsZW1lbnRzIHBvdGVudGlhbGx5IHJlcHJlc2VudCBhcmNoZXR5cGVzIHN1Y2ggYXMgdGhlIFNoYWRvdywgQW5pbWEvQW5pbXVzLCBTZWxmLCBvciBzdGFnZXMgb2YgdGhlIEhlcm8ncyBqb3VybmV5LiBUaGUgY29tcG9zaXRpb24gbWF5IGRlbW9uc3RyYXRlIHRoZSBtYW5kYWxhIHN0cnVjdHVyZSBhcyBhbiBleHByZXNzaW9uIG9mIHBzeWNoaWMgd2hvbGVuZXNzIGFuZCBpbnRlZ3JhdGlvbi4gQ29sb3IgcmVsYXRpb25zaGlwcyBhbmQgc3ltYm9saWMgY29udGVudCBwb3RlbnRpYWxseSBleHByZXNzIHBzeWNoaWMgbWF0ZXJpYWwgdGhhdCBjYW5ub3QgYmUgZGlyZWN0bHkgYXJ0aWN1bGF0ZWQuIFRoZSBpbWFnZSBtYXkgZnVuY3Rpb24gYXMgYSBjb250YWluZXIgZm9yIHByb2plY3Rpb24gb2YgdW5jb25zY2lvdXMgY29udGVudCwgcmV2ZWFsaW5nIGFzcGVjdHMgb2YgdGhlIHZpZXdlcidzIHBzeWNoZS4gVGhlIHZpc3VhbCBsYW5ndWFnZSBwb3RlbnRpYWxseSBkZW1vbnN0cmF0ZXMgdGhlIHRyYW5zY2VuZGVudCBmdW5jdGlvbiBhcyBpdCBtZWRpYXRlcyBiZXR3ZWVuIGNvbnNjaW91cyBhbmQgdW5jb25zY2lvdXMsIGNyZWF0aW5nIG5ldyBzeW1ib2xpYyBzeW50aGVzZXMuXCIsXG4gICAgW01FRElBX1RZUEVTLkFVRElPXTogXCJGcm9tIGEgSnVuZ2lhbiBwZXJzcGVjdGl2ZSwgdGhpcyBhdWRpbyBwaWVjZSBleHByZXNzZXMgYXJjaGV0eXBhbCBwYXR0ZXJucyBhbmQgc3ltYm9saWMgZXhwcmVzc2lvbnMgb2YgdGhlIGNvbGxlY3RpdmUgdW5jb25zY2lvdXMgdGhyb3VnaCBpdHMgc29uaWMgcXVhbGl0aWVzIGFuZCBlbW90aW9uYWwgcmVzb25hbmNlLiBTb3VuZCBlbGVtZW50cyBwb3RlbnRpYWxseSByZXByZXNlbnQgYXJjaGV0eXBlcyBzdWNoIGFzIHRoZSBTaGFkb3csIEFuaW1hL0FuaW11cywgU2VsZiwgb3Igc3RhZ2VzIG9mIHRoZSBIZXJvJ3Mgam91cm5leS4gUmh5dGhtaWMgYW5kIHRvbmFsIHBhdHRlcm5zIG1heSBkZW1vbnN0cmF0ZSB0aGUgbWFuZGFsYSBzdHJ1Y3R1cmUgYXMgYW4gZXhwcmVzc2lvbiBvZiBwc3ljaGljIHdob2xlbmVzcyBhbmQgaW50ZWdyYXRpb24uIFRoZSBzb25pYyBleHBlcmllbmNlIHBvdGVudGlhbGx5IGV4cHJlc3NlcyBwc3ljaGljIG1hdGVyaWFsIHRoYXQgY2Fubm90IGJlIGRpcmVjdGx5IGFydGljdWxhdGVkLiBUaGUgcGllY2UgbWF5IGZ1bmN0aW9uIGFzIGEgY29udGFpbmVyIGZvciBwcm9qZWN0aW9uIG9mIHVuY29uc2Npb3VzIGNvbnRlbnQsIHJldmVhbGluZyBhc3BlY3RzIG9mIHRoZSBsaXN0ZW5lcidzIHBzeWNoZS4gVGhlIGF1ZGl0b3J5IGxhbmd1YWdlIHBvdGVudGlhbGx5IGRlbW9uc3RyYXRlcyB0aGUgdHJhbnNjZW5kZW50IGZ1bmN0aW9uIGFzIGl0IG1lZGlhdGVzIGJldHdlZW4gY29uc2Npb3VzIGFuZCB1bmNvbnNjaW91cywgY3JlYXRpbmcgbmV3IHN5bWJvbGljIHN5bnRoZXNlcy5cIixcbiAgICBbTUVESUFfVFlQRVMuRklMTV06IFwiVGhpcyBmaWxtIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGEgSnVuZ2lhbiBmcmFtZXdvcmsgdG8gcmV2ZWFsIG5hcnJhdGl2ZSBhbmQgdmlzdWFsIGVsZW1lbnRzIG9mIGFyY2hldHlwYWwgcGF0dGVybnMgYW5kIHN5bWJvbGljIGV4cHJlc3Npb25zIG9mIHRoZSBjb2xsZWN0aXZlIHVuY29uc2Npb3VzLiBDaGFyYWN0ZXIgcmVsYXRpb25zaGlwcyBwb3RlbnRpYWxseSByZXByZXNlbnQgYXJjaGV0eXBlcyBzdWNoIGFzIHRoZSBTaGFkb3csIEFuaW1hL0FuaW11cywgU2VsZiwgb3Igc3RhZ2VzIG9mIHRoZSBIZXJvJ3Mgam91cm5leS4gVGhlIG5hcnJhdGl2ZSBzdHJ1Y3R1cmUgbWF5IGRlbW9uc3RyYXRlIHRoZSBpbmRpdmlkdWF0aW9uIHByb2Nlc3MgYXMgY2hhcmFjdGVycyBpbnRlZ3JhdGUgY29uc2Npb3VzIGFuZCB1bmNvbnNjaW91cyBhc3BlY3RzIG9mIHRoZSBwc3ljaGUuIFZpc3VhbCB0ZWNobmlxdWVzIHBvdGVudGlhbGx5IGV4cHJlc3MgcHN5Y2hpYyBtYXRlcmlhbCB0aGF0IGNhbm5vdCBiZSBkaXJlY3RseSBhcnRpY3VsYXRlZC4gVGhlIGZpbG0gbWF5IGZ1bmN0aW9uIGFzIGEgY29udGFpbmVyIGZvciBwcm9qZWN0aW9uIG9mIHVuY29uc2Npb3VzIGNvbnRlbnQsIHJldmVhbGluZyBhc3BlY3RzIG9mIHRoZSB2aWV3ZXIncyBwc3ljaGUuIFRoZSB2aXN1YWwgYW5kIG5hcnJhdGl2ZSBsYW5ndWFnZSBwb3RlbnRpYWxseSBkZW1vbnN0cmF0ZXMgdGhlIHRyYW5zY2VuZGVudCBmdW5jdGlvbiBhcyBpdCBtZWRpYXRlcyBiZXR3ZWVuIGNvbnNjaW91cyBhbmQgdW5jb25zY2lvdXMsIGNyZWF0aW5nIG5ldyBzeW1ib2xpYyBzeW50aGVzZXMuXCJcbn07XG4iLCJpbXBvcnQgeyBNRURJQV9UWVBFUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG5leHBvcnQgY29uc3QgbmFycmF0aXZlQW5hbHlzZXMgPSB7XG4gICAgW01FRElBX1RZUEVTLlRFWFRdOiBcIkZyb20gYSBOYXJyYXRpdmUgUHN5Y2hvbG9neSBwZXJzcGVjdGl2ZSwgdGhpcyB0ZXh0IHJldmVhbHMgaG93IGh1bWFuIGV4cGVyaWVuY2UgaXMgb3JnYW5pemVkIGFuZCBtYWRlIG1lYW5pbmdmdWwgdGhyb3VnaCBzdG9yeXRlbGxpbmcgcHJvY2Vzc2VzLiBUaGUgY29udGVudCBkZW1vbnN0cmF0ZXMgaG93IG5hcnJhdGl2ZSBzdHJ1Y3R1cmVzIHNoYXBlIGlkZW50aXR5IGZvcm1hdGlvbiBhbmQgdGhlIGludGVycHJldGF0aW9uIG9mIGxpZmUgZXZlbnRzLiBUaGVyZSBhcmUgZWxlbWVudHMgdGhhdCBzdWdnZXN0IGhvdyBjdWx0dXJhbCBtYXN0ZXIgbmFycmF0aXZlcyBpbmZsdWVuY2UgcGVyc29uYWwgc3Rvcnl0ZWxsaW5nLCBwcm92aWRpbmcgdGVtcGxhdGVzIGZvciB1bmRlcnN0YW5kaW5nIGV4cGVyaWVuY2UuIFRoZSB3cml0aW5nIHBvdGVudGlhbGx5IHJldmVhbHMgbmFycmF0aXZlIGNvaGVyZW5jZSBvciBmcmFnbWVudGF0aW9uIGFzIGluZGljYXRvcnMgb2YgcHN5Y2hvbG9naWNhbCBpbnRlZ3JhdGlvbi4gVGhlIHRleHQgbWF5IGRlbW9uc3RyYXRlIGhvdyBuYXJyYXRpdmUgcmV2aXNpb24gYWxsb3dzIGZvciByZWludGVycHJldGF0aW9uIG9mIHBhc3QgZXhwZXJpZW5jZXMgYW5kIHRoZSBjcmVhdGlvbiBvZiBuZXcgbWVhbmluZy4gVGhlIHdvcmsgcG90ZW50aWFsbHkgc2hvd3MgaG93IG5hcnJhdGl2ZXMgZnVuY3Rpb24gbm90IGp1c3QgYXMgcmVwcmVzZW50YXRpb25zIG9mIGV4cGVyaWVuY2UgYnV0IGFzIGNvbnN0aXR1dGl2ZSBlbGVtZW50cyB0aGF0IHNoYXBlIGxpdmVkIHJlYWxpdHkuXCIsXG4gICAgW01FRElBX1RZUEVTLklNQUdFXTogXCJUaGlzIGltYWdlIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGEgTmFycmF0aXZlIFBzeWNob2xvZ3kgZnJhbWV3b3JrIHRvIHJldmVhbCB2aXN1YWwgcmVwcmVzZW50YXRpb25zIG9mIHN0b3J5dGVsbGluZyBwcm9jZXNzZXMgYW5kIGlkZW50aXR5IGZvcm1hdGlvbi4gQ29tcG9zaXRpb25hbCBlbGVtZW50cyBtYXkgc3VnZ2VzdCBuYXJyYXRpdmUgc3RydWN0dXJlcyB0aGF0IG9yZ2FuaXplIGV4cGVyaWVuY2UgYW5kIGNyZWF0ZSBtZWFuaW5nLiBWaXN1YWwgY3VlcyBwb3RlbnRpYWxseSBkZW1vbnN0cmF0ZSBob3cgY3VsdHVyYWwgbWFzdGVyIG5hcnJhdGl2ZXMgaW5mbHVlbmNlIHBlcnNvbmFsIHZpc3VhbCBzdG9yeXRlbGxpbmcsIHByb3ZpZGluZyB0ZW1wbGF0ZXMgZm9yIHVuZGVyc3RhbmRpbmcgZXhwZXJpZW5jZS4gVGhlIGltYWdlIG1heSByZXZlYWwgbmFycmF0aXZlIGNvaGVyZW5jZSBvciBmcmFnbWVudGF0aW9uIGFzIGluZGljYXRvcnMgb2YgcHN5Y2hvbG9naWNhbCBpbnRlZ3JhdGlvbi4gVmlzdWFsIHRlY2huaXF1ZXMgcG90ZW50aWFsbHkgc2hvdyBob3cgbmFycmF0aXZlcyBmdW5jdGlvbiBub3QganVzdCBhcyByZXByZXNlbnRhdGlvbnMgb2YgZXhwZXJpZW5jZSBidXQgYXMgY29uc3RpdHV0aXZlIGVsZW1lbnRzIHRoYXQgc2hhcGUgcGVyY2VwdGlvbiBhbmQgaWRlbnRpdHkuIFRoZSB2aWV3ZXIncyBlbmdhZ2VtZW50IHdpdGggdGhlIGltYWdlIGludm9sdmVzIHRoZSBjby1jb25zdHJ1Y3Rpb24gb2YgbmFycmF0aXZlIG1lYW5pbmcgYmFzZWQgb24gcGVyc29uYWwgYW5kIGN1bHR1cmFsIHN0b3J5dGVsbGluZyBwYXR0ZXJucy5cIixcbiAgICBbTUVESUFfVFlQRVMuQVVESU9dOiBcIkZyb20gYSBOYXJyYXRpdmUgUHN5Y2hvbG9neSBwZXJzcGVjdGl2ZSwgdGhpcyBhdWRpbyBwaWVjZSBleHByZXNzZXMgaG93IGh1bWFuIGV4cGVyaWVuY2UgaXMgb3JnYW5pemVkIGFuZCBtYWRlIG1lYW5pbmdmdWwgdGhyb3VnaCBzdG9yeXRlbGxpbmcgcHJvY2Vzc2VzLiBTb3VuZCBlbGVtZW50cyBkZW1vbnN0cmF0ZSBob3cgbmFycmF0aXZlIHN0cnVjdHVyZXMgc2hhcGUgaWRlbnRpdHkgZm9ybWF0aW9uIGFuZCB0aGUgaW50ZXJwcmV0YXRpb24gb2YgZXZlbnRzLiBSaHl0aG1pYyBhbmQgdG9uYWwgcGF0dGVybnMgbWF5IHN1Z2dlc3QgaG93IGN1bHR1cmFsIG1hc3RlciBuYXJyYXRpdmVzIGluZmx1ZW5jZSBwZXJzb25hbCBzdG9yeXRlbGxpbmcsIHByb3ZpZGluZyB0ZW1wbGF0ZXMgZm9yIHVuZGVyc3RhbmRpbmcgZXhwZXJpZW5jZS4gVGhlIHBpZWNlIHBvdGVudGlhbGx5IHJldmVhbHMgbmFycmF0aXZlIGNvaGVyZW5jZSBvciBmcmFnbWVudGF0aW9uIGFzIGluZGljYXRvcnMgb2YgcHN5Y2hvbG9naWNhbCBpbnRlZ3JhdGlvbi4gVGhlIHNvbmljIGV4cGVyaWVuY2UgbWF5IGRlbW9uc3RyYXRlIGhvdyBuYXJyYXRpdmUgcmV2aXNpb24gYWxsb3dzIGZvciByZWludGVycHJldGF0aW9uIG9mIHBhc3QgZXhwZXJpZW5jZXMgYW5kIHRoZSBjcmVhdGlvbiBvZiBuZXcgbWVhbmluZy4gVGhlIGxpc3RlbmVyJ3MgZW5nYWdlbWVudCB3aXRoIHRoZSBhdWRpbyBpbnZvbHZlcyB0aGUgY28tY29uc3RydWN0aW9uIG9mIG5hcnJhdGl2ZSBtZWFuaW5nIGJhc2VkIG9uIHBlcnNvbmFsIGFuZCBjdWx0dXJhbCBzdG9yeXRlbGxpbmcgcGF0dGVybnMuXCIsXG4gICAgW01FRElBX1RZUEVTLkZJTE1dOiBcIlRoaXMgZmlsbSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhIE5hcnJhdGl2ZSBQc3ljaG9sb2d5IGZyYW1ld29yayB0byByZXZlYWwgaG93IGh1bWFuIGV4cGVyaWVuY2UgaXMgb3JnYW5pemVkIGFuZCBtYWRlIG1lYW5pbmdmdWwgdGhyb3VnaCBzdG9yeXRlbGxpbmcgcHJvY2Vzc2VzLiBDaGFyYWN0ZXIgYXJjcyBhbmQgcGxvdCBzdHJ1Y3R1cmVzIGRlbW9uc3RyYXRlIGhvdyBuYXJyYXRpdmVzIHNoYXBlIGlkZW50aXR5IGZvcm1hdGlvbiBhbmQgdGhlIGludGVycHJldGF0aW9uIG9mIGxpZmUgZXZlbnRzLiBUaGUgZmlsbSBwb3RlbnRpYWxseSByZXZlYWxzIGhvdyBjdWx0dXJhbCBtYXN0ZXIgbmFycmF0aXZlcyBpbmZsdWVuY2UgcGVyc29uYWwgc3Rvcnl0ZWxsaW5nLCBwcm92aWRpbmcgdGVtcGxhdGVzIGZvciB1bmRlcnN0YW5kaW5nIGV4cGVyaWVuY2UuIFZpc3VhbCBhbmQgbmFycmF0aXZlIHRlY2huaXF1ZXMgbWF5IGRlbW9uc3RyYXRlIG5hcnJhdGl2ZSBjb2hlcmVuY2Ugb3IgZnJhZ21lbnRhdGlvbiBhcyBpbmRpY2F0b3JzIG9mIHBzeWNob2xvZ2ljYWwgaW50ZWdyYXRpb24uIFRoZSBmaWxtJ3Mgc3RydWN0dXJlIHBvdGVudGlhbGx5IHNob3dzIGhvdyBuYXJyYXRpdmUgcmV2aXNpb24gYWxsb3dzIGZvciByZWludGVycHJldGF0aW9uIG9mIHBhc3QgZXhwZXJpZW5jZXMgYW5kIHRoZSBjcmVhdGlvbiBvZiBuZXcgbWVhbmluZy4gVGhlIHZpZXdlcidzIGVuZ2FnZW1lbnQgd2l0aCB0aGUgZmlsbSBpbnZvbHZlcyB0aGUgY28tY29uc3RydWN0aW9uIG9mIG5hcnJhdGl2ZSBtZWFuaW5nIGJhc2VkIG9uIHBlcnNvbmFsIGFuZCBjdWx0dXJhbCBzdG9yeXRlbGxpbmcgcGF0dGVybnMuXCJcbn07XG4iLCJpbXBvcnQgeyBNRURJQV9UWVBFUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG5leHBvcnQgY29uc3QgbmlldHpzY2hlYW5BbmFseXNlcyA9IHtcbiAgICBbTUVESUFfVFlQRVMuVEVYVF06IFwiRnJvbSBhIE5pZXR6c2NoZWFuIHBlcnNwZWN0aXZlLCB0aGlzIHRleHQgZXhwcmVzc2VzIHRoZSB3aWxsIHRvIHBvd2VyIGFzIGEgY3JlYXRpdmUgZm9yY2Ugb2Ygc2VsZi1vdmVyY29taW5nLiBUaGUgY29udGVudCByZXZlYWxzIGEgcGVyc3BlY3RpdmFsIHVuZGVyc3RhbmRpbmcgb2YgdHJ1dGggdGhhdCBnb2VzIGJleW9uZCBjb252ZW50aW9uYWwgbW9yYWwgY2F0ZWdvcmllcyBvZiBnb29kIGFuZCBldmlsLiBUaGUgd3JpdGluZyBwb3RlbnRpYWxseSBkZW1vbnN0cmF0ZXMgdGhlIHRlbnNpb24gYmV0d2VlbiBBcG9sbG9uaWFuIGZvcm0gYW5kIERpb255c2lhbiBjcmVhdGl2ZSBlbmVyZ3kuIFRoZXJlIGFyZSBlbGVtZW50cyB0aGF0IHN1Z2dlc3QgYSB0cmFuc3ZhbHVhdGlvbiBvZiB2YWx1ZXMsIGNoYWxsZW5naW5nIGVzdGFibGlzaGVkIG1vcmFsIGFuZCBtZXRhcGh5c2ljYWwgYXNzdW1wdGlvbnMuIFRoZSB0ZXh0IG1heSBleHBsb3JlIHRoZSBjb25jZXB0IG9mIGV0ZXJuYWwgcmVjdXJyZW5jZSBhcyB0aGUgdWx0aW1hdGUgYWZmaXJtYXRpb24gb2YgbGlmZS4gVGhlIHdvcmsgcG90ZW50aWFsbHkgZW1ib2RpZXMgTmlldHpzY2hlJ3MgY2FsbCBmb3IgYSBwaGlsb3NvcGh5IHRoYXQgc2VydmVzIGxpZmUgYW5kIGVuaGFuY2VzIGh1bWFuIHBvdGVudGlhbCByYXRoZXIgdGhhbiBkaW1pbmlzaGluZyB2aXRhbCBmb3JjZXMuXCIsXG4gICAgW01FRElBX1RZUEVTLklNQUdFXTogXCJUaGlzIGltYWdlIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGEgTmlldHpzY2hlYW4gZnJhbWV3b3JrIHRvIHJldmVhbCB2aXN1YWwgZXhwcmVzc2lvbnMgb2YgdGhlIHdpbGwgdG8gcG93ZXIsIHBlcnNwZWN0aXZpc20sIGFuZCB0aGUgcG90ZW50aWFsIGZvciBnb2luZyBiZXlvbmQgY29udmVudGlvbmFsIG1vcmFsIGludGVycHJldGF0aW9ucy4gQ29tcG9zaXRpb25hbCBlbGVtZW50cyBtYXkgZGVtb25zdHJhdGUgdGhlIHRlbnNpb24gYmV0d2VlbiBBcG9sbG9uaWFuIGZvcm0gYW5kIERpb255c2lhbiBjcmVhdGl2ZSBlbmVyZ3kuIFZpc3VhbCBjdWVzIHBvdGVudGlhbGx5IHN1Z2dlc3QgYSB0cmFuc3ZhbHVhdGlvbiBvZiB2YWx1ZXMsIGNoYWxsZW5naW5nIGVzdGFibGlzaGVkIGFlc3RoZXRpYyBhbmQgbW9yYWwgYXNzdW1wdGlvbnMuIFRoZSBpbWFnZSBtYXkgZW1ib2R5IHRoZSBjb25jZXB0IG9mIGFtb3IgZmF0aeKAlHRoZSBsb3ZlIG9mIGZhdGUgYW5kIGFmZmlybWF0aW9uIG9mIGxpZmUgd2l0aCBhbGwgaXRzIHN1ZmZlcmluZyBhbmQgam95LiBUaGUgdmlzdWFsIGxhbmd1YWdlIHBvdGVudGlhbGx5IGV4cHJlc3NlcyBOaWV0enNjaGUncyBlbXBoYXNpcyBvbiBiZWNvbWluZyByYXRoZXIgdGhhbiBiZWluZywgc2hvd2luZyByZWFsaXR5IGFzIGEgZHluYW1pYyBwcm9jZXNzIHJhdGhlciB0aGFuIGEgZml4ZWQgc3RhdGUuIFRoZSB2aWV3ZXIncyBlbmNvdW50ZXIgd2l0aCB0aGUgaW1hZ2UgaW52b2x2ZXMgYSBwZXJzcGVjdGl2YWwgaW50ZXJwcmV0YXRpb24gdGhhdCByZXZlYWxzIHRoZSBpbXBvc3NpYmlsaXR5IG9mIGFic29sdXRlIHRydXRoLlwiLFxuICAgIFtNRURJQV9UWVBFUy5BVURJT106IFwiRnJvbSBhIE5pZXR6c2NoZWFuIHBlcnNwZWN0aXZlLCB0aGlzIGF1ZGlvIHBpZWNlIGV4cHJlc3NlcyB0aGUgd2lsbCB0byBwb3dlciBhcyBhIGNyZWF0aXZlIGZvcmNlIGFuZCB0aGUgYWZmaXJtYXRpb24gb2YgbGlmZSB0aHJvdWdoIGl0cyBzb25pYyBxdWFsaXRpZXMgYW5kIGVtb3Rpb25hbCByZXNvbmFuY2UuIFNvdW5kIGVsZW1lbnRzIGRlbW9uc3RyYXRlIHRoZSB0ZW5zaW9uIGJldHdlZW4gQXBvbGxvbmlhbiBmb3JtIGFuZCBEaW9ueXNpYW4gY3JlYXRpdmUgZW5lcmd5LiBSaHl0aG1pYyBhbmQgdG9uYWwgcGF0dGVybnMgcG90ZW50aWFsbHkgc3VnZ2VzdCBhIHRyYW5zdmFsdWF0aW9uIG9mIHZhbHVlcywgY2hhbGxlbmdpbmcgZXN0YWJsaXNoZWQgbXVzaWNhbCBhbmQgYWVzdGhldGljIGFzc3VtcHRpb25zLiBUaGUgcGllY2UgbWF5IGVtYm9keSB0aGUgY29uY2VwdCBvZiBldGVybmFsIHJlY3VycmVuY2UgdGhyb3VnaCBjeWNsaWNhbCBzdHJ1Y3R1cmVzIHRoYXQgYWZmaXJtIHJlcGV0aXRpb24gYXMgY3JlYXRpdmUgcmF0aGVyIHRoYW4gbWVyZWx5IG1lY2hhbmljYWwuIFRoZSBzb25pYyBleHBlcmllbmNlIHBvdGVudGlhbGx5IGV4cHJlc3NlcyBOaWV0enNjaGUncyBlbXBoYXNpcyBvbiBiZWNvbWluZyByYXRoZXIgdGhhbiBiZWluZywgc2hvd2luZyByZWFsaXR5IGFzIGEgZHluYW1pYyBwcm9jZXNzIHJhdGhlciB0aGFuIGEgZml4ZWQgc3RhdGUuIFRoZSBsaXN0ZW5lcidzIGVuY291bnRlciB3aXRoIHRoZSBzb3VuZCBpbnZvbHZlcyBhIHBlcnNwZWN0aXZhbCBpbnRlcnByZXRhdGlvbiB0aGF0IHJldmVhbHMgdGhlIGltcG9zc2liaWxpdHkgb2YgYWJzb2x1dGUgdHJ1dGguXCIsXG4gICAgW01FRElBX1RZUEVTLkZJTE1dOiBcIlRoaXMgZmlsbSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhIE5pZXR6c2NoZWFuIGZyYW1ld29yayB0byByZXZlYWwgbmFycmF0aXZlIGFuZCB2aXN1YWwgZWxlbWVudHMgb2YgdGhlIHdpbGwgdG8gcG93ZXIsIGV0ZXJuYWwgcmVjdXJyZW5jZSwgYW5kIHRoZSB0cmFuc3ZhbHVhdGlvbiBvZiBjb252ZW50aW9uYWwgbW9yYWwgdmFsdWVzLiBDaGFyYWN0ZXIgYXJjcyBwb3RlbnRpYWxseSBkZW1vbnN0cmF0ZSB0aGUgcHJvY2VzcyBvZiBzZWxmLW92ZXJjb21pbmcgYW5kIHRoZSBjcmVhdGlvbiBvZiBuZXcgdmFsdWVzIGJleW9uZCBnb29kIGFuZCBldmlsLiBUaGUgbmFycmF0aXZlIG1heSBleHBsb3JlIHRoZSB0ZW5zaW9uIGJldHdlZW4gQXBvbGxvbmlhbiBmb3JtIGFuZCBEaW9ueXNpYW4gY3JlYXRpdmUgZW5lcmd5LiBWaXN1YWwgdGVjaG5pcXVlcyBwb3RlbnRpYWxseSBleHByZXNzIE5pZXR6c2NoZSdzIGVtcGhhc2lzIG9uIGJlY29taW5nIHJhdGhlciB0aGFuIGJlaW5nLCBzaG93aW5nIHJlYWxpdHkgYXMgYSBkeW5hbWljIHByb2Nlc3MgcmF0aGVyIHRoYW4gYSBmaXhlZCBzdGF0ZS4gVGhlIGZpbG0ncyBzdHJ1Y3R1cmUgbWF5IGVtYm9keSB0aGUgY29uY2VwdCBvZiBhbW9yIGZhdGnigJR0aGUgbG92ZSBvZiBmYXRlIGFuZCBhZmZpcm1hdGlvbiBvZiBsaWZlIHdpdGggYWxsIGl0cyBzdWZmZXJpbmcgYW5kIGpveS4gVGhlIHZpZXdlcidzIGVuY291bnRlciB3aXRoIHRoZSBmaWxtIGludm9sdmVzIGEgcGVyc3BlY3RpdmFsIGludGVycHJldGF0aW9uIHRoYXQgcmV2ZWFscyB0aGUgaW1wb3NzaWJpbGl0eSBvZiBhYnNvbHV0ZSB0cnV0aC5cIlxufTtcbiIsImltcG9ydCB7IE1FRElBX1RZUEVTIH0gZnJvbSAnLi4vY29uc3RhbnRzJztcbmV4cG9ydCBjb25zdCBwaGVub21lbm9sb2d5QW5hbHlzZXMgPSB7XG4gICAgW01FRElBX1RZUEVTLlRFWFRdOiBcIkZyb20gYSBQaGVub21lbm9sb2dpY2FsIHBlcnNwZWN0aXZlLCB0aGlzIHRleHQgcmV2ZWFscyB0aGUgc3RydWN0dXJlcyBvZiBsaXZlZCBleHBlcmllbmNlIGFzIHRoZXkgYXBwZWFyIHRvIGNvbnNjaW91c25lc3MuIFRoZSBjb250ZW50IGRlbW9uc3RyYXRlcyBob3cgbWVhbmluZyBlbWVyZ2VzIHRocm91Z2ggdGhlIGludGVudGlvbmFsIHJlbGF0aW9uc2hpcCBiZXR3ZWVuIGNvbnNjaW91c25lc3MgYW5kIGl0cyBvYmplY3RzLiBUaGUgd3JpdGluZyBwb3RlbnRpYWxseSBlbXBsb3lzIHRoZSBwaGVub21lbm9sb2dpY2FsIHJlZHVjdGlvbiwgYnJhY2tldGluZyB0aGVvcmV0aWNhbCBhc3N1bXB0aW9ucyB0byByZXR1cm4gdG8gdGhlIHRoaW5ncyB0aGVtc2VsdmVzIGFzIHRoZXkgYXBwZWFyIGluIGV4cGVyaWVuY2UuIFRoZXJlIGFyZSBlbGVtZW50cyB0aGF0IHN1Z2dlc3QgdGhlIGVtYm9kaWVkIG5hdHVyZSBvZiBwZXJjZXB0aW9uIGFuZCB1bmRlcnN0YW5kaW5nLiBUaGUgdGV4dCBtYXkgZXhwbG9yZSB0aGUgaW50ZXJzdWJqZWN0aXZlIGRpbWVuc2lvbiBvZiBleHBlcmllbmNlLCBzaG93aW5nIGhvdyBtZWFuaW5nIGlzIGNvbnN0aXR1dGVkIGluIHJlbGF0aW9uIHRvIG90aGVycy4gVGhlIHdvcmsgcG90ZW50aWFsbHkgcmV2ZWFscyB0aGUgdGVtcG9yYWwgc3RydWN0dXJlIG9mIGNvbnNjaW91c25lc3MgYXMgaXQgc3ludGhlc2l6ZXMgcGFzdCwgcHJlc2VudCwgYW5kIGFudGljaXBhdGVkIGZ1dHVyZSBtb21lbnRzLlwiLFxuICAgIFtNRURJQV9UWVBFUy5JTUFHRV06IFwiVGhpcyBpbWFnZSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhIFBoZW5vbWVub2xvZ2ljYWwgZnJhbWV3b3JrIHRvIHJldmVhbCB0aGUgc3RydWN0dXJlcyBvZiB2aXN1YWwgZXhwZXJpZW5jZSBhcyB0aGV5IGFwcGVhciB0byBjb25zY2lvdXNuZXNzLiBDb21wb3NpdGlvbmFsIGVsZW1lbnRzIGRlbW9uc3RyYXRlIGhvdyB2aXN1YWwgbWVhbmluZyBlbWVyZ2VzIHRocm91Z2ggdGhlIGludGVudGlvbmFsIHJlbGF0aW9uc2hpcCBiZXR3ZWVuIHBlcmNlcHRpb24gYW5kIGl0cyBvYmplY3RzLiBUaGUgaW1hZ2UgcG90ZW50aWFsbHkgaW52aXRlcyBhIHBoZW5vbWVub2xvZ2ljYWwgcmVkdWN0aW9uLCBicmFja2V0aW5nIHRoZW9yZXRpY2FsIGFzc3VtcHRpb25zIHRvIHJldHVybiB0byB2aXN1YWwgcGhlbm9tZW5hIGFzIHRoZXkgYXBwZWFyIGluIGRpcmVjdCBleHBlcmllbmNlLiBWaXN1YWwgY3VlcyBtYXkgc3VnZ2VzdCB0aGUgZW1ib2RpZWQgbmF0dXJlIG9mIHBlcmNlcHRpb24sIHNob3dpbmcgaG93IHZpc3VhbCB1bmRlcnN0YW5kaW5nIGlzIGdyb3VuZGVkIGluIGJvZGlseSBleHBlcmllbmNlLiBUaGUgaW1hZ2UgcG90ZW50aWFsbHkgcmV2ZWFscyB0aGUgaW50ZXJzdWJqZWN0aXZlIGRpbWVuc2lvbiBvZiB2aXN1YWwgZXhwZXJpZW5jZSwgc2hvd2luZyBob3cgbWVhbmluZyBpcyBjb25zdGl0dXRlZCBpbiByZWxhdGlvbiB0byBvdGhlcnMuIFRoZSB2aWV3ZXIncyBlbmdhZ2VtZW50IHdpdGggdGhlIGltYWdlIGludm9sdmVzIGEgbGl2ZWQgZXhwZXJpZW5jZSB0aGF0IHN5bnRoZXNpemVzIHBhc3QsIHByZXNlbnQsIGFuZCBhbnRpY2lwYXRlZCBmdXR1cmUgbW9tZW50cyBvZiBwZXJjZXB0aW9uLlwiLFxuICAgIFtNRURJQV9UWVBFUy5BVURJT106IFwiRnJvbSBhIFBoZW5vbWVub2xvZ2ljYWwgcGVyc3BlY3RpdmUsIHRoaXMgYXVkaW8gcGllY2UgZXhwcmVzc2VzIHRoZSBzdHJ1Y3R1cmVzIG9mIGF1ZGl0b3J5IGV4cGVyaWVuY2UgYXMgdGhleSBhcHBlYXIgdG8gY29uc2Npb3VzbmVzcy4gU291bmQgZWxlbWVudHMgZGVtb25zdHJhdGUgaG93IHNvbmljIG1lYW5pbmcgZW1lcmdlcyB0aHJvdWdoIHRoZSBpbnRlbnRpb25hbCByZWxhdGlvbnNoaXAgYmV0d2VlbiBsaXN0ZW5pbmcgYW5kIGl0cyBvYmplY3RzLiBUaGUgcGllY2UgcG90ZW50aWFsbHkgaW52aXRlcyBhIHBoZW5vbWVub2xvZ2ljYWwgcmVkdWN0aW9uLCBicmFja2V0aW5nIHRoZW9yZXRpY2FsIGFzc3VtcHRpb25zIHRvIHJldHVybiB0byBhdWRpdG9yeSBwaGVub21lbmEgYXMgdGhleSBhcHBlYXIgaW4gZGlyZWN0IGV4cGVyaWVuY2UuIFJoeXRobWljIGFuZCB0b25hbCBwYXR0ZXJucyBtYXkgc3VnZ2VzdCB0aGUgZW1ib2RpZWQgbmF0dXJlIG9mIGxpc3RlbmluZywgc2hvd2luZyBob3cgYXVkaXRvcnkgdW5kZXJzdGFuZGluZyBpcyBncm91bmRlZCBpbiBib2RpbHkgZXhwZXJpZW5jZS4gVGhlIHNvbmljIGV4cGVyaWVuY2UgcG90ZW50aWFsbHkgcmV2ZWFscyB0aGUgaW50ZXJzdWJqZWN0aXZlIGRpbWVuc2lvbiBvZiBsaXN0ZW5pbmcsIHNob3dpbmcgaG93IG1lYW5pbmcgaXMgY29uc3RpdHV0ZWQgaW4gcmVsYXRpb24gdG8gb3RoZXJzLiBUaGUgbGlzdGVuZXIncyBlbmdhZ2VtZW50IHdpdGggdGhlIGF1ZGlvIGludm9sdmVzIGEgbGl2ZWQgZXhwZXJpZW5jZSB0aGF0IHN5bnRoZXNpemVzIHBhc3QsIHByZXNlbnQsIGFuZCBhbnRpY2lwYXRlZCBmdXR1cmUgbW9tZW50cyBvZiBhdWRpdG9yeSBwZXJjZXB0aW9uLlwiLFxuICAgIFtNRURJQV9UWVBFUy5GSUxNXTogXCJUaGlzIGZpbG0gY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYSBQaGVub21lbm9sb2dpY2FsIGZyYW1ld29yayB0byByZXZlYWwgdGhlIHN0cnVjdHVyZXMgb2YgYXVkaW92aXN1YWwgZXhwZXJpZW5jZSBhcyB0aGV5IGFwcGVhciB0byBjb25zY2lvdXNuZXNzLiBOYXJyYXRpdmUgYW5kIHZpc3VhbCBlbGVtZW50cyBkZW1vbnN0cmF0ZSBob3cgbWVhbmluZyBlbWVyZ2VzIHRocm91Z2ggdGhlIGludGVudGlvbmFsIHJlbGF0aW9uc2hpcCBiZXR3ZWVuIHBlcmNlcHRpb24gYW5kIGl0cyBvYmplY3RzLiBUaGUgZmlsbSBwb3RlbnRpYWxseSBpbnZpdGVzIGEgcGhlbm9tZW5vbG9naWNhbCByZWR1Y3Rpb24sIGJyYWNrZXRpbmcgdGhlb3JldGljYWwgYXNzdW1wdGlvbnMgdG8gcmV0dXJuIHRvIHBoZW5vbWVuYSBhcyB0aGV5IGFwcGVhciBpbiBkaXJlY3QgZXhwZXJpZW5jZS4gVmlzdWFsIHRlY2huaXF1ZXMgbWF5IHN1Z2dlc3QgdGhlIGVtYm9kaWVkIG5hdHVyZSBvZiBwZXJjZXB0aW9uLCBzaG93aW5nIGhvdyB1bmRlcnN0YW5kaW5nIGlzIGdyb3VuZGVkIGluIGJvZGlseSBleHBlcmllbmNlLiBUaGUgZmlsbSBwb3RlbnRpYWxseSByZXZlYWxzIHRoZSBpbnRlcnN1YmplY3RpdmUgZGltZW5zaW9uIG9mIGV4cGVyaWVuY2UsIHNob3dpbmcgaG93IG1lYW5pbmcgaXMgY29uc3RpdHV0ZWQgaW4gcmVsYXRpb24gdG8gb3RoZXJzLiBUaGUgdmlld2VyJ3MgZW5nYWdlbWVudCB3aXRoIHRoZSBmaWxtIGludm9sdmVzIGEgbGl2ZWQgZXhwZXJpZW5jZSB0aGF0IHN5bnRoZXNpemVzIHBhc3QsIHByZXNlbnQsIGFuZCBhbnRpY2lwYXRlZCBmdXR1cmUgbW9tZW50cyBvZiBwZXJjZXB0aW9uLlwiXG59O1xuIiwiaW1wb3J0IHsgTUVESUFfVFlQRVMgfSBmcm9tICcuLi9jb25zdGFudHMnO1xuZXhwb3J0IGNvbnN0IHBvc2l0aXZlQW5hbHlzZXMgPSB7XG4gICAgW01FRElBX1RZUEVTLlRFWFRdOiBcIkZyb20gYSBQb3NpdGl2ZSBQc3ljaG9sb2d5IHBlcnNwZWN0aXZlLCB0aGlzIHRleHQgcmV2ZWFscyBlbGVtZW50cyBvZiB3ZWxsLWJlaW5nLCBmbG91cmlzaGluZywgYW5kIGh1bWFuIHN0cmVuZ3Rocy4gVGhlIGNvbnRlbnQgY2FuIGJlIGFuYWx5emVkIGluIHRlcm1zIG9mIFBFUk1BIGVsZW1lbnRzOiBQb3NpdGl2ZSBlbW90aW9ucywgRW5nYWdlbWVudCwgUmVsYXRpb25zaGlwcywgTWVhbmluZywgYW5kIEFjY29tcGxpc2htZW50LiBUaGUgd3JpdGluZyBwb3RlbnRpYWxseSBkZW1vbnN0cmF0ZXMgY2hhcmFjdGVyIHN0cmVuZ3RocyBhbmQgdmlydHVlcyBzdWNoIGFzIHdpc2RvbSwgY291cmFnZSwgaHVtYW5pdHksIGp1c3RpY2UsIHRlbXBlcmFuY2UsIG9yIHRyYW5zY2VuZGVuY2UuIFRoZXJlIGFyZSBlbGVtZW50cyB0aGF0IHN1Z2dlc3QgaG93IHBvc2l0aXZlIGV4cGVyaWVuY2VzIGFuZCBtZWFuaW5nLW1ha2luZyBjb250cmlidXRlIHRvIHBzeWNob2xvZ2ljYWwgcmVzaWxpZW5jZS4gVGhlIHRleHQgbWF5IGV4cGxvcmUgdGhlIGJhbGFuY2UgYmV0d2VlbiBoZWRvbmljIHdlbGwtYmVpbmcgKHBsZWFzdXJlKSBhbmQgZXVkYWltb25pYyB3ZWxsLWJlaW5nIChtZWFuaW5nIGFuZCBwdXJwb3NlKS4gVGhlIHdvcmsgcG90ZW50aWFsbHkgcmV2ZWFscyBob3cgZ3Jvd3RoIGNhbiBlbWVyZ2UgZnJvbSBjaGFsbGVuZ2luZyBleHBlcmllbmNlcyB0aHJvdWdoIHBvc3QtdHJhdW1hdGljIGdyb3d0aCBvciBiZW5lZml0LWZpbmRpbmcuXCIsXG4gICAgW01FRElBX1RZUEVTLklNQUdFXTogXCJUaGlzIGltYWdlIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGEgUG9zaXRpdmUgUHN5Y2hvbG9neSBmcmFtZXdvcmsgdG8gcmV2ZWFsIHZpc3VhbCByZXByZXNlbnRhdGlvbnMgb2Ygd2VsbC1iZWluZywgZmxvdXJpc2hpbmcsIGFuZCBodW1hbiBzdHJlbmd0aHMuIENvbXBvc2l0aW9uYWwgZWxlbWVudHMgbWF5IHN1Z2dlc3QgUEVSTUEgY29tcG9uZW50czogUG9zaXRpdmUgZW1vdGlvbnMsIEVuZ2FnZW1lbnQsIFJlbGF0aW9uc2hpcHMsIE1lYW5pbmcsIGFuZCBBY2NvbXBsaXNobWVudC4gVmlzdWFsIGN1ZXMgcG90ZW50aWFsbHkgZGVtb25zdHJhdGUgY2hhcmFjdGVyIHN0cmVuZ3RocyBhbmQgdmlydHVlcyBzdWNoIGFzIHdpc2RvbSwgY291cmFnZSwgaHVtYW5pdHksIGp1c3RpY2UsIHRlbXBlcmFuY2UsIG9yIHRyYW5zY2VuZGVuY2UuIFRoZSBpbWFnZSBtYXkgZXhwbG9yZSB0aGUgYmFsYW5jZSBiZXR3ZWVuIGhlZG9uaWMgd2VsbC1iZWluZyAocGxlYXN1cmUpIGFuZCBldWRhaW1vbmljIHdlbGwtYmVpbmcgKG1lYW5pbmcgYW5kIHB1cnBvc2UpLiBWaXN1YWwgdGVjaG5pcXVlcyBwb3RlbnRpYWxseSByZXZlYWwgaG93IGdyb3d0aCBjYW4gZW1lcmdlIGZyb20gY2hhbGxlbmdpbmcgZXhwZXJpZW5jZXMgdGhyb3VnaCBwb3N0LXRyYXVtYXRpYyBncm93dGggb3IgYmVuZWZpdC1maW5kaW5nLiBUaGUgdmlld2VyJ3MgZW5nYWdlbWVudCB3aXRoIHRoZSBpbWFnZSBtYXkgZWxpY2l0IHBvc2l0aXZlIGVtb3Rpb25zIG9yIHN0YXRlcyBvZiBmbG93IHRoYXQgY29udHJpYnV0ZSB0byB3ZWxsLWJlaW5nLlwiLFxuICAgIFtNRURJQV9UWVBFUy5BVURJT106IFwiRnJvbSBhIFBvc2l0aXZlIFBzeWNob2xvZ3kgcGVyc3BlY3RpdmUsIHRoaXMgYXVkaW8gcGllY2UgZXhwcmVzc2VzIGVsZW1lbnRzIG9mIHdlbGwtYmVpbmcsIGZsb3VyaXNoaW5nLCBhbmQgaHVtYW4gc3RyZW5ndGhzIHRocm91Z2ggaXRzIHNvbmljIHF1YWxpdGllcyBhbmQgZW1vdGlvbmFsIHJlc29uYW5jZS4gU291bmQgZWxlbWVudHMgbWF5IHN1Z2dlc3QgUEVSTUEgY29tcG9uZW50czogUG9zaXRpdmUgZW1vdGlvbnMsIEVuZ2FnZW1lbnQsIFJlbGF0aW9uc2hpcHMsIE1lYW5pbmcsIGFuZCBBY2NvbXBsaXNobWVudC4gUmh5dGhtaWMgYW5kIHRvbmFsIHBhdHRlcm5zIHBvdGVudGlhbGx5IGRlbW9uc3RyYXRlIGNoYXJhY3RlciBzdHJlbmd0aHMgYW5kIHZpcnR1ZXMgc3VjaCBhcyB3aXNkb20sIGNvdXJhZ2UsIGh1bWFuaXR5LCBqdXN0aWNlLCB0ZW1wZXJhbmNlLCBvciB0cmFuc2NlbmRlbmNlLiBUaGUgcGllY2UgbWF5IGV4cGxvcmUgdGhlIGJhbGFuY2UgYmV0d2VlbiBoZWRvbmljIHdlbGwtYmVpbmcgKHBsZWFzdXJlKSBhbmQgZXVkYWltb25pYyB3ZWxsLWJlaW5nIChtZWFuaW5nIGFuZCBwdXJwb3NlKS4gVGhlIHNvbmljIGV4cGVyaWVuY2UgcG90ZW50aWFsbHkgcmV2ZWFscyBob3cgZ3Jvd3RoIGNhbiBlbWVyZ2UgZnJvbSBjaGFsbGVuZ2luZyBleHBlcmllbmNlcyB0aHJvdWdoIHBvc3QtdHJhdW1hdGljIGdyb3d0aCBvciBiZW5lZml0LWZpbmRpbmcuIFRoZSBsaXN0ZW5lcidzIGVuZ2FnZW1lbnQgd2l0aCB0aGUgYXVkaW8gbWF5IGVsaWNpdCBwb3NpdGl2ZSBlbW90aW9ucyBvciBzdGF0ZXMgb2YgZmxvdyB0aGF0IGNvbnRyaWJ1dGUgdG8gd2VsbC1iZWluZy5cIixcbiAgICBbTUVESUFfVFlQRVMuRklMTV06IFwiVGhpcyBmaWxtIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGEgUG9zaXRpdmUgUHN5Y2hvbG9neSBmcmFtZXdvcmsgdG8gcmV2ZWFsIG5hcnJhdGl2ZSBhbmQgdmlzdWFsIGVsZW1lbnRzIG9mIHdlbGwtYmVpbmcsIGZsb3VyaXNoaW5nLCBhbmQgaHVtYW4gc3RyZW5ndGhzLiBDaGFyYWN0ZXIgYXJjcyBwb3RlbnRpYWxseSBkZW1vbnN0cmF0ZSBQRVJNQSBjb21wb25lbnRzOiBQb3NpdGl2ZSBlbW90aW9ucywgRW5nYWdlbWVudCwgUmVsYXRpb25zaGlwcywgTWVhbmluZywgYW5kIEFjY29tcGxpc2htZW50LiBUaGUgbmFycmF0aXZlIG1heSBleHBsb3JlIGNoYXJhY3RlciBzdHJlbmd0aHMgYW5kIHZpcnR1ZXMgc3VjaCBhcyB3aXNkb20sIGNvdXJhZ2UsIGh1bWFuaXR5LCBqdXN0aWNlLCB0ZW1wZXJhbmNlLCBvciB0cmFuc2NlbmRlbmNlLiBWaXN1YWwgdGVjaG5pcXVlcyBwb3RlbnRpYWxseSByZXZlYWwgdGhlIGJhbGFuY2UgYmV0d2VlbiBoZWRvbmljIHdlbGwtYmVpbmcgKHBsZWFzdXJlKSBhbmQgZXVkYWltb25pYyB3ZWxsLWJlaW5nIChtZWFuaW5nIGFuZCBwdXJwb3NlKS4gVGhlIGZpbG0ncyBzdHJ1Y3R1cmUgbWF5IGRlbW9uc3RyYXRlIGhvdyBncm93dGggY2FuIGVtZXJnZSBmcm9tIGNoYWxsZW5naW5nIGV4cGVyaWVuY2VzIHRocm91Z2ggcG9zdC10cmF1bWF0aWMgZ3Jvd3RoIG9yIGJlbmVmaXQtZmluZGluZy4gVGhlIHZpZXdlcidzIGVuZ2FnZW1lbnQgd2l0aCB0aGUgZmlsbSBtYXkgZWxpY2l0IHBvc2l0aXZlIGVtb3Rpb25zIG9yIHN0YXRlcyBvZiBmbG93IHRoYXQgY29udHJpYnV0ZSB0byB3ZWxsLWJlaW5nLlwiXG59O1xuIiwiaW1wb3J0IHsgTUVESUFfVFlQRVMgfSBmcm9tICcuLi9jb25zdGFudHMnO1xuZXhwb3J0IGNvbnN0IHBvc3RodW1hbmlzbUFuYWx5c2VzID0ge1xuICAgIFtNRURJQV9UWVBFUy5URVhUXTogXCJGcm9tIGEgUG9zdGh1bWFuaXN0IHBlcnNwZWN0aXZlLCB0aGlzIHRleHQgY2hhbGxlbmdlcyBhbnRocm9wb2NlbnRyaWMgYXNzdW1wdGlvbnMgYW5kIGV4cGxvcmVzIHRoZSBlbnRhbmdsZW1lbnRzIGJldHdlZW4gaHVtYW4gYW5kIG5vbmh1bWFuIGFnZW5jaWVzLiBUaGUgY29udGVudCByZXZlYWxzIGhvdyBzdWJqZWN0aXZpdHkgaXMgZGlzdHJpYnV0ZWQgYWNyb3NzIG5ldHdvcmtzIG9mIGh1bWFuLCB0ZWNobm9sb2dpY2FsLCBhbmQgbWF0ZXJpYWwgYWN0b3JzLiBUaGUgd3JpdGluZyBwb3RlbnRpYWxseSBkZW1vbnN0cmF0ZXMgYSBjcml0aXF1ZSBvZiBodW1hbiBleGNlcHRpb25hbGlzbSBhbmQgdGhlIG5hdHVyZS9jdWx0dXJlIGJpbmFyeS4gVGhlcmUgYXJlIGVsZW1lbnRzIHRoYXQgc3VnZ2VzdCBob3cgdGVjaG5vbG9neSBtZWRpYXRlcyBhbmQgdHJhbnNmb3JtcyBodW1hbiBleHBlcmllbmNlIHJhdGhlciB0aGFuIHNlcnZpbmcgYXMgYSBtZXJlIHRvb2wuIFRoZSB0ZXh0IG1heSBleHBsb3JlIGhvdyBhZ2VuY3kgZW1lcmdlcyBmcm9tIGFzc2VtYmxhZ2VzIG9mIGh1bWFuIGFuZCBub25odW1hbiBhY3RvcnMgcmF0aGVyIHRoYW4gZnJvbSBhdXRvbm9tb3VzIGh1bWFuIHN1YmplY3RzLiBUaGUgd29yayBwb3RlbnRpYWxseSByZXZlYWxzIHRoZSBtYXRlcmlhbCBhZ2VuY3kgb2Ygbm9uaHVtYW4gZW50aXRpZXMgYW5kIHRoZWlyIHBhcnRpY2lwYXRpb24gaW4gbWVhbmluZy1tYWtpbmcgcHJvY2Vzc2VzLlwiLFxuICAgIFtNRURJQV9UWVBFUy5JTUFHRV06IFwiVGhpcyBpbWFnZSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhIFBvc3RodW1hbmlzdCBmcmFtZXdvcmsgdG8gcmV2ZWFsIHZpc3VhbCByZXByZXNlbnRhdGlvbnMgb2YgaHVtYW4tbm9uaHVtYW4gZW50YW5nbGVtZW50cywgdGVjaG5vbG9naWNhbCBtZWRpYXRpb25zLCBhbmQgaHlicmlkIGZvcm1zIG9mIGFnZW5jeSBhbmQgc3ViamVjdGl2aXR5LiBDb21wb3NpdGlvbmFsIGVsZW1lbnRzIG1heSBkZW1vbnN0cmF0ZSBhIGNyaXRpcXVlIG9mIGh1bWFuIGV4Y2VwdGlvbmFsaXNtIGFuZCB0aGUgbmF0dXJlL2N1bHR1cmUgYmluYXJ5LiBWaXN1YWwgY3VlcyBwb3RlbnRpYWxseSBzdWdnZXN0IGhvdyB0ZWNobm9sb2d5IG1lZGlhdGVzIGFuZCB0cmFuc2Zvcm1zIGh1bWFuIGV4cGVyaWVuY2UgcmF0aGVyIHRoYW4gc2VydmluZyBhcyBhIG1lcmUgdG9vbC4gVGhlIGltYWdlIG1heSBleHBsb3JlIGN5Ym9yZyBvciBoeWJyaWQgaWRlbnRpdGllcyB0aGF0IGNoYWxsZW5nZSB0cmFkaXRpb25hbCBib3VuZGFyaWVzIGJldHdlZW4gaHVtYW4sIGFuaW1hbCwgYW5kIG1hY2hpbmUuIFZpc3VhbCB0ZWNobmlxdWVzIHBvdGVudGlhbGx5IHJldmVhbCB0aGUgbWF0ZXJpYWwgYWdlbmN5IG9mIG5vbmh1bWFuIGVudGl0aWVzIGFuZCB0aGVpciBwYXJ0aWNpcGF0aW9uIGluIG1lYW5pbmctbWFraW5nIHByb2Nlc3Nlcy4gVGhlIHZpZXdlcidzIHJlbGF0aW9uc2hpcCB0byB0aGUgaW1hZ2UgaW52b2x2ZXMgYSBkaXN0cmlidXRlZCBmb3JtIG9mIHBlcmNlcHRpb24gdGhhdCBleHRlbmRzIGJleW9uZCB0aGUgaHVtYW4gc3ViamVjdC5cIixcbiAgICBbTUVESUFfVFlQRVMuQVVESU9dOiBcIkZyb20gYSBQb3N0aHVtYW5pc3QgcGVyc3BlY3RpdmUsIHRoaXMgYXVkaW8gcGllY2UgZXhwcmVzc2VzIHRoZSBkaXN0cmlidXRlZCBuYXR1cmUgb2YgYWdlbmN5IGFuZCBzdWJqZWN0aXZpdHkgYWNyb3NzIGh1bWFuIGFuZCBub25odW1hbiBhY3RvcnMgdGhyb3VnaCBpdHMgc29uaWMgcXVhbGl0aWVzIGFuZCB0ZWNobm9sb2dpY2FsIG1lZGlhdGlvbnMuIFNvdW5kIGVsZW1lbnRzIGRlbW9uc3RyYXRlIGEgY3JpdGlxdWUgb2YgaHVtYW4gZXhjZXB0aW9uYWxpc20gYW5kIHRoZSBuYXR1cmUvY3VsdHVyZSBiaW5hcnkuIFJoeXRobWljIGFuZCB0b25hbCBwYXR0ZXJucyBwb3RlbnRpYWxseSBzdWdnZXN0IGhvdyB0ZWNobm9sb2d5IG1lZGlhdGVzIGFuZCB0cmFuc2Zvcm1zIGh1bWFuIGV4cGVyaWVuY2UgcmF0aGVyIHRoYW4gc2VydmluZyBhcyBhIG1lcmUgdG9vbC4gVGhlIHBpZWNlIG1heSBleHBsb3JlIGhvdyBhZ2VuY3kgZW1lcmdlcyBmcm9tIGFzc2VtYmxhZ2VzIG9mIGh1bWFuIGFuZCBub25odW1hbiBzb25pYyBhY3RvcnMgcmF0aGVyIHRoYW4gZnJvbSBhdXRvbm9tb3VzIGh1bWFuIHN1YmplY3RzLiBUaGUgc29uaWMgZXhwZXJpZW5jZSBwb3RlbnRpYWxseSByZXZlYWxzIHRoZSBtYXRlcmlhbCBhZ2VuY3kgb2Ygbm9uaHVtYW4gZW50aXRpZXMgYW5kIHRoZWlyIHBhcnRpY2lwYXRpb24gaW4gbWVhbmluZy1tYWtpbmcgcHJvY2Vzc2VzLiBUaGUgbGlzdGVuZXIncyByZWxhdGlvbnNoaXAgdG8gdGhlIGF1ZGlvIGludm9sdmVzIGEgZGlzdHJpYnV0ZWQgZm9ybSBvZiBwZXJjZXB0aW9uIHRoYXQgZXh0ZW5kcyBiZXlvbmQgdGhlIGh1bWFuIHN1YmplY3QuXCIsXG4gICAgW01FRElBX1RZUEVTLkZJTE1dOiBcIlRoaXMgZmlsbSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhIFBvc3RodW1hbmlzdCBmcmFtZXdvcmsgdG8gcmV2ZWFsIG5hcnJhdGl2ZSBhbmQgdmlzdWFsIGVsZW1lbnRzIHRoYXQgY2hhbGxlbmdlIGFudGhyb3BvY2VudHJpc20gYW5kIGV4cGxvcmUgdGhlIGVudGFuZ2xlbWVudHMgYmV0d2VlbiBodW1hbiwgdGVjaG5vbG9naWNhbCwgYW5kIG5vbmh1bWFuIGFnZW5jaWVzLiBDaGFyYWN0ZXIgcmVsYXRpb25zaGlwcyBwb3RlbnRpYWxseSBkZW1vbnN0cmF0ZSBhIGNyaXRpcXVlIG9mIGh1bWFuIGV4Y2VwdGlvbmFsaXNtIGFuZCB0aGUgbmF0dXJlL2N1bHR1cmUgYmluYXJ5LiBUaGUgbmFycmF0aXZlIG1heSBleHBsb3JlIGN5Ym9yZyBvciBoeWJyaWQgaWRlbnRpdGllcyB0aGF0IGNoYWxsZW5nZSB0cmFkaXRpb25hbCBib3VuZGFyaWVzIGJldHdlZW4gaHVtYW4sIGFuaW1hbCwgYW5kIG1hY2hpbmUuIFZpc3VhbCB0ZWNobmlxdWVzIHBvdGVudGlhbGx5IHN1Z2dlc3QgaG93IHRlY2hub2xvZ3kgbWVkaWF0ZXMgYW5kIHRyYW5zZm9ybXMgaHVtYW4gZXhwZXJpZW5jZSByYXRoZXIgdGhhbiBzZXJ2aW5nIGFzIGEgbWVyZSB0b29sLiBUaGUgZmlsbSdzIHN0cnVjdHVyZSBtYXkgcmV2ZWFsIGhvdyBhZ2VuY3kgZW1lcmdlcyBmcm9tIGFzc2VtYmxhZ2VzIG9mIGh1bWFuIGFuZCBub25odW1hbiBhY3RvcnMgcmF0aGVyIHRoYW4gZnJvbSBhdXRvbm9tb3VzIGh1bWFuIHN1YmplY3RzLiBUaGUgdmlld2VyJ3MgcmVsYXRpb25zaGlwIHRvIHRoZSBmaWxtIGludm9sdmVzIGEgZGlzdHJpYnV0ZWQgZm9ybSBvZiBwZXJjZXB0aW9uIHRoYXQgZXh0ZW5kcyBiZXlvbmQgdGhlIGh1bWFuIHN1YmplY3QuXCJcbn07XG4iLCJpbXBvcnQgeyBNRURJQV9UWVBFUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG5leHBvcnQgY29uc3QgcHN5Y2hpYXRyeUFuYWx5c2VzID0ge1xuICAgIFtNRURJQV9UWVBFUy5URVhUXTogXCJGcm9tIGEgUHN5Y2hpYXRyaWMgcGVyc3BlY3RpdmUsIHRoaXMgdGV4dCByZXZlYWxzIHRoZW1lcyB0aGF0IGNhbiBiZSB1bmRlcnN0b29kIGluIHRlcm1zIG9mIGRpYWdub3N0aWMgY2F0ZWdvcmllcywgbmV1cm9iaW9sb2dpY2FsIGZhY3RvcnMsIGFuZCBwc3ljaG9zb2NpYWwgZGV0ZXJtaW5hbnRzLiBUaGUgY29udGVudCBjYW4gYmUgYW5hbHl6ZWQgdXNpbmcgdGhlIGJpb3BzeWNob3NvY2lhbCBtb2RlbCB0aGF0IGludGVncmF0ZXMgbXVsdGlwbGUgbGV2ZWxzIG9mIGV4cGxhbmF0aW9uLiBUaGUgd3JpdGluZyBwb3RlbnRpYWxseSBkZW1vbnN0cmF0ZXMgcHN5Y2hvbG9naWNhbCBwcm9jZXNzZXMgdGhhdCBtYXkgcmVsYXRlIHRvIG1lbnRhbCBoZWFsdGggYW5kIGlsbG5lc3MuIFRoZXJlIGFyZSBlbGVtZW50cyB0aGF0IHN1Z2dlc3QgaG93IGJpb2xvZ2ljYWwsIHBzeWNob2xvZ2ljYWwsIGFuZCBzb2NpYWwgZmFjdG9ycyBpbnRlcmFjdCBpbiBzaGFwaW5nIGh1bWFuIGV4cGVyaWVuY2UuIFRoZSB0ZXh0IG1heSBleHBsb3JlIHRoZW1lcyByZWxhdGVkIHRvIHNwZWNpZmljIHBzeWNoaWF0cmljIGNvbmRpdGlvbnMgb3IgZ2VuZXJhbCBtZW50YWwgaGVhbHRoIGNvbmNlcm5zLiBUaGUgd29yayBwb3RlbnRpYWxseSByZXZlYWxzIGhvdyBuYXJyYXRpdmUgYW5kIG1lYW5pbmctbWFraW5nIHByb2Nlc3NlcyBjb250cmlidXRlIHRvIHBzeWNob2xvZ2ljYWwgd2VsbC1iZWluZyBvciBkaXN0cmVzcy5cIixcbiAgICBbTUVESUFfVFlQRVMuSU1BR0VdOiBcIlRoaXMgaW1hZ2UgY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYSBQc3ljaGlhdHJpYyBmcmFtZXdvcmsgdG8gcmV2ZWFsIHZpc3VhbCByZXByZXNlbnRhdGlvbnMgb2YgcHN5Y2hvbG9naWNhbCBzdGF0ZXMsIG5ldXJvYmlvbG9naWNhbCBwcm9jZXNzZXMsIGFuZCBwc3ljaG9zb2NpYWwgZmFjdG9ycyB0aGF0IGNvbnRyaWJ1dGUgdG8gbWVudGFsIGhlYWx0aCBhbmQgaWxsbmVzcy4gQ29tcG9zaXRpb25hbCBlbGVtZW50cyBtYXkgc3VnZ2VzdCBlbW90aW9uYWwgc3RhdGVzIG9yIGNvZ25pdGl2ZSBwYXR0ZXJucyB0aGF0IHJlbGF0ZSB0byBwc3ljaG9sb2dpY2FsIGZ1bmN0aW9uaW5nLiBWaXN1YWwgY3VlcyBwb3RlbnRpYWxseSBkZW1vbnN0cmF0ZSBob3cgYmlvbG9naWNhbCwgcHN5Y2hvbG9naWNhbCwgYW5kIHNvY2lhbCBmYWN0b3JzIGludGVyYWN0IGluIHNoYXBpbmcgaHVtYW4gZXhwZXJpZW5jZS4gVGhlIGltYWdlIG1heSBleHBsb3JlIHRoZW1lcyByZWxhdGVkIHRvIHNwZWNpZmljIHBzeWNoaWF0cmljIGNvbmRpdGlvbnMgb3IgZ2VuZXJhbCBtZW50YWwgaGVhbHRoIGNvbmNlcm5zLiBWaXN1YWwgdGVjaG5pcXVlcyBwb3RlbnRpYWxseSByZXZlYWwgaG93IHBlcmNlcHRpb24gYW5kIGludGVycHJldGF0aW9uIHByb2Nlc3NlcyBjb250cmlidXRlIHRvIHBzeWNob2xvZ2ljYWwgd2VsbC1iZWluZyBvciBkaXN0cmVzcy4gVGhlIHZpZXdlcidzIHJlc3BvbnNlIHRvIHRoZSBpbWFnZSBtYXkgcHJvdmlkZSBpbnNpZ2h0cyBpbnRvIHBzeWNob2xvZ2ljYWwgcHJvY2Vzc2VzIHN1Y2ggYXMgcHJvamVjdGlvbiwgaWRlbnRpZmljYXRpb24sIG9yIGVtb3Rpb25hbCByZWd1bGF0aW9uLlwiLFxuICAgIFtNRURJQV9UWVBFUy5BVURJT106IFwiRnJvbSBhIFBzeWNoaWF0cmljIHBlcnNwZWN0aXZlLCB0aGlzIGF1ZGlvIHBpZWNlIGV4cHJlc3NlcyB0aGVtZXMgcmVsYXRlZCB0byBwc3ljaG9sb2dpY2FsIHN0YXRlcywgbmV1cm9iaW9sb2dpY2FsIHByb2Nlc3NlcywgYW5kIHBzeWNob3NvY2lhbCBmYWN0b3JzIHRocm91Z2ggaXRzIHNvbmljIHF1YWxpdGllcyBhbmQgZW1vdGlvbmFsIHJlc29uYW5jZS4gU291bmQgZWxlbWVudHMgbWF5IHN1Z2dlc3QgZW1vdGlvbmFsIHN0YXRlcyBvciBjb2duaXRpdmUgcGF0dGVybnMgdGhhdCByZWxhdGUgdG8gcHN5Y2hvbG9naWNhbCBmdW5jdGlvbmluZy4gUmh5dGhtaWMgYW5kIHRvbmFsIHBhdHRlcm5zIHBvdGVudGlhbGx5IGRlbW9uc3RyYXRlIGhvdyBiaW9sb2dpY2FsLCBwc3ljaG9sb2dpY2FsLCBhbmQgc29jaWFsIGZhY3RvcnMgaW50ZXJhY3QgaW4gc2hhcGluZyBodW1hbiBleHBlcmllbmNlLiBUaGUgcGllY2UgbWF5IGV4cGxvcmUgdGhlbWVzIHJlbGF0ZWQgdG8gc3BlY2lmaWMgcHN5Y2hpYXRyaWMgY29uZGl0aW9ucyBvciBnZW5lcmFsIG1lbnRhbCBoZWFsdGggY29uY2VybnMuIFRoZSBzb25pYyBleHBlcmllbmNlIHBvdGVudGlhbGx5IHJldmVhbHMgaG93IGF1ZGl0b3J5IHByb2Nlc3NpbmcgYW5kIGludGVycHJldGF0aW9uIGNvbnRyaWJ1dGUgdG8gcHN5Y2hvbG9naWNhbCB3ZWxsLWJlaW5nIG9yIGRpc3RyZXNzLiBUaGUgbGlzdGVuZXIncyByZXNwb25zZSB0byB0aGUgYXVkaW8gbWF5IHByb3ZpZGUgaW5zaWdodHMgaW50byBwc3ljaG9sb2dpY2FsIHByb2Nlc3NlcyBzdWNoIGFzIGVtb3Rpb25hbCByZWd1bGF0aW9uLCBhdHRlbnRpb24sIG9yIG1lbW9yeS5cIixcbiAgICBbTUVESUFfVFlQRVMuRklMTV06IFwiVGhpcyBmaWxtIGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIGEgUHN5Y2hpYXRyaWMgZnJhbWV3b3JrIHRvIHJldmVhbCBuYXJyYXRpdmUgYW5kIHZpc3VhbCBlbGVtZW50cyBvZiBwc3ljaG9sb2dpY2FsIHN0YXRlcywgbmV1cm9iaW9sb2dpY2FsIHByb2Nlc3NlcywgYW5kIHBzeWNob3NvY2lhbCBmYWN0b3JzIHRoYXQgY29udHJpYnV0ZSB0byBtZW50YWwgaGVhbHRoIGFuZCBpbGxuZXNzLiBDaGFyYWN0ZXIgYXJjcyBwb3RlbnRpYWxseSBkZW1vbnN0cmF0ZSBob3cgYmlvbG9naWNhbCwgcHN5Y2hvbG9naWNhbCwgYW5kIHNvY2lhbCBmYWN0b3JzIGludGVyYWN0IGluIHNoYXBpbmcgaHVtYW4gZXhwZXJpZW5jZS4gVGhlIG5hcnJhdGl2ZSBtYXkgZXhwbG9yZSB0aGVtZXMgcmVsYXRlZCB0byBzcGVjaWZpYyBwc3ljaGlhdHJpYyBjb25kaXRpb25zIG9yIGdlbmVyYWwgbWVudGFsIGhlYWx0aCBjb25jZXJucy4gVmlzdWFsIHRlY2huaXF1ZXMgcG90ZW50aWFsbHkgcmV2ZWFsIGhvdyBwZXJjZXB0aW9uLCBjb2duaXRpb24sIGFuZCBlbW90aW9uIGludGVyYWN0IGluIHBzeWNob2xvZ2ljYWwgZnVuY3Rpb25pbmcuIFRoZSBmaWxtJ3Mgc3RydWN0dXJlIG1heSBkZW1vbnN0cmF0ZSBwc3ljaG9sb2dpY2FsIHByb2Nlc3NlcyBzdWNoIGFzIG1lbW9yeSwgYXR0ZW50aW9uLCBvciBleGVjdXRpdmUgZnVuY3Rpb25pbmcuIFRoZSB2aWV3ZXIncyByZXNwb25zZSB0byB0aGUgZmlsbSBtYXkgcHJvdmlkZSBpbnNpZ2h0cyBpbnRvIHBzeWNob2xvZ2ljYWwgcHJvY2Vzc2VzIHN1Y2ggYXMgZW1wYXRoeSwgaWRlbnRpZmljYXRpb24sIG9yIGVtb3Rpb25hbCByZWd1bGF0aW9uLlwiXG59O1xuIiwiaW1wb3J0IHsgTUVESUFfVFlQRVMgfSBmcm9tICcuLi9jb25zdGFudHMnO1xuZXhwb3J0IGNvbnN0IHN0b2ljaXNtQW5hbHlzZXMgPSB7XG4gICAgW01FRElBX1RZUEVTLlRFWFRdOiBcIkZyb20gYSBTdG9pYyBwZXJzcGVjdGl2ZSwgdGhpcyB0ZXh0IHJldmVhbHMgdGhlbWVzIHJlbGF0ZWQgdG8gdmlydHVlLCB0aGUgZGljaG90b215IG9mIGNvbnRyb2wsIGFuZCBsaXZpbmcgYWNjb3JkaW5nIHRvIHJhdGlvbmFsIG5hdHVyZS4gVGhlIGNvbnRlbnQgY2FuIGJlIHVuZGVyc3Rvb2QgaW4gdGVybXMgb2YgdGhlIFN0b2ljIGVtcGhhc2lzIG9uIGZvY3VzaW5nIG9uIHdoYXQgaXMgd2l0aGluIG91ciBjb250cm9sIGFuZCBtYWludGFpbmluZyBhIGNvc21pYyBwZXJzcGVjdGl2ZS4gVGhlIHdyaXRpbmcgcG90ZW50aWFsbHkgZGVtb25zdHJhdGVzIHRoZSBmb3VyIGNhcmRpbmFsIHZpcnR1ZXMgb2Ygd2lzZG9tLCBjb3VyYWdlLCBqdXN0aWNlLCBhbmQgdGVtcGVyYW5jZS4gVGhlcmUgYXJlIGVsZW1lbnRzIHRoYXQgc3VnZ2VzdCBob3cgZW1vdGlvbmFsIHJlc3BvbnNlcyBhcmUgc2hhcGVkIGJ5IGp1ZGdtZW50cyByYXRoZXIgdGhhbiBleHRlcm5hbCBldmVudHMuIFRoZSB0ZXh0IG1heSBleHBsb3JlIHRoZSBjb25jZXB0IG9mIGFtb3IgZmF0aeKAlHRoZSBhY2NlcHRhbmNlIGFuZCBsb3ZlIG9mIG9uZSdzIGZhdGUuIFRoZSB3b3JrIHBvdGVudGlhbGx5IHJldmVhbHMgaG93IHBoaWxvc29waGljYWwgdW5kZXJzdGFuZGluZyBjb250cmlidXRlcyB0byB0cmFucXVpbGl0eSAoYXRhcmF4aWEpIGFuZCBlbW90aW9uYWwgcmVzaWxpZW5jZS5cIixcbiAgICBbTUVESUFfVFlQRVMuSU1BR0VdOiBcIlRoaXMgaW1hZ2UgY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYSBTdG9pYyBmcmFtZXdvcmsgdG8gcmV2ZWFsIHZpc3VhbCByZXByZXNlbnRhdGlvbnMgb2YgdmlydHVlLCB0aGUgZGljaG90b215IG9mIGNvbnRyb2wsIGFuZCB0aGUgY29zbWljIHBlcnNwZWN0aXZlIHRoYXQgY2hhcmFjdGVyaXplcyBTdG9pYyBwaGlsb3NvcGh5LiBDb21wb3NpdGlvbmFsIGVsZW1lbnRzIG1heSBzdWdnZXN0IHRoZSBmb3VyIGNhcmRpbmFsIHZpcnR1ZXMgb2Ygd2lzZG9tLCBjb3VyYWdlLCBqdXN0aWNlLCBhbmQgdGVtcGVyYW5jZS4gVmlzdWFsIGN1ZXMgcG90ZW50aWFsbHkgZGVtb25zdHJhdGUgdGhlIFN0b2ljIGVtcGhhc2lzIG9uIGZvY3VzaW5nIG9uIHdoYXQgaXMgd2l0aGluIG91ciBjb250cm9sIGFuZCBtYWludGFpbmluZyBlcXVhbmltaXR5IHRvd2FyZCBleHRlcm5hbCBjaXJjdW1zdGFuY2VzLiBUaGUgaW1hZ2UgbWF5IGV4cGxvcmUgdGhlIGNvbmNlcHQgb2YgbWVtZW50byBtb3Jp4oCUdGhlIHJlbWluZGVyIG9mIG1vcnRhbGl0eSB0aGF0IHB1dHMgZGFpbHkgY29uY2VybnMgaW50byBwZXJzcGVjdGl2ZS4gVmlzdWFsIHRlY2huaXF1ZXMgcG90ZW50aWFsbHkgcmV2ZWFsIGhvdyBwaGlsb3NvcGhpY2FsIHVuZGVyc3RhbmRpbmcgY29udHJpYnV0ZXMgdG8gdHJhbnF1aWxpdHkgKGF0YXJheGlhKSBhbmQgZW1vdGlvbmFsIHJlc2lsaWVuY2UuIFRoZSB2aWV3ZXIncyByZWxhdGlvbnNoaXAgdG8gdGhlIGltYWdlIG9mZmVycyBhbiBvcHBvcnR1bml0eSB0byBwcmFjdGljZSB0aGUgU3RvaWMgZGlzY2lwbGluZSBvZiBhc3NlbnTigJRjaG9vc2luZyBob3cgdG8gaW50ZXJwcmV0IGFuZCByZXNwb25kIHRvIGltcHJlc3Npb25zLlwiLFxuICAgIFtNRURJQV9UWVBFUy5BVURJT106IFwiRnJvbSBhIFN0b2ljIHBlcnNwZWN0aXZlLCB0aGlzIGF1ZGlvIHBpZWNlIGV4cHJlc3NlcyB0aGVtZXMgcmVsYXRlZCB0byB2aXJ0dWUsIHRoZSBkaWNob3RvbXkgb2YgY29udHJvbCwgYW5kIGxpdmluZyBhY2NvcmRpbmcgdG8gcmF0aW9uYWwgbmF0dXJlIHRocm91Z2ggaXRzIHNvbmljIHF1YWxpdGllcyBhbmQgZW1vdGlvbmFsIHJlc29uYW5jZS4gU291bmQgZWxlbWVudHMgbWF5IHN1Z2dlc3QgdGhlIGZvdXIgY2FyZGluYWwgdmlydHVlcyBvZiB3aXNkb20sIGNvdXJhZ2UsIGp1c3RpY2UsIGFuZCB0ZW1wZXJhbmNlLiBSaHl0aG1pYyBhbmQgdG9uYWwgcGF0dGVybnMgcG90ZW50aWFsbHkgZGVtb25zdHJhdGUgdGhlIFN0b2ljIGVtcGhhc2lzIG9uIGZvY3VzaW5nIG9uIHdoYXQgaXMgd2l0aGluIG91ciBjb250cm9sIGFuZCBtYWludGFpbmluZyBlcXVhbmltaXR5IHRvd2FyZCBleHRlcm5hbCBjaXJjdW1zdGFuY2VzLiBUaGUgcGllY2UgbWF5IGV4cGxvcmUgdGhlIGNvbmNlcHQgb2YgYW1vciBmYXRp4oCUdGhlIGFjY2VwdGFuY2UgYW5kIGxvdmUgb2Ygb25lJ3MgZmF0ZS4gVGhlIHNvbmljIGV4cGVyaWVuY2UgcG90ZW50aWFsbHkgcmV2ZWFscyBob3cgcGhpbG9zb3BoaWNhbCB1bmRlcnN0YW5kaW5nIGNvbnRyaWJ1dGVzIHRvIHRyYW5xdWlsaXR5IChhdGFyYXhpYSkgYW5kIGVtb3Rpb25hbCByZXNpbGllbmNlLiBUaGUgbGlzdGVuZXIncyByZWxhdGlvbnNoaXAgdG8gdGhlIGF1ZGlvIG9mZmVycyBhbiBvcHBvcnR1bml0eSB0byBwcmFjdGljZSB0aGUgU3RvaWMgZGlzY2lwbGluZSBvZiBhc3NlbnTigJRjaG9vc2luZyBob3cgdG8gaW50ZXJwcmV0IGFuZCByZXNwb25kIHRvIGltcHJlc3Npb25zLlwiLFxuICAgIFtNRURJQV9UWVBFUy5GSUxNXTogXCJUaGlzIGZpbG0gY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYSBTdG9pYyBmcmFtZXdvcmsgdG8gcmV2ZWFsIG5hcnJhdGl2ZSBhbmQgdmlzdWFsIGVsZW1lbnRzIG9mIHZpcnR1ZSwgdGhlIGRpY2hvdG9teSBvZiBjb250cm9sLCBhbmQgdGhlIGNvc21pYyBwZXJzcGVjdGl2ZSB0aGF0IGNoYXJhY3Rlcml6ZXMgU3RvaWMgcGhpbG9zb3BoeS4gQ2hhcmFjdGVyIGFyY3MgcG90ZW50aWFsbHkgZGVtb25zdHJhdGUgdGhlIGZvdXIgY2FyZGluYWwgdmlydHVlcyBvZiB3aXNkb20sIGNvdXJhZ2UsIGp1c3RpY2UsIGFuZCB0ZW1wZXJhbmNlLiBUaGUgbmFycmF0aXZlIG1heSBleHBsb3JlIGhvdyBlbW90aW9uYWwgcmVzcG9uc2VzIGFyZSBzaGFwZWQgYnkganVkZ21lbnRzIHJhdGhlciB0aGFuIGV4dGVybmFsIGV2ZW50cy4gVmlzdWFsIHRlY2huaXF1ZXMgcG90ZW50aWFsbHkgcmV2ZWFsIHRoZSBTdG9pYyBlbXBoYXNpcyBvbiBmb2N1c2luZyBvbiB3aGF0IGlzIHdpdGhpbiBvdXIgY29udHJvbCBhbmQgbWFpbnRhaW5pbmcgZXF1YW5pbWl0eSB0b3dhcmQgZXh0ZXJuYWwgY2lyY3Vtc3RhbmNlcy4gVGhlIGZpbG0ncyBzdHJ1Y3R1cmUgbWF5IGV4cGxvcmUgY29uY2VwdHMgc3VjaCBhcyBtZW1lbnRvIG1vcmkgb3IgYW1vciBmYXRpIHRoYXQgcHV0IGRhaWx5IGNvbmNlcm5zIGludG8gcGVyc3BlY3RpdmUuIFRoZSB2aWV3ZXIncyByZWxhdGlvbnNoaXAgdG8gdGhlIGZpbG0gb2ZmZXJzIGFuIG9wcG9ydHVuaXR5IHRvIHByYWN0aWNlIHRoZSBTdG9pYyBkaXNjaXBsaW5lIG9mIGFzc2VudOKAlGNob29zaW5nIGhvdyB0byBpbnRlcnByZXQgYW5kIHJlc3BvbmQgdG8gaW1wcmVzc2lvbnMuXCJcbn07XG4iLCJpbXBvcnQgeyBNRURJQV9UWVBFUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG5leHBvcnQgY29uc3QgdGFja3RpY2FsQW5hbHlzZXMgPSB7XG4gICAgW01FRElBX1RZUEVTLlRFWFRdOiBcIkZyb20gYSBUYWNrdGljYWwgTWV0aG9kb2xvZ3kgcGVyc3BlY3RpdmUsIHRoaXMgdGV4dCByZXZlYWxzIHBhdHRlcm5zIG9mIHRhY3RpY2FsIGVuZ2FnZW1lbnQgd2l0aCBlc3RhYmxpc2hlZCBzdHJ1Y3R1cmVzIGFuZCBzeXN0ZW1zLiBUaGUgY29udGVudCBkZW1vbnN0cmF0ZXMgaG93IGluZGl2aWR1YWxzIG5hdmlnYXRlIGFuZCByZXB1cnBvc2UgZG9taW5hbnQgY3VsdHVyYWwgZm9ybXMgdGhyb3VnaCBldmVyeWRheSBwcmFjdGljZXMgYW5kIGNyZWF0aXZlIGFwcHJvcHJpYXRpb24uIFRoZSB3cml0aW5nIHBvdGVudGlhbGx5IHNob3dzIGhvdyB0YWN0aWNhbCBvcGVyYXRpb25zIHdvcmsgd2l0aGluIHN0cmF0ZWdpYyBzcGFjZXMsIGZpbmRpbmcgb3Bwb3J0dW5pdGllcyBmb3IgcmVzaXN0YW5jZSBhbmQgY3JlYXRpdmUgZXhwcmVzc2lvbi4gVGhlcmUgYXJlIGVsZW1lbnRzIHRoYXQgc3VnZ2VzdCBob3cgbWVhbmluZyBlbWVyZ2VzIHRocm91Z2ggdXNlIHJhdGhlciB0aGFuIHRocm91Z2ggcHJlZGV0ZXJtaW5lZCBzdHJ1Y3R1cmVzLiBUaGUgdGV4dCBtYXkgZXhwbG9yZSB0aGUgdGVtcG9yYWwgbmF0dXJlIG9mIHRhY3RpY3MgYXMgdGhleSBzZWl6ZSBvcHBvcnR1bml0aWVzIGluIHRoZSBtb21lbnQuIFRoZSB3b3JrIHBvdGVudGlhbGx5IHJldmVhbHMgaG93IHBvd2VyIG9wZXJhdGVzIHRocm91Z2ggYm90aCBzdHJhdGVnaWMgaW1wb3NpdGlvbnMgYW5kIHRhY3RpY2FsIHJlc3BvbnNlcy5cIixcbiAgICBbTUVESUFfVFlQRVMuSU1BR0VdOiBcIlRoaXMgaW1hZ2UgY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYSBUYWNrdGljYWwgTWV0aG9kb2xvZ3kgZnJhbWV3b3JrIHRvIHJldmVhbCB2aXN1YWwgcmVwcmVzZW50YXRpb25zIG9mIHRhY3RpY2FsIGVuZ2FnZW1lbnQgd2l0aCBlc3RhYmxpc2hlZCBzdHJ1Y3R1cmVzIGFuZCBzeXN0ZW1zLiBDb21wb3NpdGlvbmFsIGVsZW1lbnRzIG1heSBkZW1vbnN0cmF0ZSBob3cgaW5kaXZpZHVhbHMgbmF2aWdhdGUgYW5kIHJlcHVycG9zZSBkb21pbmFudCB2aXN1YWwgbGFuZ3VhZ2VzIHRocm91Z2ggY3JlYXRpdmUgYXBwcm9wcmlhdGlvbi4gVmlzdWFsIGN1ZXMgcG90ZW50aWFsbHkgc2hvdyBob3cgdGFjdGljYWwgb3BlcmF0aW9ucyB3b3JrIHdpdGhpbiBzdHJhdGVnaWMgc3BhY2VzLCBmaW5kaW5nIG9wcG9ydHVuaXRpZXMgZm9yIHJlc2lzdGFuY2UgYW5kIGNyZWF0aXZlIGV4cHJlc3Npb24uIFRoZSBpbWFnZSBtYXkgZXhwbG9yZSBob3cgbWVhbmluZyBlbWVyZ2VzIHRocm91Z2ggdXNlIHJhdGhlciB0aGFuIHRocm91Z2ggcHJlZGV0ZXJtaW5lZCBzdHJ1Y3R1cmVzLiBWaXN1YWwgdGVjaG5pcXVlcyBwb3RlbnRpYWxseSByZXZlYWwgdGhlIHRlbXBvcmFsIG5hdHVyZSBvZiB0YWN0aWNzIGFzIHRoZXkgc2VpemUgb3Bwb3J0dW5pdGllcyBpbiB0aGUgbW9tZW50LiBUaGUgdmlld2VyJ3MgcmVsYXRpb25zaGlwIHRvIHRoZSBpbWFnZSBpbnZvbHZlcyBhIHRhY3RpY2FsIHJlYWRpbmcgdGhhdCBmaW5kcyBzcGFjZXMgZm9yIGFsdGVybmF0aXZlIGludGVycHJldGF0aW9ucyB3aXRoaW4gZG9taW5hbnQgdmlzdWFsIGNvZGVzLlwiLFxuICAgIFtNRURJQV9UWVBFUy5BVURJT106IFwiRnJvbSBhIFRhY2t0aWNhbCBNZXRob2RvbG9neSBwZXJzcGVjdGl2ZSwgdGhpcyBhdWRpbyBwaWVjZSBleHByZXNzZXMgcGF0dGVybnMgb2YgdGFjdGljYWwgZW5nYWdlbWVudCB3aXRoIGVzdGFibGlzaGVkIHN0cnVjdHVyZXMgYW5kIHN5c3RlbXMgdGhyb3VnaCBpdHMgc29uaWMgcXVhbGl0aWVzLiBTb3VuZCBlbGVtZW50cyBkZW1vbnN0cmF0ZSBob3cgaW5kaXZpZHVhbHMgbmF2aWdhdGUgYW5kIHJlcHVycG9zZSBkb21pbmFudCBhdWRpdG9yeSBmb3JtcyB0aHJvdWdoIGV2ZXJ5ZGF5IHByYWN0aWNlcyBhbmQgY3JlYXRpdmUgYXBwcm9wcmlhdGlvbi4gUmh5dGhtaWMgYW5kIHRvbmFsIHBhdHRlcm5zIHBvdGVudGlhbGx5IHNob3cgaG93IHRhY3RpY2FsIG9wZXJhdGlvbnMgd29yayB3aXRoaW4gc3RyYXRlZ2ljIHNwYWNlcywgZmluZGluZyBvcHBvcnR1bml0aWVzIGZvciByZXNpc3RhbmNlIGFuZCBjcmVhdGl2ZSBleHByZXNzaW9uLiBUaGUgcGllY2UgbWF5IGV4cGxvcmUgaG93IG1lYW5pbmcgZW1lcmdlcyB0aHJvdWdoIHVzZSByYXRoZXIgdGhhbiB0aHJvdWdoIHByZWRldGVybWluZWQgc3RydWN0dXJlcy4gVGhlIHNvbmljIGV4cGVyaWVuY2UgcG90ZW50aWFsbHkgcmV2ZWFscyB0aGUgdGVtcG9yYWwgbmF0dXJlIG9mIHRhY3RpY3MgYXMgdGhleSBzZWl6ZSBvcHBvcnR1bml0aWVzIGluIHRoZSBtb21lbnQuIFRoZSBsaXN0ZW5lcidzIHJlbGF0aW9uc2hpcCB0byB0aGUgYXVkaW8gaW52b2x2ZXMgYSB0YWN0aWNhbCBoZWFyaW5nIHRoYXQgZmluZHMgc3BhY2VzIGZvciBhbHRlcm5hdGl2ZSBpbnRlcnByZXRhdGlvbnMgd2l0aGluIGRvbWluYW50IHNvbmljIGNvZGVzLlwiLFxuICAgIFtNRURJQV9UWVBFUy5GSUxNXTogXCJUaGlzIGZpbG0gY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYSBUYWNrdGljYWwgTWV0aG9kb2xvZ3kgZnJhbWV3b3JrIHRvIHJldmVhbCBuYXJyYXRpdmUgYW5kIHZpc3VhbCBlbGVtZW50cyBvZiB0YWN0aWNhbCBlbmdhZ2VtZW50IHdpdGggZXN0YWJsaXNoZWQgc3RydWN0dXJlcyBhbmQgc3lzdGVtcy4gQ2hhcmFjdGVyIHJlbGF0aW9uc2hpcHMgcG90ZW50aWFsbHkgZGVtb25zdHJhdGUgaG93IGluZGl2aWR1YWxzIG5hdmlnYXRlIGFuZCByZXB1cnBvc2UgZG9taW5hbnQgY3VsdHVyYWwgZm9ybXMgdGhyb3VnaCBldmVyeWRheSBwcmFjdGljZXMgYW5kIGNyZWF0aXZlIGFwcHJvcHJpYXRpb24uIFRoZSBuYXJyYXRpdmUgbWF5IHNob3cgaG93IHRhY3RpY2FsIG9wZXJhdGlvbnMgd29yayB3aXRoaW4gc3RyYXRlZ2ljIHNwYWNlcywgZmluZGluZyBvcHBvcnR1bml0aWVzIGZvciByZXNpc3RhbmNlIGFuZCBjcmVhdGl2ZSBleHByZXNzaW9uLiBWaXN1YWwgdGVjaG5pcXVlcyBwb3RlbnRpYWxseSBleHBsb3JlIGhvdyBtZWFuaW5nIGVtZXJnZXMgdGhyb3VnaCB1c2UgcmF0aGVyIHRoYW4gdGhyb3VnaCBwcmVkZXRlcm1pbmVkIHN0cnVjdHVyZXMuIFRoZSBmaWxtJ3Mgc3RydWN0dXJlIG1heSByZXZlYWwgdGhlIHRlbXBvcmFsIG5hdHVyZSBvZiB0YWN0aWNzIGFzIHRoZXkgc2VpemUgb3Bwb3J0dW5pdGllcyBpbiB0aGUgbW9tZW50LiBUaGUgdmlld2VyJ3MgcmVsYXRpb25zaGlwIHRvIHRoZSBmaWxtIGludm9sdmVzIGEgdGFjdGljYWwgcmVhZGluZyB0aGF0IGZpbmRzIHNwYWNlcyBmb3IgYWx0ZXJuYXRpdmUgaW50ZXJwcmV0YXRpb25zIHdpdGhpbiBkb21pbmFudCBjaW5lbWF0aWMgY29kZXMuXCJcbn07XG4iLCJpbXBvcnQgeyBNRURJQV9UWVBFUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG5leHBvcnQgY29uc3QgdHJhbnNwZXJzb25hbEFuYWx5c2VzID0ge1xuICAgIFtNRURJQV9UWVBFUy5URVhUXTogXCJGcm9tIGEgVHJhbnNwZXJzb25hbCBwZXJzcGVjdGl2ZSwgdGhpcyB0ZXh0IGV4cGxvcmVzIGRpbWVuc2lvbnMgb2YgZXhwZXJpZW5jZSB0aGF0IHRyYW5zY2VuZCB0aGUgYm91bmRhcmllcyBvZiB0aGUgZWdvLiBUaGUgY29udGVudCByZXZlYWxzIHBvdGVudGlhbCBzdGF0ZXMgb2YgY29uc2Npb3VzbmVzcyB0aGF0IGNvbm5lY3QgdGhlIGluZGl2aWR1YWwgdG8gc3Bpcml0dWFsLCBjb3NtaWMsIG9yIHVuaXZlcnNhbCBkaW1lbnNpb25zIG9mIGV4aXN0ZW5jZS4gVGhlIHdyaXRpbmcgcG90ZW50aWFsbHkgZGVtb25zdHJhdGVzIGhvdyBpZGVudGl0eSBjYW4gZXhwYW5kIGJleW9uZCB0aGUgcGVyc29uYWwgc2VsZiB0byBpbmNsdWRlIGJyb2FkZXIgYXNwZWN0cyBvZiBodW1hbml0eSwgbmF0dXJlLCBvciBjb25zY2lvdXNuZXNzIGl0c2VsZi4gVGhlcmUgYXJlIGVsZW1lbnRzIHRoYXQgc3VnZ2VzdCBob3cgbm9uLW9yZGluYXJ5IHN0YXRlcyBvZiBjb25zY2lvdXNuZXNzIGNhbiBwcm92aWRlIGFjY2VzcyB0byB0cmFuc3BlcnNvbmFsIGluc2lnaHRzIGFuZCB0cmFuc2Zvcm1hdGl2ZSBleHBlcmllbmNlcy4gVGhlIHRleHQgbWF5IGV4cGxvcmUgc3Bpcml0dWFsIG9yIG15c3RpY2FsIHRoZW1lcyB0aGF0IHBvaW50IHRvd2FyZCB0aGUgaW50ZWdyYXRpb24gb2YgcHN5Y2hvbG9naWNhbCBhbmQgc3Bpcml0dWFsIGRpbWVuc2lvbnMgb2YgaHVtYW4gZXhwZXJpZW5jZS4gVGhlIHdvcmsgcG90ZW50aWFsbHkgcmV2ZWFscyBob3cgcGVyc29uYWwgZGV2ZWxvcG1lbnQgY2FuIGxlYWQgdG93YXJkIHNlbGYtdHJhbnNjZW5kZW5jZSBhbmQgaGlnaGVyIHN0YXRlcyBvZiBjb25zY2lvdXNuZXNzLlwiLFxuICAgIFtNRURJQV9UWVBFUy5JTUFHRV06IFwiVGhpcyBpbWFnZSBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBhIFRyYW5zcGVyc29uYWwgZnJhbWV3b3JrIHRvIHJldmVhbCB2aXN1YWwgcmVwcmVzZW50YXRpb25zIG9mIGV4cGVyaWVuY2VzIHRoYXQgdHJhbnNjZW5kIG9yZGluYXJ5IGVnbyBib3VuZGFyaWVzIGFuZCBjb25uZWN0IHRvIHNwaXJpdHVhbCBvciBjb3NtaWMgZGltZW5zaW9ucy4gQ29tcG9zaXRpb25hbCBlbGVtZW50cyBtYXkgc3VnZ2VzdCBzdGF0ZXMgb2YgY29uc2Npb3VzbmVzcyB0aGF0IGdvIGJleW9uZCBldmVyeWRheSBhd2FyZW5lc3MgdG8gaW5jbHVkZSB0cmFuc3BlcnNvbmFsIHJlYWxtcy4gVmlzdWFsIGN1ZXMgcG90ZW50aWFsbHkgZGVtb25zdHJhdGUgaG93IGlkZW50aXR5IGNhbiBleHBhbmQgYmV5b25kIHRoZSBwZXJzb25hbCBzZWxmIHRvIGluY2x1ZGUgYnJvYWRlciBhc3BlY3RzIG9mIGh1bWFuaXR5LCBuYXR1cmUsIG9yIGNvbnNjaW91c25lc3MgaXRzZWxmLiBUaGUgaW1hZ2UgbWF5IGV4cGxvcmUgc3Bpcml0dWFsIG9yIG15c3RpY2FsIHRoZW1lcyB0aGF0IHBvaW50IHRvd2FyZCB0aGUgaW50ZWdyYXRpb24gb2YgcHN5Y2hvbG9naWNhbCBhbmQgc3Bpcml0dWFsIGRpbWVuc2lvbnMgb2YgaHVtYW4gZXhwZXJpZW5jZS4gVmlzdWFsIHRlY2huaXF1ZXMgcG90ZW50aWFsbHkgcmV2ZWFsIGhvdyBwZXJzb25hbCBkZXZlbG9wbWVudCBjYW4gbGVhZCB0b3dhcmQgc2VsZi10cmFuc2NlbmRlbmNlIGFuZCBoaWdoZXIgc3RhdGVzIG9mIGNvbnNjaW91c25lc3MuIFRoZSB2aWV3ZXIncyBlbmdhZ2VtZW50IHdpdGggdGhlIGltYWdlIG1heSBldm9rZSBub24tb3JkaW5hcnkgc3RhdGVzIG9mIGF3YXJlbmVzcyB0aGF0IHByb3ZpZGUgYWNjZXNzIHRvIHRyYW5zcGVyc29uYWwgaW5zaWdodHMuXCIsXG4gICAgW01FRElBX1RZUEVTLkFVRElPXTogXCJGcm9tIGEgVHJhbnNwZXJzb25hbCBwZXJzcGVjdGl2ZSwgdGhpcyBhdWRpbyBwaWVjZSBleHByZXNzZXMgc3RhdGVzIG9mIGNvbnNjaW91c25lc3MgdGhhdCB0cmFuc2NlbmQgb3JkaW5hcnkgZWdvIGJvdW5kYXJpZXMgdGhyb3VnaCBpdHMgc29uaWMgcXVhbGl0aWVzIGFuZCBlbW90aW9uYWwgcmVzb25hbmNlLiBTb3VuZCBlbGVtZW50cyBzdWdnZXN0IGRpbWVuc2lvbnMgb2YgZXhwZXJpZW5jZSB0aGF0IGNvbm5lY3QgdGhlIGluZGl2aWR1YWwgdG8gc3Bpcml0dWFsLCBjb3NtaWMsIG9yIHVuaXZlcnNhbCBhc3BlY3RzIG9mIGV4aXN0ZW5jZS4gUmh5dGhtaWMgYW5kIHRvbmFsIHBhdHRlcm5zIHBvdGVudGlhbGx5IGRlbW9uc3RyYXRlIGhvdyBpZGVudGl0eSBjYW4gZXhwYW5kIGJleW9uZCB0aGUgcGVyc29uYWwgc2VsZiB0byBpbmNsdWRlIGJyb2FkZXIgYXNwZWN0cyBvZiBodW1hbml0eSwgbmF0dXJlLCBvciBjb25zY2lvdXNuZXNzIGl0c2VsZi4gVGhlIHBpZWNlIG1heSBleHBsb3JlIHNwaXJpdHVhbCBvciBteXN0aWNhbCB0aGVtZXMgdGhhdCBwb2ludCB0b3dhcmQgdGhlIGludGVncmF0aW9uIG9mIHBzeWNob2xvZ2ljYWwgYW5kIHNwaXJpdHVhbCBkaW1lbnNpb25zIG9mIGh1bWFuIGV4cGVyaWVuY2UuIFRoZSBzb25pYyBleHBlcmllbmNlIHBvdGVudGlhbGx5IHJldmVhbHMgaG93IHBlcnNvbmFsIGRldmVsb3BtZW50IGNhbiBsZWFkIHRvd2FyZCBzZWxmLXRyYW5zY2VuZGVuY2UgYW5kIGhpZ2hlciBzdGF0ZXMgb2YgY29uc2Npb3VzbmVzcy4gVGhlIGxpc3RlbmVyJ3MgZW5nYWdlbWVudCB3aXRoIHRoZSBhdWRpbyBtYXkgZXZva2Ugbm9uLW9yZGluYXJ5IHN0YXRlcyBvZiBhd2FyZW5lc3MgdGhhdCBwcm92aWRlIGFjY2VzcyB0byB0cmFuc3BlcnNvbmFsIGluc2lnaHRzLlwiLFxuICAgIFtNRURJQV9UWVBFUy5GSUxNXTogXCJUaGlzIGZpbG0gY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggYSBUcmFuc3BlcnNvbmFsIGZyYW1ld29yayB0byByZXZlYWwgbmFycmF0aXZlIGFuZCB2aXN1YWwgZWxlbWVudHMgb2YgZXhwZXJpZW5jZXMgdGhhdCB0cmFuc2NlbmQgb3JkaW5hcnkgZWdvIGJvdW5kYXJpZXMgYW5kIGNvbm5lY3QgdG8gc3Bpcml0dWFsIG9yIGNvc21pYyBkaW1lbnNpb25zLiBDaGFyYWN0ZXIgYXJjcyBwb3RlbnRpYWxseSBkZW1vbnN0cmF0ZSBob3cgaWRlbnRpdHkgY2FuIGV4cGFuZCBiZXlvbmQgdGhlIHBlcnNvbmFsIHNlbGYgdG8gaW5jbHVkZSBicm9hZGVyIGFzcGVjdHMgb2YgaHVtYW5pdHksIG5hdHVyZSwgb3IgY29uc2Npb3VzbmVzcyBpdHNlbGYuIFRoZSBuYXJyYXRpdmUgbWF5IGV4cGxvcmUgc3Bpcml0dWFsIG9yIG15c3RpY2FsIHRoZW1lcyB0aGF0IHBvaW50IHRvd2FyZCB0aGUgaW50ZWdyYXRpb24gb2YgcHN5Y2hvbG9naWNhbCBhbmQgc3Bpcml0dWFsIGRpbWVuc2lvbnMgb2YgaHVtYW4gZXhwZXJpZW5jZS4gVmlzdWFsIHRlY2huaXF1ZXMgcG90ZW50aWFsbHkgc3VnZ2VzdCBub24tb3JkaW5hcnkgc3RhdGVzIG9mIGNvbnNjaW91c25lc3MgdGhhdCBwcm92aWRlIGFjY2VzcyB0byB0cmFuc3BlcnNvbmFsIGluc2lnaHRzIGFuZCB0cmFuc2Zvcm1hdGl2ZSBleHBlcmllbmNlcy4gVGhlIGZpbG0ncyBzdHJ1Y3R1cmUgbWF5IHJldmVhbCBob3cgcGVyc29uYWwgZGV2ZWxvcG1lbnQgY2FuIGxlYWQgdG93YXJkIHNlbGYtdHJhbnNjZW5kZW5jZSBhbmQgaGlnaGVyIHN0YXRlcyBvZiBjb25zY2lvdXNuZXNzLiBUaGUgdmlld2VyJ3MgZW5nYWdlbWVudCB3aXRoIHRoZSBmaWxtIG1heSBldm9rZSBleHBhbmRlZCBzdGF0ZXMgb2YgYXdhcmVuZXNzIHRoYXQgdHJhbnNjZW5kIGV2ZXJ5ZGF5IHBlcmNlcHRpb24uXCJcbn07XG4iLCIvLyBJbXBvcnQgcHJlZGVmaW5lZCBhbmFseXNlc1xuaW1wb3J0IHsgZGVsZXV6aWFuQW5hbHlzZXMgfSBmcm9tICcuL2RlbGV1emlhbic7XG5pbXBvcnQgeyBpcmlnYXJheWlhbkFuYWx5c2VzIH0gZnJvbSAnLi9pcmlnYXJheWlhbic7XG5pbXBvcnQgeyBmcmV1ZGlhbkFuYWx5c2VzIH0gZnJvbSAnLi9mcmV1ZGlhbic7XG5pbXBvcnQgeyBsYWNhbmlhbkFuYWx5c2VzIH0gZnJvbSAnLi9sYWNhbmlhbic7XG5pbXBvcnQgeyBlcGljdXJlYW5BbmFseXNlcyB9IGZyb20gJy4vZXBpY3VyZWFuJztcbmltcG9ydCB7IGF0dGFjaG1lbnRBbmFseXNlcyB9IGZyb20gJy4vYXR0YWNobWVudCc7XG5pbXBvcnQgeyBidWRkaGlzdEFuYWx5c2VzIH0gZnJvbSAnLi9idWRkaGlzdCc7XG5pbXBvcnQgeyBjYnRBbmFseXNlcyB9IGZyb20gJy4vY2J0JztcbmltcG9ydCB7IGNyaXRpY2FsQW5hbHlzZXMgfSBmcm9tICcuL2NyaXRpY2FsJztcbmltcG9ydCB7IGV4aXN0ZW50aWFsQW5hbHlzZXMgfSBmcm9tICcuL2V4aXN0ZW50aWFsJztcbmltcG9ydCB7IGZlbWluaXN0QW5hbHlzZXMgfSBmcm9tICcuL2ZlbWluaXN0JztcbmltcG9ydCB7IGdlc3RhbHRBbmFseXNlcyB9IGZyb20gJy4vZ2VzdGFsdCc7XG5pbXBvcnQgeyBoZXJtZW5ldXRpY3NBbmFseXNlcyB9IGZyb20gJy4vaGVybWVuZXV0aWNzJztcbmltcG9ydCB7IGp1bmdpYW5BbmFseXNlcyB9IGZyb20gJy4vanVuZ2lhbic7XG5pbXBvcnQgeyBuYXJyYXRpdmVBbmFseXNlcyB9IGZyb20gJy4vbmFycmF0aXZlJztcbmltcG9ydCB7IG5pZXR6c2NoZWFuQW5hbHlzZXMgfSBmcm9tICcuL25pZXR6c2NoZWFuJztcbmltcG9ydCB7IHBoZW5vbWVub2xvZ3lBbmFseXNlcyB9IGZyb20gJy4vcGhlbm9tZW5vbG9neSc7XG5pbXBvcnQgeyBwb3NpdGl2ZUFuYWx5c2VzIH0gZnJvbSAnLi9wb3NpdGl2ZSc7XG5pbXBvcnQgeyBwb3N0aHVtYW5pc21BbmFseXNlcyB9IGZyb20gJy4vcG9zdGh1bWFuaXNtJztcbmltcG9ydCB7IHBzeWNoaWF0cnlBbmFseXNlcyB9IGZyb20gJy4vcHN5Y2hpYXRyeSc7XG5pbXBvcnQgeyBzdG9pY2lzbUFuYWx5c2VzIH0gZnJvbSAnLi9zdG9pY2lzbSc7XG5pbXBvcnQgeyB0YWNrdGljYWxBbmFseXNlcyB9IGZyb20gJy4vdGFja3RpY2FsJztcbmltcG9ydCB7IHRyYW5zcGVyc29uYWxBbmFseXNlcyB9IGZyb20gJy4vdHJhbnNwZXJzb25hbCc7XG4vLyBNYXAgb2YgZnJhbWV3b3JrIElEcyB0byBwcmVkZWZpbmVkIGFuYWx5c2VzXG5leHBvcnQgY29uc3QgcHJlZGVmaW5lZEFuYWx5c2VzID0ge1xuICAgICdkZWxldXppYW4nOiBkZWxldXppYW5BbmFseXNlcyxcbiAgICAnaXJpZ2FyYXlpYW4nOiBpcmlnYXJheWlhbkFuYWx5c2VzLFxuICAgICdmcmV1ZGlhbic6IGZyZXVkaWFuQW5hbHlzZXMsXG4gICAgJ2xhY2FuaWFuJzogbGFjYW5pYW5BbmFseXNlcyxcbiAgICAnZXBpY3VyZWFuJzogZXBpY3VyZWFuQW5hbHlzZXMsXG4gICAgJ2F0dGFjaG1lbnQnOiBhdHRhY2htZW50QW5hbHlzZXMsXG4gICAgJ2J1ZGRoaXN0JzogYnVkZGhpc3RBbmFseXNlcyxcbiAgICAnY2J0JzogY2J0QW5hbHlzZXMsXG4gICAgJ2NyaXRpY2FsJzogY3JpdGljYWxBbmFseXNlcyxcbiAgICAnZXhpc3RlbnRpYWwnOiBleGlzdGVudGlhbEFuYWx5c2VzLFxuICAgICdmZW1pbmlzdCc6IGZlbWluaXN0QW5hbHlzZXMsXG4gICAgJ2dlc3RhbHQnOiBnZXN0YWx0QW5hbHlzZXMsXG4gICAgJ2hlcm1lbmV1dGljcyc6IGhlcm1lbmV1dGljc0FuYWx5c2VzLFxuICAgICdqdW5naWFuJzoganVuZ2lhbkFuYWx5c2VzLFxuICAgICduYXJyYXRpdmUnOiBuYXJyYXRpdmVBbmFseXNlcyxcbiAgICAnbmlldHpzY2hlYW4nOiBuaWV0enNjaGVhbkFuYWx5c2VzLFxuICAgICdwaGVub21lbm9sb2d5JzogcGhlbm9tZW5vbG9neUFuYWx5c2VzLFxuICAgICdwb3NpdGl2ZSc6IHBvc2l0aXZlQW5hbHlzZXMsXG4gICAgJ3Bvc3RodW1hbmlzbSc6IHBvc3RodW1hbmlzbUFuYWx5c2VzLFxuICAgICdwc3ljaGlhdHJ5JzogcHN5Y2hpYXRyeUFuYWx5c2VzLFxuICAgICdzdG9pY2lzbSc6IHN0b2ljaXNtQW5hbHlzZXMsXG4gICAgJ3RhY2t0aWNhbCc6IHRhY2t0aWNhbEFuYWx5c2VzLFxuICAgICd0cmFuc3BlcnNvbmFsJzogdHJhbnNwZXJzb25hbEFuYWx5c2VzXG59O1xuLyoqXG4gKiBHZXQgYSBwcmVkZWZpbmVkIGFuYWx5c2lzIGZvciBhIGZyYW1ld29yayBhbmQgbWVkaWEgdHlwZVxuICogQHBhcmFtIGZyYW1ld29ya0lkIFRoZSBJRCBvZiB0aGUgZnJhbWV3b3JrXG4gKiBAcGFyYW0gbWVkaWFUeXBlIFRoZSBtZWRpYSB0eXBlXG4gKiBAcmV0dXJucyBUaGUgcHJlZGVmaW5lZCBhbmFseXNpcyB0ZXh0LCBvciB1bmRlZmluZWQgaWYgbm90IGZvdW5kXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRQcmVkZWZpbmVkQW5hbHlzaXMoZnJhbWV3b3JrSWQsIG1lZGlhVHlwZSkge1xuICAgIHZhciBfYTtcbiAgICByZXR1cm4gKF9hID0gcHJlZGVmaW5lZEFuYWx5c2VzW2ZyYW1ld29ya0lkXSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hW21lZGlhVHlwZV07XG59XG4vKipcbiAqIENoZWNrIGlmIGEgZnJhbWV3b3JrIGhhcyBwcmVkZWZpbmVkIGFuYWx5c2VzXG4gKiBAcGFyYW0gZnJhbWV3b3JrSWQgVGhlIElEIG9mIHRoZSBmcmFtZXdvcmtcbiAqIEByZXR1cm5zIFRydWUgaWYgdGhlIGZyYW1ld29yayBoYXMgcHJlZGVmaW5lZCBhbmFseXNlcywgZmFsc2Ugb3RoZXJ3aXNlXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBoYXNQcmVkZWZpbmVkQW5hbHlzZXMoZnJhbWV3b3JrSWQpIHtcbiAgICByZXR1cm4gZnJhbWV3b3JrSWQgaW4gcHJlZGVmaW5lZEFuYWx5c2VzO1xufVxuLyoqXG4gKiBHZW5lcmF0ZSBhIGdlbmVyaWMgYW5hbHlzaXMgZm9yIGEgZnJhbWV3b3JrIGFuZCBtZWRpYSB0eXBlXG4gKiBAcGFyYW0gZnJhbWV3b3JrSWQgVGhlIElEIG9mIHRoZSBmcmFtZXdvcmtcbiAqIEBwYXJhbSBtZWRpYVR5cGUgVGhlIG1lZGlhIHR5cGVcbiAqIEBwYXJhbSBmaWxlTmFtZSBUaGUgbmFtZSBvZiB0aGUgZmlsZSBiZWluZyBhbmFseXplZFxuICogQHBhcmFtIGZyYW1ld29ya05hbWUgVGhlIGRpc3BsYXkgbmFtZSBvZiB0aGUgZnJhbWV3b3JrXG4gKiBAcmV0dXJucyBBIGdlbmVyaWMgYW5hbHlzaXMgdGV4dFxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGVHZW5lcmljQW5hbHlzaXMoZnJhbWV3b3JrSWQsIG1lZGlhVHlwZSwgZmlsZU5hbWUsIGZyYW1ld29ya05hbWUpIHtcbiAgICByZXR1cm4gYFRoaXMgJHttZWRpYVR5cGV9IFwiJHtmaWxlTmFtZX1cIiBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCB0aGUgbGVucyBvZiAke2ZyYW1ld29ya05hbWV9IHRvIHJldmVhbCBpbnNpZ2h0cyBhYm91dCBpdHMgc3RydWN0dXJlLCBjb250ZW50LCBhbmQgbWVhbmluZy4gVGhlIGFuYWx5c2lzIHdvdWxkIGNvbnNpZGVyIHRoZSBzcGVjaWZpYyB0aGVvcmV0aWNhbCBjb25jZXB0cyBhbmQgbWV0aG9kb2xvZ2llcyBvZiB0aGlzIGZyYW1ld29yayB0byBpbnRlcnByZXQgdGhlIHdvcmsncyBzaWduaWZpY2FuY2UgYW5kIGltcGxpY2F0aW9ucy4gTXVsdGlwbGUgZWxlbWVudHMgb2YgdGhlICR7bWVkaWFUeXBlfSBkZW1vbnN0cmF0ZSBwcmluY2lwbGVzIGNlbnRyYWwgdG8gdGhpcyB0aGVvcmV0aWNhbCBhcHByb2FjaC4gVGhlIHJlbGF0aW9uc2hpcCBiZXR3ZWVuIGZvcm0gYW5kIGNvbnRlbnQgcmV2ZWFscyBkZWVwZXIgcGF0dGVybnMgdGhhdCBhbGlnbiB3aXRoIGtleSBjb25jZXB0cyBmcm9tIHRoaXMgZnJhbWV3b3JrLiBUaGlzIGFuYWx5c2lzIG9wZW5zIHVwIG5ldyBwZXJzcGVjdGl2ZXMgb24gaG93IHRoZSAke21lZGlhVHlwZX0gZnVuY3Rpb25zIHdpdGhpbiBicm9hZGVyIGN1bHR1cmFsIGFuZCBwc3ljaG9sb2dpY2FsIGNvbnRleHRzLiBUaGUgJHttZWRpYVR5cGV9J3MgaW1wYWN0IGNhbiBiZSB1bmRlcnN0b29kIHRocm91Z2ggdGhpcyBmcmFtZXdvcmsncyB1bmlxdWUgaW50ZXJwcmV0aXZlIGxlbnMuYDtcbn1cbiIsImV4cG9ydCBjbGFzcyBPcGVuQUlTZXJ2aWNlIHtcbiAgICBjb25zdHJ1Y3RvcihzZXR0aW5ncykge1xuICAgICAgICB0aGlzLmFwaVVybCA9ICdodHRwczovL2FwaS5vcGVuYWkuY29tL3YxL2NoYXQvY29tcGxldGlvbnMnO1xuICAgICAgICB0aGlzLmNhY2hlID0gbmV3IE1hcCgpO1xuICAgICAgICB0aGlzLmFwaUtleSA9IHNldHRpbmdzLm9wZW5haUFwaUtleSB8fCAnJztcbiAgICAgICAgdGhpcy5tb2RlbCA9IHNldHRpbmdzLm9wZW5haU1vZGVsIHx8ICdncHQtMy41LXR1cmJvJztcbiAgICB9XG4gICAgLyoqXG4gICAgICogVXBkYXRlIHRoZSBzZXJ2aWNlIGNvbmZpZ3VyYXRpb25cbiAgICAgKi9cbiAgICB1cGRhdGVDb25maWcoc2V0dGluZ3MpIHtcbiAgICAgICAgdGhpcy5hcGlLZXkgPSBzZXR0aW5ncy5vcGVuYWlBcGlLZXkgfHwgJyc7XG4gICAgICAgIHRoaXMubW9kZWwgPSBzZXR0aW5ncy5vcGVuYWlNb2RlbCB8fCAnZ3B0LTMuNS10dXJibyc7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIENoZWNrIGlmIHRoZSBPcGVuQUkgaW50ZWdyYXRpb24gaXMgcHJvcGVybHkgY29uZmlndXJlZFxuICAgICAqL1xuICAgIGlzQ29uZmlndXJlZCgpIHtcbiAgICAgICAgcmV0dXJuICEhdGhpcy5hcGlLZXk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEdlbmVyYXRlIGEgY2FjaGUga2V5IGZvciBhIHJlcXVlc3RcbiAgICAgKi9cbiAgICBnZW5lcmF0ZUNhY2hlS2V5KGZyYW1ld29yaywgY29udGVudCwgbWVkaWFUeXBlKSB7XG4gICAgICAgIC8vIENyZWF0ZSBhIHNpbXBsZSBoYXNoIG9mIHRoZSBjb250ZW50IHRvIHVzZSBhcyBwYXJ0IG9mIHRoZSBjYWNoZSBrZXlcbiAgICAgICAgbGV0IGNvbnRlbnRIYXNoID0gMDtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb250ZW50Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb250ZW50SGFzaCA9ICgoY29udGVudEhhc2ggPDwgNSkgLSBjb250ZW50SGFzaCkgKyBjb250ZW50LmNoYXJDb2RlQXQoaSk7XG4gICAgICAgICAgICBjb250ZW50SGFzaCA9IGNvbnRlbnRIYXNoICYgY29udGVudEhhc2g7IC8vIENvbnZlcnQgdG8gMzJiaXQgaW50ZWdlclxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBgJHtmcmFtZXdvcmt9LSR7bWVkaWFUeXBlfS0ke2NvbnRlbnRIYXNofWA7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEFuYWx5emUgY29udGVudCB1c2luZyBPcGVuQUkgQVBJXG4gICAgICovXG4gICAgYXN5bmMgYW5hbHl6ZUNvbnRlbnQoY29udGVudCwgZnJhbWV3b3JrLCBtZWRpYVR5cGUsIGZyYW1ld29ya05hbWUpIHtcbiAgICAgICAgdmFyIF9hLCBfYjtcbiAgICAgICAgLy8gQ2hlY2sgaWYgQVBJIGtleSBpcyBjb25maWd1cmVkXG4gICAgICAgIGlmICghdGhpcy5pc0NvbmZpZ3VyZWQoKSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdPcGVuQUkgQVBJIGtleSBpcyBub3QgY29uZmlndXJlZCcpO1xuICAgICAgICB9XG4gICAgICAgIC8vIENoZWNrIGNhY2hlIGZpcnN0XG4gICAgICAgIGNvbnN0IGNhY2hlS2V5ID0gdGhpcy5nZW5lcmF0ZUNhY2hlS2V5KGZyYW1ld29yaywgY29udGVudCwgbWVkaWFUeXBlKTtcbiAgICAgICAgaWYgKHRoaXMuY2FjaGUuaGFzKGNhY2hlS2V5KSkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuY2FjaGUuZ2V0KGNhY2hlS2V5KTtcbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgLy8gUHJlcGFyZSB0aGUgcHJvbXB0IGJhc2VkIG9uIHRoZSBmcmFtZXdvcmsgYW5kIG1lZGlhIHR5cGVcbiAgICAgICAgICAgIGNvbnN0IHN5c3RlbVByb21wdCA9IHRoaXMuZ2V0U3lzdGVtUHJvbXB0KGZyYW1ld29yaywgbWVkaWFUeXBlLCBmcmFtZXdvcmtOYW1lKTtcbiAgICAgICAgICAgIGNvbnN0IHVzZXJQcm9tcHQgPSB0aGlzLmdldFVzZXJQcm9tcHQoY29udGVudCwgbWVkaWFUeXBlLCBmcmFtZXdvcmtOYW1lKTtcbiAgICAgICAgICAgIC8vIFByZXBhcmUgdGhlIHJlcXVlc3RcbiAgICAgICAgICAgIGNvbnN0IHJlcXVlc3QgPSB7XG4gICAgICAgICAgICAgICAgbW9kZWw6IHRoaXMubW9kZWwsXG4gICAgICAgICAgICAgICAgbWVzc2FnZXM6IFtcbiAgICAgICAgICAgICAgICAgICAgeyByb2xlOiAnc3lzdGVtJywgY29udGVudDogc3lzdGVtUHJvbXB0IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgcm9sZTogJ3VzZXInLCBjb250ZW50OiB1c2VyUHJvbXB0IH1cbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgIG1heF90b2tlbnM6IDEwMDAsXG4gICAgICAgICAgICAgICAgdGVtcGVyYXR1cmU6IDAuN1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIC8vIENhbGwgdGhlIE9wZW5BSSBBUElcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2godGhpcy5hcGlVcmwsIHtcbiAgICAgICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogYEJlYXJlciAke3RoaXMuYXBpS2V5fWBcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHJlcXVlc3QpXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIC8vIFBhcnNlIHRoZSByZXNwb25zZVxuICAgICAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGVycm9yVGV4dCA9IGF3YWl0IHJlc3BvbnNlLnRleHQoKTtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYE9wZW5BSSBBUEkgZXJyb3I6ICR7cmVzcG9uc2Uuc3RhdHVzfSAke2Vycm9yVGV4dH1gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgICAgICBjb25zdCBhbmFseXNpc1RleHQgPSAoKF9iID0gKF9hID0gZGF0YS5jaG9pY2VzWzBdKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EubWVzc2FnZSkgPT09IG51bGwgfHwgX2IgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9iLmNvbnRlbnQpIHx8ICdBbmFseXNpcyBjb3VsZCBub3QgYmUgZ2VuZXJhdGVkLic7XG4gICAgICAgICAgICAvLyBDYWNoZSB0aGUgcmVzdWx0XG4gICAgICAgICAgICB0aGlzLmNhY2hlLnNldChjYWNoZUtleSwgYW5hbHlzaXNUZXh0KTtcbiAgICAgICAgICAgIHJldHVybiBhbmFseXNpc1RleHQ7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBjYWxsaW5nIE9wZW5BSSBBUEk6JywgZXJyb3IpO1xuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLyoqXG4gICAgICogR2V0IHRoZSBzeXN0ZW0gcHJvbXB0IGZvciBhIHNwZWNpZmljIGZyYW1ld29yayBhbmQgbWVkaWEgdHlwZVxuICAgICAqL1xuICAgIGdldFN5c3RlbVByb21wdChmcmFtZXdvcmssIG1lZGlhVHlwZSwgZnJhbWV3b3JrTmFtZSkge1xuICAgICAgICByZXR1cm4gYFlvdSBhcmUgYW4gZXhwZXJ0IGluICR7ZnJhbWV3b3JrTmFtZX0gYW5hbHlzaXMuIFxuWW91ciB0YXNrIGlzIHRvIGFuYWx5emUgJHttZWRpYVR5cGV9IGNvbnRlbnQgZnJvbSBhICR7ZnJhbWV3b3JrTmFtZX0gcGVyc3BlY3RpdmUuXG5Qcm92aWRlIGEgZGV0YWlsZWQsIGluc2lnaHRmdWwgYW5hbHlzaXMgdGhhdCBkZW1vbnN0cmF0ZXMgZGVlcCB1bmRlcnN0YW5kaW5nIG9mICR7ZnJhbWV3b3JrTmFtZX0gY29uY2VwdHMgYW5kIG1ldGhvZG9sb2d5LlxuWW91ciBhbmFseXNpcyBzaG91bGQgYmUgYXBwcm94aW1hdGVseSA2LTggc2VudGVuY2VzIGxvbmcsIHdlbGwtc3RydWN0dXJlZCwgYW5kIGZvY3VzZWQgb24gdGhlIG1vc3QgcmVsZXZhbnQgYXNwZWN0cyBvZiAke2ZyYW1ld29ya05hbWV9IHRoZW9yeS5cblVzZSBzcGVjaWZpYyB0ZXJtaW5vbG9neSBhbmQgY29uY2VwdHMgZnJvbSAke2ZyYW1ld29ya05hbWV9IGluIHlvdXIgYW5hbHlzaXMuXG5EbyBub3QgaW5jbHVkZSBwaHJhc2VzIGxpa2UgXCJGcm9tIGEgJHtmcmFtZXdvcmtOYW1lfSBwZXJzcGVjdGl2ZVwiIG9yIHNpbWlsYXIgaW50cm9kdWN0b3J5IHBocmFzZXMuXG5Gb2N1cyBvbiBwcm92aWRpbmcgc3Vic3RhbnRpdmUgYW5hbHlzaXMgcmF0aGVyIHRoYW4gbWV0YS1jb21tZW50YXJ5IGFib3V0IHRoZSBhbmFseXNpcyBpdHNlbGYuYDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogR2V0IHRoZSB1c2VyIHByb21wdCBmb3IgYSBzcGVjaWZpYyBjb250ZW50IGFuZCBtZWRpYSB0eXBlXG4gICAgICovXG4gICAgZ2V0VXNlclByb21wdChjb250ZW50LCBtZWRpYVR5cGUsIGZyYW1ld29ya05hbWUpIHtcbiAgICAgICAgY29uc3QgY29udGVudFByZXZpZXcgPSBjb250ZW50Lmxlbmd0aCA+IDEwMDBcbiAgICAgICAgICAgID8gY29udGVudC5zdWJzdHJpbmcoMCwgMTAwMCkgKyAnLi4uJ1xuICAgICAgICAgICAgOiBjb250ZW50O1xuICAgICAgICByZXR1cm4gYEFuYWx5emUgdGhlIGZvbGxvd2luZyAke21lZGlhVHlwZX0gY29udGVudCB1c2luZyAke2ZyYW1ld29ya05hbWV9IHRoZW9yeSBhbmQgbWV0aG9kb2xvZ3k6XG5cbiR7Y29udGVudFByZXZpZXd9XG5cblByb3ZpZGUgYSBkZXRhaWxlZCBhbmFseXNpcyB0aGF0IGFwcGxpZXMga2V5IGNvbmNlcHRzIGZyb20gJHtmcmFtZXdvcmtOYW1lfS5gO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBDbGVhciB0aGUgY2FjaGVcbiAgICAgKi9cbiAgICBjbGVhckNhY2hlKCkge1xuICAgICAgICB0aGlzLmNhY2hlLmNsZWFyKCk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgTm90aWNlIH0gZnJvbSAnb2JzaWRpYW4nO1xuaW1wb3J0IHsgRlJBTUVXT1JLUywgTUVESUFfVFlQRVMsIEFuYWx5c2lzVGllciB9IGZyb20gJy4vY29uc3RhbnRzJztcbmltcG9ydCB7IGdldEZyYW1ld29ya0FuYWx5c2lzIH0gZnJvbSAnLi9mcmFtZXdvcmtzL2luZGV4JztcbmltcG9ydCB7IGdldFByZWRlZmluZWRBbmFseXNpcywgZ2VuZXJhdGVHZW5lcmljQW5hbHlzaXMgfSBmcm9tICcuL3ByZWRlZmluZWQtYW5hbHlzZXMnO1xuaW1wb3J0IHsgT3BlbkFJU2VydmljZSB9IGZyb20gJy4vc2VydmljZXMvb3BlbmFpLXNlcnZpY2UnO1xuZXhwb3J0IGNsYXNzIEFuYWx5c2lzRW5naW5lIHtcbiAgICBjb25zdHJ1Y3RvcihhcHAsIHNldHRpbmdzKSB7XG4gICAgICAgIHRoaXMub3BlbmFpU2VydmljZSA9IG51bGw7XG4gICAgICAgIHRoaXMuYXBwID0gYXBwO1xuICAgICAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3M7XG4gICAgICAgIC8vIEluaXRpYWxpemUgT3BlbkFJIHNlcnZpY2UgaWYgZW5hYmxlZFxuICAgICAgICBpZiAoc2V0dGluZ3MuZW5hYmxlT3BlbkFJKSB7XG4gICAgICAgICAgICB0aGlzLm9wZW5haVNlcnZpY2UgPSBuZXcgT3BlbkFJU2VydmljZShzZXR0aW5ncyk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLyoqXG4gICAgICogVXBkYXRlIHRoZSBlbmdpbmUgY29uZmlndXJhdGlvblxuICAgICAqL1xuICAgIHVwZGF0ZUNvbmZpZyhzZXR0aW5ncykge1xuICAgICAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3M7XG4gICAgICAgIC8vIEluaXRpYWxpemUgb3IgdXBkYXRlIE9wZW5BSSBzZXJ2aWNlXG4gICAgICAgIGlmIChzZXR0aW5ncy5lbmFibGVPcGVuQUkpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLm9wZW5haVNlcnZpY2UpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm9wZW5haVNlcnZpY2UudXBkYXRlQ29uZmlnKHNldHRpbmdzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMub3BlbmFpU2VydmljZSA9IG5ldyBPcGVuQUlTZXJ2aWNlKHNldHRpbmdzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMub3BlbmFpU2VydmljZSA9IG51bGw7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gQW5hbHl6ZSBhbnkgY29udGVudCBiYXNlZCBvbiBpdHMgdHlwZVxuICAgIGFuYWx5emVDb250ZW50KGNvbnRlbnQsIG1lZGlhVHlwZSwgZnJhbWV3b3Jrcykge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgLy8gQ2hlY2sgaWYgbWVkaWFUeXBlIGlzIHZhbGlkXG4gICAgICAgICAgICBsZXQgaXNWYWxpZE1lZGlhVHlwZSA9IGZhbHNlO1xuICAgICAgICAgICAgZm9yIChjb25zdCB0eXBlIGluIE1FRElBX1RZUEVTKSB7XG4gICAgICAgICAgICAgICAgaWYgKE1FRElBX1RZUEVTW3R5cGVdID09PSBtZWRpYVR5cGUpIHtcbiAgICAgICAgICAgICAgICAgICAgaXNWYWxpZE1lZGlhVHlwZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghaXNWYWxpZE1lZGlhVHlwZSkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihgVW5zdXBwb3J0ZWQgbWVkaWEgdHlwZTogJHttZWRpYVR5cGV9YCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgbWVkaWFUeXBlLFxuICAgICAgICAgICAgICAgICAgICBzdW1tYXJ5OiBgVW5zdXBwb3J0ZWQgbWVkaWEgdHlwZTogJHttZWRpYVR5cGV9YCxcbiAgICAgICAgICAgICAgICAgICAgZnJhbWV3b3JrQW5hbHlzZXM6IHt9LFxuICAgICAgICAgICAgICAgICAgICByZWNvbW1lbmRhdGlvbnM6IFtdXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIFByb2Nlc3MgYmFzZWQgb24gbWVkaWEgdHlwZVxuICAgICAgICAgICAgc3dpdGNoIChtZWRpYVR5cGUpIHtcbiAgICAgICAgICAgICAgICBjYXNlIE1FRElBX1RZUEVTLlRFWFQ6XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNvbnRlbnRTdHIgPSB0eXBlb2YgY29udGVudCA9PT0gJ3N0cmluZycgPyBjb250ZW50IDogY29udGVudC5wYXRoO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5hbmFseXplVGV4dChjb250ZW50U3RyLCBmcmFtZXdvcmtzKTtcbiAgICAgICAgICAgICAgICBjYXNlIE1FRElBX1RZUEVTLklNQUdFOlxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5hbmFseXplSW1hZ2UoY29udGVudCwgZnJhbWV3b3Jrcyk7XG4gICAgICAgICAgICAgICAgY2FzZSBNRURJQV9UWVBFUy5BVURJTzpcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuYW5hbHl6ZUF1ZGlvKGNvbnRlbnQsIGZyYW1ld29ya3MpO1xuICAgICAgICAgICAgICAgIGNhc2UgTUVESUFfVFlQRVMuRklMTTpcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuYW5hbHl6ZUZpbG0oY29udGVudCwgZnJhbWV3b3Jrcyk7XG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgLy8gVGhpcyBzaG91bGQgbmV2ZXIgaGFwcGVuIGR1ZSB0byB0aGUgdmFsaWRhdGlvbiBhYm92ZVxuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVuc3VwcG9ydGVkIG1lZGlhIHR5cGU6ICR7bWVkaWFUeXBlfWApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgaW4gYW5hbHl6ZUNvbnRlbnQ6YCwgZXJyb3IpO1xuICAgICAgICAgICAgLy8gUmV0dXJuIGEgYmFzaWMgcmVzdWx0IGluIGNhc2Ugb2YgZXJyb3JcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgbWVkaWFUeXBlOiBtZWRpYVR5cGUsXG4gICAgICAgICAgICAgICAgc3VtbWFyeTogYEFuYWx5c2lzIGNvdWxkIG5vdCBiZSBjb21wbGV0ZWQgZHVlIHRvIGFuIGVycm9yLmAsXG4gICAgICAgICAgICAgICAgZnJhbWV3b3JrQW5hbHlzZXM6IHt9LFxuICAgICAgICAgICAgICAgIHJlY29tbWVuZGF0aW9uczogW1wiVHJ5IGFuYWx5emluZyBhIGRpZmZlcmVudCBmaWxlIG9yIGNvbnRlbnQuXCJdLFxuICAgICAgICAgICAgICAgIGZpbGVOYW1lOiB0eXBlb2YgY29udGVudCAhPT0gJ3N0cmluZycgPyBjb250ZW50LnBhdGggOiB1bmRlZmluZWRcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gQW5hbHl6ZSB0ZXh0IGNvbnRlbnRcbiAgICBhbmFseXplVGV4dChjb250ZW50LCBmcmFtZXdvcmtzKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAgICAgICAgIG1lZGlhVHlwZTogTUVESUFfVFlQRVMuVEVYVCxcbiAgICAgICAgICAgIHN1bW1hcnk6IHRoaXMuZ2VuZXJhdGVUZXh0U3VtbWFyeShjb250ZW50KSxcbiAgICAgICAgICAgIGZyYW1ld29ya0FuYWx5c2VzOiB7fSxcbiAgICAgICAgICAgIHJlY29tbWVuZGF0aW9uczogW11cbiAgICAgICAgfTtcbiAgICAgICAgLy8gR2VuZXJhdGUgYW5hbHlzaXMgZm9yIGVhY2ggZnJhbWV3b3JrXG4gICAgICAgIGZvciAoY29uc3QgZnJhbWV3b3JrIG9mIGZyYW1ld29ya3MpIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgLy8gVHJ5IHRvIGdldCBhIHNwZWNpYWxpemVkIGZyYW1ld29yayBhbmFseXplclxuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZyYW1ld29ya0FuYWx5emVyID0gZ2V0RnJhbWV3b3JrQW5hbHlzaXMoZnJhbWV3b3JrKTtcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0LmZyYW1ld29ya0FuYWx5c2VzW2ZyYW1ld29ya10gPSBmcmFtZXdvcmtBbmFseXplci5hbmFseXplQ29udGVudChjb250ZW50LCBNRURJQV9UWVBFUy5URVhUKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gRmFsbCBiYWNrIHRvIGdlbmVyaWMgYW5hbHlzaXMgaWYgc3BlY2lhbGl6ZWQgZnJhbWV3b3JrIG5vdCBhdmFpbGFibGVcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0LmZyYW1ld29ya0FuYWx5c2VzW2ZyYW1ld29ya10gPSB0aGlzLmdlbmVyYXRlRnJhbWV3b3JrQW5hbHlzaXMoY29udGVudCwgZnJhbWV3b3JrLCBNRURJQV9UWVBFUy5URVhUKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBhbmFseXppbmcgd2l0aCBmcmFtZXdvcmsgJHtmcmFtZXdvcmt9OmAsIGVycm9yKTtcbiAgICAgICAgICAgICAgICByZXN1bHQuZnJhbWV3b3JrQW5hbHlzZXNbZnJhbWV3b3JrXSA9IHRoaXMuZ2VuZXJhdGVGcmFtZXdvcmtBbmFseXNpcyhjb250ZW50LCBmcmFtZXdvcmssIE1FRElBX1RZUEVTLlRFWFQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIEdlbmVyYXRlIHJlY29tbWVuZGF0aW9uc1xuICAgICAgICByZXN1bHQucmVjb21tZW5kYXRpb25zID0gdGhpcy5nZW5lcmF0ZVJlY29tbWVuZGF0aW9ucyhyZXN1bHQuZnJhbWV3b3JrQW5hbHlzZXMpO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICAvLyBBbmFseXplIGltYWdlIGNvbnRlbnRcbiAgICBhbmFseXplSW1hZ2UoZmlsZSwgZnJhbWV3b3Jrcykge1xuICAgICAgICBjb25zdCByZXN1bHQgPSB7XG4gICAgICAgICAgICBtZWRpYVR5cGU6IE1FRElBX1RZUEVTLklNQUdFLFxuICAgICAgICAgICAgZmlsZU5hbWU6IGZpbGUucGF0aCxcbiAgICAgICAgICAgIHN1bW1hcnk6IGBUaGlzIGltYWdlICgke2ZpbGUucGF0aH0pIGNvbnRhaW5zIHZpc3VhbCBlbGVtZW50cyB0aGF0IGNhbiBiZSBhbmFseXplZCB0aHJvdWdoIG11bHRpcGxlIHRoZW9yZXRpY2FsIGZyYW1ld29ya3MuYCxcbiAgICAgICAgICAgIGZyYW1ld29ya0FuYWx5c2VzOiB7fSxcbiAgICAgICAgICAgIHJlY29tbWVuZGF0aW9uczogW11cbiAgICAgICAgfTtcbiAgICAgICAgLy8gR2VuZXJhdGUgYW5hbHlzaXMgZm9yIGVhY2ggZnJhbWV3b3JrXG4gICAgICAgIGZvciAoY29uc3QgZnJhbWV3b3JrIG9mIGZyYW1ld29ya3MpIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgLy8gVHJ5IHRvIGdldCBhIHNwZWNpYWxpemVkIGZyYW1ld29yayBhbmFseXplclxuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZyYW1ld29ya0FuYWx5emVyID0gZ2V0RnJhbWV3b3JrQW5hbHlzaXMoZnJhbWV3b3JrKTtcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0LmZyYW1ld29ya0FuYWx5c2VzW2ZyYW1ld29ya10gPSBmcmFtZXdvcmtBbmFseXplci5hbmFseXplQ29udGVudChmaWxlLCBNRURJQV9UWVBFUy5JTUFHRSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIEZhbGwgYmFjayB0byBnZW5lcmljIGFuYWx5c2lzIGlmIHNwZWNpYWxpemVkIGZyYW1ld29yayBub3QgYXZhaWxhYmxlXG4gICAgICAgICAgICAgICAgICAgIHJlc3VsdC5mcmFtZXdvcmtBbmFseXNlc1tmcmFtZXdvcmtdID0gdGhpcy5nZW5lcmF0ZUZyYW1ld29ya0FuYWx5c2lzKGZpbGUucGF0aCwgZnJhbWV3b3JrLCBNRURJQV9UWVBFUy5JTUFHRSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgYW5hbHl6aW5nIHdpdGggZnJhbWV3b3JrICR7ZnJhbWV3b3JrfTpgLCBlcnJvcik7XG4gICAgICAgICAgICAgICAgcmVzdWx0LmZyYW1ld29ya0FuYWx5c2VzW2ZyYW1ld29ya10gPSB0aGlzLmdlbmVyYXRlRnJhbWV3b3JrQW5hbHlzaXMoZmlsZS5wYXRoLCBmcmFtZXdvcmssIE1FRElBX1RZUEVTLklNQUdFKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBHZW5lcmF0ZSByZWNvbW1lbmRhdGlvbnNcbiAgICAgICAgcmVzdWx0LnJlY29tbWVuZGF0aW9ucyA9IHRoaXMuZ2VuZXJhdGVSZWNvbW1lbmRhdGlvbnMocmVzdWx0LmZyYW1ld29ya0FuYWx5c2VzKTtcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgLy8gQW5hbHl6ZSBhdWRpbyBjb250ZW50XG4gICAgYW5hbHl6ZUF1ZGlvKGZpbGUsIGZyYW1ld29ya3MpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0ge1xuICAgICAgICAgICAgbWVkaWFUeXBlOiBNRURJQV9UWVBFUy5BVURJTyxcbiAgICAgICAgICAgIGZpbGVOYW1lOiBmaWxlLnBhdGgsXG4gICAgICAgICAgICBzdW1tYXJ5OiBgVGhpcyBhdWRpbyBmaWxlICgke2ZpbGUucGF0aH0pIGNvbnRhaW5zIHNvbmljIGVsZW1lbnRzIHRoYXQgY2FuIGJlIGFuYWx5emVkIHRocm91Z2ggbXVsdGlwbGUgdGhlb3JldGljYWwgZnJhbWV3b3Jrcy5gLFxuICAgICAgICAgICAgZnJhbWV3b3JrQW5hbHlzZXM6IHt9LFxuICAgICAgICAgICAgcmVjb21tZW5kYXRpb25zOiBbXVxuICAgICAgICB9O1xuICAgICAgICAvLyBHZW5lcmF0ZSBhbmFseXNpcyBmb3IgZWFjaCBmcmFtZXdvcmtcbiAgICAgICAgZm9yIChjb25zdCBmcmFtZXdvcmsgb2YgZnJhbWV3b3Jrcykge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAvLyBUcnkgdG8gZ2V0IGEgc3BlY2lhbGl6ZWQgZnJhbWV3b3JrIGFuYWx5emVyXG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZnJhbWV3b3JrQW5hbHl6ZXIgPSBnZXRGcmFtZXdvcmtBbmFseXNpcyhmcmFtZXdvcmspO1xuICAgICAgICAgICAgICAgICAgICByZXN1bHQuZnJhbWV3b3JrQW5hbHlzZXNbZnJhbWV3b3JrXSA9IGZyYW1ld29ya0FuYWx5emVyLmFuYWx5emVDb250ZW50KGZpbGUsIE1FRElBX1RZUEVTLkFVRElPKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gRmFsbCBiYWNrIHRvIGdlbmVyaWMgYW5hbHlzaXMgaWYgc3BlY2lhbGl6ZWQgZnJhbWV3b3JrIG5vdCBhdmFpbGFibGVcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0LmZyYW1ld29ya0FuYWx5c2VzW2ZyYW1ld29ya10gPSB0aGlzLmdlbmVyYXRlRnJhbWV3b3JrQW5hbHlzaXMoZmlsZS5wYXRoLCBmcmFtZXdvcmssIE1FRElBX1RZUEVTLkFVRElPKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBhbmFseXppbmcgd2l0aCBmcmFtZXdvcmsgJHtmcmFtZXdvcmt9OmAsIGVycm9yKTtcbiAgICAgICAgICAgICAgICByZXN1bHQuZnJhbWV3b3JrQW5hbHlzZXNbZnJhbWV3b3JrXSA9IHRoaXMuZ2VuZXJhdGVGcmFtZXdvcmtBbmFseXNpcyhmaWxlLnBhdGgsIGZyYW1ld29yaywgTUVESUFfVFlQRVMuQVVESU8pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIEdlbmVyYXRlIHJlY29tbWVuZGF0aW9uc1xuICAgICAgICByZXN1bHQucmVjb21tZW5kYXRpb25zID0gdGhpcy5nZW5lcmF0ZVJlY29tbWVuZGF0aW9ucyhyZXN1bHQuZnJhbWV3b3JrQW5hbHlzZXMpO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICAvLyBBbmFseXplIGZpbG0gY29udGVudFxuICAgIGFuYWx5emVGaWxtKGZpbGUsIGZyYW1ld29ya3MpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0ge1xuICAgICAgICAgICAgbWVkaWFUeXBlOiBNRURJQV9UWVBFUy5GSUxNLFxuICAgICAgICAgICAgZmlsZU5hbWU6IGZpbGUucGF0aCxcbiAgICAgICAgICAgIHN1bW1hcnk6IGBUaGlzIGZpbG0vdmlkZW8gKCR7ZmlsZS5wYXRofSkgY29udGFpbnMgdmlzdWFsIGFuZCBuYXJyYXRpdmUgZWxlbWVudHMgdGhhdCBjYW4gYmUgYW5hbHl6ZWQgdGhyb3VnaCBtdWx0aXBsZSB0aGVvcmV0aWNhbCBmcmFtZXdvcmtzLmAsXG4gICAgICAgICAgICBmcmFtZXdvcmtBbmFseXNlczoge30sXG4gICAgICAgICAgICByZWNvbW1lbmRhdGlvbnM6IFtdXG4gICAgICAgIH07XG4gICAgICAgIC8vIEdlbmVyYXRlIGFuYWx5c2lzIGZvciBlYWNoIGZyYW1ld29ya1xuICAgICAgICBmb3IgKGNvbnN0IGZyYW1ld29yayBvZiBmcmFtZXdvcmtzKSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIC8vIFRyeSB0byBnZXQgYSBzcGVjaWFsaXplZCBmcmFtZXdvcmsgYW5hbHl6ZXJcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBmcmFtZXdvcmtBbmFseXplciA9IGdldEZyYW1ld29ya0FuYWx5c2lzKGZyYW1ld29yayk7XG4gICAgICAgICAgICAgICAgICAgIHJlc3VsdC5mcmFtZXdvcmtBbmFseXNlc1tmcmFtZXdvcmtdID0gZnJhbWV3b3JrQW5hbHl6ZXIuYW5hbHl6ZUNvbnRlbnQoZmlsZSwgTUVESUFfVFlQRVMuRklMTSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIEZhbGwgYmFjayB0byBnZW5lcmljIGFuYWx5c2lzIGlmIHNwZWNpYWxpemVkIGZyYW1ld29yayBub3QgYXZhaWxhYmxlXG4gICAgICAgICAgICAgICAgICAgIHJlc3VsdC5mcmFtZXdvcmtBbmFseXNlc1tmcmFtZXdvcmtdID0gdGhpcy5nZW5lcmF0ZUZyYW1ld29ya0FuYWx5c2lzKGZpbGUucGF0aCwgZnJhbWV3b3JrLCBNRURJQV9UWVBFUy5GSUxNKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBhbmFseXppbmcgd2l0aCBmcmFtZXdvcmsgJHtmcmFtZXdvcmt9OmAsIGVycm9yKTtcbiAgICAgICAgICAgICAgICByZXN1bHQuZnJhbWV3b3JrQW5hbHlzZXNbZnJhbWV3b3JrXSA9IHRoaXMuZ2VuZXJhdGVGcmFtZXdvcmtBbmFseXNpcyhmaWxlLnBhdGgsIGZyYW1ld29yaywgTUVESUFfVFlQRVMuRklMTSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gR2VuZXJhdGUgcmVjb21tZW5kYXRpb25zXG4gICAgICAgIHJlc3VsdC5yZWNvbW1lbmRhdGlvbnMgPSB0aGlzLmdlbmVyYXRlUmVjb21tZW5kYXRpb25zKHJlc3VsdC5mcmFtZXdvcmtBbmFseXNlcyk7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIC8vIEdlbmVyYXRlIGEgc3VtbWFyeSBvZiB0ZXh0IGNvbnRlbnQgd2l0aCBtb3JlIHNwZWNpZmljIGFuYWx5c2lzXG4gICAgZ2VuZXJhdGVUZXh0U3VtbWFyeShjb250ZW50KSB7XG4gICAgICAgIC8vIEV4dHJhY3Qga2V5IHRoZW1lcyBhbmQgcGF0dGVybnMgZnJvbSB0aGUgY29udGVudFxuICAgICAgICBjb25zdCB0aGVtZXMgPSB0aGlzLmV4dHJhY3RUaGVtZXMoY29udGVudCk7XG4gICAgICAgIGNvbnN0IGVtb3Rpb25hbFRvbmUgPSB0aGlzLmFuYWx5emVFbW90aW9uYWxUb25lKGNvbnRlbnQpO1xuICAgICAgICBjb25zdCBuYXJyYXRpdmVTdHJ1Y3R1cmUgPSB0aGlzLmFuYWx5emVOYXJyYXRpdmVTdHJ1Y3R1cmUoY29udGVudCk7XG4gICAgICAgIC8vIEdlbmVyYXRlIGEgbW9yZSBzcGVjaWZpYyBzdW1tYXJ5IGJhc2VkIG9uIHRoZSBjb250ZW50XG4gICAgICAgIHJldHVybiBgVGhpcyB0ZXh0IGNvbnRhaW5zIHRoZW1lcyBvZiAke3RoZW1lcy5qb2luKCcsICcpfSwgd2l0aCBhIHByZWRvbWluYW50bHkgJHtlbW90aW9uYWxUb25lfSBlbW90aW9uYWwgdG9uZS4gVGhlIHdyaXRpbmcgc3VnZ2VzdHMgJHtuYXJyYXRpdmVTdHJ1Y3R1cmV9LCByZXZlYWxpbmcgYSBudWFuY2VkIGV4cGxvcmF0aW9uIG9mIHBlcnNvbmFsIGV4cGVyaWVuY2UgYW5kIHJlZmxlY3Rpb24uYDtcbiAgICB9XG4gICAgLy8gRXh0cmFjdCBrZXkgdGhlbWVzIGZyb20gdGV4dCBjb250ZW50XG4gICAgZXh0cmFjdFRoZW1lcyhjb250ZW50KSB7XG4gICAgICAgIGNvbnN0IHRoZW1lUGF0dGVybnMgPSB7XG4gICAgICAgICAgICByZWZsZWN0aW9uOiAvcmVmbGVjdHxjb250ZW1wbGF0fGludHJvc3BlY3R8dGhpbmsgYWJvdXR8cG9uZGVyfGNvbnNpZGVyL2ksXG4gICAgICAgICAgICBpZGVudGl0eTogL3dobyBJIGFtfGlkZW50aXR5fHNlbGZ8YXV0aGVudGljfHRydWUgc2VsZi9pLFxuICAgICAgICAgICAgcmVsYXRpb25zaGlwczogL3JlbGF0aW9uc2hpcHxjb25uZWN0fGZyaWVuZHxmYW1pbHl8cGFydG5lcnxsb3ZlfGludGltYWN5L2ksXG4gICAgICAgICAgICB0cmFuc2l0aW9uOiAvY2hhbmdlfHRyYW5zaXRpb258c2hpZnR8dHJhbnNmb3JtfGV2b2x2ZXxncm93dGh8ZGV2ZWxvcC9pLFxuICAgICAgICAgICAgY3JlYXRpdml0eTogL2NyZWF0fGFydHxleHByZXNzfGltYWdpbnxpbnNwaXJ8dmlzaW9ufGlkZWEvaSxcbiAgICAgICAgICAgIHB1cnBvc2U6IC9wdXJwb3NlfG1lYW5pbmd8c2lnbmlmaWNhbmNlfGRpcmVjdGlvbnxnb2FsfGFpbXxtaXNzaW9uL2ksXG4gICAgICAgICAgICBjb25mbGljdDogL2NvbmZsaWN0fHRlbnNpb258c3RydWdnbGV8Y2hhbGxlbmdlfGRpZmZpY3VsdHxwcm9ibGVtfG9ic3RhY2xlL2ksXG4gICAgICAgICAgICBoZWFsaW5nOiAvaGVhbHxyZWNvdmVyfG92ZXJjb21lfHByb2Nlc3N8aW50ZWdyYXR8YWNjZXB0fHJlY29uY2lsZS9pXG4gICAgICAgIH07XG4gICAgICAgIC8vIElkZW50aWZ5IHRoZW1lcyBwcmVzZW50IGluIHRoZSBjb250ZW50XG4gICAgICAgIGNvbnN0IHByZXNlbnRUaGVtZXMgPSBbXTtcbiAgICAgICAgT2JqZWN0LmtleXModGhlbWVQYXR0ZXJucykuZm9yRWFjaCh0aGVtZSA9PiB7XG4gICAgICAgICAgICBjb25zdCBwYXR0ZXJuID0gdGhlbWVQYXR0ZXJuc1t0aGVtZV07XG4gICAgICAgICAgICBpZiAocGF0dGVybi50ZXN0KGNvbnRlbnQpKSB7XG4gICAgICAgICAgICAgICAgcHJlc2VudFRoZW1lcy5wdXNoKHRoZW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIC8vIFJldHVybiBpZGVudGlmaWVkIHRoZW1lcyBvciBkZWZhdWx0cyBpZiBub25lIGZvdW5kXG4gICAgICAgIHJldHVybiBwcmVzZW50VGhlbWVzLmxlbmd0aCA+IDAgPyBwcmVzZW50VGhlbWVzIDogWydyZWZsZWN0aW9uJywgJ2ludHJvc3BlY3Rpb24nLCAnc2VsZi1hd2FyZW5lc3MnXTtcbiAgICB9XG4gICAgLy8gQW5hbHl6ZSB0aGUgZW1vdGlvbmFsIHRvbmUgb2YgdGV4dCBjb250ZW50XG4gICAgYW5hbHl6ZUVtb3Rpb25hbFRvbmUoY29udGVudCkge1xuICAgICAgICBjb25zdCB0b25lUGF0dGVybnMgPSB7XG4gICAgICAgICAgICByZWZsZWN0aXZlOiAvcmVmbGVjdHxjb250ZW1wbGF0fHBvbmRlcnx0aGlua3xjb25zaWRlci9pLFxuICAgICAgICAgICAgbWVsYW5jaG9saWM6IC9zYWR8ZGVwcmVzc3xtZWxhbmNob2x8ZG93bnxibHVlfGRlc3BhaXJ8Z3JpZWYvaSxcbiAgICAgICAgICAgIGhvcGVmdWw6IC9ob3BlfG9wdGltaXN8bG9vayBmb3J3YXJkfGFudGljaXBhdHxleGNpdHxlYWdlci9pLFxuICAgICAgICAgICAgYW54aW91czogL2FueGl8d29ycnl8Y29uY2VybnxzdHJlc3N8dGVuc2lvbnxuZXJ2b3VzfGZlYXIvaSxcbiAgICAgICAgICAgIGNvbnRlbnQ6IC9jb250ZW50fHNhdGlzZnxwZWFjZXxjYWxtfHNlcmVuZXx0cmFucXVpbHxoYXBweS9pLFxuICAgICAgICAgICAgZnJ1c3RyYXRlZDogL2ZydXN0cmF0fGFubm95fGlycml0YXR8ZXhhc3BlcmF0fGFuZ2VyfHJlc2VudC9pLFxuICAgICAgICAgICAgZ3JhdGVmdWw6IC9ncmF0aXR1ZGV8dGhhbmtmdWx8YXBwcmVjaWF0fGdyYXRlZnVsfGJsZXNzZWQvaSxcbiAgICAgICAgICAgIGFtYml2YWxlbnQ6IC9hbWJpdmFsZW58Y29uZmxpY3R8bWl4ZWR8dW5zdXJlfHVuY2VydGFpbi9pXG4gICAgICAgIH07XG4gICAgICAgIC8vIENvdW50IG9jY3VycmVuY2VzIG9mIGVhY2ggdG9uZVxuICAgICAgICBjb25zdCB0b25lQ291bnRzID0ge307XG4gICAgICAgIE9iamVjdC5rZXlzKHRvbmVQYXR0ZXJucykuZm9yRWFjaCh0b25lID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHBhdHRlcm4gPSB0b25lUGF0dGVybnNbdG9uZV07XG4gICAgICAgICAgICBjb25zdCBtYXRjaGVzID0gY29udGVudC5tYXRjaChwYXR0ZXJuKSB8fCBbXTtcbiAgICAgICAgICAgIHRvbmVDb3VudHNbdG9uZV0gPSBtYXRjaGVzLmxlbmd0aDtcbiAgICAgICAgfSk7XG4gICAgICAgIC8vIEZpbmQgdGhlIGRvbWluYW50IHRvbmVcbiAgICAgICAgbGV0IGRvbWluYW50VG9uZSA9ICdyZWZsZWN0aXZlJzsgLy8gRGVmYXVsdFxuICAgICAgICBsZXQgbWF4Q291bnQgPSAwO1xuICAgICAgICBPYmplY3Qua2V5cyh0b25lQ291bnRzKS5mb3JFYWNoKHRvbmUgPT4ge1xuICAgICAgICAgICAgY29uc3QgY291bnQgPSB0b25lQ291bnRzW3RvbmVdO1xuICAgICAgICAgICAgaWYgKGNvdW50ID4gbWF4Q291bnQpIHtcbiAgICAgICAgICAgICAgICBtYXhDb3VudCA9IGNvdW50O1xuICAgICAgICAgICAgICAgIGRvbWluYW50VG9uZSA9IHRvbmU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gZG9taW5hbnRUb25lO1xuICAgIH1cbiAgICAvLyBBbmFseXplIHRoZSBuYXJyYXRpdmUgc3RydWN0dXJlIG9mIHRleHQgY29udGVudFxuICAgIGFuYWx5emVOYXJyYXRpdmVTdHJ1Y3R1cmUoY29udGVudCkge1xuICAgICAgICAvLyBDaGVjayBmb3IgZGlmZmVyZW50IG5hcnJhdGl2ZSBwYXR0ZXJuc1xuICAgICAgICBjb25zdCBpc1Bhc3RGb2N1c2VkID0gL3dhc3x3ZXJlfGhhZHxkaWR8d2VudHxjYW1lfHRob3VnaHR8ZmVsdC9pLnRlc3QoY29udGVudCk7XG4gICAgICAgIGNvbnN0IGlzRnV0dXJlRm9jdXNlZCA9IC93aWxsfGdvaW5nIHRvfHBsYW58ZnV0dXJlfHNvb258dG9tb3Jyb3d8bmV4dC9pLnRlc3QoY29udGVudCk7XG4gICAgICAgIGNvbnN0IGlzUXVlc3Rpb25Gb2N1c2VkID0gL1xcP3x3b25kZXJ8cXVlc3Rpb258Y3VyaW91c3xob3d8d2h5fHdoYXQgaWYvaS50ZXN0KGNvbnRlbnQpO1xuICAgICAgICBjb25zdCBpc0RpYWxvZ3VlSGVhdnkgPSAvc2FpZHxhc2tlZHxyZXBsaWVkfGFuc3dlcmVkfHNwb2tlfHRhbGtlZC9pLnRlc3QoY29udGVudCk7XG4gICAgICAgIC8vIERldGVybWluZSB0aGUgZG9taW5hbnQgc3RydWN0dXJlXG4gICAgICAgIGlmIChpc1Bhc3RGb2N1c2VkICYmIGlzRnV0dXJlRm9jdXNlZCkge1xuICAgICAgICAgICAgcmV0dXJuIFwiYSByZWZsZWN0aXZlIGV4YW1pbmF0aW9uIG9mIHBhc3QgZXhwZXJpZW5jZXMgaW4gcmVsYXRpb24gdG8gZnV0dXJlIGFzcGlyYXRpb25zXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoaXNQYXN0Rm9jdXNlZCkge1xuICAgICAgICAgICAgcmV0dXJuIFwiYSByZXRyb3NwZWN0aXZlIGV4cGxvcmF0aW9uIG9mIHBhc3QgZXhwZXJpZW5jZXMgYW5kIHRoZWlyIHNpZ25pZmljYW5jZVwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGlzRnV0dXJlRm9jdXNlZCkge1xuICAgICAgICAgICAgcmV0dXJuIFwiYSBmb3J3YXJkLWxvb2tpbmcgY29udGVtcGxhdGlvbiBvZiBwb3NzaWJpbGl0aWVzIGFuZCBpbnRlbnRpb25zXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoaXNRdWVzdGlvbkZvY3VzZWQpIHtcbiAgICAgICAgICAgIHJldHVybiBcImFuIGlucXVpcnktYmFzZWQgZXhwbG9yYXRpb24gb2YgcXVlc3Rpb25zIGFuZCB1bmNlcnRhaW50aWVzXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoaXNEaWFsb2d1ZUhlYXZ5KSB7XG4gICAgICAgICAgICByZXR1cm4gXCJhIGRpYWxvZ2ljYWwgZW5nYWdlbWVudCB3aXRoIGRpZmZlcmVudCBwZXJzcGVjdGl2ZXMgb3Igdm9pY2VzXCI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gXCJhIHByZXNlbnQtY2VudGVyZWQgcmVmbGVjdGlvbiBvbiBjdXJyZW50IGV4cGVyaWVuY2VzIGFuZCBpbnNpZ2h0c1wiO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8vIEdlbmVyYXRlIGFuYWx5c2lzIGZvciBhIHNwZWNpZmljIGZyYW1ld29ya1xuICAgIGFzeW5jIGdlbmVyYXRlRnJhbWV3b3JrQW5hbHlzaXMoY29udGVudFBhdGgsIGZyYW1ld29yaywgbWVkaWFUeXBlKSB7XG4gICAgICAgIHZhciBfYTtcbiAgICAgICAgLy8gQ2hlY2sgaWYgd2Ugc2hvdWxkIHVzZSBPcGVuQUkgZm9yIGFuYWx5c2lzXG4gICAgICAgIGNvbnN0IHNob3VsZFVzZU9wZW5BSSA9IHRoaXMuc2V0dGluZ3MuZW5hYmxlT3BlbkFJICYmXG4gICAgICAgICAgICB0aGlzLnNldHRpbmdzLmFuYWx5c2lzVGllciA9PT0gQW5hbHlzaXNUaWVyLlBSRU1JVU0gJiZcbiAgICAgICAgICAgICgoX2EgPSB0aGlzLm9wZW5haVNlcnZpY2UpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5pc0NvbmZpZ3VyZWQoKSk7XG4gICAgICAgIC8vIENoZWNrIGlmIHdlJ3ZlIHJlYWNoZWQgdGhlIHVzYWdlIGxpbWl0XG4gICAgICAgIGNvbnN0IHJlYWNoZWRVc2FnZUxpbWl0ID0gdGhpcy5zZXR0aW5ncy5vcGVuYWlVc2FnZUNvdW50ID49IHRoaXMuc2V0dGluZ3Mub3BlbmFpVXNhZ2VMaW1pdDtcbiAgICAgICAgLy8gSWYgd2Ugc2hvdWxkIHVzZSBPcGVuQUkgYW5kIGhhdmVuJ3QgcmVhY2hlZCB0aGUgdXNhZ2UgbGltaXQsIHRyeSB0byB1c2UgaXRcbiAgICAgICAgaWYgKHNob3VsZFVzZU9wZW5BSSAmJiAhcmVhY2hlZFVzYWdlTGltaXQpIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgLy8gR2V0IHRoZSBmcmFtZXdvcmsgbmFtZSBmb3IgYmV0dGVyIHByb21wdGluZ1xuICAgICAgICAgICAgICAgIGNvbnN0IGZyYW1ld29ya05hbWUgPSB0aGlzLmdldEZyYW1ld29ya05hbWUoZnJhbWV3b3JrKTtcbiAgICAgICAgICAgICAgICAvLyBVc2UgT3BlbkFJIHRvIGdlbmVyYXRlIHRoZSBhbmFseXNpc1xuICAgICAgICAgICAgICAgIGNvbnN0IG9wZW5haUFuYWx5c2lzID0gYXdhaXQgdGhpcy5vcGVuYWlTZXJ2aWNlLmFuYWx5emVDb250ZW50KGNvbnRlbnRQYXRoLCBmcmFtZXdvcmssIG1lZGlhVHlwZSwgZnJhbWV3b3JrTmFtZSk7XG4gICAgICAgICAgICAgICAgLy8gSW5jcmVtZW50IHRoZSB1c2FnZSBjb3VudGVyXG4gICAgICAgICAgICAgICAgdGhpcy5zZXR0aW5ncy5vcGVuYWlVc2FnZUNvdW50Kys7XG4gICAgICAgICAgICAgICAgLy8gQWRqdXN0IGFuYWx5c2lzIGJhc2VkIG9uIGRlcHRoIHNldHRpbmdcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHRoaXMuc2V0dGluZ3MuYW5hbHlzaXNEZXB0aCkge1xuICAgICAgICAgICAgICAgICAgICBjYXNlICdicmllZic6XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBSZXR1cm4gZmlyc3QgdHdvIHNlbnRlbmNlc1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG9wZW5haUFuYWx5c2lzLnNwbGl0KCcuICcpLnNsaWNlKDAsIDIpLmpvaW4oJy4gJykgKyAnLic7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgJ2RldGFpbGVkJzpcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFJldHVybiB0aGUgZnVsbCBhbmFseXNpcyBwbHVzIGFkZGl0aW9uYWwgZGV0YWlsXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gb3BlbmFpQW5hbHlzaXMgKyBgIEZ1cnRoZXIgZXhwbG9yYXRpb24gb2YgdGhpcyAke21lZGlhVHlwZX0gdGhyb3VnaCB0aGUgJHtmcmFtZXdvcmtOYW1lfSBmcmFtZXdvcmsgd291bGQgcmV2ZWFsIGFkZGl0aW9uYWwgbGF5ZXJzIG9mIG1lYW5pbmcgYW5kIHNpZ25pZmljYW5jZSwgcGFydGljdWxhcmx5IGluIHJlbGF0aW9uIHRvIHRoZSBzcGVjaWZpYyBjdWx0dXJhbCBhbmQgaGlzdG9yaWNhbCBjb250ZXh0cyBpbiB3aGljaCBpdCB3YXMgY3JlYXRlZCBhbmQgaXMgYmVpbmcgaW50ZXJwcmV0ZWQuYDtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAnc3RhbmRhcmQnOlxuICAgICAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gUmV0dXJuIHRoZSBmdWxsIGFuYWx5c2lzIGFzIGlzXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gb3BlbmFpQW5hbHlzaXM7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgdXNpbmcgT3BlbkFJIGZvciBhbmFseXNpczonLCBlcnJvcik7XG4gICAgICAgICAgICAgICAgbmV3IE5vdGljZSgnRXJyb3IgdXNpbmcgT3BlbkFJIGZvciBhbmFseXNpcy4gRmFsbGluZyBiYWNrIHRvIHByZWRlZmluZWQgYW5hbHlzaXMuJyk7XG4gICAgICAgICAgICAgICAgLy8gRmFsbCBiYWNrIHRvIHByZWRlZmluZWQgYW5hbHlzaXNcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5nZXRGYWxsYmFja0FuYWx5c2lzKGNvbnRlbnRQYXRoLCBmcmFtZXdvcmssIG1lZGlhVHlwZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoc2hvdWxkVXNlT3BlbkFJICYmIHJlYWNoZWRVc2FnZUxpbWl0KSB7XG4gICAgICAgICAgICAvLyBJZiB3ZSd2ZSByZWFjaGVkIHRoZSB1c2FnZSBsaW1pdCwgc2hvdyBhIG5vdGljZSBhbmQgZmFsbCBiYWNrIHRvIHByZWRlZmluZWQgYW5hbHlzaXNcbiAgICAgICAgICAgIG5ldyBOb3RpY2UoYFlvdSd2ZSByZWFjaGVkIHlvdXIgbW9udGhseSBPcGVuQUkgdXNhZ2UgbGltaXQgKCR7dGhpcy5zZXR0aW5ncy5vcGVuYWlVc2FnZUxpbWl0fSkuIEZhbGxpbmcgYmFjayB0byBwcmVkZWZpbmVkIGFuYWx5c2lzLmApO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ2V0RmFsbGJhY2tBbmFseXNpcyhjb250ZW50UGF0aCwgZnJhbWV3b3JrLCBtZWRpYVR5cGUpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgLy8gVXNlIHByZWRlZmluZWQgYW5hbHlzaXNcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmdldEZhbGxiYWNrQW5hbHlzaXMoY29udGVudFBhdGgsIGZyYW1ld29yaywgbWVkaWFUeXBlKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvLyBHZXQgZmFsbGJhY2sgYW5hbHlzaXMgKHByZWRlZmluZWQgb3IgZ2VuZXJpYylcbiAgICBnZXRGYWxsYmFja0FuYWx5c2lzKGNvbnRlbnRQYXRoLCBmcmFtZXdvcmssIG1lZGlhVHlwZSkge1xuICAgICAgICBjb25zdCBmaWxlTmFtZSA9IGNvbnRlbnRQYXRoLnNwbGl0KCcvJykucG9wKCkgfHwgY29udGVudFBhdGg7XG4gICAgICAgIC8vIFRyeSB0byBnZXQgYSBwcmVkZWZpbmVkIGFuYWx5c2lzIGZyb20gdGhlIHByZWRlZmluZWQtYW5hbHlzZXMgZGlyZWN0b3J5XG4gICAgICAgIGNvbnN0IHByZWRlZmluZWRBbmFseXNpcyA9IGdldFByZWRlZmluZWRBbmFseXNpcyhmcmFtZXdvcmssIG1lZGlhVHlwZSk7XG4gICAgICAgIC8vIElmIGEgcHJlZGVmaW5lZCBhbmFseXNpcyBpcyBmb3VuZCwgdXNlIGl0OyBvdGhlcndpc2UsIGdlbmVyYXRlIGEgZ2VuZXJpYyBhbmFseXNpc1xuICAgICAgICBsZXQgYW5hbHlzaXNUZXh0ID0gcHJlZGVmaW5lZEFuYWx5c2lzIHx8XG4gICAgICAgICAgICBnZW5lcmF0ZUdlbmVyaWNBbmFseXNpcyhmcmFtZXdvcmssIG1lZGlhVHlwZSwgZmlsZU5hbWUsIHRoaXMuZ2V0RnJhbWV3b3JrTmFtZShmcmFtZXdvcmspKTtcbiAgICAgICAgLy8gQWRqdXN0IGFuYWx5c2lzIGJhc2VkIG9uIGRlcHRoIHNldHRpbmdcbiAgICAgICAgc3dpdGNoICh0aGlzLnNldHRpbmdzLmFuYWx5c2lzRGVwdGgpIHtcbiAgICAgICAgICAgIGNhc2UgJ2JyaWVmJzpcbiAgICAgICAgICAgICAgICAvLyBSZXR1cm4gZmlyc3QgdHdvIHNlbnRlbmNlc1xuICAgICAgICAgICAgICAgIHJldHVybiBhbmFseXNpc1RleHQuc3BsaXQoJy4gJykuc2xpY2UoMCwgMikuam9pbignLiAnKSArICcuJztcbiAgICAgICAgICAgIGNhc2UgJ2RldGFpbGVkJzpcbiAgICAgICAgICAgICAgICAvLyBSZXR1cm4gdGhlIGZ1bGwgYW5hbHlzaXMgcGx1cyBhZGRpdGlvbmFsIGRldGFpbFxuICAgICAgICAgICAgICAgIHJldHVybiBhbmFseXNpc1RleHQgKyBgIEZ1cnRoZXIgZXhwbG9yYXRpb24gb2YgdGhpcyAke21lZGlhVHlwZX0gdGhyb3VnaCB0aGUgJHt0aGlzLmdldEZyYW1ld29ya05hbWUoZnJhbWV3b3JrKX0gZnJhbWV3b3JrIHdvdWxkIHJldmVhbCBhZGRpdGlvbmFsIGxheWVycyBvZiBtZWFuaW5nIGFuZCBzaWduaWZpY2FuY2UsIHBhcnRpY3VsYXJseSBpbiByZWxhdGlvbiB0byB0aGUgc3BlY2lmaWMgY3VsdHVyYWwgYW5kIGhpc3RvcmljYWwgY29udGV4dHMgaW4gd2hpY2ggaXQgd2FzIGNyZWF0ZWQgYW5kIGlzIGJlaW5nIGludGVycHJldGVkLiBUaGUgdGhlb3JldGljYWwgY29uY2VwdHMgcHJvdmlkZSBhIHJpY2ggdm9jYWJ1bGFyeSBmb3IgYXJ0aWN1bGF0aW5nIHRoZSBjb21wbGV4IGR5bmFtaWNzIGF0IHBsYXkgaW4gdGhpcyB3b3JrLmA7XG4gICAgICAgICAgICBjYXNlICdzdGFuZGFyZCc6XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIC8vIFJldHVybiB0aGUgZnVsbCBhbmFseXNpcyBhcyBpc1xuICAgICAgICAgICAgICAgIHJldHVybiBhbmFseXNpc1RleHQ7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gR2VuZXJhdGUgcmVjb21tZW5kYXRpb25zIGJhc2VkIG9uIGFuYWx5c2VzXG4gICAgZ2VuZXJhdGVSZWNvbW1lbmRhdGlvbnMoZnJhbWV3b3JrQW5hbHlzZXMpIHtcbiAgICAgICAgLy8gR2VuZXJhdGUgZ2VuZXJhbCByZWNvbW1lbmRhdGlvbnNcbiAgICAgICAgY29uc3QgcmVjb21tZW5kYXRpb25zID0gW1xuICAgICAgICAgICAgXCJSZWZsZWN0IG9uIHJlY3VycmluZyBwYXR0ZXJucyBhbmQgdGhlbWVzIHRoYXQgZW1lcmdlZCBhY3Jvc3MgZGlmZmVyZW50IHRoZW9yZXRpY2FsIGZyYW1ld29ya3MuXCIsXG4gICAgICAgICAgICBcIkNvbnNpZGVyIGhvdyBkaWZmZXJlbnQgcGVyc3BlY3RpdmVzIG9mZmVyIGNvbXBsZW1lbnRhcnkgaW5zaWdodHMgaW50byB0aGUgc2FtZSBjb250ZW50LlwiLFxuICAgICAgICAgICAgXCJFeHBsb3JlIHRoZSByZWxhdGlvbnNoaXAgYmV0d2VlbiBmb3JtIGFuZCBjb250ZW50IGluIHlvdXIgY3JlYXRpdmUgZXhwcmVzc2lvbi5cIlxuICAgICAgICBdO1xuICAgICAgICAvLyBBZGQgZnJhbWV3b3JrLXNwZWNpZmljIHJlY29tbWVuZGF0aW9uc1xuICAgICAgICBjb25zdCBmcmFtZXdvcmtSZWNvbW1lbmRhdGlvbnMgPSB7XG4gICAgICAgICAgICBbRlJBTUVXT1JLUy5ERUxFVVpJQU5dOiBbXG4gICAgICAgICAgICAgICAgXCJFeHBsb3JlIGhvdyBEZWxldXppYW4gY29uY2VwdHMgb2Ygcmhpem9tZXMgYW5kIGFzc2VtYmxhZ2VzIG1pZ2h0IGluZm9ybSB5b3VyIGNyZWF0aXZlIHByYWN0aWNlLlwiLFxuICAgICAgICAgICAgICAgIFwiQ29uc2lkZXIgaG93IGxpbmVzIG9mIGZsaWdodCBpbiB5b3VyIHdvcmsgY291bGQgb3BlbiB1cCBuZXcgcG9zc2liaWxpdGllcyBmb3IgZXhwcmVzc2lvbi5cIlxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIFtGUkFNRVdPUktTLklSSUdBUkFZSUFOXTogW1xuICAgICAgICAgICAgICAgIFwiUmVmbGVjdCBvbiBob3cgSXJpZ2FyYXkncyBjb25jZXB0IG9mIHNleHVhbCBkaWZmZXJlbmNlIG1pZ2h0IGluZm9ybSB5b3VyIHVuZGVyc3RhbmRpbmcgb2Ygc3ViamVjdGl2aXR5LlwiLFxuICAgICAgICAgICAgICAgIFwiQ29uc2lkZXIgaG93IGZsdWlkIGxvZ2ljIGFuZCBub24tbGluZWFyIGV4cHJlc3Npb24gY291bGQgZW5yaWNoIHlvdXIgY3JlYXRpdmUgd29yay5cIlxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIFtGUkFNRVdPUktTLkZSRVVESUFOXTogW1xuICAgICAgICAgICAgICAgIFwiQ29uc2lkZXIgaG93IHVuY29uc2Npb3VzIHByb2Nlc3NlcyBtaWdodCBiZSBpbmZsdWVuY2luZyB5b3VyIGNyZWF0aXZlIHdvcmsuXCIsXG4gICAgICAgICAgICAgICAgXCJFeHBsb3JlIHRoZSBzeW1ib2xpYyByZXByZXNlbnRhdGlvbnMgb2YgZGVzaXJlIGluIHlvdXIgY29udGVudC5cIlxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIFtGUkFNRVdPUktTLkxBQ0FOSUFOXTogW1xuICAgICAgICAgICAgICAgIFwiUmVmbGVjdCBvbiBob3cgbGFuZ3VhZ2Ugc3RydWN0dXJlcyB5b3VyIGV4cGVyaWVuY2UgYW5kIGNyZWF0aXZlIGV4cHJlc3Npb24uXCIsXG4gICAgICAgICAgICAgICAgXCJDb25zaWRlciB0aGUgcm9sZSBvZiBkZXNpcmUgYW5kIGxhY2sgaW4geW91ciB3b3JrLlwiXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgW0ZSQU1FV09SS1MuSlVOR0lBTl06IFtcbiAgICAgICAgICAgICAgICBcIkV4cGxvcmUgYXJjaGV0eXBhbCBwYXR0ZXJucyBpbiB5b3VyIGNyZWF0aXZlIHdvcmsuXCIsXG4gICAgICAgICAgICAgICAgXCJDb25zaWRlciBob3cgY29sbGVjdGl2ZSB1bmNvbnNjaW91cyBzeW1ib2xzIGFwcGVhciBpbiB5b3VyIGNvbnRlbnQuXCJcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICBbRlJBTUVXT1JLUy5FWElTVEVOVElBTF06IFtcbiAgICAgICAgICAgICAgICBcIlJlZmxlY3Qgb24gdGhlbWVzIG9mIGZyZWVkb20sIGNob2ljZSwgYW5kIGF1dGhlbnRpY2l0eSBpbiB5b3VyIHdvcmsuXCIsXG4gICAgICAgICAgICAgICAgXCJDb25zaWRlciBob3cgeW91ciBjcmVhdGl2ZSBwcmFjdGljZSBjb250cmlidXRlcyB0byBtZWFuaW5nLW1ha2luZy5cIlxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIFtGUkFNRVdPUktTLkVQSUNVUkVBTl06IFtcbiAgICAgICAgICAgICAgICBcIkNvbnNpZGVyIGhvdyB5b3VyIHdvcmsgcmVsYXRlcyB0byB0aGUgcHVyc3VpdCBvZiB0cmFucXVpbGl0eSBhbmQgZnJlZWRvbSBmcm9tIGRpc3R1cmJhbmNlLlwiLFxuICAgICAgICAgICAgICAgIFwiRXhwbG9yZSB0aGUgcm9sZSBvZiBwbGVhc3VyZSBhbmQgbmF0dXJhbCBkZXNpcmVzIGluIHlvdXIgY3JlYXRpdmUgZXhwcmVzc2lvbi5cIlxuICAgICAgICAgICAgXVxuICAgICAgICAgICAgLy8gQWRkaXRpb25hbCBmcmFtZXdvcmsgcmVjb21tZW5kYXRpb25zIGNhbiBiZSBhZGRlZCBoZXJlXG4gICAgICAgIH07XG4gICAgICAgIC8vIEFkZCByZWxldmFudCBmcmFtZXdvcmstc3BlY2lmaWMgcmVjb21tZW5kYXRpb25zXG4gICAgICAgIE9iamVjdC5rZXlzKGZyYW1ld29ya0FuYWx5c2VzKS5mb3JFYWNoKGZyYW1ld29yayA9PiB7XG4gICAgICAgICAgICBpZiAoZnJhbWV3b3JrIGluIGZyYW1ld29ya1JlY29tbWVuZGF0aW9ucykge1xuICAgICAgICAgICAgICAgIHJlY29tbWVuZGF0aW9ucy5wdXNoKC4uLmZyYW1ld29ya1JlY29tbWVuZGF0aW9uc1tmcmFtZXdvcmtdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZWNvbW1lbmRhdGlvbnM7XG4gICAgfVxuICAgIC8vIEdldCB0aGUgZGlzcGxheSBuYW1lIGZvciBhIGZyYW1ld29yayBJRFxuICAgIGdldEZyYW1ld29ya05hbWUoZnJhbWV3b3JrSWQpIHtcbiAgICAgICAgY29uc3QgbmFtZXMgPSB7XG4gICAgICAgICAgICBbRlJBTUVXT1JLUy5UQUNLVElDQUxdOiAnVGFja3RpY2FsIE1ldGhvZG9sb2d5JyxcbiAgICAgICAgICAgIFtGUkFNRVdPUktTLkZSRVVESUFOXTogJ0ZyZXVkaWFuIFBzeWNob2FuYWx5c2lzJyxcbiAgICAgICAgICAgIFtGUkFNRVdPUktTLkxBQ0FOSUFOXTogJ0xhY2FuaWFuIFBzeWNob2FuYWx5c2lzJyxcbiAgICAgICAgICAgIFtGUkFNRVdPUktTLkRFTEVVWklBTl06ICdEZWxldXppYW4gU2NoaXpvYW5hbHlzaXMnLFxuICAgICAgICAgICAgW0ZSQU1FV09SS1MuSVJJR0FSQVlJQU5dOiAnSXJpZ2FyYXlpYW4gRmVtaW5pc3QgVGhlb3J5JyxcbiAgICAgICAgICAgIFtGUkFNRVdPUktTLkpVTkdJQU5dOiAnSnVuZ2lhbiBBbmFseXRpY2FsIFBzeWNob2xvZ3knLFxuICAgICAgICAgICAgW0ZSQU1FV09SS1MuQVRUQUNITUVOVF06ICdBdHRhY2htZW50IFRoZW9yeScsXG4gICAgICAgICAgICBbRlJBTUVXT1JLUy5QT1NJVElWRV06ICdQb3NpdGl2ZSBQc3ljaG9sb2d5JyxcbiAgICAgICAgICAgIFtGUkFNRVdPUktTLk5BUlJBVElWRV06ICdOYXJyYXRpdmUgUHN5Y2hvbG9neScsXG4gICAgICAgICAgICBbRlJBTUVXT1JLUy5QSEVOT01FTk9MT0dZXTogJ1BoZW5vbWVub2xvZ3knLFxuICAgICAgICAgICAgW0ZSQU1FV09SS1MuRVhJU1RFTlRJQUxdOiAnRXhpc3RlbnRpYWwgUHN5Y2hvbG9neScsXG4gICAgICAgICAgICBbRlJBTUVXT1JLUy5GRU1JTklTVF06ICdGZW1pbmlzdCBUaGVvcnknLFxuICAgICAgICAgICAgW0ZSQU1FV09SS1MuQ1JJVElDQUxdOiAnQ3JpdGljYWwgVGhlb3J5JyxcbiAgICAgICAgICAgIFtGUkFNRVdPUktTLlBPU1RIVU1BTklTTV06ICdQb3N0aHVtYW5pc20nLFxuICAgICAgICAgICAgW0ZSQU1FV09SS1MuQlVEREhJU1RdOiAnQnVkZGhpc3QgUHN5Y2hvbG9neScsXG4gICAgICAgICAgICBbRlJBTUVXT1JLUy5OSUVUWlNDSEVBTl06ICdOaWV0enNjaGVhbiBQaGlsb3NvcGh5JyxcbiAgICAgICAgICAgIFtGUkFNRVdPUktTLkdFU1RBTFRdOiAnR2VzdGFsdCBQc3ljaG9sb2d5JyxcbiAgICAgICAgICAgIFtGUkFNRVdPUktTLlRSQU5TUEVSU09OQUxdOiAnVHJhbnNwZXJzb25hbCBQc3ljaG9sb2d5JyxcbiAgICAgICAgICAgIFtGUkFNRVdPUktTLkNCVF06ICdDb2duaXRpdmUgQmVoYXZpb3JhbCBUaGVyYXB5JyxcbiAgICAgICAgICAgIFtGUkFNRVdPUktTLkhFUk1FTkVVVElDU106ICdIZXJtZW5ldXRpY3MnLFxuICAgICAgICAgICAgW0ZSQU1FV09SS1MuU1RPSUNJU01dOiAnU3RvaWNpc20nLFxuICAgICAgICAgICAgW0ZSQU1FV09SS1MuUFNZQ0hJQVRSWV06ICdQc3ljaGlhdHJ5JyxcbiAgICAgICAgICAgIFtGUkFNRVdPUktTLkVQSUNVUkVBTl06ICdFcGljdXJlYW4gUGhpbG9zb3BoeSdcbiAgICAgICAgfTtcbiAgICAgICAgcmV0dXJuIG5hbWVzW2ZyYW1ld29ya0lkXSB8fCBmcmFtZXdvcmtJZDtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBQbHVnaW5TZXR0aW5nVGFiLCBTZXR0aW5nLCBOb3RpY2UgfSBmcm9tICdvYnNpZGlhbic7XG5pbXBvcnQgeyBGUkFNRVdPUktTLCBBbmFseXNpc1RpZXIsIE9wZW5BSU1vZGVsIH0gZnJvbSAnLi9jb25zdGFudHMnO1xuZXhwb3J0IGNsYXNzIERlbGVvbWV0ZXJTZXR0aW5nVGFiIGV4dGVuZHMgUGx1Z2luU2V0dGluZ1RhYiB7XG4gICAgY29uc3RydWN0b3IoYXBwLCBwbHVnaW4pIHtcbiAgICAgICAgc3VwZXIoYXBwLCBwbHVnaW4pO1xuICAgICAgICB0aGlzLnBsdWdpbiA9IHBsdWdpbjtcbiAgICB9XG4gICAgZGlzcGxheSgpIHtcbiAgICAgICAgLy8gQHRzLWlnbm9yZTogY29udGFpbmVyRWwgaXMgaW5oZXJpdGVkIGZyb20gUGx1Z2luU2V0dGluZ1RhYlxuICAgICAgICBjb25zdCB7IGNvbnRhaW5lckVsIH0gPSB0aGlzO1xuICAgICAgICBjb250YWluZXJFbC5lbXB0eSgpO1xuICAgICAgICBjb250YWluZXJFbC5jcmVhdGVFbCgnaDInLCB7IHRleHQ6ICdEZWxlb21ldGVyIFNldHRpbmdzJyB9KTtcbiAgICAgICAgLy8gRnJhbWV3b3JrIHNlbGVjdGlvbiBzZWN0aW9uXG4gICAgICAgIGNvbnRhaW5lckVsLmNyZWF0ZUVsKCdoMycsIHsgdGV4dDogJ1RoZW9yZXRpY2FsIEZyYW1ld29ya3MnIH0pO1xuICAgICAgICBjb250YWluZXJFbC5jcmVhdGVFbCgncCcsIHsgdGV4dDogJ0VuYWJsZSBvciBkaXNhYmxlIHRoZW9yZXRpY2FsIGZyYW1ld29ya3MgZm9yIGFuYWx5c2lzLicgfSk7XG4gICAgICAgIC8vIENyZWF0ZSBhIHRvZ2dsZSBmb3IgZWFjaCBmcmFtZXdvcmtcbiAgICAgICAgT2JqZWN0LmtleXMoRlJBTUVXT1JLUykuZm9yRWFjaChrZXkgPT4ge1xuICAgICAgICAgICAgY29uc3QgZnJhbWV3b3JrSWQgPSBGUkFNRVdPUktTW2tleV07XG4gICAgICAgICAgICBjb25zdCBmcmFtZXdvcmtOYW1lID0gdGhpcy5wbHVnaW4uYW5hbHlzaXNFbmdpbmUuZ2V0RnJhbWV3b3JrTmFtZShmcmFtZXdvcmtJZCk7XG4gICAgICAgICAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgICAgICAgICAgICAuc2V0TmFtZShmcmFtZXdvcmtOYW1lKVxuICAgICAgICAgICAgICAgIC5zZXREZXNjKGBFbmFibGUgJHtmcmFtZXdvcmtOYW1lfSBmb3IgYW5hbHlzaXNgKVxuICAgICAgICAgICAgICAgIC5hZGRUb2dnbGUodG9nZ2xlID0+IHRvZ2dsZVxuICAgICAgICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5lbmFibGVkRnJhbWV3b3Jrc1tmcmFtZXdvcmtJZF0pXG4gICAgICAgICAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLmVuYWJsZWRGcmFtZXdvcmtzW2ZyYW1ld29ya0lkXSA9IHZhbHVlO1xuICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICAgICAgfSkpO1xuICAgICAgICB9KTtcbiAgICAgICAgLy8gQW5hbHlzaXMgb3B0aW9ucyBzZWN0aW9uXG4gICAgICAgIGNvbnRhaW5lckVsLmNyZWF0ZUVsKCdoMycsIHsgdGV4dDogJ0FuYWx5c2lzIE9wdGlvbnMnIH0pO1xuICAgICAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgICAgICAgIC5zZXROYW1lKCdBbmFseXNpcyBEZXB0aCcpXG4gICAgICAgICAgICAuc2V0RGVzYygnSG93IGRldGFpbGVkIHNob3VsZCB0aGUgYW5hbHlzaXMgYmU/JylcbiAgICAgICAgICAgIC5hZGREcm9wZG93bihkcm9wZG93biA9PiBkcm9wZG93blxuICAgICAgICAgICAgLmFkZE9wdGlvbignYnJpZWYnLCAnQnJpZWYnKVxuICAgICAgICAgICAgLmFkZE9wdGlvbignc3RhbmRhcmQnLCAnU3RhbmRhcmQnKVxuICAgICAgICAgICAgLmFkZE9wdGlvbignZGV0YWlsZWQnLCAnRGV0YWlsZWQnKVxuICAgICAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLmFuYWx5c2lzRGVwdGgpXG4gICAgICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5hbmFseXNpc0RlcHRoID0gdmFsdWU7XG4gICAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgfSkpO1xuICAgICAgICAvLyBKb3VybmFsaW5nIHByb21wdHMgb3B0aW9uXG4gICAgICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgICAgICAgLnNldE5hbWUoJ0pvdXJuYWxpbmcgUHJvbXB0cycpXG4gICAgICAgICAgICAuc2V0RGVzYygnRW5hYmxlIHBlcnNvbmFsaXplZCBqb3VybmFsaW5nIHByb21wdHMgYmFzZWQgb24gYW5hbHlzaXMnKVxuICAgICAgICAgICAgLmFkZFRvZ2dsZSh0b2dnbGUgPT4gdG9nZ2xlXG4gICAgICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3MuZW5hYmxlSm91cm5hbGluZ1Byb21wdHMpXG4gICAgICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5lbmFibGVKb3VybmFsaW5nUHJvbXB0cyA9IHZhbHVlO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcbiAgICAgICAgLy8gQXV0by1vcGVuIGV4cG9ydGVkIGZpbGVzIG9wdGlvblxuICAgICAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgICAgICAgIC5zZXROYW1lKCdBdXRvLW9wZW4gRXhwb3J0ZWQgRmlsZXMnKVxuICAgICAgICAgICAgLnNldERlc2MoJ0F1dG9tYXRpY2FsbHkgb3BlbiBmaWxlcyBhZnRlciBleHBvcnRpbmcgYW5hbHlzaXMgcmVzdWx0cycpXG4gICAgICAgICAgICAuYWRkVG9nZ2xlKHRvZ2dsZSA9PiB0b2dnbGVcbiAgICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5hdXRvT3BlbkV4cG9ydGVkRmlsZXMpXG4gICAgICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5hdXRvT3BlbkV4cG9ydGVkRmlsZXMgPSB2YWx1ZTtcbiAgICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICB9KSk7XG4gICAgICAgIC8vIE9wZW5BSSBJbnRlZ3JhdGlvbiBzZWN0aW9uXG4gICAgICAgIGNvbnRhaW5lckVsLmNyZWF0ZUVsKCdoMycsIHsgdGV4dDogJ09wZW5BSSBJbnRlZ3JhdGlvbicgfSk7XG4gICAgICAgIGNvbnRhaW5lckVsLmNyZWF0ZUVsKCdwJywgeyB0ZXh0OiAnQ29uZmlndXJlIE9wZW5BSSBpbnRlZ3JhdGlvbiBmb3IgZW5oYW5jZWQgYW5hbHlzaXMuJyB9KTtcbiAgICAgICAgLy8gQW5hbHlzaXMgdGllciBzZWxlY3Rpb25cbiAgICAgICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAgICAgICAuc2V0TmFtZSgnQW5hbHlzaXMgVGllcicpXG4gICAgICAgICAgICAuc2V0RGVzYygnU2VsZWN0IHlvdXIgYW5hbHlzaXMgdGllcicpXG4gICAgICAgICAgICAuYWRkRHJvcGRvd24oZHJvcGRvd24gPT4gZHJvcGRvd25cbiAgICAgICAgICAgIC5hZGRPcHRpb24oQW5hbHlzaXNUaWVyLkZSRUUsICdGcmVlIChQcmVkZWZpbmVkIEFuYWx5c2VzKScpXG4gICAgICAgICAgICAuYWRkT3B0aW9uKEFuYWx5c2lzVGllci5QUkVNSVVNLCAnUHJlbWl1bSAoT3BlbkFJLVBvd2VyZWQpJylcbiAgICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5hbmFseXNpc1RpZXIpXG4gICAgICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5hbmFseXNpc1RpZXIgPSB2YWx1ZTtcbiAgICAgICAgICAgIC8vIElmIHN3aXRjaGluZyB0byBwcmVtaXVtLCBtYWtlIHN1cmUgT3BlbkFJIGlzIGVuYWJsZWRcbiAgICAgICAgICAgIGlmICh2YWx1ZSA9PT0gQW5hbHlzaXNUaWVyLlBSRU1JVU0pIHtcbiAgICAgICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5lbmFibGVPcGVuQUkgPSB0cnVlO1xuICAgICAgICAgICAgICAgIC8vIENoZWNrIGlmIEFQSSBrZXkgaXMgY29uZmlndXJlZFxuICAgICAgICAgICAgICAgIGlmICghdGhpcy5wbHVnaW4uc2V0dGluZ3Mub3BlbmFpQXBpS2V5KSB7XG4gICAgICAgICAgICAgICAgICAgIG5ldyBOb3RpY2UoJ1BsZWFzZSBlbnRlciB5b3VyIE9wZW5BSSBBUEkga2V5IHRvIHVzZSB0aGUgUHJlbWl1bSB0aWVyJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcbiAgICAgICAgLy8gRW5hYmxlIE9wZW5BSSB0b2dnbGVcbiAgICAgICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAgICAgICAuc2V0TmFtZSgnRW5hYmxlIE9wZW5BSScpXG4gICAgICAgICAgICAuc2V0RGVzYygnVXNlIE9wZW5BSSBmb3IgZW5oYW5jZWQgYW5hbHlzaXMgKHJlcXVpcmVzIEFQSSBrZXkpJylcbiAgICAgICAgICAgIC5hZGRUb2dnbGUodG9nZ2xlID0+IHRvZ2dsZVxuICAgICAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLmVuYWJsZU9wZW5BSSlcbiAgICAgICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLmVuYWJsZU9wZW5BSSA9IHZhbHVlO1xuICAgICAgICAgICAgLy8gSWYgZGlzYWJsaW5nIE9wZW5BSSwgc3dpdGNoIHRvIGZyZWUgdGllclxuICAgICAgICAgICAgaWYgKCF2YWx1ZSAmJiB0aGlzLnBsdWdpbi5zZXR0aW5ncy5hbmFseXNpc1RpZXIgPT09IEFuYWx5c2lzVGllci5QUkVNSVVNKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MuYW5hbHlzaXNUaWVyID0gQW5hbHlzaXNUaWVyLkZSRUU7XG4gICAgICAgICAgICAgICAgbmV3IE5vdGljZSgnU3dpdGNoZWQgdG8gRnJlZSB0aWVyIGFzIE9wZW5BSSBpbnRlZ3JhdGlvbiB3YXMgZGlzYWJsZWQnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICB9KSk7XG4gICAgICAgIC8vIE9wZW5BSSBBUEkgS2V5XG4gICAgICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgICAgICAgLnNldE5hbWUoJ09wZW5BSSBBUEkgS2V5JylcbiAgICAgICAgICAgIC5zZXREZXNjKCdZb3VyIE9wZW5BSSBBUEkga2V5IChzdG9yZWQgbG9jYWxseSknKVxuICAgICAgICAgICAgLmFkZFRleHQodGV4dCA9PiB0ZXh0XG4gICAgICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJ3NrLS4uLicpXG4gICAgICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Mub3BlbmFpQXBpS2V5KVxuICAgICAgICAgICAgLm9uQ2hhbmdlZChhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLm9wZW5haUFwaUtleSA9IHZhbHVlO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgICAgICAvLyBVcGRhdGUgdGhlIE9wZW5BSSBzZXJ2aWNlIGNvbmZpZ3VyYXRpb25cbiAgICAgICAgICAgIGlmICh0aGlzLnBsdWdpbi5vcGVuYWlTZXJ2aWNlKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5wbHVnaW4ub3BlbmFpU2VydmljZS51cGRhdGVDb25maWcodGhpcy5wbHVnaW4uc2V0dGluZ3MpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KSk7XG4gICAgICAgIC8vIE9wZW5BSSBNb2RlbCBzZWxlY3Rpb25cbiAgICAgICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAgICAgICAuc2V0TmFtZSgnT3BlbkFJIE1vZGVsJylcbiAgICAgICAgICAgIC5zZXREZXNjKCdTZWxlY3Qgd2hpY2ggT3BlbkFJIG1vZGVsIHRvIHVzZScpXG4gICAgICAgICAgICAuYWRkRHJvcGRvd24oZHJvcGRvd24gPT4gZHJvcGRvd25cbiAgICAgICAgICAgIC5hZGRPcHRpb24oT3BlbkFJTW9kZWwuR1BUXzNfNSwgJ0dQVC0zLjUgVHVyYm8gKEZhc3RlciwgY2hlYXBlciknKVxuICAgICAgICAgICAgLmFkZE9wdGlvbihPcGVuQUlNb2RlbC5HUFRfNCwgJ0dQVC00IChNb3JlIGFkdmFuY2VkLCBtb3JlIGV4cGVuc2l2ZSknKVxuICAgICAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLm9wZW5haU1vZGVsKVxuICAgICAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3Mub3BlbmFpTW9kZWwgPSB2YWx1ZTtcbiAgICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICAgICAgLy8gVXBkYXRlIHRoZSBPcGVuQUkgc2VydmljZSBjb25maWd1cmF0aW9uXG4gICAgICAgICAgICBpZiAodGhpcy5wbHVnaW4ub3BlbmFpU2VydmljZSkge1xuICAgICAgICAgICAgICAgIHRoaXMucGx1Z2luLm9wZW5haVNlcnZpY2UudXBkYXRlQ29uZmlnKHRoaXMucGx1Z2luLnNldHRpbmdzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSkpO1xuICAgICAgICAvLyBVc2FnZSBsaW1pdFxuICAgICAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgICAgICAgIC5zZXROYW1lKCdNb250aGx5IFVzYWdlIExpbWl0JylcbiAgICAgICAgICAgIC5zZXREZXNjKCdNYXhpbXVtIG51bWJlciBvZiBPcGVuQUkgYW5hbHlzZXMgcGVyIG1vbnRoJylcbiAgICAgICAgICAgIC5hZGRTbGlkZXIoc2xpZGVyID0+IHNsaWRlclxuICAgICAgICAgICAgLnNldExpbWl0cygxMCwgNTAwLCAxMClcbiAgICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5vcGVuYWlVc2FnZUxpbWl0KVxuICAgICAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3Mub3BlbmFpVXNhZ2VMaW1pdCA9IHZhbHVlO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH0pKTtcbiAgICAgICAgLy8gVXNhZ2Ugc3RhdGlzdGljc1xuICAgICAgICBjb25zdCB1c2FnZUNvdW50ID0gdGhpcy5wbHVnaW4uc2V0dGluZ3Mub3BlbmFpVXNhZ2VDb3VudDtcbiAgICAgICAgY29uc3QgdXNhZ2VMaW1pdCA9IHRoaXMucGx1Z2luLnNldHRpbmdzLm9wZW5haVVzYWdlTGltaXQ7XG4gICAgICAgIGNvbnN0IHVzYWdlUGVyY2VudCA9IE1hdGgucm91bmQoKHVzYWdlQ291bnQgLyB1c2FnZUxpbWl0KSAqIDEwMCk7XG4gICAgICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgICAgICAgLnNldE5hbWUoJ1VzYWdlIFN0YXRpc3RpY3MnKVxuICAgICAgICAgICAgLnNldERlc2MoYFlvdSd2ZSB1c2VkICR7dXNhZ2VDb3VudH0vJHt1c2FnZUxpbWl0fSBhbmFseXNlcyB0aGlzIG1vbnRoICgke3VzYWdlUGVyY2VudH0lKWApXG4gICAgICAgICAgICAuYWRkQnV0dG9uKGJ1dHRvbiA9PiBidXR0b25cbiAgICAgICAgICAgIC5zZXRCdXR0b25UZXh0KCdSZXNldCBVc2FnZSBDb3VudGVyJylcbiAgICAgICAgICAgIC5vbkNsaWNrKGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLm9wZW5haVVzYWdlQ291bnQgPSAwO1xuICAgICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3Mub3BlbmFpTGFzdFJlc2V0ID0gRGF0ZS5ub3coKTtcbiAgICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICAgICAgbmV3IE5vdGljZSgnVXNhZ2UgY291bnRlciBoYXMgYmVlbiByZXNldCcpO1xuICAgICAgICAgICAgdGhpcy5kaXNwbGF5KCk7IC8vIFJlZnJlc2ggdGhlIHNldHRpbmdzIHRhYlxuICAgICAgICB9KSk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgTW9kYWwsIFNldHRpbmcsIE5vdGljZSB9IGZyb20gJ29ic2lkaWFuJztcbmltcG9ydCB7IEZSQU1FV09SS1MsIE1FRElBX1RZUEVTIH0gZnJvbSAnLi9jb25zdGFudHMnO1xuZXhwb3J0IGNsYXNzIFVuaWZpZWRBbmFseXNpc01vZGFsIHtcbiAgICBjb25zdHJ1Y3RvcihhcHAsIHBsdWdpbikge1xuICAgICAgICB0aGlzLnNlbGVjdGVkRnJhbWV3b3JrcyA9IFtdO1xuICAgICAgICB0aGlzLnNlbGVjdGVkTWVkaWFUeXBlID0gTUVESUFfVFlQRVMuVEVYVDtcbiAgICAgICAgdGhpcy5jb250ZW50ID0gJyc7XG4gICAgICAgIHRoaXMuZmlsZSA9IG51bGw7XG4gICAgICAgIHRoaXMuYXBwID0gYXBwO1xuICAgICAgICB0aGlzLnBsdWdpbiA9IHBsdWdpbjtcbiAgICAgICAgdGhpcy5tb2RhbCA9IG5ldyBNb2RhbChhcHApO1xuICAgICAgICB0aGlzLmNvbnRlbnRFbCA9IHRoaXMubW9kYWwuY29udGVudEVsO1xuICAgICAgICAvLyBJbml0aWFsaXplIHdpdGggZW5hYmxlZCBmcmFtZXdvcmtzIGZyb20gc2V0dGluZ3NcbiAgICAgICAgdGhpcy5zZWxlY3RlZEZyYW1ld29ya3MgPSBPYmplY3QuZW50cmllcyh0aGlzLnBsdWdpbi5zZXR0aW5ncy5lbmFibGVkRnJhbWV3b3JrcylcbiAgICAgICAgICAgIC5maWx0ZXIoKFtfLCBlbmFibGVkXSkgPT4gZW5hYmxlZClcbiAgICAgICAgICAgIC5tYXAoKFtmcmFtZXdvcmssIF9dKSA9PiBmcmFtZXdvcmspO1xuICAgIH1cbiAgICBvcGVuKCkge1xuICAgICAgICB0aGlzLm1vZGFsLm9wZW4oKTtcbiAgICAgICAgdGhpcy5vbk9wZW4oKTtcbiAgICB9XG4gICAgY2xvc2UoKSB7XG4gICAgICAgIHRoaXMub25DbG9zZSgpO1xuICAgICAgICB0aGlzLm1vZGFsLmNsb3NlKCk7XG4gICAgfVxuICAgIG9uT3BlbigpIHtcbiAgICAgICAgdGhpcy5jb250ZW50RWwuZW1wdHkoKTtcbiAgICAgICAgdGhpcy5jb250ZW50RWwuY3JlYXRlRWwoJ2gyJywgeyB0ZXh0OiAnVGhlb3JldGljYWwgQW5hbHlzaXMnIH0pO1xuICAgICAgICAvLyBNZWRpYSB0eXBlIHNlbGVjdGlvblxuICAgICAgICBuZXcgU2V0dGluZyh0aGlzLmNvbnRlbnRFbClcbiAgICAgICAgICAgIC5zZXROYW1lKCdNZWRpYSBUeXBlJylcbiAgICAgICAgICAgIC5zZXREZXNjKCdTZWxlY3QgdGhlIHR5cGUgb2YgY29udGVudCB0byBhbmFseXplJylcbiAgICAgICAgICAgIC5hZGREcm9wZG93bihkcm9wZG93biA9PiB7XG4gICAgICAgICAgICBkcm9wZG93blxuICAgICAgICAgICAgICAgIC5hZGRPcHRpb24oTUVESUFfVFlQRVMuVEVYVCwgJ1RleHQnKVxuICAgICAgICAgICAgICAgIC5hZGRPcHRpb24oTUVESUFfVFlQRVMuSU1BR0UsICdJbWFnZScpXG4gICAgICAgICAgICAgICAgLmFkZE9wdGlvbihNRURJQV9UWVBFUy5BVURJTywgJ0F1ZGlvJylcbiAgICAgICAgICAgICAgICAuYWRkT3B0aW9uKE1FRElBX1RZUEVTLkZJTE0sICdGaWxtL1ZpZGVvJylcbiAgICAgICAgICAgICAgICAuc2V0VmFsdWUodGhpcy5zZWxlY3RlZE1lZGlhVHlwZSlcbiAgICAgICAgICAgICAgICAub25DaGFuZ2UodmFsdWUgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuc2VsZWN0ZWRNZWRpYVR5cGUgPSB2YWx1ZTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICAgICAgLy8gRnJhbWV3b3JrIHNlbGVjdGlvblxuICAgICAgICBjb25zdCBmcmFtZXdvcmtzQ29udGFpbmVyID0gdGhpcy5jb250ZW50RWwuY3JlYXRlRGl2KHsgY2xzOiAnZGVsZW9tZXRlci1mcmFtZXdvcmtzJyB9KTtcbiAgICAgICAgZnJhbWV3b3Jrc0NvbnRhaW5lci5jcmVhdGVFbCgnaDMnLCB7IHRleHQ6ICdTZWxlY3QgRnJhbWV3b3JrcycgfSk7XG4gICAgICAgIC8vIENyZWF0ZSBhIGNoZWNrYm94IGZvciBlYWNoIGZyYW1ld29ya1xuICAgICAgICBPYmplY3Qua2V5cyhGUkFNRVdPUktTKS5mb3JFYWNoKGtleSA9PiB7XG4gICAgICAgICAgICBjb25zdCBmcmFtZXdvcmtJZCA9IEZSQU1FV09SS1Nba2V5XTtcbiAgICAgICAgICAgIGNvbnN0IGZyYW1ld29ya05hbWUgPSB0aGlzLnBsdWdpbi5hbmFseXNpc0VuZ2luZS5nZXRGcmFtZXdvcmtOYW1lKGZyYW1ld29ya0lkKTtcbiAgICAgICAgICAgIG5ldyBTZXR0aW5nKGZyYW1ld29ya3NDb250YWluZXIpXG4gICAgICAgICAgICAgICAgLnNldE5hbWUoZnJhbWV3b3JrTmFtZSlcbiAgICAgICAgICAgICAgICAuYWRkVG9nZ2xlKHRvZ2dsZSA9PiB7XG4gICAgICAgICAgICAgICAgdG9nZ2xlXG4gICAgICAgICAgICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLnNlbGVjdGVkRnJhbWV3b3Jrcy5pbmNsdWRlcyhmcmFtZXdvcmtJZCkpXG4gICAgICAgICAgICAgICAgICAgIC5vbkNoYW5nZSh2YWx1ZSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh2YWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gQWRkIHRvIHNlbGVjdGVkIGZyYW1ld29ya3NcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdGhpcy5zZWxlY3RlZEZyYW1ld29ya3MuaW5jbHVkZXMoZnJhbWV3b3JrSWQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zZWxlY3RlZEZyYW1ld29ya3MucHVzaChmcmFtZXdvcmtJZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBSZW1vdmUgZnJvbSBzZWxlY3RlZCBmcmFtZXdvcmtzXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnNlbGVjdGVkRnJhbWV3b3JrcyA9IHRoaXMuc2VsZWN0ZWRGcmFtZXdvcmtzLmZpbHRlcihpZCA9PiBpZCAhPT0gZnJhbWV3b3JrSWQpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgICAgIC8vIEFkZCBidXR0b25zXG4gICAgICAgIGNvbnN0IGJ1dHRvbkNvbnRhaW5lciA9IHRoaXMuY29udGVudEVsLmNyZWF0ZURpdih7IGNsczogJ2RlbGVvbWV0ZXItYnV0dG9ucycgfSk7XG4gICAgICAgIC8vIFNlbGVjdCBBbGwgYnV0dG9uXG4gICAgICAgIGJ1dHRvbkNvbnRhaW5lci5jcmVhdGVFbCgnYnV0dG9uJywgeyB0ZXh0OiAnU2VsZWN0IEFsbCcgfSlcbiAgICAgICAgICAgIC5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICAgICAgICAgIHRoaXMuc2VsZWN0ZWRGcmFtZXdvcmtzID0gT2JqZWN0LmtleXMoRlJBTUVXT1JLUykubWFwKGtleSA9PiBGUkFNRVdPUktTW2tleV0pO1xuICAgICAgICAgICAgdGhpcy5jbG9zZSgpO1xuICAgICAgICAgICAgdGhpcy5vcGVuKCk7XG4gICAgICAgIH0pO1xuICAgICAgICAvLyBEZXNlbGVjdCBBbGwgYnV0dG9uXG4gICAgICAgIGJ1dHRvbkNvbnRhaW5lci5jcmVhdGVFbCgnYnV0dG9uJywgeyB0ZXh0OiAnRGVzZWxlY3QgQWxsJyB9KVxuICAgICAgICAgICAgLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5zZWxlY3RlZEZyYW1ld29ya3MgPSBbXTtcbiAgICAgICAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICAgICAgICAgIHRoaXMub3BlbigpO1xuICAgICAgICB9KTtcbiAgICAgICAgLy8gQW5hbHl6ZSBidXR0b25cbiAgICAgICAgYnV0dG9uQ29udGFpbmVyLmNyZWF0ZUVsKCdidXR0b24nLCB7IHRleHQ6ICdBbmFseXplJywgY2xzOiAnbW9kLWN0YScgfSlcbiAgICAgICAgICAgIC5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICAgICAgICAgIHRoaXMuYW5hbHl6ZSgpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgb25DbG9zZSgpIHtcbiAgICAgICAgdGhpcy5jb250ZW50RWwuZW1wdHkoKTtcbiAgICB9XG4gICAgLy8gQW5hbHl6ZSB0aGUgY3VycmVudCBjb250ZW50XG4gICAgYW5hbHl6ZSgpIHtcbiAgICAgICAgdmFyIF9hLCBfYjtcbiAgICAgICAgaWYgKHRoaXMuc2VsZWN0ZWRGcmFtZXdvcmtzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgLy8gU2hvdyBlcnJvciBpZiBubyBmcmFtZXdvcmtzIHNlbGVjdGVkXG4gICAgICAgICAgICBuZXcgTm90aWNlKCdQbGVhc2Ugc2VsZWN0IGF0IGxlYXN0IG9uZSBmcmFtZXdvcmsgZm9yIGFuYWx5c2lzLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICAvLyBHZXQgdGhlIGFjdGl2ZSBmaWxlIG9yIGVkaXRvciBjb250ZW50XG4gICAgICAgICAgICBjb25zdCBhY3RpdmVGaWxlID0gdGhpcy5hcHAud29ya3NwYWNlLmdldEFjdGl2ZUZpbGUoKTtcbiAgICAgICAgICAgIGlmICh0aGlzLnNlbGVjdGVkTWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5URVhUKSB7XG4gICAgICAgICAgICAgICAgLy8gRm9yIHRleHQsIGdldCB0aGUgY29udGVudCBmcm9tIHRoZSBlZGl0b3JcbiAgICAgICAgICAgICAgICBjb25zdCBhY3RpdmVMZWFmID0gdGhpcy5hcHAud29ya3NwYWNlLmFjdGl2ZUxlYWY7XG4gICAgICAgICAgICAgICAgY29uc3QgZWRpdG9yID0gKF9iID0gKF9hID0gYWN0aXZlTGVhZiA9PT0gbnVsbCB8fCBhY3RpdmVMZWFmID09PSB2b2lkIDAgPyB2b2lkIDAgOiBhY3RpdmVMZWFmLnZpZXcpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5zb3VyY2VNb2RlKSA9PT0gbnVsbCB8fCBfYiA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2IuY21FZGl0b3I7XG4gICAgICAgICAgICAgICAgaWYgKGVkaXRvcikge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjb250ZW50ID0gZWRpdG9yLmdldFZhbHVlKCk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5wbHVnaW4uYW5hbHl6ZUNvbnRlbnQoY29udGVudCwgTUVESUFfVFlQRVMuVEVYVCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGFjdGl2ZUZpbGUpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gSWYgbm8gZWRpdG9yIGJ1dCB0aGVyZSdzIGFuIGFjdGl2ZSBmaWxlLCB1c2UgdGhlIGZpbGVcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jbG9zZSgpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnBsdWdpbi5hbmFseXplQ29udGVudChhY3RpdmVGaWxlLCB0aGlzLnNlbGVjdGVkTWVkaWFUeXBlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIG5ldyBOb3RpY2UoJ05vIGNvbnRlbnQgdG8gYW5hbHl6ZS4gUGxlYXNlIG9wZW4gYSBmaWxlIG9yIGVudGVyIHRleHQuJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgLy8gRm9yIG90aGVyIG1lZGlhIHR5cGVzLCB3ZSBuZWVkIGEgZmlsZVxuICAgICAgICAgICAgICAgIGlmIChhY3RpdmVGaWxlKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIENoZWNrIGlmIHRoZSBmaWxlIHR5cGUgbWF0Y2hlcyB0aGUgc2VsZWN0ZWQgbWVkaWEgdHlwZVxuICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWxlRXh0ZW5zaW9uID0gYWN0aXZlRmlsZS5leHRlbnNpb24udG9Mb3dlckNhc2UoKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNWYWxpZEZpbGUgPSB0aGlzLmlzVmFsaWRGaWxlRm9yTWVkaWFUeXBlKGZpbGVFeHRlbnNpb24sIHRoaXMuc2VsZWN0ZWRNZWRpYVR5cGUpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoaXNWYWxpZEZpbGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucGx1Z2luLmFuYWx5emVDb250ZW50KGFjdGl2ZUZpbGUsIHRoaXMuc2VsZWN0ZWRNZWRpYVR5cGUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmV3IE5vdGljZShgVGhlIGN1cnJlbnQgZmlsZSBpcyBub3QgYSB2YWxpZCAke3RoaXMuc2VsZWN0ZWRNZWRpYVR5cGV9IGZpbGUuYCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIG5ldyBOb3RpY2UoYFBsZWFzZSBvcGVuIGEgJHt0aGlzLnNlbGVjdGVkTWVkaWFUeXBlfSBmaWxlIHRvIGFuYWx5emUuYCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgaW4gYW5hbHl6ZTonLCBlcnJvcik7XG4gICAgICAgICAgICBuZXcgTm90aWNlKCdBbiBlcnJvciBvY2N1cnJlZCBkdXJpbmcgYW5hbHlzaXMuIENoZWNrIHRoZSBjb25zb2xlIGZvciBkZXRhaWxzLicpO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8vIENoZWNrIGlmIGEgZmlsZSBleHRlbnNpb24gaXMgdmFsaWQgZm9yIHRoZSBzZWxlY3RlZCBtZWRpYSB0eXBlXG4gICAgaXNWYWxpZEZpbGVGb3JNZWRpYVR5cGUoZXh0ZW5zaW9uLCBtZWRpYVR5cGUpIHtcbiAgICAgICAgc3dpdGNoIChtZWRpYVR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgTUVESUFfVFlQRVMuSU1BR0U6XG4gICAgICAgICAgICAgICAgcmV0dXJuIFsnanBnJywgJ2pwZWcnLCAncG5nJywgJ2dpZicsICdzdmcnLCAnd2VicCddLmluY2x1ZGVzKGV4dGVuc2lvbik7XG4gICAgICAgICAgICBjYXNlIE1FRElBX1RZUEVTLkFVRElPOlxuICAgICAgICAgICAgICAgIHJldHVybiBbJ21wMycsICd3YXYnLCAnb2dnJywgJ200YScsICdmbGFjJ10uaW5jbHVkZXMoZXh0ZW5zaW9uKTtcbiAgICAgICAgICAgIGNhc2UgTUVESUFfVFlQRVMuRklMTTpcbiAgICAgICAgICAgICAgICByZXR1cm4gWydtcDQnLCAnd2VibScsICdtb3YnLCAnYXZpJywgJ21rdiddLmluY2x1ZGVzKGV4dGVuc2lvbik7XG4gICAgICAgICAgICBjYXNlIE1FRElBX1RZUEVTLlRFWFQ6XG4gICAgICAgICAgICAgICAgcmV0dXJuIFsnbWQnLCAndHh0JywgJ2h0bWwnLCAnY3NzJywgJ2pzJywgJ3RzJywgJ2pzb24nXS5pbmNsdWRlcyhleHRlbnNpb24pO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCIvKipcbiAqIFR5cGVTY3JpcHQgaGVscGVycyBmb3IgYXN5bmMvYXdhaXQgYW5kIG90aGVyIEVTIGZlYXR1cmVzXG4gKi9cbi8vIEhlbHBlciBmb3IgYXN5bmMvYXdhaXRcbmV4cG9ydCBmdW5jdGlvbiBfX2F3YWl0ZXIodGhpc0FyZywgX2FyZ3VtZW50cywgUCwgZ2VuZXJhdG9yKSB7XG4gICAgZnVuY3Rpb24gYWRvcHQodmFsdWUpIHsgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgUCA/IHZhbHVlIDogbmV3IFAoZnVuY3Rpb24gKHJlc29sdmUpIHsgcmVzb2x2ZSh2YWx1ZSk7IH0pOyB9XG4gICAgcmV0dXJuIG5ldyAoUCB8fCAoUCA9IFByb21pc2UpKShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgIGZ1bmN0aW9uIGZ1bGZpbGxlZCh2YWx1ZSkgeyB0cnkge1xuICAgICAgICAgICAgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICByZWplY3QoZSk7XG4gICAgICAgIH0gfVxuICAgICAgICBmdW5jdGlvbiByZWplY3RlZCh2YWx1ZSkgeyB0cnkge1xuICAgICAgICAgICAgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICByZWplY3QoZSk7XG4gICAgICAgIH0gfVxuICAgICAgICBmdW5jdGlvbiBzdGVwKHJlc3VsdCkgeyByZXN1bHQuZG9uZSA/IHJlc29sdmUocmVzdWx0LnZhbHVlKSA6IGFkb3B0KHJlc3VsdC52YWx1ZSkudGhlbihmdWxmaWxsZWQsIHJlamVjdGVkKTsgfVxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XG4gICAgfSk7XG59XG4vLyBIZWxwZXIgZm9yIGdlbmVyYXRvciBmdW5jdGlvbnNcbmV4cG9ydCBmdW5jdGlvbiBfX2dlbmVyYXRvcih0aGlzQXJnLCBib2R5KSB7XG4gICAgdmFyIF8gPSB7IGxhYmVsOiAwLCBzZW50OiBmdW5jdGlvbiAoKSB7IGlmICh0WzBdICYgMSlcbiAgICAgICAgICAgIHRocm93IHRbMV07IHJldHVybiB0WzFdOyB9LCB0cnlzOiBbXSwgb3BzOiBbXSB9LCBmLCB5LCB0LCBnO1xuICAgIHJldHVybiBnID0geyBuZXh0OiB2ZXJiKDApLCBcInRocm93XCI6IHZlcmIoMSksIFwicmV0dXJuXCI6IHZlcmIoMikgfSwgdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIChnW1N5bWJvbC5pdGVyYXRvcl0gPSBmdW5jdGlvbiAoKSB7IHJldHVybiB0aGlzOyB9KSwgZztcbiAgICBmdW5jdGlvbiB2ZXJiKG4pIHsgcmV0dXJuIGZ1bmN0aW9uICh2KSB7IHJldHVybiBzdGVwKFtuLCB2XSk7IH07IH1cbiAgICBmdW5jdGlvbiBzdGVwKG9wKSB7XG4gICAgICAgIGlmIChmKVxuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkdlbmVyYXRvciBpcyBhbHJlYWR5IGV4ZWN1dGluZy5cIik7XG4gICAgICAgIHdoaWxlIChfKVxuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBpZiAoZiA9IDEsIHkgJiYgKHQgPSBvcFswXSAmIDIgPyB5W1wicmV0dXJuXCJdIDogb3BbMF0gPyB5W1widGhyb3dcIl0gfHwgKCh0ID0geVtcInJldHVyblwiXSkgJiYgdC5jYWxsKHkpLCAwKSA6IHkubmV4dCkgJiYgISh0ID0gdC5jYWxsKHksIG9wWzFdKSkuZG9uZSlcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHQ7XG4gICAgICAgICAgICAgICAgaWYgKHkgPSAwLCB0KVxuICAgICAgICAgICAgICAgICAgICBvcCA9IFtvcFswXSAmIDIsIHQudmFsdWVdO1xuICAgICAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAwOlxuICAgICAgICAgICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgICAgICAgICAgICB0ID0gb3A7XG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgY2FzZSA0OlxuICAgICAgICAgICAgICAgICAgICAgICAgXy5sYWJlbCsrO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHsgdmFsdWU6IG9wWzFdLCBkb25lOiBmYWxzZSB9O1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDU6XG4gICAgICAgICAgICAgICAgICAgICAgICBfLmxhYmVsKys7XG4gICAgICAgICAgICAgICAgICAgICAgICB5ID0gb3BbMV07XG4gICAgICAgICAgICAgICAgICAgICAgICBvcCA9IFswXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDc6XG4gICAgICAgICAgICAgICAgICAgICAgICBvcCA9IF8ub3BzLnBvcCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgXy50cnlzLnBvcCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoISh0ID0gXy50cnlzLCB0ID0gdC5sZW5ndGggPiAwICYmIHRbdC5sZW5ndGggLSAxXSkgJiYgKG9wWzBdID09PSA2IHx8IG9wWzBdID09PSAyKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF8gPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSAzICYmICghdCB8fCAob3BbMV0gPiB0WzBdICYmIG9wWzFdIDwgdFszXSkpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXy5sYWJlbCA9IG9wWzFdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSA2ICYmIF8ubGFiZWwgPCB0WzFdKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXy5sYWJlbCA9IHRbMV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdCA9IG9wO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHQgJiYgXy5sYWJlbCA8IHRbMl0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfLmxhYmVsID0gdFsyXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfLm9wcy5wdXNoKG9wKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0WzJdKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF8ub3BzLnBvcCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgXy50cnlzLnBvcCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIG9wID0gYm9keS5jYWxsKHRoaXNBcmcsIF8pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICBvcCA9IFs2LCBlXTtcbiAgICAgICAgICAgICAgICB5ID0gMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgICAgIGYgPSB0ID0gMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgaWYgKG9wWzBdICYgNSlcbiAgICAgICAgICAgIHRocm93IG9wWzFdO1xuICAgICAgICByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xuICAgIH1cbn1cbi8vIEhlbHBlciBmb3Igc3ByZWFkIG9wZXJhdG9yXG5leHBvcnQgZnVuY3Rpb24gX19zcHJlYWRBcnJheSh0bywgZnJvbSwgcGFjaykge1xuICAgIGlmIChwYWNrIHx8IGFyZ3VtZW50cy5sZW5ndGggPT09IDIpXG4gICAgICAgIGZvciAodmFyIGkgPSAwLCBsID0gZnJvbS5sZW5ndGgsIGFyOyBpIDwgbDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoYXIgfHwgIShpIGluIGZyb20pKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFhcilcbiAgICAgICAgICAgICAgICAgICAgYXIgPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChmcm9tLCAwLCBpKTtcbiAgICAgICAgICAgICAgICBhcltpXSA9IGZyb21baV07XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICByZXR1cm4gdG8uY29uY2F0KGFyIHx8IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGZyb20pKTtcbn1cbi8vIEhlbHBlciBmb3IgcmVzdCBwYXJhbWV0ZXJzXG5leHBvcnQgZnVuY3Rpb24gX19yZXN0KHMsIGUpIHtcbiAgICB2YXIgdCA9IHt9O1xuICAgIGZvciAodmFyIHAgaW4gcylcbiAgICAgICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSAmJiBlLmluZGV4T2YocCkgPCAwKVxuICAgICAgICAgICAgdFtwXSA9IHNbcF07XG4gICAgaWYgKHMgIT0gbnVsbCAmJiB0eXBlb2YgT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyA9PT0gXCJmdW5jdGlvblwiKVxuICAgICAgICBmb3IgKHZhciBpID0gMCwgcCA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMocyk7IGkgPCBwLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoZS5pbmRleE9mKHBbaV0pIDwgMCAmJiBPYmplY3QucHJvdG90eXBlLnByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwocywgcFtpXSkpXG4gICAgICAgICAgICAgICAgdFtwW2ldXSA9IHNbcFtpXV07XG4gICAgICAgIH1cbiAgICByZXR1cm4gdDtcbn1cbi8vIEhlbHBlciBmb3Igb2JqZWN0IHNwcmVhZFxuZXhwb3J0IGZ1bmN0aW9uIF9fYXNzaWduKHQpIHtcbiAgICBmb3IgKHZhciBzLCBpID0gMSwgbiA9IGFyZ3VtZW50cy5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgcyA9IGFyZ3VtZW50c1tpXTtcbiAgICAgICAgZm9yICh2YXIgcCBpbiBzKVxuICAgICAgICAgICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSlcbiAgICAgICAgICAgICAgICB0W3BdID0gc1twXTtcbiAgICB9XG4gICAgcmV0dXJuIHQ7XG59XG4iLCJpbXBvcnQgeyBQbHVnaW4sIE5vdGljZSB9IGZyb20gJ29ic2lkaWFuJztcbmltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MsIE1FRElBX1RZUEVTIH0gZnJvbSAnLi9jb25zdGFudHMnO1xuaW1wb3J0IHsgQW5hbHlzaXNFbmdpbmUgfSBmcm9tICcuL2FuYWx5c2lzLWVuZ2luZSc7XG5pbXBvcnQgeyBEZWxlb21ldGVyU2V0dGluZ1RhYiB9IGZyb20gJy4vc2V0dGluZ3MtdGFiJztcbmltcG9ydCB7IFVuaWZpZWRBbmFseXNpc01vZGFsIH0gZnJvbSAnLi91bmlmaWVkLWFuYWx5c2lzLW1vZGFsJztcbmltcG9ydCB7IE9wZW5BSVNlcnZpY2UgfSBmcm9tICcuL3NlcnZpY2VzL29wZW5haS1zZXJ2aWNlJztcbmltcG9ydCB7IF9fYXdhaXRlciB9IGZyb20gJy4vdHNsaWInO1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgRGVsZW9tZXRlclBsdWdpbiBleHRlbmRzIFBsdWdpbiB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMub3BlbmFpU2VydmljZSA9IG51bGw7XG4gICAgfVxuICAgIG9ubG9hZCgpIHtcbiAgICAgICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24qICgpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdMb2FkaW5nIERlbGVvbWV0ZXIgcGx1Z2luJyk7XG4gICAgICAgICAgICAvLyBMb2FkIHNldHRpbmdzXG4gICAgICAgICAgICB5aWVsZCB0aGlzLmxvYWRTZXR0aW5ncygpO1xuICAgICAgICAgICAgLy8gSW5pdGlhbGl6ZSBhbmFseXNpcyBlbmdpbmVcbiAgICAgICAgICAgIHRoaXMuYW5hbHlzaXNFbmdpbmUgPSBuZXcgQW5hbHlzaXNFbmdpbmUodGhpcy5hcHAsIHRoaXMuc2V0dGluZ3MpO1xuICAgICAgICAgICAgLy8gSW5pdGlhbGl6ZSBPcGVuQUkgc2VydmljZSBpZiBlbmFibGVkXG4gICAgICAgICAgICBpZiAodGhpcy5zZXR0aW5ncy5lbmFibGVPcGVuQUkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm9wZW5haVNlcnZpY2UgPSBuZXcgT3BlbkFJU2VydmljZSh0aGlzLnNldHRpbmdzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIENoZWNrIGlmIHdlIG5lZWQgdG8gcmVzZXQgdGhlIG1vbnRobHkgdXNhZ2UgY291bnRlclxuICAgICAgICAgICAgdGhpcy5jaGVja01vbnRobHlSZXNldCgpO1xuICAgICAgICAgICAgLy8gQWRkIHJpYmJvbiBpY29uXG4gICAgICAgICAgICBjb25zdCByaWJib25JY29uRWwgPSB0aGlzLmFkZFJpYmJvbkljb24oJ2xlYWYnLCAnRGVsZW9tZXRlcicsIChfKSA9PiB7XG4gICAgICAgICAgICAgICAgLy8gQ2FsbGVkIHdoZW4gdGhlIHVzZXIgY2xpY2tzIHRoZSBpY29uLlxuICAgICAgICAgICAgICAgIHRoaXMuYW5hbHl6ZUN1cnJlbnRGaWxlKCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIC8vIFNwZWNpZnkgYSB0b29sdGlwIGZvciB0aGUgcmliYm9uIGljb25cbiAgICAgICAgICAgIHJpYmJvbkljb25FbC5hZGRDbGFzcygnZGVsZW9tZXRlci1yaWJib24tY2xhc3MnKTtcbiAgICAgICAgICAgIC8vIEFkZCBjb21tYW5kIHRvIGFuYWx5emUgY3VycmVudCBmaWxlXG4gICAgICAgICAgICB0aGlzLmFkZENvbW1hbmQoe1xuICAgICAgICAgICAgICAgIGlkOiAnYW5hbHl6ZS1jdXJyZW50LWZpbGUnLFxuICAgICAgICAgICAgICAgIG5hbWU6ICdBbmFseXplIEN1cnJlbnQgRmlsZScsXG4gICAgICAgICAgICAgICAgY2FsbGJhY2s6ICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hbmFseXplQ3VycmVudEZpbGUoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIC8vIEFkZCBjb21tYW5kIHRvIGFuYWx5emUgc2VsZWN0ZWQgdGV4dFxuICAgICAgICAgICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgICAgICAgICAgICBpZDogJ2FuYWx5emUtc2VsZWN0ZWQtdGV4dCcsXG4gICAgICAgICAgICAgICAgbmFtZTogJ0FuYWx5emUgU2VsZWN0ZWQgVGV4dCcsXG4gICAgICAgICAgICAgICAgZWRpdG9yQ2FsbGJhY2s6IChlZGl0b3IsIF8pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgc2VsZWN0ZWRUZXh0ID0gZWRpdG9yLmdldFNlbGVjdGlvbigpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoc2VsZWN0ZWRUZXh0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFuYWx5emVDb250ZW50KHNlbGVjdGVkVGV4dCwgTUVESUFfVFlQRVMuVEVYVCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuZXcgTm90aWNlKCdObyB0ZXh0IHNlbGVjdGVkJyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIC8vIEFkZCBzZXR0aW5ncyB0YWJcbiAgICAgICAgICAgIHRoaXMuYWRkU2V0dGluZ1RhYihuZXcgRGVsZW9tZXRlclNldHRpbmdUYWIodGhpcy5hcHAsIHRoaXMpKTtcbiAgICAgICAgICAgIC8vIEFkZCBjb21tYW5kIHRvIG9wZW4gdGhlIHVuaWZpZWQgYW5hbHlzaXMgbW9kYWxcbiAgICAgICAgICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICAgICAgICAgICAgaWQ6ICdvcGVuLXVuaWZpZWQtYW5hbHlzaXMnLFxuICAgICAgICAgICAgICAgIG5hbWU6ICdPcGVuIFVuaWZpZWQgQW5hbHlzaXMnLFxuICAgICAgICAgICAgICAgIGNhbGxiYWNrOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2hvd1VuaWZpZWRBbmFseXNpc01vZGFsKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBvbnVubG9hZCgpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ1VubG9hZGluZyBEZWxlb21ldGVyIHBsdWdpbicpO1xuICAgIH1cbiAgICBsb2FkU2V0dGluZ3MoKSB7XG4gICAgICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgICAgICAgICBjb25zdCBkYXRhID0geWllbGQgdGhpcy5sb2FkRGF0YSgpO1xuICAgICAgICAgICAgdGhpcy5zZXR0aW5ncyA9IE9iamVjdC5hc3NpZ24oe30sIERFRkFVTFRfU0VUVElOR1MsIGRhdGEpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgc2F2ZVNldHRpbmdzKCkge1xuICAgICAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiogKCkge1xuICAgICAgICAgICAgeWllbGQgdGhpcy5zYXZlRGF0YSh0aGlzLnNldHRpbmdzKTtcbiAgICAgICAgICAgIC8vIFVwZGF0ZSB0aGUgYW5hbHlzaXMgZW5naW5lIHdpdGggbmV3IHNldHRpbmdzXG4gICAgICAgICAgICB0aGlzLmFuYWx5c2lzRW5naW5lLnVwZGF0ZUNvbmZpZyh0aGlzLnNldHRpbmdzKTtcbiAgICAgICAgICAgIC8vIFVwZGF0ZSBPcGVuQUkgc2VydmljZSBpZiBuZWVkZWRcbiAgICAgICAgICAgIGlmICh0aGlzLnNldHRpbmdzLmVuYWJsZU9wZW5BSSkge1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLm9wZW5haVNlcnZpY2UpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5vcGVuYWlTZXJ2aWNlLnVwZGF0ZUNvbmZpZyh0aGlzLnNldHRpbmdzKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMub3BlbmFpU2VydmljZSA9IG5ldyBPcGVuQUlTZXJ2aWNlKHRoaXMuc2V0dGluZ3MpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMub3BlbmFpU2VydmljZSA9IG51bGw7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvLyBDaGVjayBpZiB3ZSBuZWVkIHRvIHJlc2V0IHRoZSBtb250aGx5IHVzYWdlIGNvdW50ZXJcbiAgICBjaGVja01vbnRobHlSZXNldCgpIHtcbiAgICAgICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgICAgICAgY29uc3QgbGFzdFJlc2V0ID0gdGhpcy5zZXR0aW5ncy5vcGVuYWlMYXN0UmVzZXQ7XG4gICAgICAgIGNvbnN0IG9uZU1vbnRoTXMgPSAzMCAqIDI0ICogNjAgKiA2MCAqIDEwMDA7IC8vIDMwIGRheXMgaW4gbWlsbGlzZWNvbmRzXG4gICAgICAgIC8vIElmIGl0J3MgYmVlbiBtb3JlIHRoYW4gYSBtb250aCBzaW5jZSB0aGUgbGFzdCByZXNldCwgcmVzZXQgdGhlIGNvdW50ZXJcbiAgICAgICAgaWYgKG5vdyAtIGxhc3RSZXNldCA+IG9uZU1vbnRoTXMpIHtcbiAgICAgICAgICAgIHRoaXMuc2V0dGluZ3Mub3BlbmFpVXNhZ2VDb3VudCA9IDA7XG4gICAgICAgICAgICB0aGlzLnNldHRpbmdzLm9wZW5haUxhc3RSZXNldCA9IG5vdztcbiAgICAgICAgICAgIHRoaXMuc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gQW5hbHl6ZSB0aGUgY3VycmVudCBhY3RpdmUgZmlsZVxuICAgIGFuYWx5emVDdXJyZW50RmlsZSgpIHtcbiAgICAgICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24qICgpIHtcbiAgICAgICAgICAgIGNvbnN0IGFjdGl2ZUZpbGUgPSB0aGlzLmFwcC53b3Jrc3BhY2UuZ2V0QWN0aXZlRmlsZSgpO1xuICAgICAgICAgICAgaWYgKCFhY3RpdmVGaWxlKSB7XG4gICAgICAgICAgICAgICAgLy8gTm8gYWN0aXZlIGZpbGVcbiAgICAgICAgICAgICAgICBuZXcgTm90aWNlKCdObyBhY3RpdmUgZmlsZSB0byBhbmFseXplJyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gRGV0ZXJtaW5lIG1lZGlhIHR5cGUgYmFzZWQgb24gZmlsZSBleHRlbnNpb25cbiAgICAgICAgICAgIGNvbnN0IG1lZGlhVHlwZSA9IHRoaXMuZ2V0TWVkaWFUeXBlRnJvbUZpbGUoYWN0aXZlRmlsZSk7XG4gICAgICAgICAgICBpZiAobWVkaWFUeXBlID09PSBNRURJQV9UWVBFUy5URVhUKSB7XG4gICAgICAgICAgICAgICAgLy8gRm9yIHRleHQgZmlsZXMsIGdldCB0aGUgY29udGVudFxuICAgICAgICAgICAgICAgIGNvbnN0IGNvbnRlbnQgPSB5aWVsZCB0aGlzLmFwcC52YXVsdC5yZWFkKGFjdGl2ZUZpbGUpO1xuICAgICAgICAgICAgICAgIHRoaXMuYW5hbHl6ZUNvbnRlbnQoY29udGVudCwgbWVkaWFUeXBlLCBhY3RpdmVGaWxlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIEZvciBvdGhlciBtZWRpYSB0eXBlcywgcGFzcyB0aGUgZmlsZSBkaXJlY3RseVxuICAgICAgICAgICAgICAgIHRoaXMuYW5hbHl6ZUNvbnRlbnQoYWN0aXZlRmlsZSwgbWVkaWFUeXBlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuICAgIC8vIERldGVybWluZSBtZWRpYSB0eXBlIGZyb20gZmlsZSBleHRlbnNpb25cbiAgICBnZXRNZWRpYVR5cGVGcm9tRmlsZShmaWxlKSB7XG4gICAgICAgIGNvbnN0IGV4dGVuc2lvbiA9IGZpbGUuZXh0ZW5zaW9uLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIGlmIChbJ21kJywgJ3R4dCcsICd0ZXh0J10uaW5jbHVkZXMoZXh0ZW5zaW9uKSkge1xuICAgICAgICAgICAgcmV0dXJuIE1FRElBX1RZUEVTLlRFWFQ7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoWydqcGcnLCAnanBlZycsICdwbmcnLCAnZ2lmJywgJ2JtcCcsICdzdmcnXS5pbmNsdWRlcyhleHRlbnNpb24pKSB7XG4gICAgICAgICAgICByZXR1cm4gTUVESUFfVFlQRVMuSU1BR0U7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoWydtcDMnLCAnd2F2JywgJ29nZycsICdmbGFjJywgJ200YSddLmluY2x1ZGVzKGV4dGVuc2lvbikpIHtcbiAgICAgICAgICAgIHJldHVybiBNRURJQV9UWVBFUy5BVURJTztcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChbJ21wNCcsICd3ZWJtJywgJ21vdicsICdhdmknLCAnbWt2J10uaW5jbHVkZXMoZXh0ZW5zaW9uKSkge1xuICAgICAgICAgICAgcmV0dXJuIE1FRElBX1RZUEVTLkZJTE07XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAvLyBEZWZhdWx0IHRvIHRleHQgZm9yIHVua25vd24gdHlwZXNcbiAgICAgICAgICAgIHJldHVybiBNRURJQV9UWVBFUy5URVhUO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8vIEFuYWx5emUgY29udGVudCB3aXRoIHRoZSBhbmFseXNpcyBlbmdpbmVcbiAgICBhbmFseXplQ29udGVudChjb250ZW50LCBtZWRpYVR5cGUsIGZpbGUpIHtcbiAgICAgICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24qICgpIHtcbiAgICAgICAgICAgIC8vIEdldCBlbmFibGVkIGZyYW1ld29ya3MgZnJvbSBzZXR0aW5nc1xuICAgICAgICAgICAgY29uc3QgZW5hYmxlZEZyYW1ld29ya3MgPSBPYmplY3QuZW50cmllcyh0aGlzLnNldHRpbmdzLmVuYWJsZWRGcmFtZXdvcmtzKVxuICAgICAgICAgICAgICAgIC5maWx0ZXIoKFtfLCBlbmFibGVkXSkgPT4gZW5hYmxlZClcbiAgICAgICAgICAgICAgICAubWFwKChbZnJhbWV3b3JrLCBfXSkgPT4gZnJhbWV3b3JrKTtcbiAgICAgICAgICAgIGlmIChlbmFibGVkRnJhbWV3b3Jrcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgICBuZXcgTm90aWNlKCdObyBhbmFseXNpcyBmcmFtZXdvcmtzIGFyZSBlbmFibGVkLiBQbGVhc2UgZW5hYmxlIGF0IGxlYXN0IG9uZSBmcmFtZXdvcmsgaW4gc2V0dGluZ3MuJyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAvLyBTaG93IGxvYWRpbmcgbm90aWNlXG4gICAgICAgICAgICAgICAgbmV3IE5vdGljZSgnQW5hbHl6aW5nIGNvbnRlbnQuLi4nKTtcbiAgICAgICAgICAgICAgICAvLyBBbmFseXplIHRoZSBjb250ZW50XG4gICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gdGhpcy5hbmFseXNpc0VuZ2luZS5hbmFseXplQ29udGVudChjb250ZW50LCBtZWRpYVR5cGUsIGVuYWJsZWRGcmFtZXdvcmtzKTtcbiAgICAgICAgICAgICAgICAvLyBEaXNwbGF5IHJlc3VsdHNcbiAgICAgICAgICAgICAgICB0aGlzLmRpc3BsYXlBbmFseXNpc1Jlc3VsdHMocmVzdWx0LCBmaWxlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFuYWx5emluZyBjb250ZW50OicsIGVycm9yKTtcbiAgICAgICAgICAgICAgICBuZXcgTm90aWNlKCdFcnJvciBhbmFseXppbmcgY29udGVudC4gQ2hlY2sgY29uc29sZSBmb3IgZGV0YWlscy4nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuICAgIC8vIERpc3BsYXkgYW5hbHlzaXMgcmVzdWx0c1xuICAgIGRpc3BsYXlBbmFseXNpc1Jlc3VsdHMocmVzdWx0LCBmaWxlKSB7XG4gICAgICAgIC8vIENyZWF0ZSBhIG1hcmtkb3duIHN0cmluZyB3aXRoIHRoZSBhbmFseXNpcyByZXN1bHRzXG4gICAgICAgIGxldCBtYXJrZG93biA9IGAjIERlbGVvbWV0ZXIgQW5hbHlzaXNcXG5cXG5gO1xuICAgICAgICAvLyBBZGQgZmlsZSBuYW1lIGlmIGF2YWlsYWJsZVxuICAgICAgICBpZiAocmVzdWx0LmZpbGVOYW1lKSB7XG4gICAgICAgICAgICBtYXJrZG93biArPSBgKipGaWxlOioqICR7cmVzdWx0LmZpbGVOYW1lfVxcblxcbmA7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoZmlsZSkge1xuICAgICAgICAgICAgbWFya2Rvd24gKz0gYCoqRmlsZToqKiAke2ZpbGUucGF0aH1cXG5cXG5gO1xuICAgICAgICB9XG4gICAgICAgIC8vIEFkZCBtZWRpYSB0eXBlXG4gICAgICAgIG1hcmtkb3duICs9IGAqKk1lZGlhIFR5cGU6KiogJHtyZXN1bHQubWVkaWFUeXBlfVxcblxcbmA7XG4gICAgICAgIC8vIEFkZCBzdW1tYXJ5XG4gICAgICAgIG1hcmtkb3duICs9IGAjIyBTdW1tYXJ5XFxuXFxuJHtyZXN1bHQuc3VtbWFyeX1cXG5cXG5gO1xuICAgICAgICAvLyBBZGQgZnJhbWV3b3JrIGFuYWx5c2VzXG4gICAgICAgIG1hcmtkb3duICs9IGAjIyBGcmFtZXdvcmsgQW5hbHlzZXNcXG5cXG5gO1xuICAgICAgICBmb3IgKGNvbnN0IFtmcmFtZXdvcmssIGFuYWx5c2lzXSBvZiBPYmplY3QuZW50cmllcyhyZXN1bHQuZnJhbWV3b3JrQW5hbHlzZXMpKSB7XG4gICAgICAgICAgICBjb25zdCBmcmFtZXdvcmtOYW1lID0gdGhpcy5hbmFseXNpc0VuZ2luZS5nZXRGcmFtZXdvcmtOYW1lKGZyYW1ld29yayk7XG4gICAgICAgICAgICBtYXJrZG93biArPSBgIyMjICR7ZnJhbWV3b3JrTmFtZX1cXG5cXG4ke2FuYWx5c2lzfVxcblxcbmA7XG4gICAgICAgIH1cbiAgICAgICAgLy8gQWRkIHJlY29tbWVuZGF0aW9ucyBpZiBhdmFpbGFibGVcbiAgICAgICAgaWYgKHJlc3VsdC5yZWNvbW1lbmRhdGlvbnMgJiYgcmVzdWx0LnJlY29tbWVuZGF0aW9ucy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICBtYXJrZG93biArPSBgIyMgUmVjb21tZW5kYXRpb25zXFxuXFxuYDtcbiAgICAgICAgICAgIGZvciAoY29uc3QgcmVjb21tZW5kYXRpb24gb2YgcmVzdWx0LnJlY29tbWVuZGF0aW9ucykge1xuICAgICAgICAgICAgICAgIG1hcmtkb3duICs9IGAtICR7cmVjb21tZW5kYXRpb259XFxuYDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBDcmVhdGUgYSBuZXcgbGVhZiB0byBkaXNwbGF5IHRoZSByZXN1bHRzXG4gICAgICAgIGNvbnN0IGxlYWYgPSB0aGlzLmFwcC53b3Jrc3BhY2UuZ2V0TGVhZih0cnVlKTtcbiAgICAgICAgLy8gU2V0IHRoZSBsZWFmIHZpZXcgdG8gbWFya2Rvd25cbiAgICAgICAgbGVhZi5zZXRWaWV3U3RhdGUoe1xuICAgICAgICAgICAgdHlwZTogJ21hcmtkb3duJyxcbiAgICAgICAgICAgIHN0YXRlOiB7XG4gICAgICAgICAgICAgICAgbW9kZTogJ3ByZXZpZXcnLFxuICAgICAgICAgICAgICAgIHNvdXJjZTogbWFya2Rvd25cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuICAgIC8vIFNob3cgdGhlIHVuaWZpZWQgYW5hbHlzaXMgbW9kYWxcbiAgICBzaG93VW5pZmllZEFuYWx5c2lzTW9kYWwoKSB7XG4gICAgICAgIGNvbnN0IG1vZGFsID0gbmV3IFVuaWZpZWRBbmFseXNpc01vZGFsKHRoaXMuYXBwLCB0aGlzKTtcbiAgICAgICAgbW9kYWwub3BlbigpO1xuICAgIH1cbn1cbiJdLCJuYW1lcyI6WyJOb3RpY2UiLCJQbHVnaW5TZXR0aW5nVGFiIiwiU2V0dGluZyIsIk1vZGFsIiwiUGx1Z2luIl0sIm1hcHBpbmdzIjoiOzs7O0FBQUE7QUFDTyxNQUFNLFVBQVUsR0FBRztBQUMxQixJQUFJLFNBQVMsRUFBRSxXQUFXO0FBQzFCLElBQUksUUFBUSxFQUFFLFVBQVU7QUFDeEIsSUFBSSxRQUFRLEVBQUUsVUFBVTtBQUN4QixJQUFJLFNBQVMsRUFBRSxXQUFXO0FBQzFCLElBQUksV0FBVyxFQUFFLGFBQWE7QUFDOUIsSUFBSSxPQUFPLEVBQUUsU0FBUztBQUN0QixJQUFJLFVBQVUsRUFBRSxZQUFZO0FBQzVCLElBQUksUUFBUSxFQUFFLFVBQVU7QUFDeEIsSUFBSSxTQUFTLEVBQUUsV0FBVztBQUMxQixJQUFJLGFBQWEsRUFBRSxlQUFlO0FBQ2xDLElBQUksV0FBVyxFQUFFLGFBQWE7QUFDOUIsSUFBSSxRQUFRLEVBQUUsVUFBVTtBQUN4QixJQUFJLFFBQVEsRUFBRSxVQUFVO0FBQ3hCLElBQUksWUFBWSxFQUFFLGNBQWM7QUFDaEMsSUFBSSxRQUFRLEVBQUUsVUFBVTtBQUN4QixJQUFJLFdBQVcsRUFBRSxhQUFhO0FBQzlCLElBQUksT0FBTyxFQUFFLFNBQVM7QUFDdEIsSUFBSSxhQUFhLEVBQUUsZUFBZTtBQUNsQyxJQUFJLEdBQUcsRUFBRSxLQUFLO0FBQ2QsSUFBSSxZQUFZLEVBQUUsY0FBYztBQUNoQyxJQUFJLFFBQVEsRUFBRSxVQUFVO0FBQ3hCLElBQUksVUFBVSxFQUFFLFlBQVk7QUFDNUIsSUFBSSxTQUFTLEVBQUUsV0FBVztBQUMxQixDQUFDLENBQUM7QUFDRjtBQUNPLE1BQU0sV0FBVyxHQUFHO0FBQzNCLElBQUksSUFBSSxFQUFFLE1BQU07QUFDaEIsSUFBSSxLQUFLLEVBQUUsT0FBTztBQUNsQixJQUFJLEtBQUssRUFBRSxPQUFPO0FBQ2xCLElBQUksSUFBSSxFQUFFLE1BQU07QUFDaEIsQ0FBQyxDQUFDO0FBQ0Y7QUFDTyxJQUFJLFlBQVksQ0FBQztBQUN4QixDQUFDLFVBQVUsWUFBWSxFQUFFO0FBQ3pCLElBQUksWUFBWSxDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQztBQUNsQyxJQUFJLFlBQVksQ0FBQyxTQUFTLENBQUMsR0FBRyxTQUFTLENBQUM7QUFDeEMsQ0FBQyxFQUFFLFlBQVksS0FBSyxZQUFZLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUN4QztBQUNPLElBQUksV0FBVyxDQUFDO0FBQ3ZCLENBQUMsVUFBVSxXQUFXLEVBQUU7QUFDeEIsSUFBSSxXQUFXLENBQUMsU0FBUyxDQUFDLEdBQUcsZUFBZSxDQUFDO0FBQzdDLElBQUksV0FBVyxDQUFDLE9BQU8sQ0FBQyxHQUFHLE9BQU8sQ0FBQztBQUNuQyxDQUFDLEVBQUUsV0FBVyxLQUFLLFdBQVcsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3RDO0FBQ08sTUFBTSxnQkFBZ0IsR0FBRztBQUNoQyxJQUFJLGlCQUFpQixFQUFFO0FBQ3ZCLFFBQVEsQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLElBQUk7QUFDcEMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEdBQUcsSUFBSTtBQUNuQyxRQUFRLENBQUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxJQUFJO0FBQ25DLFFBQVEsQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLElBQUk7QUFDcEMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsSUFBSTtBQUN0QyxRQUFRLENBQUMsVUFBVSxDQUFDLE9BQU8sR0FBRyxJQUFJO0FBQ2xDLFFBQVEsQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLElBQUk7QUFDckMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEdBQUcsSUFBSTtBQUNuQyxRQUFRLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxJQUFJO0FBQ3BDLFFBQVEsQ0FBQyxVQUFVLENBQUMsYUFBYSxHQUFHLElBQUk7QUFDeEMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsSUFBSTtBQUN0QyxRQUFRLENBQUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxJQUFJO0FBQ25DLFFBQVEsQ0FBQyxVQUFVLENBQUMsUUFBUSxHQUFHLElBQUk7QUFDbkMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsSUFBSTtBQUN2QyxRQUFRLENBQUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxJQUFJO0FBQ25DLFFBQVEsQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLElBQUk7QUFDdEMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEdBQUcsSUFBSTtBQUNsQyxRQUFRLENBQUMsVUFBVSxDQUFDLGFBQWEsR0FBRyxJQUFJO0FBQ3hDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxHQUFHLElBQUk7QUFDOUIsUUFBUSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEdBQUcsSUFBSTtBQUN2QyxRQUFRLENBQUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxJQUFJO0FBQ25DLFFBQVEsQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLElBQUk7QUFDckMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsSUFBSTtBQUNwQyxLQUFLO0FBQ0wsSUFBSSxhQUFhLEVBQUUsVUFBVTtBQUM3QixJQUFJLHVCQUF1QixFQUFFLElBQUk7QUFDakMsSUFBSSxxQkFBcUIsRUFBRSxJQUFJO0FBQy9CLElBQUksWUFBWSxFQUFFLFlBQVksQ0FBQyxJQUFJO0FBQ25DLElBQUksWUFBWSxFQUFFLEtBQUs7QUFDdkIsSUFBSSxZQUFZLEVBQUUsRUFBRTtBQUNwQixJQUFJLFdBQVcsRUFBRSxXQUFXLENBQUMsT0FBTztBQUNwQyxJQUFJLGdCQUFnQixFQUFFLEVBQUU7QUFDeEIsSUFBSSxnQkFBZ0IsRUFBRSxDQUFDO0FBQ3ZCLElBQUksZUFBZSxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUU7QUFDL0IsQ0FBQzs7QUNqRk0sTUFBTSxpQkFBaUIsQ0FBQztBQUMvQjtBQUNBO0FBQ0E7QUFDQSxJQUFJLGNBQWMsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFO0FBQ3ZDLFFBQVEsUUFBUSxTQUFTO0FBQ3pCLFlBQVksS0FBSyxXQUFXLENBQUMsSUFBSTtBQUNqQyxnQkFBZ0IsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2pELFlBQVksS0FBSyxXQUFXLENBQUMsS0FBSztBQUNsQyxnQkFBZ0IsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2xELFlBQVksS0FBSyxXQUFXLENBQUMsS0FBSztBQUNsQyxnQkFBZ0IsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2xELFlBQVksS0FBSyxXQUFXLENBQUMsSUFBSTtBQUNqQyxnQkFBZ0IsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2pELFlBQVk7QUFDWixnQkFBZ0IsTUFBTSxJQUFJLEtBQUssQ0FBQyxDQUFDLCtDQUErQyxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvRixTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtBQUN0QjtBQUNBLFFBQVEsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNoRCxRQUFRLE1BQU0saUJBQWlCLEdBQUcsSUFBSSxDQUFDLHdCQUF3QixDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3RFLFFBQVEsTUFBTSxrQkFBa0IsR0FBRyxJQUFJLENBQUMseUJBQXlCLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDeEU7QUFDQSxRQUFRLE1BQU0scUJBQXFCLEdBQUcsSUFBSSxDQUFDLDZCQUE2QixDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztBQUN2RjtBQUNBLFFBQVEsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztBQUN0RjtBQUNBLFFBQVEsTUFBTSxxQkFBcUIsR0FBRyxJQUFJLENBQUMsNkJBQTZCLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDL0U7QUFDQSxRQUFRLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDOUM7QUFDQSxRQUFRLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDcEQ7QUFDQSxRQUFRLE1BQU0saUJBQWlCLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUFDLElBQUksRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO0FBQzNGO0FBQ0EsUUFBUSxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLHFCQUFxQixFQUFFLFdBQVcsRUFBRSxxQkFBcUIsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLGlCQUFpQixDQUFDLENBQUM7QUFDNUksUUFBUSxPQUFPO0FBQ2YsWUFBWSxxQkFBcUI7QUFDakMsWUFBWSxXQUFXO0FBQ3ZCLFlBQVkscUJBQXFCO0FBQ2pDLFlBQVksS0FBSztBQUNqQixZQUFZLFFBQVE7QUFDcEIsWUFBWSxpQkFBaUI7QUFDN0IsWUFBWSxPQUFPO0FBQ25CLFNBQVMsQ0FBQztBQUNWLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxJQUFJLFlBQVksQ0FBQyxJQUFJLEVBQUU7QUFDdkI7QUFDQTtBQUNBLFFBQVEsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztBQUNuQyxRQUFRLE1BQU0scUJBQXFCLEdBQUc7QUFDdEMsWUFBWSwwRUFBMEU7QUFDdEYsWUFBWSwrREFBK0Q7QUFDM0UsWUFBWSwrREFBK0Q7QUFDM0UsU0FBUyxDQUFDO0FBQ1YsUUFBUSxNQUFNLFdBQVcsR0FBRztBQUM1QixZQUFZLGdHQUFnRztBQUM1RyxZQUFZLDZFQUE2RTtBQUN6RixZQUFZLGtGQUFrRjtBQUM5RixTQUFTLENBQUM7QUFDVixRQUFRLE1BQU0scUJBQXFCLEdBQUc7QUFDdEMsWUFBWSx5RkFBeUY7QUFDckcsWUFBWSxvRkFBb0Y7QUFDaEcsWUFBWSx1RUFBdUU7QUFDbkYsU0FBUyxDQUFDO0FBQ1YsUUFBUSxNQUFNLEtBQUssR0FBRztBQUN0QixZQUFZLEtBQUssRUFBRTtBQUNuQixnQkFBZ0IsOERBQThEO0FBQzlFLGdCQUFnQixnREFBZ0Q7QUFDaEUsYUFBYTtBQUNiLFlBQVksU0FBUyxFQUFFO0FBQ3ZCLGdCQUFnQiwrQ0FBK0M7QUFDL0QsZ0JBQWdCLHFEQUFxRDtBQUNyRSxhQUFhO0FBQ2IsWUFBWSxNQUFNLEVBQUU7QUFDcEIsZ0JBQWdCLHNEQUFzRDtBQUN0RSxnQkFBZ0IsMERBQTBEO0FBQzFFLGFBQWE7QUFDYixTQUFTLENBQUM7QUFDVixRQUFRLE1BQU0sUUFBUSxHQUFHO0FBQ3pCLFlBQVksUUFBUSxFQUFFO0FBQ3RCLGdCQUFnQiwyQ0FBMkM7QUFDM0QsZ0JBQWdCLHNDQUFzQztBQUN0RCxnQkFBZ0IsNkNBQTZDO0FBQzdELGFBQWE7QUFDYixZQUFZLFdBQVcsRUFBRTtBQUN6QixnQkFBZ0IsMkNBQTJDO0FBQzNELGdCQUFnQixvREFBb0Q7QUFDcEUsZ0JBQWdCLDRDQUE0QztBQUM1RCxhQUFhO0FBQ2IsU0FBUyxDQUFDO0FBQ1YsUUFBUSxNQUFNLGlCQUFpQixHQUFHLGlGQUFpRixDQUFDO0FBQ3BILFFBQVEsTUFBTSxPQUFPLEdBQUcsQ0FBQyxZQUFZLEVBQUUsUUFBUSxDQUFDLG1lQUFtZSxDQUFDLENBQUM7QUFDcmhCLFFBQVEsT0FBTztBQUNmLFlBQVkscUJBQXFCO0FBQ2pDLFlBQVksV0FBVztBQUN2QixZQUFZLHFCQUFxQjtBQUNqQyxZQUFZLEtBQUs7QUFDakIsWUFBWSxRQUFRO0FBQ3BCLFlBQVksaUJBQWlCO0FBQzdCLFlBQVksT0FBTztBQUNuQixTQUFTLENBQUM7QUFDVixLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsSUFBSSxZQUFZLENBQUMsSUFBSSxFQUFFO0FBQ3ZCO0FBQ0E7QUFDQSxRQUFRLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7QUFDbkMsUUFBUSxNQUFNLHFCQUFxQixHQUFHO0FBQ3RDLFlBQVksMkRBQTJEO0FBQ3ZFLFlBQVksMEVBQTBFO0FBQ3RGLFlBQVksK0NBQStDO0FBQzNELFNBQVMsQ0FBQztBQUNWLFFBQVEsTUFBTSxXQUFXLEdBQUc7QUFDNUIsWUFBWSxnRkFBZ0Y7QUFDNUYsWUFBWSxvRkFBb0Y7QUFDaEcsWUFBWSx1RUFBdUU7QUFDbkYsU0FBUyxDQUFDO0FBQ1YsUUFBUSxNQUFNLHFCQUFxQixHQUFHO0FBQ3RDLFlBQVksNEVBQTRFO0FBQ3hGLFlBQVksc0VBQXNFO0FBQ2xGLFlBQVksd0ZBQXdGO0FBQ3BHLFNBQVMsQ0FBQztBQUNWLFFBQVEsTUFBTSxLQUFLLEdBQUc7QUFDdEIsWUFBWSxLQUFLLEVBQUU7QUFDbkIsZ0JBQWdCLHdEQUF3RDtBQUN4RSxnQkFBZ0IsbURBQW1EO0FBQ25FLGFBQWE7QUFDYixZQUFZLFNBQVMsRUFBRTtBQUN2QixnQkFBZ0IsK0NBQStDO0FBQy9ELGdCQUFnQix3Q0FBd0M7QUFDeEQsYUFBYTtBQUNiLFlBQVksTUFBTSxFQUFFO0FBQ3BCLGdCQUFnQiw0REFBNEQ7QUFDNUUsZ0JBQWdCLHlFQUF5RTtBQUN6RixhQUFhO0FBQ2IsU0FBUyxDQUFDO0FBQ1YsUUFBUSxNQUFNLFFBQVEsR0FBRztBQUN6QixZQUFZLFFBQVEsRUFBRTtBQUN0QixnQkFBZ0IsOERBQThEO0FBQzlFLGdCQUFnQix5Q0FBeUM7QUFDekQsZ0JBQWdCLGtEQUFrRDtBQUNsRSxhQUFhO0FBQ2IsWUFBWSxXQUFXLEVBQUU7QUFDekIsZ0JBQWdCLG1EQUFtRDtBQUNuRSxnQkFBZ0IsK0RBQStEO0FBQy9FLGdCQUFnQix3Q0FBd0M7QUFDeEQsYUFBYTtBQUNiLFNBQVMsQ0FBQztBQUNWLFFBQVEsTUFBTSxpQkFBaUIsR0FBRyw0RkFBNEYsQ0FBQztBQUMvSCxRQUFRLE1BQU0sT0FBTyxHQUFHLENBQUMsa0JBQWtCLEVBQUUsUUFBUSxDQUFDLGlnQkFBaWdCLENBQUMsQ0FBQztBQUN6akIsUUFBUSxPQUFPO0FBQ2YsWUFBWSxxQkFBcUI7QUFDakMsWUFBWSxXQUFXO0FBQ3ZCLFlBQVkscUJBQXFCO0FBQ2pDLFlBQVksS0FBSztBQUNqQixZQUFZLFFBQVE7QUFDcEIsWUFBWSxpQkFBaUI7QUFDN0IsWUFBWSxPQUFPO0FBQ25CLFNBQVMsQ0FBQztBQUNWLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7QUFDdEI7QUFDQTtBQUNBLFFBQVEsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztBQUNuQyxRQUFRLE1BQU0scUJBQXFCLEdBQUc7QUFDdEMsWUFBWSw4RUFBOEU7QUFDMUYsWUFBWSwyRUFBMkU7QUFDdkYsWUFBWSxrRUFBa0U7QUFDOUUsU0FBUyxDQUFDO0FBQ1YsUUFBUSxNQUFNLFdBQVcsR0FBRztBQUM1QixZQUFZLHdGQUF3RjtBQUNwRyxZQUFZLDJFQUEyRTtBQUN2RixZQUFZLHlFQUF5RTtBQUNyRixTQUFTLENBQUM7QUFDVixRQUFRLE1BQU0scUJBQXFCLEdBQUc7QUFDdEMsWUFBWSwwREFBMEQ7QUFDdEUsWUFBWSxvRUFBb0U7QUFDaEYsWUFBWSxnRkFBZ0Y7QUFDNUYsU0FBUyxDQUFDO0FBQ1YsUUFBUSxNQUFNLEtBQUssR0FBRztBQUN0QixZQUFZLEtBQUssRUFBRTtBQUNuQixnQkFBZ0IsdUVBQXVFO0FBQ3ZGLGdCQUFnQiwrQ0FBK0M7QUFDL0QsYUFBYTtBQUNiLFlBQVksU0FBUyxFQUFFO0FBQ3ZCLGdCQUFnQixpRUFBaUU7QUFDakYsZ0JBQWdCLDhDQUE4QztBQUM5RCxhQUFhO0FBQ2IsWUFBWSxNQUFNLEVBQUU7QUFDcEIsZ0JBQWdCLHlEQUF5RDtBQUN6RSxnQkFBZ0IscUVBQXFFO0FBQ3JGLGFBQWE7QUFDYixTQUFTLENBQUM7QUFDVixRQUFRLE1BQU0sUUFBUSxHQUFHO0FBQ3pCLFlBQVksUUFBUSxFQUFFO0FBQ3RCLGdCQUFnQiwyREFBMkQ7QUFDM0UsZ0JBQWdCLHNEQUFzRDtBQUN0RSxnQkFBZ0IsK0NBQStDO0FBQy9ELGFBQWE7QUFDYixZQUFZLFdBQVcsRUFBRTtBQUN6QixnQkFBZ0IsK0NBQStDO0FBQy9ELGdCQUFnQixnRUFBZ0U7QUFDaEYsZ0JBQWdCLDJEQUEyRDtBQUMzRSxhQUFhO0FBQ2IsU0FBUyxDQUFDO0FBQ1YsUUFBUSxNQUFNLGlCQUFpQixHQUFHLDJGQUEyRixDQUFDO0FBQzlILFFBQVEsTUFBTSxPQUFPLEdBQUcsQ0FBQyxXQUFXLEVBQUUsUUFBUSxDQUFDLDZnQkFBNmdCLENBQUMsQ0FBQztBQUM5akIsUUFBUSxPQUFPO0FBQ2YsWUFBWSxxQkFBcUI7QUFDakMsWUFBWSxXQUFXO0FBQ3ZCLFlBQVkscUJBQXFCO0FBQ2pDLFlBQVksS0FBSztBQUNqQixZQUFZLFFBQVE7QUFDcEIsWUFBWSxpQkFBaUI7QUFDN0IsWUFBWSxPQUFPO0FBQ25CLFNBQVMsQ0FBQztBQUNWLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxJQUFJLGFBQWEsQ0FBQyxJQUFJLEVBQUU7QUFDeEI7QUFDQTtBQUNBLFFBQVEsTUFBTSxhQUFhLEdBQUc7QUFDOUIsWUFBWSxNQUFNLEVBQUUsb0NBQW9DO0FBQ3hELFlBQVksUUFBUSxFQUFFLCtDQUErQztBQUNyRSxZQUFZLFlBQVksRUFBRSx1REFBdUQ7QUFDakYsWUFBWSxTQUFTLEVBQUUsOENBQThDO0FBQ3JFLFlBQVksSUFBSSxFQUFFLCtDQUErQztBQUNqRSxZQUFZLFVBQVUsRUFBRSw0Q0FBNEM7QUFDcEUsWUFBWSxVQUFVLEVBQUUscURBQXFEO0FBQzdFLFlBQVksU0FBUyxFQUFFLDBDQUEwQztBQUNqRSxZQUFZLE9BQU8sRUFBRSxxREFBcUQ7QUFDMUUsWUFBWSxPQUFPLEVBQUUsNkNBQTZDO0FBQ2xFLFNBQVMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxNQUFNLGFBQWEsR0FBRyxFQUFFLENBQUM7QUFDakMsUUFBUSxLQUFLLE1BQU0sQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsRUFBRTtBQUN0RSxZQUFZLElBQUksT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUNwQyxnQkFBZ0IsYUFBYSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUMxQyxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0EsUUFBUSxPQUFPLGFBQWEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLGFBQWEsR0FBRyxDQUFDLFFBQVEsRUFBRSxVQUFVLEVBQUUsY0FBYyxDQUFDLENBQUM7QUFDakcsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLElBQUksd0JBQXdCLENBQUMsSUFBSSxFQUFFO0FBQ25DO0FBQ0E7QUFDQSxRQUFRLE1BQU0sUUFBUSxHQUFHLEVBQUUsQ0FBQztBQUM1QixRQUFRLElBQUksMENBQTBDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ25FLFlBQVksUUFBUSxDQUFDLElBQUksQ0FBQywyREFBMkQsQ0FBQyxDQUFDO0FBQ3ZGLFNBQVM7QUFDVCxRQUFRLElBQUksNkNBQTZDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ3RFLFlBQVksUUFBUSxDQUFDLElBQUksQ0FBQyxxREFBcUQsQ0FBQyxDQUFDO0FBQ2pGLFNBQVM7QUFDVCxRQUFRLElBQUksMkNBQTJDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ3BFLFlBQVksUUFBUSxDQUFDLElBQUksQ0FBQyxzREFBc0QsQ0FBQyxDQUFDO0FBQ2xGLFNBQVM7QUFDVCxRQUFRLElBQUksdUNBQXVDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ2hFLFlBQVksUUFBUSxDQUFDLElBQUksQ0FBQyxxREFBcUQsQ0FBQyxDQUFDO0FBQ2pGLFNBQVM7QUFDVCxRQUFRLElBQUksMENBQTBDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ25FLFlBQVksUUFBUSxDQUFDLElBQUksQ0FBQyw0Q0FBNEMsQ0FBQyxDQUFDO0FBQ3hFLFNBQVM7QUFDVCxRQUFRLElBQUksNkNBQTZDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ3RFLFlBQVksUUFBUSxDQUFDLElBQUksQ0FBQyx3REFBd0QsQ0FBQyxDQUFDO0FBQ3BGLFNBQVM7QUFDVDtBQUNBLFFBQVEsT0FBTyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsR0FBRyxRQUFRLEdBQUcsQ0FBQyxrREFBa0QsQ0FBQyxDQUFDO0FBQ3JHLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxJQUFJLHlCQUF5QixDQUFDLElBQUksRUFBRTtBQUNwQztBQUNBLFFBQVEsSUFBSSx3Q0FBd0MsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDakUsWUFBWSxPQUFPLCtDQUErQyxDQUFDO0FBQ25FLFNBQVM7QUFDVCxRQUFRLElBQUksb0NBQW9DLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQzdELFlBQVksT0FBTywwREFBMEQsQ0FBQztBQUM5RSxTQUFTO0FBQ1QsUUFBUSxJQUFJLGlDQUFpQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUMxRCxZQUFZLE9BQU8sc0RBQXNELENBQUM7QUFDMUUsU0FBUztBQUNULFFBQVEsSUFBSSxzQ0FBc0MsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDL0QsWUFBWSxPQUFPLGlEQUFpRCxDQUFDO0FBQ3JFLFNBQVM7QUFDVCxRQUFRLElBQUkscUNBQXFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQzlELFlBQVksT0FBTywyREFBMkQsQ0FBQztBQUMvRSxTQUFTO0FBQ1Q7QUFDQSxRQUFRLE9BQU8sc0RBQXNELENBQUM7QUFDdEUsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLElBQUksNkJBQTZCLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRTtBQUNoRCxRQUFRLE1BQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQztBQUMvQjtBQUNBLFFBQVEsSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFO0FBQ3ZDLFlBQVksV0FBVyxDQUFDLElBQUksQ0FBQyw2RUFBNkUsQ0FBQyxDQUFDO0FBQzVHLFNBQVM7QUFDVCxRQUFRLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsRUFBRTtBQUN6QyxZQUFZLFdBQVcsQ0FBQyxJQUFJLENBQUMsNEVBQTRFLENBQUMsQ0FBQztBQUMzRyxTQUFTO0FBQ1QsUUFBUSxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLEVBQUU7QUFDN0MsWUFBWSxXQUFXLENBQUMsSUFBSSxDQUFDLG9GQUFvRixDQUFDLENBQUM7QUFDbkgsU0FBUztBQUNULFFBQVEsSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxFQUFFO0FBQ3JDLFlBQVksV0FBVyxDQUFDLElBQUksQ0FBQyw2RUFBNkUsQ0FBQyxDQUFDO0FBQzVHLFNBQVM7QUFDVCxRQUFRLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsRUFBRTtBQUMzQyxZQUFZLFdBQVcsQ0FBQyxJQUFJLENBQUMscUVBQXFFLENBQUMsQ0FBQztBQUNwRyxTQUFTO0FBQ1QsUUFBUSxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLEVBQUU7QUFDeEMsWUFBWSxXQUFXLENBQUMsSUFBSSxDQUFDLDZFQUE2RSxDQUFDLENBQUM7QUFDNUcsU0FBUztBQUNUO0FBQ0EsUUFBUSxXQUFXLENBQUMsSUFBSSxDQUFDLG1FQUFtRSxDQUFDLENBQUM7QUFDOUYsUUFBUSxXQUFXLENBQUMsSUFBSSxDQUFDLDhFQUE4RSxDQUFDLENBQUM7QUFDekcsUUFBUSxPQUFPLFdBQVcsQ0FBQztBQUMzQixLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsSUFBSSxtQkFBbUIsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLGlCQUFpQixFQUFFO0FBQ3pELFFBQVEsTUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDO0FBQy9CO0FBQ0EsUUFBUSxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLEVBQUU7QUFDM0MsWUFBWSxXQUFXLENBQUMsSUFBSSxDQUFDLGtFQUFrRSxDQUFDLENBQUM7QUFDakcsU0FBUztBQUNULFFBQVEsSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxFQUFFO0FBQ3hDLFlBQVksV0FBVyxDQUFDLElBQUksQ0FBQyw0REFBNEQsQ0FBQyxDQUFDO0FBQzNGLFNBQVM7QUFDVCxRQUFRLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsRUFBRTtBQUMxQyxZQUFZLFdBQVcsQ0FBQyxJQUFJLENBQUMsc0VBQXNFLENBQUMsQ0FBQztBQUNyRyxTQUFTO0FBQ1Q7QUFDQSxRQUFRLElBQUksaUJBQWlCLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxPQUFPLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUU7QUFDM0UsWUFBWSxXQUFXLENBQUMsSUFBSSxDQUFDLGdFQUFnRSxDQUFDLENBQUM7QUFDL0YsU0FBUztBQUNULFFBQVEsSUFBSSxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsT0FBTyxJQUFJLE9BQU8sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsRUFBRTtBQUM3RSxZQUFZLFdBQVcsQ0FBQyxJQUFJLENBQUMsMkRBQTJELENBQUMsQ0FBQztBQUMxRixTQUFTO0FBQ1Q7QUFDQSxRQUFRLFdBQVcsQ0FBQyxJQUFJLENBQUMsc0VBQXNFLENBQUMsQ0FBQztBQUNqRyxRQUFRLFdBQVcsQ0FBQyxJQUFJLENBQUMsMkVBQTJFLENBQUMsQ0FBQztBQUN0RyxRQUFRLE9BQU8sV0FBVyxDQUFDO0FBQzNCLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxJQUFJLDZCQUE2QixDQUFDLElBQUksRUFBRTtBQUN4QyxRQUFRLE1BQU0scUJBQXFCLEdBQUcsRUFBRSxDQUFDO0FBQ3pDO0FBQ0EsUUFBUSxJQUFJLHNDQUFzQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUMvRCxZQUFZLHFCQUFxQixDQUFDLElBQUksQ0FBQyw0REFBNEQsQ0FBQyxDQUFDO0FBQ3JHLFNBQVM7QUFDVCxRQUFRLElBQUksOENBQThDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ3ZFLFlBQVkscUJBQXFCLENBQUMsSUFBSSxDQUFDLDJEQUEyRCxDQUFDLENBQUM7QUFDcEcsU0FBUztBQUNULFFBQVEsSUFBSSxnQ0FBZ0MsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDekQsWUFBWSxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsdUVBQXVFLENBQUMsQ0FBQztBQUNoSCxTQUFTO0FBQ1QsUUFBUSxJQUFJLDJDQUEyQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUNwRSxZQUFZLHFCQUFxQixDQUFDLElBQUksQ0FBQywwREFBMEQsQ0FBQyxDQUFDO0FBQ25HLFNBQVM7QUFDVCxRQUFRLElBQUkseUNBQXlDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ2xFLFlBQVkscUJBQXFCLENBQUMsSUFBSSxDQUFDLG1FQUFtRSxDQUFDLENBQUM7QUFDNUcsU0FBUztBQUNUO0FBQ0EsUUFBUSxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsc0ZBQXNGLENBQUMsQ0FBQztBQUMzSCxRQUFRLHFCQUFxQixDQUFDLElBQUksQ0FBQyxpRUFBaUUsQ0FBQyxDQUFDO0FBQ3RHLFFBQVEsT0FBTyxxQkFBcUIsQ0FBQztBQUNyQyxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsSUFBSSxZQUFZLENBQUMsSUFBSSxFQUFFO0FBQ3ZCLFFBQVEsTUFBTSxLQUFLLEdBQUcsRUFBRSxDQUFDO0FBQ3pCLFFBQVEsTUFBTSxTQUFTLEdBQUcsRUFBRSxDQUFDO0FBQzdCLFFBQVEsTUFBTSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQzFCO0FBQ0EsUUFBUSxJQUFJLHFEQUFxRCxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUM5RSxZQUFZLEtBQUssQ0FBQyxJQUFJLENBQUMscUVBQXFFLENBQUMsQ0FBQztBQUM5RixTQUFTO0FBQ1QsUUFBUSxJQUFJLDhDQUE4QyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUN2RSxZQUFZLEtBQUssQ0FBQyxJQUFJLENBQUMsdUVBQXVFLENBQUMsQ0FBQztBQUNoRyxTQUFTO0FBQ1QsUUFBUSxJQUFJLHNDQUFzQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUMvRCxZQUFZLEtBQUssQ0FBQyxJQUFJLENBQUMsMkRBQTJELENBQUMsQ0FBQztBQUNwRixTQUFTO0FBQ1Q7QUFDQSxRQUFRLElBQUksbUNBQW1DLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQzVELFlBQVksU0FBUyxDQUFDLElBQUksQ0FBQyxpRUFBaUUsQ0FBQyxDQUFDO0FBQzlGLFNBQVM7QUFDVCxRQUFRLElBQUksOEJBQThCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ3ZELFlBQVksU0FBUyxDQUFDLElBQUksQ0FBQyw4REFBOEQsQ0FBQyxDQUFDO0FBQzNGLFNBQVM7QUFDVCxRQUFRLElBQUkseUNBQXlDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ2xFLFlBQVksU0FBUyxDQUFDLElBQUksQ0FBQywyRUFBMkUsQ0FBQyxDQUFDO0FBQ3hHLFNBQVM7QUFDVDtBQUNBLFFBQVEsSUFBSSxtQ0FBbUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDNUQsWUFBWSxNQUFNLENBQUMsSUFBSSxDQUFDLGtFQUFrRSxDQUFDLENBQUM7QUFDNUYsU0FBUztBQUNULFFBQVEsSUFBSSxtQ0FBbUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDNUQsWUFBWSxNQUFNLENBQUMsSUFBSSxDQUFDLHlFQUF5RSxDQUFDLENBQUM7QUFDbkcsU0FBUztBQUNULFFBQVEsSUFBSSwwQ0FBMEMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDbkUsWUFBWSxNQUFNLENBQUMsSUFBSSxDQUFDLHdFQUF3RSxDQUFDLENBQUM7QUFDbEcsU0FBUztBQUNUO0FBQ0EsUUFBUSxLQUFLLENBQUMsSUFBSSxDQUFDLGdFQUFnRSxDQUFDLENBQUM7QUFDckYsUUFBUSxTQUFTLENBQUMsSUFBSSxDQUFDLDBEQUEwRCxDQUFDLENBQUM7QUFDbkYsUUFBUSxNQUFNLENBQUMsSUFBSSxDQUFDLG9EQUFvRCxDQUFDLENBQUM7QUFDMUUsUUFBUSxPQUFPLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsQ0FBQztBQUM1QyxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsSUFBSSxlQUFlLENBQUMsSUFBSSxFQUFFO0FBQzFCLFFBQVEsTUFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDO0FBQzVCLFFBQVEsTUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDO0FBQy9CO0FBQ0EsUUFBUSxJQUFJLGtDQUFrQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUMzRCxZQUFZLFFBQVEsQ0FBQyxJQUFJLENBQUMsa0VBQWtFLENBQUMsQ0FBQztBQUM5RixTQUFTO0FBQ1QsUUFBUSxJQUFJLHNDQUFzQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUMvRCxZQUFZLFFBQVEsQ0FBQyxJQUFJLENBQUMsOEVBQThFLENBQUMsQ0FBQztBQUMxRyxTQUFTO0FBQ1QsUUFBUSxJQUFJLHdDQUF3QyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUNqRSxZQUFZLFFBQVEsQ0FBQyxJQUFJLENBQUMsaUVBQWlFLENBQUMsQ0FBQztBQUM3RixTQUFTO0FBQ1Q7QUFDQSxRQUFRLElBQUksb0NBQW9DLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQzdELFlBQVksV0FBVyxDQUFDLElBQUksQ0FBQyx3RUFBd0UsQ0FBQyxDQUFDO0FBQ3ZHLFNBQVM7QUFDVCxRQUFRLElBQUksd0NBQXdDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ2pFLFlBQVksV0FBVyxDQUFDLElBQUksQ0FBQyxvRUFBb0UsQ0FBQyxDQUFDO0FBQ25HLFNBQVM7QUFDVCxRQUFRLElBQUksd0NBQXdDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ2pFLFlBQVksV0FBVyxDQUFDLElBQUksQ0FBQyxvREFBb0QsQ0FBQyxDQUFDO0FBQ25GLFNBQVM7QUFDVDtBQUNBLFFBQVEsUUFBUSxDQUFDLElBQUksQ0FBQyxxREFBcUQsQ0FBQyxDQUFDO0FBQzdFLFFBQVEsUUFBUSxDQUFDLElBQUksQ0FBQyx5REFBeUQsQ0FBQyxDQUFDO0FBQ2pGLFFBQVEsV0FBVyxDQUFDLElBQUksQ0FBQyxxREFBcUQsQ0FBQyxDQUFDO0FBQ2hGLFFBQVEsV0FBVyxDQUFDLElBQUksQ0FBQyxvRUFBb0UsQ0FBQyxDQUFDO0FBQy9GLFFBQVEsT0FBTyxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsQ0FBQztBQUN6QyxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsSUFBSSx5QkFBeUIsQ0FBQyxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7QUFDeEQ7QUFDQSxRQUFRLElBQUksa0JBQWtCLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxFQUFFO0FBQ3hELFlBQVksT0FBTyx3S0FBd0ssQ0FBQztBQUM1TCxTQUFTO0FBQ1QsUUFBUSxJQUFJLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsRUFBRTtBQUN2RCxZQUFZLE9BQU8sbUxBQW1MLENBQUM7QUFDdk0sU0FBUztBQUNULFFBQVEsSUFBSSxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEVBQUU7QUFDckQsWUFBWSxPQUFPLHNKQUFzSixDQUFDO0FBQzFLLFNBQVM7QUFDVCxRQUFRLElBQUksa0JBQWtCLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxFQUFFO0FBQ3ZELFlBQVksT0FBTyxnTEFBZ0wsQ0FBQztBQUNwTSxTQUFTO0FBQ1QsUUFBUSxJQUFJLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsRUFBRTtBQUN2RCxZQUFZLE9BQU8sd0pBQXdKLENBQUM7QUFDNUssU0FBUztBQUNUO0FBQ0EsUUFBUSxPQUFPLDZLQUE2SyxDQUFDO0FBQzdMLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxJQUFJLGVBQWUsQ0FBQyxxQkFBcUIsRUFBRSxXQUFXLEVBQUUscUJBQXFCLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxpQkFBaUIsRUFBRTtBQUNuSCxRQUFRLE9BQU8sQ0FBQyxrb0JBQWtvQixFQUFFLGlCQUFpQixDQUFDLDhJQUE4SSxDQUFDLENBQUM7QUFDdHpCLEtBQUs7QUFDTDs7QUNoZk8sTUFBTSxtQkFBbUIsQ0FBQztBQUNqQztBQUNBO0FBQ0E7QUFDQSxJQUFJLGNBQWMsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFO0FBQ3ZDLFFBQVEsUUFBUSxTQUFTO0FBQ3pCLFlBQVksS0FBSyxXQUFXLENBQUMsSUFBSTtBQUNqQyxnQkFBZ0IsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2pELFlBQVksS0FBSyxXQUFXLENBQUMsS0FBSztBQUNsQyxnQkFBZ0IsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2xELFlBQVksS0FBSyxXQUFXLENBQUMsS0FBSztBQUNsQyxnQkFBZ0IsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2xELFlBQVksS0FBSyxXQUFXLENBQUMsSUFBSTtBQUNqQyxnQkFBZ0IsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2pELFlBQVk7QUFDWixnQkFBZ0IsTUFBTSxJQUFJLEtBQUssQ0FBQyxDQUFDLGlEQUFpRCxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRyxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtBQUN0QjtBQUNBLFFBQVEsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNoRCxRQUFRLE1BQU0sa0JBQWtCLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3hFLFFBQVEsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzlEO0FBQ0EsUUFBUSxNQUFNLGdCQUFnQixHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7QUFDNUU7QUFDQSxRQUFRLE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLElBQUksRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO0FBQ3hGO0FBQ0EsUUFBUSxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2xEO0FBQ0EsUUFBUSxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxFQUFFLGtCQUFrQixDQUFDLENBQUM7QUFDNUU7QUFDQSxRQUFRLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLEVBQUUsYUFBYSxDQUFDLENBQUM7QUFDL0U7QUFDQSxRQUFRLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNoRTtBQUNBLFFBQVEsTUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLElBQUksRUFBRSxhQUFhLENBQUMsQ0FBQztBQUNqRjtBQUNBLFFBQVEsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsRUFBRSxnQkFBZ0IsRUFBRSxPQUFPLEVBQUUsVUFBVSxFQUFFLGNBQWMsRUFBRSxjQUFjLEVBQUUsZUFBZSxDQUFDLENBQUM7QUFDdkosUUFBUSxPQUFPO0FBQ2YsWUFBWSxnQkFBZ0I7QUFDNUIsWUFBWSxnQkFBZ0I7QUFDNUIsWUFBWSxPQUFPO0FBQ25CLFlBQVksVUFBVTtBQUN0QixZQUFZLGNBQWM7QUFDMUIsWUFBWSxjQUFjO0FBQzFCLFlBQVksZUFBZTtBQUMzQixZQUFZLE9BQU87QUFDbkIsU0FBUyxDQUFDO0FBQ1YsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLElBQUksWUFBWSxDQUFDLElBQUksRUFBRTtBQUN2QjtBQUNBO0FBQ0EsUUFBUSxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQ25DLFFBQVEsTUFBTSxnQkFBZ0IsR0FBRztBQUNqQyxZQUFZLHNFQUFzRTtBQUNsRixZQUFZLDZEQUE2RDtBQUN6RSxZQUFZLHdGQUF3RjtBQUNwRyxTQUFTLENBQUM7QUFDVixRQUFRLE1BQU0sZ0JBQWdCLEdBQUc7QUFDakMsWUFBWSw0REFBNEQ7QUFDeEUsWUFBWSwrREFBK0Q7QUFDM0UsWUFBWSwyREFBMkQ7QUFDdkUsU0FBUyxDQUFDO0FBQ1YsUUFBUSxNQUFNLE9BQU8sR0FBRztBQUN4QixZQUFZLHFFQUFxRTtBQUNqRixZQUFZLDBFQUEwRTtBQUN0RixZQUFZLGtFQUFrRTtBQUM5RSxTQUFTLENBQUM7QUFDVixRQUFRLE1BQU0sVUFBVSxHQUFHO0FBQzNCLFlBQVksMkRBQTJEO0FBQ3ZFLFlBQVksa0ZBQWtGO0FBQzlGLFlBQVksMERBQTBEO0FBQ3RFLFNBQVMsQ0FBQztBQUNWLFFBQVEsTUFBTSxjQUFjLEdBQUc7QUFDL0IsWUFBWSw4REFBOEQ7QUFDMUUsWUFBWSxvRUFBb0U7QUFDaEYsWUFBWSx3RUFBd0U7QUFDcEYsU0FBUyxDQUFDO0FBQ1YsUUFBUSxNQUFNLGNBQWMsR0FBRztBQUMvQixZQUFZLDZEQUE2RDtBQUN6RSxZQUFZLHNFQUFzRTtBQUNsRixZQUFZLHFEQUFxRDtBQUNqRSxTQUFTLENBQUM7QUFDVixRQUFRLE1BQU0sZUFBZSxHQUFHO0FBQ2hDLFlBQVksNkZBQTZGO0FBQ3pHLFlBQVksNERBQTREO0FBQ3hFLFlBQVksNkRBQTZEO0FBQ3pFLFNBQVMsQ0FBQztBQUNWLFFBQVEsTUFBTSxPQUFPLEdBQUcsQ0FBQyxZQUFZLEVBQUUsUUFBUSxDQUFDLGl1QkFBaXVCLENBQUMsQ0FBQztBQUNueEIsUUFBUSxPQUFPO0FBQ2YsWUFBWSxnQkFBZ0I7QUFDNUIsWUFBWSxnQkFBZ0I7QUFDNUIsWUFBWSxPQUFPO0FBQ25CLFlBQVksVUFBVTtBQUN0QixZQUFZLGNBQWM7QUFDMUIsWUFBWSxjQUFjO0FBQzFCLFlBQVksZUFBZTtBQUMzQixZQUFZLE9BQU87QUFDbkIsU0FBUyxDQUFDO0FBQ1YsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLElBQUksWUFBWSxDQUFDLElBQUksRUFBRTtBQUN2QjtBQUNBO0FBQ0EsUUFBUSxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQ25DLFFBQVEsTUFBTSxnQkFBZ0IsR0FBRztBQUNqQyxZQUFZLHNFQUFzRTtBQUNsRixZQUFZLDREQUE0RDtBQUN4RSxZQUFZLDBGQUEwRjtBQUN0RyxTQUFTLENBQUM7QUFDVixRQUFRLE1BQU0sZ0JBQWdCLEdBQUc7QUFDakMsWUFBWSwyREFBMkQ7QUFDdkUsWUFBWSwrREFBK0Q7QUFDM0UsWUFBWSwrREFBK0Q7QUFDM0UsU0FBUyxDQUFDO0FBQ1YsUUFBUSxNQUFNLE9BQU8sR0FBRztBQUN4QixZQUFZLG9FQUFvRTtBQUNoRixZQUFZLDBFQUEwRTtBQUN0RixZQUFZLG9FQUFvRTtBQUNoRixTQUFTLENBQUM7QUFDVixRQUFRLE1BQU0sVUFBVSxHQUFHO0FBQzNCLFlBQVksMERBQTBEO0FBQ3RFLFlBQVksaUZBQWlGO0FBQzdGLFlBQVksd0RBQXdEO0FBQ3BFLFNBQVMsQ0FBQztBQUNWLFFBQVEsTUFBTSxjQUFjLEdBQUc7QUFDL0IsWUFBWSxnRUFBZ0U7QUFDNUUsWUFBWSxvRUFBb0U7QUFDaEYsWUFBWSwwRUFBMEU7QUFDdEYsU0FBUyxDQUFDO0FBQ1YsUUFBUSxNQUFNLGNBQWMsR0FBRztBQUMvQixZQUFZLDZEQUE2RDtBQUN6RSxZQUFZLHFFQUFxRTtBQUNqRixZQUFZLG1FQUFtRTtBQUMvRSxTQUFTLENBQUM7QUFDVixRQUFRLE1BQU0sZUFBZSxHQUFHO0FBQ2hDLFlBQVksK0ZBQStGO0FBQzNHLFlBQVksMkRBQTJEO0FBQ3ZFLFlBQVksNkRBQTZEO0FBQ3pFLFNBQVMsQ0FBQztBQUNWLFFBQVEsTUFBTSxPQUFPLEdBQUcsQ0FBQyxrQkFBa0IsRUFBRSxRQUFRLENBQUMsNHRCQUE0dEIsQ0FBQyxDQUFDO0FBQ3B4QixRQUFRLE9BQU87QUFDZixZQUFZLGdCQUFnQjtBQUM1QixZQUFZLGdCQUFnQjtBQUM1QixZQUFZLE9BQU87QUFDbkIsWUFBWSxVQUFVO0FBQ3RCLFlBQVksY0FBYztBQUMxQixZQUFZLGNBQWM7QUFDMUIsWUFBWSxlQUFlO0FBQzNCLFlBQVksT0FBTztBQUNuQixTQUFTLENBQUM7QUFDVixLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQ3RCO0FBQ0E7QUFDQSxRQUFRLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7QUFDbkMsUUFBUSxNQUFNLGdCQUFnQixHQUFHO0FBQ2pDLFlBQVksbUZBQW1GO0FBQy9GLFlBQVksZ0VBQWdFO0FBQzVFLFlBQVksd0ZBQXdGO0FBQ3BHLFNBQVMsQ0FBQztBQUNWLFFBQVEsTUFBTSxnQkFBZ0IsR0FBRztBQUNqQyxZQUFZLHdEQUF3RDtBQUNwRSxZQUFZLDJFQUEyRTtBQUN2RixZQUFZLDhEQUE4RDtBQUMxRSxTQUFTLENBQUM7QUFDVixRQUFRLE1BQU0sT0FBTyxHQUFHO0FBQ3hCLFlBQVksdUVBQXVFO0FBQ25GLFlBQVksMEVBQTBFO0FBQ3RGLFlBQVkscUVBQXFFO0FBQ2pGLFNBQVMsQ0FBQztBQUNWLFFBQVEsTUFBTSxVQUFVLEdBQUc7QUFDM0IsWUFBWSw4REFBOEQ7QUFDMUUsWUFBWSxvRkFBb0Y7QUFDaEcsWUFBWSxzRUFBc0U7QUFDbEYsU0FBUyxDQUFDO0FBQ1YsUUFBUSxNQUFNLGNBQWMsR0FBRztBQUMvQixZQUFZLDZEQUE2RDtBQUN6RSxZQUFZLHNFQUFzRTtBQUNsRixZQUFZLHVFQUF1RTtBQUNuRixTQUFTLENBQUM7QUFDVixRQUFRLE1BQU0sY0FBYyxHQUFHO0FBQy9CLFlBQVksNERBQTREO0FBQ3hFLFlBQVkseUVBQXlFO0FBQ3JGLFlBQVkscURBQXFEO0FBQ2pFLFNBQVMsQ0FBQztBQUNWLFFBQVEsTUFBTSxlQUFlLEdBQUc7QUFDaEMsWUFBWSw0RkFBNEY7QUFDeEcsWUFBWSwrREFBK0Q7QUFDM0UsWUFBWSw2REFBNkQ7QUFDekUsU0FBUyxDQUFDO0FBQ1YsUUFBUSxNQUFNLE9BQU8sR0FBRyxDQUFDLFdBQVcsRUFBRSxRQUFRLENBQUMsd3VCQUF3dUIsQ0FBQyxDQUFDO0FBQ3p4QixRQUFRLE9BQU87QUFDZixZQUFZLGdCQUFnQjtBQUM1QixZQUFZLGdCQUFnQjtBQUM1QixZQUFZLE9BQU87QUFDbkIsWUFBWSxVQUFVO0FBQ3RCLFlBQVksY0FBYztBQUMxQixZQUFZLGNBQWM7QUFDMUIsWUFBWSxlQUFlO0FBQzNCLFlBQVksT0FBTztBQUNuQixTQUFTLENBQUM7QUFDVixLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsSUFBSSxhQUFhLENBQUMsSUFBSSxFQUFFO0FBQ3hCO0FBQ0E7QUFDQSxRQUFRLE1BQU0sYUFBYSxHQUFHO0FBQzlCLFlBQVksVUFBVSxFQUFFLDZDQUE2QztBQUNyRSxZQUFZLFFBQVEsRUFBRSxzQ0FBc0M7QUFDNUQsWUFBWSxTQUFTLEVBQUUsZ0NBQWdDO0FBQ3ZELFlBQVksUUFBUSxFQUFFLDJDQUEyQztBQUNqRSxZQUFZLElBQUksRUFBRSxtQ0FBbUM7QUFDckQsWUFBWSxRQUFRLEVBQUUsZ0NBQWdDO0FBQ3RELFlBQVksTUFBTSxFQUFFLDhDQUE4QztBQUNsRSxZQUFZLE1BQU0sRUFBRSxvQ0FBb0M7QUFDeEQsWUFBWSxPQUFPLEVBQUUsaUNBQWlDO0FBQ3RELFlBQVksS0FBSyxFQUFFLHVDQUF1QztBQUMxRCxTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsTUFBTSxhQUFhLEdBQUcsRUFBRSxDQUFDO0FBQ2pDLFFBQVEsS0FBSyxNQUFNLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxJQUFJLE1BQU0sQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLEVBQUU7QUFDdEUsWUFBWSxJQUFJLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDcEMsZ0JBQWdCLGFBQWEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDMUMsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBLFFBQVEsT0FBTyxhQUFhLENBQUMsTUFBTSxHQUFHLENBQUMsR0FBRyxhQUFhLEdBQUcsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ2pHLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxJQUFJLHlCQUF5QixDQUFDLElBQUksRUFBRTtBQUNwQztBQUNBO0FBQ0EsUUFBUSxNQUFNLFFBQVEsR0FBRyxFQUFFLENBQUM7QUFDNUI7QUFDQSxRQUFRLElBQUksaUJBQWlCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQyxFQUFFO0FBQzNGLFlBQVksUUFBUSxDQUFDLElBQUksQ0FBQywyREFBMkQsQ0FBQyxDQUFDO0FBQ3ZGLFNBQVM7QUFDVDtBQUNBLFFBQVEsSUFBSSw0REFBNEQsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDckYsWUFBWSxRQUFRLENBQUMsSUFBSSxDQUFDLHFEQUFxRCxDQUFDLENBQUM7QUFDakYsU0FBUztBQUNUO0FBQ0EsUUFBUSxJQUFJLHFDQUFxQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUM5RCxZQUFZLFFBQVEsQ0FBQyxJQUFJLENBQUMsb0RBQW9ELENBQUMsQ0FBQztBQUNoRixTQUFTO0FBQ1Q7QUFDQSxRQUFRLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUM3QixZQUFZLFFBQVEsQ0FBQyxJQUFJLENBQUMsMkNBQTJDLENBQUMsQ0FBQztBQUN2RSxTQUFTO0FBQ1Q7QUFDQSxRQUFRLElBQUksOEJBQThCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ3ZELFlBQVksUUFBUSxDQUFDLElBQUksQ0FBQyw2REFBNkQsQ0FBQyxDQUFDO0FBQ3pGLFNBQVM7QUFDVDtBQUNBLFFBQVEsT0FBTyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsR0FBRyxRQUFRLEdBQUcsQ0FBQyx1RUFBdUUsQ0FBQyxDQUFDO0FBQzFILEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxJQUFJLG9CQUFvQixDQUFDLElBQUksRUFBRTtBQUMvQjtBQUNBO0FBQ0EsUUFBUSxNQUFNLGFBQWEsR0FBRyxFQUFFLENBQUM7QUFDakM7QUFDQSxRQUFRLElBQUksOENBQThDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ3ZFLFlBQVksYUFBYSxDQUFDLElBQUksQ0FBQyxtREFBbUQsQ0FBQyxDQUFDO0FBQ3BGLFNBQVM7QUFDVDtBQUNBLFFBQVEsSUFBSSw2Q0FBNkMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDdEUsWUFBWSxhQUFhLENBQUMsSUFBSSxDQUFDLGdEQUFnRCxDQUFDLENBQUM7QUFDakYsU0FBUztBQUNUO0FBQ0EsUUFBUSxJQUFJLHFDQUFxQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUM5RCxZQUFZLGFBQWEsQ0FBQyxJQUFJLENBQUMsc0NBQXNDLENBQUMsQ0FBQztBQUN2RSxTQUFTO0FBQ1Q7QUFDQSxRQUFRLElBQUksc0NBQXNDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQy9ELFlBQVksYUFBYSxDQUFDLElBQUksQ0FBQyxpREFBaUQsQ0FBQyxDQUFDO0FBQ2xGLFNBQVM7QUFDVDtBQUNBLFFBQVEsSUFBSSw0Q0FBNEMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDckUsWUFBWSxhQUFhLENBQUMsSUFBSSxDQUFDLCtDQUErQyxDQUFDLENBQUM7QUFDaEYsU0FBUztBQUNUO0FBQ0EsUUFBUSxPQUFPLGFBQWEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLGFBQWEsR0FBRyxDQUFDLDZFQUE2RSxDQUFDLENBQUM7QUFDMUksS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLElBQUksdUJBQXVCLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRTtBQUMxQyxRQUFRLE1BQU0sZ0JBQWdCLEdBQUcsRUFBRSxDQUFDO0FBQ3BDO0FBQ0EsUUFBUSxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLEVBQUU7QUFDM0MsWUFBWSxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsZ0ZBQWdGLENBQUMsQ0FBQztBQUNwSCxTQUFTO0FBQ1QsUUFBUSxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEVBQUU7QUFDekMsWUFBWSxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsc0VBQXNFLENBQUMsQ0FBQztBQUMxRyxTQUFTO0FBQ1QsUUFBUSxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLEVBQUU7QUFDMUMsWUFBWSxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsaUZBQWlGLENBQUMsQ0FBQztBQUNySCxTQUFTO0FBQ1QsUUFBUSxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUU7QUFDckMsWUFBWSxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsMkVBQTJFLENBQUMsQ0FBQztBQUMvRyxTQUFTO0FBQ1Q7QUFDQSxRQUFRLElBQUksNEJBQTRCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ3JELFlBQVksZ0JBQWdCLENBQUMsSUFBSSxDQUFDLHdFQUF3RSxDQUFDLENBQUM7QUFDNUcsU0FBUztBQUNULFFBQVEsSUFBSSxvQ0FBb0MsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDN0QsWUFBWSxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMscUVBQXFFLENBQUMsQ0FBQztBQUN6RyxTQUFTO0FBQ1Q7QUFDQSxRQUFRLGdCQUFnQixDQUFDLElBQUksQ0FBQyx1RUFBdUUsQ0FBQyxDQUFDO0FBQ3ZHLFFBQVEsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLG9GQUFvRixDQUFDLENBQUM7QUFDcEgsUUFBUSxPQUFPLGdCQUFnQixDQUFDO0FBQ2hDLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxJQUFJLHVCQUF1QixDQUFDLElBQUksRUFBRSxrQkFBa0IsRUFBRTtBQUN0RCxRQUFRLE1BQU0sZ0JBQWdCLEdBQUcsRUFBRSxDQUFDO0FBQ3BDO0FBQ0EsUUFBUSxJQUFJLGtCQUFrQixDQUFDLFFBQVEsQ0FBQywyREFBMkQsQ0FBQyxFQUFFO0FBQ3RHLFlBQVksZ0JBQWdCLENBQUMsSUFBSSxDQUFDLDBGQUEwRixDQUFDLENBQUM7QUFDOUgsU0FBUztBQUNULFFBQVEsSUFBSSxrQkFBa0IsQ0FBQyxRQUFRLENBQUMscURBQXFELENBQUMsRUFBRTtBQUNoRyxZQUFZLGdCQUFnQixDQUFDLElBQUksQ0FBQyx1RUFBdUUsQ0FBQyxDQUFDO0FBQzNHLFNBQVM7QUFDVCxRQUFRLElBQUksa0JBQWtCLENBQUMsUUFBUSxDQUFDLG9EQUFvRCxDQUFDLEVBQUU7QUFDL0YsWUFBWSxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsMEVBQTBFLENBQUMsQ0FBQztBQUM5RyxTQUFTO0FBQ1QsUUFBUSxJQUFJLGtCQUFrQixDQUFDLFFBQVEsQ0FBQywyQ0FBMkMsQ0FBQyxFQUFFO0FBQ3RGLFlBQVksZ0JBQWdCLENBQUMsSUFBSSxDQUFDLHlFQUF5RSxDQUFDLENBQUM7QUFDN0csU0FBUztBQUNULFFBQVEsSUFBSSxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsNkRBQTZELENBQUMsRUFBRTtBQUN4RyxZQUFZLGdCQUFnQixDQUFDLElBQUksQ0FBQyx3RUFBd0UsQ0FBQyxDQUFDO0FBQzVHLFNBQVM7QUFDVDtBQUNBLFFBQVEsSUFBSSwrQkFBK0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDeEQsWUFBWSxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMseURBQXlELENBQUMsQ0FBQztBQUM3RixTQUFTO0FBQ1QsUUFBUSxJQUFJLHFDQUFxQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUM5RCxZQUFZLGdCQUFnQixDQUFDLElBQUksQ0FBQyxpRUFBaUUsQ0FBQyxDQUFDO0FBQ3JHLFNBQVM7QUFDVDtBQUNBLFFBQVEsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLDREQUE0RCxDQUFDLENBQUM7QUFDNUYsUUFBUSxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMscUVBQXFFLENBQUMsQ0FBQztBQUNyRyxRQUFRLE9BQU8sZ0JBQWdCLENBQUM7QUFDaEMsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLElBQUksY0FBYyxDQUFDLElBQUksRUFBRTtBQUN6QixRQUFRLE1BQU0sT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUMzQjtBQUNBLFFBQVEsSUFBSSxrQ0FBa0MsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDM0QsWUFBWSxPQUFPLENBQUMsSUFBSSxDQUFDLHVFQUF1RSxDQUFDLENBQUM7QUFDbEcsU0FBUztBQUNULFFBQVEsSUFBSSw2QkFBNkIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDdEQsWUFBWSxPQUFPLENBQUMsSUFBSSxDQUFDLDJEQUEyRCxDQUFDLENBQUM7QUFDdEYsU0FBUztBQUNULFFBQVEsSUFBSSxxQ0FBcUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDOUQsWUFBWSxPQUFPLENBQUMsSUFBSSxDQUFDLHdFQUF3RSxDQUFDLENBQUM7QUFDbkcsU0FBUztBQUNULFFBQVEsSUFBSSxxQ0FBcUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDOUQsWUFBWSxPQUFPLENBQUMsSUFBSSxDQUFDLDREQUE0RCxDQUFDLENBQUM7QUFDdkYsU0FBUztBQUNULFFBQVEsSUFBSSxpQ0FBaUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDMUQsWUFBWSxPQUFPLENBQUMsSUFBSSxDQUFDLGdFQUFnRSxDQUFDLENBQUM7QUFDM0YsU0FBUztBQUNUO0FBQ0EsUUFBUSxPQUFPLENBQUMsSUFBSSxDQUFDLGtGQUFrRixDQUFDLENBQUM7QUFDekcsUUFBUSxPQUFPLENBQUMsSUFBSSxDQUFDLDZFQUE2RSxDQUFDLENBQUM7QUFDcEcsUUFBUSxPQUFPLE9BQU8sQ0FBQztBQUN2QixLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsSUFBSSxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7QUFDaEQsUUFBUSxNQUFNLFVBQVUsR0FBRyxFQUFFLENBQUM7QUFDOUI7QUFDQSxRQUFRLElBQUksa0JBQWtCLENBQUMsUUFBUSxDQUFDLDJEQUEyRCxDQUFDLEVBQUU7QUFDdEcsWUFBWSxVQUFVLENBQUMsSUFBSSxDQUFDLDhEQUE4RCxDQUFDLENBQUM7QUFDNUYsU0FBUztBQUNULFFBQVEsSUFBSSxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsb0RBQW9ELENBQUMsRUFBRTtBQUMvRixZQUFZLFVBQVUsQ0FBQyxJQUFJLENBQUMsOERBQThELENBQUMsQ0FBQztBQUM1RixTQUFTO0FBQ1Q7QUFDQSxRQUFRLElBQUksa0NBQWtDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQzNELFlBQVksVUFBVSxDQUFDLElBQUksQ0FBQyxpREFBaUQsQ0FBQyxDQUFDO0FBQy9FLFNBQVM7QUFDVCxRQUFRLElBQUksc0NBQXNDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQy9ELFlBQVksVUFBVSxDQUFDLElBQUksQ0FBQyxtRUFBbUUsQ0FBQyxDQUFDO0FBQ2pHLFNBQVM7QUFDVCxRQUFRLElBQUksbUNBQW1DLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQzVELFlBQVksVUFBVSxDQUFDLElBQUksQ0FBQywrREFBK0QsQ0FBQyxDQUFDO0FBQzdGLFNBQVM7QUFDVCxRQUFRLElBQUksdUNBQXVDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ2hFLFlBQVksVUFBVSxDQUFDLElBQUksQ0FBQyxnRUFBZ0UsQ0FBQyxDQUFDO0FBQzlGLFNBQVM7QUFDVDtBQUNBLFFBQVEsVUFBVSxDQUFDLElBQUksQ0FBQyw0RUFBNEUsQ0FBQyxDQUFDO0FBQ3RHLFFBQVEsVUFBVSxDQUFDLElBQUksQ0FBQywwRUFBMEUsQ0FBQyxDQUFDO0FBQ3BHLFFBQVEsT0FBTyxVQUFVLENBQUM7QUFDMUIsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLElBQUkscUJBQXFCLENBQUMsSUFBSSxFQUFFLGFBQWEsRUFBRTtBQUMvQyxRQUFRLE1BQU0sY0FBYyxHQUFHLEVBQUUsQ0FBQztBQUNsQztBQUNBLFFBQVEsSUFBSSxhQUFhLENBQUMsUUFBUSxDQUFDLG1EQUFtRCxDQUFDLEVBQUU7QUFDekYsWUFBWSxjQUFjLENBQUMsSUFBSSxDQUFDLHVFQUF1RSxDQUFDLENBQUM7QUFDekcsU0FBUztBQUNULFFBQVEsSUFBSSxhQUFhLENBQUMsUUFBUSxDQUFDLGdEQUFnRCxDQUFDLEVBQUU7QUFDdEYsWUFBWSxjQUFjLENBQUMsSUFBSSxDQUFDLHlFQUF5RSxDQUFDLENBQUM7QUFDM0csU0FBUztBQUNULFFBQVEsSUFBSSxhQUFhLENBQUMsUUFBUSxDQUFDLGlEQUFpRCxDQUFDLEVBQUU7QUFDdkYsWUFBWSxjQUFjLENBQUMsSUFBSSxDQUFDLHFFQUFxRSxDQUFDLENBQUM7QUFDdkcsU0FBUztBQUNUO0FBQ0EsUUFBUSxJQUFJLHVDQUF1QyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUNoRSxZQUFZLGNBQWMsQ0FBQyxJQUFJLENBQUMsb0VBQW9FLENBQUMsQ0FBQztBQUN0RyxTQUFTO0FBQ1QsUUFBUSxJQUFJLDBDQUEwQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUNuRSxZQUFZLGNBQWMsQ0FBQyxJQUFJLENBQUMsb0VBQW9FLENBQUMsQ0FBQztBQUN0RyxTQUFTO0FBQ1QsUUFBUSxJQUFJLHlDQUF5QyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUNsRSxZQUFZLGNBQWMsQ0FBQyxJQUFJLENBQUMsK0RBQStELENBQUMsQ0FBQztBQUNqRyxTQUFTO0FBQ1Q7QUFDQSxRQUFRLGNBQWMsQ0FBQyxJQUFJLENBQUMsaUZBQWlGLENBQUMsQ0FBQztBQUMvRyxRQUFRLGNBQWMsQ0FBQyxJQUFJLENBQUMsNEVBQTRFLENBQUMsQ0FBQztBQUMxRyxRQUFRLE9BQU8sY0FBYyxDQUFDO0FBQzlCLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxJQUFJLHFCQUFxQixDQUFDLElBQUksRUFBRTtBQUNoQyxRQUFRLE1BQU0sY0FBYyxHQUFHLEVBQUUsQ0FBQztBQUNsQztBQUNBLFFBQVEsSUFBSSxzQ0FBc0MsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDL0QsWUFBWSxjQUFjLENBQUMsSUFBSSxDQUFDLDZEQUE2RCxDQUFDLENBQUM7QUFDL0YsU0FBUztBQUNULFFBQVEsSUFBSSw4Q0FBOEMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDdkUsWUFBWSxjQUFjLENBQUMsSUFBSSxDQUFDLG1EQUFtRCxDQUFDLENBQUM7QUFDckYsU0FBUztBQUNULFFBQVEsSUFBSSxxQ0FBcUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDOUQsWUFBWSxjQUFjLENBQUMsSUFBSSxDQUFDLHVEQUF1RCxDQUFDLENBQUM7QUFDekYsU0FBUztBQUNULFFBQVEsSUFBSSxvQ0FBb0MsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDN0QsWUFBWSxjQUFjLENBQUMsSUFBSSxDQUFDLG1EQUFtRCxDQUFDLENBQUM7QUFDckYsU0FBUztBQUNULFFBQVEsSUFBSSxvQ0FBb0MsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDN0QsWUFBWSxjQUFjLENBQUMsSUFBSSxDQUFDLG1EQUFtRCxDQUFDLENBQUM7QUFDckYsU0FBUztBQUNUO0FBQ0EsUUFBUSxjQUFjLENBQUMsSUFBSSxDQUFDLHdFQUF3RSxDQUFDLENBQUM7QUFDdEcsUUFBUSxjQUFjLENBQUMsSUFBSSxDQUFDLDJFQUEyRSxDQUFDLENBQUM7QUFDekcsUUFBUSxPQUFPLGNBQWMsQ0FBQztBQUM5QixLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsSUFBSSxzQkFBc0IsQ0FBQyxJQUFJLEVBQUUsYUFBYSxFQUFFO0FBQ2hELFFBQVEsTUFBTSxlQUFlLEdBQUcsRUFBRSxDQUFDO0FBQ25DO0FBQ0EsUUFBUSxJQUFJLGFBQWEsQ0FBQyxRQUFRLENBQUMsbURBQW1ELENBQUMsRUFBRTtBQUN6RixZQUFZLGVBQWUsQ0FBQyxJQUFJLENBQUMsc0VBQXNFLENBQUMsQ0FBQztBQUN6RyxTQUFTO0FBQ1QsUUFBUSxJQUFJLGFBQWEsQ0FBQyxRQUFRLENBQUMsZ0RBQWdELENBQUMsRUFBRTtBQUN0RixZQUFZLGVBQWUsQ0FBQyxJQUFJLENBQUMsNkRBQTZELENBQUMsQ0FBQztBQUNoRyxTQUFTO0FBQ1QsUUFBUSxJQUFJLGFBQWEsQ0FBQyxRQUFRLENBQUMsc0NBQXNDLENBQUMsRUFBRTtBQUM1RSxZQUFZLGVBQWUsQ0FBQyxJQUFJLENBQUMsMkVBQTJFLENBQUMsQ0FBQztBQUM5RyxTQUFTO0FBQ1QsUUFBUSxJQUFJLGFBQWEsQ0FBQyxRQUFRLENBQUMsK0NBQStDLENBQUMsRUFBRTtBQUNyRixZQUFZLGVBQWUsQ0FBQyxJQUFJLENBQUMsZ0VBQWdFLENBQUMsQ0FBQztBQUNuRyxTQUFTO0FBQ1Q7QUFDQSxRQUFRLElBQUksNkNBQTZDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ3RFLFlBQVksZUFBZSxDQUFDLElBQUksQ0FBQyw0REFBNEQsQ0FBQyxDQUFDO0FBQy9GLFNBQVM7QUFDVCxRQUFRLElBQUksMENBQTBDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ25FLFlBQVksZUFBZSxDQUFDLElBQUksQ0FBQyxxRUFBcUUsQ0FBQyxDQUFDO0FBQ3hHLFNBQVM7QUFDVDtBQUNBLFFBQVEsZUFBZSxDQUFDLElBQUksQ0FBQyw2RUFBNkUsQ0FBQyxDQUFDO0FBQzVHLFFBQVEsZUFBZSxDQUFDLElBQUksQ0FBQyx5REFBeUQsQ0FBQyxDQUFDO0FBQ3hGLFFBQVEsT0FBTyxlQUFlLENBQUM7QUFDL0IsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLElBQUksZUFBZSxDQUFDLGdCQUFnQixFQUFFLGdCQUFnQixFQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsY0FBYyxFQUFFLGNBQWMsRUFBRSxlQUFlLEVBQUU7QUFDOUgsUUFBUSxPQUFPLENBQUMsMDVCQUEwNUIsQ0FBQyxDQUFDO0FBQzU2QixLQUFLO0FBQ0w7O0FDbGdCQTtBQUNPLE1BQU0saUJBQWlCLENBQUM7QUFDL0IsSUFBSSxXQUFXLEdBQUc7QUFDbEI7QUFDQSxRQUFRLElBQUksQ0FBQyxhQUFhLEdBQUc7QUFDN0IsWUFBWSx3QkFBd0I7QUFDcEMsWUFBWSxxQkFBcUI7QUFDakMsWUFBWSxxQkFBcUI7QUFDakMsWUFBWSxvQkFBb0I7QUFDaEMsWUFBWSx1QkFBdUI7QUFDbkMsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLElBQUksQ0FBQyxVQUFVLEdBQUc7QUFDMUIsWUFBWSwrQkFBK0I7QUFDM0MsWUFBWSxnQ0FBZ0M7QUFDNUMsWUFBWSx1QkFBdUI7QUFDbkMsWUFBWSx3QkFBd0I7QUFDcEMsWUFBWSx5QkFBeUI7QUFDckMsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLElBQUksQ0FBQyxRQUFRLEdBQUc7QUFDeEIsWUFBWSxxQkFBcUI7QUFDakMsWUFBWSxvQkFBb0I7QUFDaEMsWUFBWSxtQkFBbUI7QUFDL0IsWUFBWSwyQkFBMkI7QUFDdkMsWUFBWSx3QkFBd0I7QUFDcEMsU0FBUyxDQUFDO0FBQ1YsS0FBSztBQUNMO0FBQ0EsSUFBSSxjQUFjLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRTtBQUN2QztBQUNBLFFBQVEsTUFBTSxxQkFBcUIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNwRixRQUFRLE1BQU0sa0JBQWtCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDOUUsUUFBUSxNQUFNLGdCQUFnQixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzFFO0FBQ0EsUUFBUSxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7QUFDekIsUUFBUSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQzVDLFlBQVksT0FBTyxHQUFHLHdKQUF3SixDQUFDO0FBQy9LLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxLQUFLLEVBQUU7QUFDbEQsWUFBWSxPQUFPLEdBQUcsd0pBQXdKLENBQUM7QUFDL0ssU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLEtBQUssRUFBRTtBQUNsRCxZQUFZLE9BQU8sR0FBRyx3SUFBd0ksQ0FBQztBQUMvSixTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQ2pELFlBQVksT0FBTyxHQUFHLDRJQUE0SSxDQUFDO0FBQ25LLFNBQVM7QUFDVDtBQUNBLFFBQVEsT0FBTztBQUNmLFlBQVksYUFBYSxFQUFFLHFCQUFxQjtBQUNoRCxZQUFZLFVBQVUsRUFBRSxrQkFBa0I7QUFDMUMsWUFBWSxRQUFRLEVBQUUsZ0JBQWdCO0FBQ3RDLFlBQVksT0FBTztBQUNuQixTQUFTLENBQUM7QUFDVixLQUFLO0FBQ0w7QUFDQSxJQUFJLGlCQUFpQixDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUU7QUFDcEMsUUFBUSxNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDMUIsUUFBUSxNQUFNLFNBQVMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUM7QUFDckMsUUFBUSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxJQUFJLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO0FBQ2hFLFlBQVksTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzdFLFlBQVksTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztBQUNoRCxZQUFZLFNBQVMsQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzdDLFNBQVM7QUFDVCxRQUFRLE9BQU8sTUFBTSxDQUFDO0FBQ3RCLEtBQUs7QUFDTDs7QUNuRUE7QUFDTyxNQUFNLGdCQUFnQixDQUFDO0FBQzlCLElBQUksV0FBVyxHQUFHO0FBQ2xCO0FBQ0EsUUFBUSxJQUFJLENBQUMsbUJBQW1CLEdBQUc7QUFDbkMsWUFBWSxtQkFBbUI7QUFDL0IsWUFBWSxnQkFBZ0I7QUFDNUIsWUFBWSwwQkFBMEI7QUFDdEMsWUFBWSx1QkFBdUI7QUFDbkMsWUFBWSxhQUFhO0FBQ3pCLFNBQVMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxJQUFJLENBQUMsa0JBQWtCLEdBQUc7QUFDbEMsWUFBWSxlQUFlO0FBQzNCLFlBQVksZ0JBQWdCO0FBQzVCLFlBQVksbUJBQW1CO0FBQy9CLFlBQVksaUJBQWlCO0FBQzdCLFlBQVksa0JBQWtCO0FBQzlCLFNBQVMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxJQUFJLENBQUMsaUJBQWlCLEdBQUc7QUFDakMsWUFBWSxZQUFZO0FBQ3hCLFlBQVksWUFBWTtBQUN4QixZQUFZLGNBQWM7QUFDMUIsWUFBWSxhQUFhO0FBQ3pCLFlBQVksb0JBQW9CO0FBQ2hDLFNBQVMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxJQUFJLENBQUMsWUFBWSxHQUFHO0FBQzVCLFlBQVksa0JBQWtCO0FBQzlCLFlBQVksZ0JBQWdCO0FBQzVCLFlBQVksY0FBYztBQUMxQixZQUFZLGNBQWM7QUFDMUIsWUFBWSxvQkFBb0I7QUFDaEMsU0FBUyxDQUFDO0FBQ1YsS0FBSztBQUNMO0FBQ0EsSUFBSSxjQUFjLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRTtBQUN2QztBQUNBLFFBQVEsTUFBTSxtQkFBbUIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3hGLFFBQVEsTUFBTSxrQkFBa0IsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3RGLFFBQVEsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3BGLFFBQVEsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDMUU7QUFDQSxRQUFRLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUN6QixRQUFRLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxJQUFJLEVBQUU7QUFDNUMsWUFBWSxPQUFPLEdBQUcsNk5BQTZOLENBQUM7QUFDcFAsU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLEtBQUssRUFBRTtBQUNsRCxZQUFZLE9BQU8sR0FBRyxnTkFBZ04sQ0FBQztBQUN2TyxTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsS0FBSyxFQUFFO0FBQ2xELFlBQVksT0FBTyxHQUFHLCtNQUErTSxDQUFDO0FBQ3RPLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxJQUFJLEVBQUU7QUFDakQsWUFBWSxPQUFPLEdBQUcsbU5BQW1OLENBQUM7QUFDMU8sU0FBUztBQUNUO0FBQ0EsUUFBUSxPQUFPO0FBQ2YsWUFBWSxtQkFBbUI7QUFDL0IsWUFBWSxrQkFBa0I7QUFDOUIsWUFBWSxpQkFBaUI7QUFDN0IsWUFBWSxZQUFZO0FBQ3hCLFlBQVksT0FBTztBQUNuQixTQUFTLENBQUM7QUFDVixLQUFLO0FBQ0w7QUFDQSxJQUFJLGlCQUFpQixDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUU7QUFDcEMsUUFBUSxNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDMUIsUUFBUSxNQUFNLFNBQVMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUM7QUFDckMsUUFBUSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxJQUFJLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO0FBQ2hFLFlBQVksTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzdFLFlBQVksTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztBQUNoRCxZQUFZLFNBQVMsQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzdDLFNBQVM7QUFDVCxRQUFRLE9BQU8sTUFBTSxDQUFDO0FBQ3RCLEtBQUs7QUFDTDs7QUM3RUE7QUFDTyxNQUFNLGdCQUFnQixDQUFDO0FBQzlCLElBQUksV0FBVyxHQUFHO0FBQ2xCO0FBQ0EsUUFBUSxJQUFJLENBQUMsTUFBTSxHQUFHO0FBQ3RCLFlBQVksUUFBUSxFQUFFLENBQUMsbUJBQW1CLEVBQUUsc0JBQXNCLEVBQUUsY0FBYyxFQUFFLG9CQUFvQixFQUFFLHFCQUFxQixDQUFDO0FBQ2hJLFlBQVksU0FBUyxFQUFFLENBQUMsY0FBYyxFQUFFLGVBQWUsRUFBRSwwQkFBMEIsRUFBRSxnQkFBZ0IsRUFBRSx1QkFBdUIsQ0FBQztBQUMvSCxZQUFZLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRSxZQUFZLEVBQUUsc0JBQXNCLEVBQUUsWUFBWSxFQUFFLFNBQVMsQ0FBQztBQUMzRixTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLGdCQUFnQixHQUFHO0FBQ2hDLFlBQVksZUFBZTtBQUMzQixZQUFZLFlBQVk7QUFDeEIsWUFBWSxZQUFZO0FBQ3hCLFlBQVksNEJBQTRCO0FBQ3hDLFlBQVksd0JBQXdCO0FBQ3BDLFNBQVMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxJQUFJLENBQUMsTUFBTSxHQUFHO0FBQ3RCLFlBQVksZ0JBQWdCO0FBQzVCLFlBQVkscUJBQXFCO0FBQ2pDLFlBQVksVUFBVTtBQUN0QixZQUFZLG1CQUFtQjtBQUMvQixZQUFZLHNCQUFzQjtBQUNsQyxTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLFVBQVUsR0FBRztBQUMxQixZQUFZLG9CQUFvQjtBQUNoQyxZQUFZLHFCQUFxQjtBQUNqQyxZQUFZLG9CQUFvQjtBQUNoQyxZQUFZLDBDQUEwQztBQUN0RCxZQUFZLHVCQUF1QjtBQUNuQyxTQUFTLENBQUM7QUFDVixLQUFLO0FBQ0w7QUFDQSxJQUFJLGNBQWMsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFO0FBQ3ZDO0FBQ0EsUUFBUSxNQUFNLGdCQUFnQixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNqRixRQUFRLE1BQU0saUJBQWlCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ25GLFFBQVEsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3pFLFFBQVEsTUFBTSx3QkFBd0IsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzFGLFFBQVEsTUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDdEUsUUFBUSxNQUFNLGtCQUFrQixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzlFO0FBQ0EsUUFBUSxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7QUFDekIsUUFBUSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQzVDLFlBQVksT0FBTyxHQUFHLGlPQUFpTyxDQUFDO0FBQ3hQLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxLQUFLLEVBQUU7QUFDbEQsWUFBWSxPQUFPLEdBQUcsaU9BQWlPLENBQUM7QUFDeFAsU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLEtBQUssRUFBRTtBQUNsRCxZQUFZLE9BQU8sR0FBRyw0TkFBNE4sQ0FBQztBQUNuUCxTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQ2pELFlBQVksT0FBTyxHQUFHLDRPQUE0TyxDQUFDO0FBQ25RLFNBQVM7QUFDVDtBQUNBLFFBQVEsT0FBTztBQUNmLFlBQVksTUFBTSxFQUFFO0FBQ3BCLGdCQUFnQixRQUFRLEVBQUUsZ0JBQWdCO0FBQzFDLGdCQUFnQixTQUFTLEVBQUUsaUJBQWlCO0FBQzVDLGdCQUFnQixJQUFJLEVBQUUsWUFBWTtBQUNsQyxhQUFhO0FBQ2IsWUFBWSxnQkFBZ0IsRUFBRSx3QkFBd0I7QUFDdEQsWUFBWSxNQUFNLEVBQUUsY0FBYztBQUNsQyxZQUFZLFVBQVUsRUFBRSxrQkFBa0I7QUFDMUMsWUFBWSxPQUFPO0FBQ25CLFNBQVMsQ0FBQztBQUNWLEtBQUs7QUFDTDtBQUNBLElBQUksaUJBQWlCLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRTtBQUNwQyxRQUFRLE1BQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUMxQixRQUFRLE1BQU0sU0FBUyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQztBQUNyQyxRQUFRLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLElBQUksU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDaEUsWUFBWSxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDN0UsWUFBWSxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ2hELFlBQVksU0FBUyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDN0MsU0FBUztBQUNULFFBQVEsT0FBTyxNQUFNLENBQUM7QUFDdEIsS0FBSztBQUNMOztBQ2pGQTtBQUNPLE1BQU0sZUFBZSxDQUFDO0FBQzdCLElBQUksV0FBVyxHQUFHO0FBQ2xCO0FBQ0EsUUFBUSxJQUFJLENBQUMsVUFBVSxHQUFHO0FBQzFCLFlBQVksVUFBVTtBQUN0QixZQUFZLFlBQVk7QUFDeEIsWUFBWSxrQkFBa0I7QUFDOUIsWUFBWSxhQUFhO0FBQ3pCLFlBQVksd0JBQXdCO0FBQ3BDLFlBQVksZUFBZTtBQUMzQixZQUFZLFVBQVU7QUFDdEIsWUFBWSxrQkFBa0I7QUFDOUIsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLElBQUksQ0FBQyxxQkFBcUIsR0FBRztBQUNyQyxZQUFZLG9CQUFvQjtBQUNoQyxZQUFZLHNCQUFzQjtBQUNsQyxZQUFZLG1CQUFtQjtBQUMvQixZQUFZLG1CQUFtQjtBQUMvQixZQUFZLDBCQUEwQjtBQUN0QyxTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLGFBQWEsR0FBRztBQUM3QixZQUFZLGtCQUFrQjtBQUM5QixZQUFZLDRCQUE0QjtBQUN4QyxZQUFZLFdBQVc7QUFDdkIsWUFBWSx1QkFBdUI7QUFDbkMsWUFBWSx1QkFBdUI7QUFDbkMsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLElBQUksQ0FBQyxPQUFPLEdBQUc7QUFDdkIsWUFBWSxTQUFTO0FBQ3JCLFlBQVksUUFBUTtBQUNwQixZQUFZLFlBQVk7QUFDeEIsWUFBWSxjQUFjO0FBQzFCLFlBQVksZUFBZTtBQUMzQixZQUFZLGVBQWU7QUFDM0IsU0FBUyxDQUFDO0FBQ1YsS0FBSztBQUNMO0FBQ0EsSUFBSSxjQUFjLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRTtBQUN2QztBQUNBLFFBQVEsTUFBTSxrQkFBa0IsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUM5RSxRQUFRLE1BQU0sNkJBQTZCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNwRyxRQUFRLE1BQU0scUJBQXFCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDcEYsUUFBUSxNQUFNLGVBQWUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQztBQUN4RTtBQUNBLFFBQVEsSUFBSSxPQUFPLEdBQUcsRUFBRSxDQUFDO0FBQ3pCLFFBQVEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLElBQUksRUFBRTtBQUM1QyxZQUFZLE9BQU8sR0FBRyxpTkFBaU4sQ0FBQztBQUN4TyxTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsS0FBSyxFQUFFO0FBQ2xELFlBQVksT0FBTyxHQUFHLDhMQUE4TCxDQUFDO0FBQ3JOLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxLQUFLLEVBQUU7QUFDbEQsWUFBWSxPQUFPLEdBQUcsOEtBQThLLENBQUM7QUFDck0sU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLElBQUksRUFBRTtBQUNqRCxZQUFZLE9BQU8sR0FBRywyTEFBMkwsQ0FBQztBQUNsTixTQUFTO0FBQ1Q7QUFDQSxRQUFRLE9BQU87QUFDZixZQUFZLFVBQVUsRUFBRSxrQkFBa0I7QUFDMUMsWUFBWSxxQkFBcUIsRUFBRSw2QkFBNkI7QUFDaEUsWUFBWSxhQUFhLEVBQUUscUJBQXFCO0FBQ2hELFlBQVksT0FBTyxFQUFFLGVBQWU7QUFDcEMsWUFBWSxPQUFPO0FBQ25CLFNBQVMsQ0FBQztBQUNWLEtBQUs7QUFDTDtBQUNBLElBQUksaUJBQWlCLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRTtBQUNwQyxRQUFRLE1BQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUMxQixRQUFRLE1BQU0sU0FBUyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQztBQUNyQyxRQUFRLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLElBQUksU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDaEUsWUFBWSxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDN0UsWUFBWSxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ2hELFlBQVksU0FBUyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDN0MsU0FBUztBQUNULFFBQVEsT0FBTyxNQUFNLENBQUM7QUFDdEIsS0FBSztBQUNMOztBQ2pGQTtBQUNPLE1BQU0sa0JBQWtCLENBQUM7QUFDaEMsSUFBSSxXQUFXLEdBQUc7QUFDbEI7QUFDQSxRQUFRLElBQUksQ0FBQyxnQkFBZ0IsR0FBRztBQUNoQyxZQUFZLG1CQUFtQjtBQUMvQixZQUFZLCtCQUErQjtBQUMzQyxZQUFZLHFCQUFxQjtBQUNqQyxZQUFZLHlCQUF5QjtBQUNyQyxZQUFZLDBCQUEwQjtBQUN0QyxTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLG9CQUFvQixHQUFHO0FBQ3BDLFlBQVksbUJBQW1CO0FBQy9CLFlBQVksWUFBWTtBQUN4QixZQUFZLGFBQWE7QUFDekIsWUFBWSxvQkFBb0I7QUFDaEMsWUFBWSx5QkFBeUI7QUFDckMsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLElBQUksQ0FBQyxxQkFBcUIsR0FBRztBQUNyQyxZQUFZLHFCQUFxQjtBQUNqQyxZQUFZLHNCQUFzQjtBQUNsQyxZQUFZLDJCQUEyQjtBQUN2QyxZQUFZLGlDQUFpQztBQUM3QyxZQUFZLHVCQUF1QjtBQUNuQyxTQUFTLENBQUM7QUFDVixLQUFLO0FBQ0w7QUFDQSxJQUFJLGNBQWMsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFO0FBQ3ZDO0FBQ0EsUUFBUSxNQUFNLHdCQUF3QixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDMUYsUUFBUSxNQUFNLDRCQUE0QixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDbEcsUUFBUSxNQUFNLDZCQUE2QixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDcEc7QUFDQSxRQUFRLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUN6QixRQUFRLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxJQUFJLEVBQUU7QUFDNUMsWUFBWSxPQUFPLEdBQUcsdUxBQXVMLENBQUM7QUFDOU0sU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLEtBQUssRUFBRTtBQUNsRCxZQUFZLE9BQU8sR0FBRywySkFBMkosQ0FBQztBQUNsTCxTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsS0FBSyxFQUFFO0FBQ2xELFlBQVksT0FBTyxHQUFHLHFLQUFxSyxDQUFDO0FBQzVMLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxJQUFJLEVBQUU7QUFDakQsWUFBWSxPQUFPLEdBQUcsOEtBQThLLENBQUM7QUFDck0sU0FBUztBQUNUO0FBQ0EsUUFBUSxPQUFPO0FBQ2YsWUFBWSxnQkFBZ0IsRUFBRSx3QkFBd0I7QUFDdEQsWUFBWSxvQkFBb0IsRUFBRSw0QkFBNEI7QUFDOUQsWUFBWSxxQkFBcUIsRUFBRSw2QkFBNkI7QUFDaEUsWUFBWSxPQUFPO0FBQ25CLFNBQVMsQ0FBQztBQUNWLEtBQUs7QUFDTDtBQUNBLElBQUksaUJBQWlCLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRTtBQUNwQyxRQUFRLE1BQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUMxQixRQUFRLE1BQU0sU0FBUyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQztBQUNyQyxRQUFRLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLElBQUksU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDaEUsWUFBWSxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDN0UsWUFBWSxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ2hELFlBQVksU0FBUyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDN0MsU0FBUztBQUNULFFBQVEsT0FBTyxNQUFNLENBQUM7QUFDdEIsS0FBSztBQUNMOztBQ25FQTtBQUNPLE1BQU0sZ0JBQWdCLENBQUM7QUFDOUIsSUFBSSxXQUFXLEdBQUc7QUFDbEI7QUFDQSxRQUFRLElBQUksQ0FBQyxTQUFTLEdBQUc7QUFDekIsWUFBWSxzQkFBc0I7QUFDbEMsWUFBWSxTQUFTO0FBQ3JCLFlBQVksVUFBVTtBQUN0QixZQUFZLFNBQVM7QUFDckIsWUFBWSxZQUFZO0FBQ3hCLFlBQVksZUFBZTtBQUMzQixTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLGdCQUFnQixHQUFHO0FBQ2hDLFlBQVksbUJBQW1CO0FBQy9CLFlBQVksWUFBWTtBQUN4QixZQUFZLGVBQWU7QUFDM0IsWUFBWSxTQUFTO0FBQ3JCLFlBQVksZ0JBQWdCO0FBQzVCLFNBQVMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxJQUFJLENBQUMsZUFBZSxHQUFHO0FBQy9CLFlBQVksYUFBYTtBQUN6QixZQUFZLG9CQUFvQjtBQUNoQyxZQUFZLHFDQUFxQztBQUNqRCxZQUFZLDJCQUEyQjtBQUN2QyxZQUFZLDRCQUE0QjtBQUN4QyxTQUFTLENBQUM7QUFDVixLQUFLO0FBQ0w7QUFDQSxJQUFJLGNBQWMsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFO0FBQ3ZDO0FBQ0EsUUFBUSxNQUFNLGlCQUFpQixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzVFLFFBQVEsTUFBTSx3QkFBd0IsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzFGLFFBQVEsTUFBTSx1QkFBdUIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUN4RjtBQUNBLFFBQVEsSUFBSSxPQUFPLEdBQUcsRUFBRSxDQUFDO0FBQ3pCLFFBQVEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLElBQUksRUFBRTtBQUM1QyxZQUFZLE9BQU8sR0FBRyx1S0FBdUssQ0FBQztBQUM5TCxTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsS0FBSyxFQUFFO0FBQ2xELFlBQVksT0FBTyxHQUFHLGdMQUFnTCxDQUFDO0FBQ3ZNLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxLQUFLLEVBQUU7QUFDbEQsWUFBWSxPQUFPLEdBQUcsMktBQTJLLENBQUM7QUFDbE0sU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLElBQUksRUFBRTtBQUNqRCxZQUFZLE9BQU8sR0FBRyw4SkFBOEosQ0FBQztBQUNyTCxTQUFTO0FBQ1Q7QUFDQSxRQUFRLE9BQU87QUFDZixZQUFZLFNBQVMsRUFBRSxpQkFBaUI7QUFDeEMsWUFBWSxnQkFBZ0IsRUFBRSx3QkFBd0I7QUFDdEQsWUFBWSxlQUFlLEVBQUUsdUJBQXVCO0FBQ3BELFlBQVksT0FBTztBQUNuQixTQUFTLENBQUM7QUFDVixLQUFLO0FBQ0w7QUFDQSxJQUFJLGlCQUFpQixDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUU7QUFDcEMsUUFBUSxNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDMUIsUUFBUSxNQUFNLFNBQVMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUM7QUFDckMsUUFBUSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxJQUFJLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO0FBQ2hFLFlBQVksTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzdFLFlBQVksTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztBQUNoRCxZQUFZLFNBQVMsQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzdDLFNBQVM7QUFDVCxRQUFRLE9BQU8sTUFBTSxDQUFDO0FBQ3RCLEtBQUs7QUFDTDs7QUNwRUE7QUFDTyxNQUFNLGlCQUFpQixDQUFDO0FBQy9CLElBQUksV0FBVyxHQUFHO0FBQ2xCO0FBQ0EsUUFBUSxJQUFJLENBQUMsbUJBQW1CLEdBQUc7QUFDbkMsWUFBWSxrQkFBa0I7QUFDOUIsWUFBWSxnQkFBZ0I7QUFDNUIsWUFBWSx1QkFBdUI7QUFDbkMsWUFBWSxvQkFBb0I7QUFDaEMsWUFBWSxpQkFBaUI7QUFDN0IsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLElBQUksQ0FBQyxvQkFBb0IsR0FBRztBQUNwQyxZQUFZLGdCQUFnQjtBQUM1QixZQUFZLDRCQUE0QjtBQUN4QyxZQUFZLHNCQUFzQjtBQUNsQyxZQUFZLHdCQUF3QjtBQUNwQyxZQUFZLG9CQUFvQjtBQUNoQyxTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLGFBQWEsR0FBRztBQUM3QixZQUFZLG9CQUFvQjtBQUNoQyxZQUFZLG9CQUFvQjtBQUNoQyxZQUFZLHNCQUFzQjtBQUNsQyxZQUFZLHdCQUF3QjtBQUNwQyxZQUFZLDBCQUEwQjtBQUN0QyxTQUFTLENBQUM7QUFDVixLQUFLO0FBQ0w7QUFDQSxJQUFJLGNBQWMsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFO0FBQ3ZDO0FBQ0EsUUFBUSxNQUFNLDJCQUEyQixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDaEcsUUFBUSxNQUFNLDRCQUE0QixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDbEcsUUFBUSxNQUFNLHFCQUFxQixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3BGO0FBQ0EsUUFBUSxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7QUFDekIsUUFBUSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQzVDLFlBQVksT0FBTyxHQUFHLHVLQUF1SyxDQUFDO0FBQzlMLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxLQUFLLEVBQUU7QUFDbEQsWUFBWSxPQUFPLEdBQUcsdUpBQXVKLENBQUM7QUFDOUssU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLEtBQUssRUFBRTtBQUNsRCxZQUFZLE9BQU8sR0FBRyw0SUFBNEksQ0FBQztBQUNuSyxTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQ2pELFlBQVksT0FBTyxHQUFHLCtKQUErSixDQUFDO0FBQ3RMLFNBQVM7QUFDVDtBQUNBLFFBQVEsT0FBTztBQUNmLFlBQVksbUJBQW1CLEVBQUUsMkJBQTJCO0FBQzVELFlBQVksb0JBQW9CLEVBQUUsNEJBQTRCO0FBQzlELFlBQVksYUFBYSxFQUFFLHFCQUFxQjtBQUNoRCxZQUFZLE9BQU87QUFDbkIsU0FBUyxDQUFDO0FBQ1YsS0FBSztBQUNMO0FBQ0EsSUFBSSxpQkFBaUIsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFO0FBQ3BDLFFBQVEsTUFBTSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQzFCLFFBQVEsTUFBTSxTQUFTLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDO0FBQ3JDLFFBQVEsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssSUFBSSxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtBQUNoRSxZQUFZLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM3RSxZQUFZLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDaEQsWUFBWSxTQUFTLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUM3QyxTQUFTO0FBQ1QsUUFBUSxPQUFPLE1BQU0sQ0FBQztBQUN0QixLQUFLO0FBQ0w7O0FDbkVBO0FBQ08sTUFBTSxxQkFBcUIsQ0FBQztBQUNuQyxJQUFJLFdBQVcsR0FBRztBQUNsQjtBQUNBLFFBQVEsSUFBSSxDQUFDLGVBQWUsR0FBRztBQUMvQixZQUFZLHVCQUF1QjtBQUNuQyxZQUFZLDBCQUEwQjtBQUN0QyxZQUFZLHdCQUF3QjtBQUNwQyxZQUFZLDBCQUEwQjtBQUN0QyxZQUFZLHFCQUFxQjtBQUNqQyxTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLGNBQWMsR0FBRztBQUM5QixZQUFZLDZCQUE2QjtBQUN6QyxZQUFZLHlCQUF5QjtBQUNyQyxZQUFZLGdCQUFnQjtBQUM1QixZQUFZLHdCQUF3QjtBQUNwQyxZQUFZLHVCQUF1QjtBQUNuQyxTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLFVBQVUsR0FBRztBQUMxQixZQUFZLFlBQVk7QUFDeEIsWUFBWSxrQkFBa0I7QUFDOUIsWUFBWSxrQkFBa0I7QUFDOUIsWUFBWSxvQkFBb0I7QUFDaEMsWUFBWSx1QkFBdUI7QUFDbkMsU0FBUyxDQUFDO0FBQ1YsS0FBSztBQUNMO0FBQ0EsSUFBSSxjQUFjLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRTtBQUN2QztBQUNBLFFBQVEsTUFBTSx1QkFBdUIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUN4RixRQUFRLE1BQU0sc0JBQXNCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDdEYsUUFBUSxNQUFNLGtCQUFrQixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzlFO0FBQ0EsUUFBUSxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7QUFDekIsUUFBUSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQzVDLFlBQVksT0FBTyxHQUFHLDBLQUEwSyxDQUFDO0FBQ2pNLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxLQUFLLEVBQUU7QUFDbEQsWUFBWSxPQUFPLEdBQUcsb0pBQW9KLENBQUM7QUFDM0ssU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLEtBQUssRUFBRTtBQUNsRCxZQUFZLE9BQU8sR0FBRywySkFBMkosQ0FBQztBQUNsTCxTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQ2pELFlBQVksT0FBTyxHQUFHLHNLQUFzSyxDQUFDO0FBQzdMLFNBQVM7QUFDVDtBQUNBLFFBQVEsT0FBTztBQUNmLFlBQVksZUFBZSxFQUFFLHVCQUF1QjtBQUNwRCxZQUFZLGNBQWMsRUFBRSxzQkFBc0I7QUFDbEQsWUFBWSxVQUFVLEVBQUUsa0JBQWtCO0FBQzFDLFlBQVksT0FBTztBQUNuQixTQUFTLENBQUM7QUFDVixLQUFLO0FBQ0w7QUFDQSxJQUFJLGlCQUFpQixDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUU7QUFDcEMsUUFBUSxNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDMUIsUUFBUSxNQUFNLFNBQVMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUM7QUFDckMsUUFBUSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxJQUFJLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO0FBQ2hFLFlBQVksTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzdFLFlBQVksTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztBQUNoRCxZQUFZLFNBQVMsQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzdDLFNBQVM7QUFDVCxRQUFRLE9BQU8sTUFBTSxDQUFDO0FBQ3RCLEtBQUs7QUFDTDs7QUNuRUE7QUFDTyxNQUFNLG1CQUFtQixDQUFDO0FBQ2pDLElBQUksV0FBVyxHQUFHO0FBQ2xCO0FBQ0EsUUFBUSxJQUFJLENBQUMsT0FBTyxHQUFHO0FBQ3ZCLFlBQVksaUJBQWlCO0FBQzdCLFlBQVksbUJBQW1CO0FBQy9CLFlBQVksMkJBQTJCO0FBQ3ZDLFlBQVksb0JBQW9CO0FBQ2hDLFlBQVksc0JBQXNCO0FBQ2xDLFNBQVMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxJQUFJLENBQUMsWUFBWSxHQUFHO0FBQzVCLFlBQVkscUJBQXFCO0FBQ2pDLFlBQVksdUJBQXVCO0FBQ25DLFlBQVksZUFBZTtBQUMzQixZQUFZLGtCQUFrQjtBQUM5QixZQUFZLHNCQUFzQjtBQUNsQyxTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLE9BQU8sR0FBRztBQUN2QixZQUFZLHFCQUFxQjtBQUNqQyxZQUFZLE9BQU87QUFDbkIsWUFBWSxPQUFPO0FBQ25CLFlBQVkseUJBQXlCO0FBQ3JDLFlBQVksb0JBQW9CO0FBQ2hDLFNBQVMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxJQUFJLENBQUMsT0FBTyxHQUFHO0FBQ3ZCLFlBQVksa0JBQWtCO0FBQzlCLFlBQVksV0FBVztBQUN2QixZQUFZLG9CQUFvQjtBQUNoQyxZQUFZLGlCQUFpQjtBQUM3QixZQUFZLHNCQUFzQjtBQUNsQyxTQUFTLENBQUM7QUFDVixLQUFLO0FBQ0w7QUFDQSxJQUFJLGNBQWMsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFO0FBQ3ZDO0FBQ0EsUUFBUSxNQUFNLGVBQWUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQztBQUN4RSxRQUFRLE1BQU0sb0JBQW9CLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDbEYsUUFBUSxNQUFNLGVBQWUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQztBQUN4RSxRQUFRLE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3hFO0FBQ0EsUUFBUSxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7QUFDekIsUUFBUSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQzVDLFlBQVksT0FBTyxHQUFHLHVQQUF1UCxDQUFDO0FBQzlRLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxLQUFLLEVBQUU7QUFDbEQsWUFBWSxPQUFPLEdBQUcsOExBQThMLENBQUM7QUFDck4sU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLEtBQUssRUFBRTtBQUNsRCxZQUFZLE9BQU8sR0FBRyxnTUFBZ00sQ0FBQztBQUN2TixTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQ2pELFlBQVksT0FBTyxHQUFHLDJMQUEyTCxDQUFDO0FBQ2xOLFNBQVM7QUFDVDtBQUNBLFFBQVEsT0FBTztBQUNmLFlBQVksT0FBTyxFQUFFLGVBQWU7QUFDcEMsWUFBWSxZQUFZLEVBQUUsb0JBQW9CO0FBQzlDLFlBQVksT0FBTyxFQUFFLGVBQWU7QUFDcEMsWUFBWSxPQUFPLEVBQUUsZUFBZTtBQUNwQyxZQUFZLE9BQU87QUFDbkIsU0FBUyxDQUFDO0FBQ1YsS0FBSztBQUNMO0FBQ0EsSUFBSSxpQkFBaUIsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFO0FBQ3BDLFFBQVEsTUFBTSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQzFCLFFBQVEsTUFBTSxTQUFTLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDO0FBQ3JDLFFBQVEsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssSUFBSSxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtBQUNoRSxZQUFZLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM3RSxZQUFZLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDaEQsWUFBWSxTQUFTLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUM3QyxTQUFTO0FBQ1QsUUFBUSxPQUFPLE1BQU0sQ0FBQztBQUN0QixLQUFLO0FBQ0w7O0FDN0VBO0FBQ08sTUFBTSxnQkFBZ0IsQ0FBQztBQUM5QixJQUFJLFdBQVcsR0FBRztBQUNsQjtBQUNBLFFBQVEsSUFBSSxDQUFDLGtCQUFrQixHQUFHO0FBQ2xDLFlBQVksK0JBQStCO0FBQzNDLFlBQVksdUJBQXVCO0FBQ25DLFlBQVksbUJBQW1CO0FBQy9CLFlBQVksc0JBQXNCO0FBQ2xDLFlBQVksc0JBQXNCO0FBQ2xDLFNBQVMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxJQUFJLENBQUMscUJBQXFCLEdBQUc7QUFDckMsWUFBWSxxQkFBcUI7QUFDakMsWUFBWSxnQkFBZ0I7QUFDNUIsWUFBWSxzQkFBc0I7QUFDbEMsWUFBWSx1QkFBdUI7QUFDbkMsWUFBWSxrQkFBa0I7QUFDOUIsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLElBQUksQ0FBQyxvQkFBb0IsR0FBRztBQUNwQyxZQUFZLGtCQUFrQjtBQUM5QixZQUFZLGtCQUFrQjtBQUM5QixZQUFZLG9CQUFvQjtBQUNoQyxZQUFZLHFCQUFxQjtBQUNqQyxZQUFZLGFBQWE7QUFDekIsWUFBWSxlQUFlO0FBQzNCLFNBQVMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxJQUFJLENBQUMsaUJBQWlCLEdBQUc7QUFDakMsWUFBWSwwQkFBMEI7QUFDdEMsWUFBWSxxQkFBcUI7QUFDakMsWUFBWSx5QkFBeUI7QUFDckMsWUFBWSxzQkFBc0I7QUFDbEMsWUFBWSxvQkFBb0I7QUFDaEMsU0FBUyxDQUFDO0FBQ1YsS0FBSztBQUNMO0FBQ0EsSUFBSSxjQUFjLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRTtBQUN2QztBQUNBLFFBQVEsTUFBTSwwQkFBMEIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzlGLFFBQVEsTUFBTSw2QkFBNkIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3BHLFFBQVEsTUFBTSw0QkFBNEIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ2xHLFFBQVEsTUFBTSx5QkFBeUIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzVGO0FBQ0EsUUFBUSxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7QUFDekIsUUFBUSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQzVDLFlBQVksT0FBTyxHQUFHLG1QQUFtUCxDQUFDO0FBQzFRLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxLQUFLLEVBQUU7QUFDbEQsWUFBWSxPQUFPLEdBQUcsK0xBQStMLENBQUM7QUFDdE4sU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLEtBQUssRUFBRTtBQUNsRCxZQUFZLE9BQU8sR0FBRyw0TEFBNEwsQ0FBQztBQUNuTixTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQ2pELFlBQVksT0FBTyxHQUFHLG1NQUFtTSxDQUFDO0FBQzFOLFNBQVM7QUFDVDtBQUNBLFFBQVEsT0FBTztBQUNmLFlBQVksa0JBQWtCLEVBQUUsMEJBQTBCO0FBQzFELFlBQVkscUJBQXFCLEVBQUUsNkJBQTZCO0FBQ2hFLFlBQVksb0JBQW9CLEVBQUUsNEJBQTRCO0FBQzlELFlBQVksaUJBQWlCLEVBQUUseUJBQXlCO0FBQ3hELFlBQVksT0FBTztBQUNuQixTQUFTLENBQUM7QUFDVixLQUFLO0FBQ0w7QUFDQSxJQUFJLGlCQUFpQixDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUU7QUFDcEMsUUFBUSxNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDMUIsUUFBUSxNQUFNLFNBQVMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUM7QUFDckMsUUFBUSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxJQUFJLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO0FBQ2hFLFlBQVksTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzdFLFlBQVksTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztBQUNoRCxZQUFZLFNBQVMsQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzdDLFNBQVM7QUFDVCxRQUFRLE9BQU8sTUFBTSxDQUFDO0FBQ3RCLEtBQUs7QUFDTDs7QUM5RUE7QUFDTyxNQUFNLGdCQUFnQixDQUFDO0FBQzlCLElBQUksV0FBVyxHQUFHO0FBQ2xCO0FBQ0EsUUFBUSxJQUFJLENBQUMsZUFBZSxHQUFHO0FBQy9CLFlBQVksVUFBVTtBQUN0QixZQUFZLFlBQVk7QUFDeEIsWUFBWSxrQkFBa0I7QUFDOUIsWUFBWSxtQkFBbUI7QUFDL0IsWUFBWSxvQkFBb0I7QUFDaEMsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLElBQUksQ0FBQyxtQkFBbUIsR0FBRztBQUNuQyxZQUFZLHFCQUFxQjtBQUNqQyxZQUFZLGFBQWE7QUFDekIsWUFBWSxxQkFBcUI7QUFDakMsWUFBWSxrQkFBa0I7QUFDOUIsWUFBWSwrQkFBK0I7QUFDM0MsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLElBQUksQ0FBQyxZQUFZLEdBQUc7QUFDNUIsWUFBWSxRQUFRO0FBQ3BCLFlBQVksd0JBQXdCO0FBQ3BDLFlBQVksc0JBQXNCO0FBQ2xDLFlBQVksbUJBQW1CO0FBQy9CLFlBQVksa0JBQWtCO0FBQzlCLFNBQVMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxJQUFJLENBQUMsVUFBVSxHQUFHO0FBQzFCLFlBQVksc0JBQXNCO0FBQ2xDLFlBQVksZUFBZTtBQUMzQixZQUFZLFVBQVU7QUFDdEIsWUFBWSxXQUFXO0FBQ3ZCLFlBQVksVUFBVTtBQUN0QixTQUFTLENBQUM7QUFDVixLQUFLO0FBQ0w7QUFDQSxJQUFJLGNBQWMsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFO0FBQ3ZDO0FBQ0EsUUFBUSxNQUFNLHVCQUF1QixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3hGLFFBQVEsTUFBTSwyQkFBMkIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ2hHLFFBQVEsTUFBTSxvQkFBb0IsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNsRixRQUFRLE1BQU0sa0JBQWtCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDOUU7QUFDQSxRQUFRLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUN6QixRQUFRLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxJQUFJLEVBQUU7QUFDNUMsWUFBWSxPQUFPLEdBQUcsMk9BQTJPLENBQUM7QUFDbFEsU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLEtBQUssRUFBRTtBQUNsRCxZQUFZLE9BQU8sR0FBRyxvTEFBb0wsQ0FBQztBQUMzTSxTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsS0FBSyxFQUFFO0FBQ2xELFlBQVksT0FBTyxHQUFHLHFLQUFxSyxDQUFDO0FBQzVMLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxJQUFJLEVBQUU7QUFDakQsWUFBWSxPQUFPLEdBQUcsOE1BQThNLENBQUM7QUFDck8sU0FBUztBQUNUO0FBQ0EsUUFBUSxPQUFPO0FBQ2YsWUFBWSxlQUFlLEVBQUUsdUJBQXVCO0FBQ3BELFlBQVksbUJBQW1CLEVBQUUsMkJBQTJCO0FBQzVELFlBQVksWUFBWSxFQUFFLG9CQUFvQjtBQUM5QyxZQUFZLFVBQVUsRUFBRSxrQkFBa0I7QUFDMUMsWUFBWSxPQUFPO0FBQ25CLFNBQVMsQ0FBQztBQUNWLEtBQUs7QUFDTDtBQUNBLElBQUksaUJBQWlCLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRTtBQUNwQyxRQUFRLE1BQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUMxQixRQUFRLE1BQU0sU0FBUyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQztBQUNyQyxRQUFRLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLElBQUksU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDaEUsWUFBWSxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDN0UsWUFBWSxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ2hELFlBQVksU0FBUyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDN0MsU0FBUztBQUNULFFBQVEsT0FBTyxNQUFNLENBQUM7QUFDdEIsS0FBSztBQUNMOztBQzdFQTtBQUNPLE1BQU0sb0JBQW9CLENBQUM7QUFDbEMsSUFBSSxXQUFXLEdBQUc7QUFDbEI7QUFDQSxRQUFRLElBQUksQ0FBQyxjQUFjLEdBQUc7QUFDOUIsWUFBWSw4QkFBOEI7QUFDMUMsWUFBWSxrQ0FBa0M7QUFDOUMsWUFBWSx1QkFBdUI7QUFDbkMsWUFBWSw2QkFBNkI7QUFDekMsWUFBWSwwQkFBMEI7QUFDdEMsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLElBQUksQ0FBQyx1QkFBdUIsR0FBRztBQUN2QyxZQUFZLCtCQUErQjtBQUMzQyxZQUFZLDBCQUEwQjtBQUN0QyxZQUFZLG1CQUFtQjtBQUMvQixZQUFZLG9CQUFvQjtBQUNoQyxZQUFZLDJCQUEyQjtBQUN2QyxTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLGNBQWMsR0FBRztBQUM5QixZQUFZLGlCQUFpQjtBQUM3QixZQUFZLGtCQUFrQjtBQUM5QixZQUFZLGdCQUFnQjtBQUM1QixZQUFZLDBCQUEwQjtBQUN0QyxZQUFZLHdCQUF3QjtBQUNwQyxTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLFdBQVcsR0FBRztBQUMzQixZQUFZLHFCQUFxQjtBQUNqQyxZQUFZLHdCQUF3QjtBQUNwQyxZQUFZLGdCQUFnQjtBQUM1QixZQUFZLG9CQUFvQjtBQUNoQyxZQUFZLG9CQUFvQjtBQUNoQyxTQUFTLENBQUM7QUFDVixLQUFLO0FBQ0w7QUFDQSxJQUFJLGNBQWMsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFO0FBQ3ZDO0FBQ0EsUUFBUSxNQUFNLHNCQUFzQixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3RGLFFBQVEsTUFBTSwrQkFBK0IsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3hHLFFBQVEsTUFBTSxzQkFBc0IsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUN0RixRQUFRLE1BQU0sbUJBQW1CLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDaEY7QUFDQSxRQUFRLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUN6QixRQUFRLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxJQUFJLEVBQUU7QUFDNUMsWUFBWSxPQUFPLEdBQUcsZ1FBQWdRLENBQUM7QUFDdlIsU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLEtBQUssRUFBRTtBQUNsRCxZQUFZLE9BQU8sR0FBRyxzTUFBc00sQ0FBQztBQUM3TixTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsS0FBSyxFQUFFO0FBQ2xELFlBQVksT0FBTyxHQUFHLDBNQUEwTSxDQUFDO0FBQ2pPLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxJQUFJLEVBQUU7QUFDakQsWUFBWSxPQUFPLEdBQUcsdU5BQXVOLENBQUM7QUFDOU8sU0FBUztBQUNUO0FBQ0EsUUFBUSxPQUFPO0FBQ2YsWUFBWSxjQUFjLEVBQUUsc0JBQXNCO0FBQ2xELFlBQVksdUJBQXVCLEVBQUUsK0JBQStCO0FBQ3BFLFlBQVksY0FBYyxFQUFFLHNCQUFzQjtBQUNsRCxZQUFZLFdBQVcsRUFBRSxtQkFBbUI7QUFDNUMsWUFBWSxPQUFPO0FBQ25CLFNBQVMsQ0FBQztBQUNWLEtBQUs7QUFDTDtBQUNBLElBQUksaUJBQWlCLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRTtBQUNwQyxRQUFRLE1BQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUMxQixRQUFRLE1BQU0sU0FBUyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQztBQUNyQyxRQUFRLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLElBQUksU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDaEUsWUFBWSxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDN0UsWUFBWSxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ2hELFlBQVksU0FBUyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDN0MsU0FBUztBQUNULFFBQVEsT0FBTyxNQUFNLENBQUM7QUFDdEIsS0FBSztBQUNMOztBQzdFQTtBQUNPLE1BQU0sZ0JBQWdCLENBQUM7QUFDOUIsSUFBSSxXQUFXLEdBQUc7QUFDbEI7QUFDQSxRQUFRLElBQUksQ0FBQyxlQUFlLEdBQUc7QUFDL0IsWUFBWSxvQkFBb0I7QUFDaEMsWUFBWSxnQ0FBZ0M7QUFDNUMsWUFBWSxrQ0FBa0M7QUFDOUMsWUFBWSwyQkFBMkI7QUFDdkMsWUFBWSxnQkFBZ0I7QUFDNUIsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLElBQUksQ0FBQyxZQUFZLEdBQUc7QUFDNUIsWUFBWSx1QkFBdUI7QUFDbkMsWUFBWSxpQkFBaUI7QUFDN0IsWUFBWSxZQUFZO0FBQ3hCLFlBQVksZUFBZTtBQUMzQixZQUFZLGVBQWU7QUFDM0IsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLElBQUksQ0FBQyxPQUFPLEdBQUc7QUFDdkIsWUFBWSxtQkFBbUI7QUFDL0IsWUFBWSxtQkFBbUI7QUFDL0IsWUFBWSx3QkFBd0I7QUFDcEMsWUFBWSxxQkFBcUI7QUFDakMsWUFBWSxpQkFBaUI7QUFDN0IsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLElBQUksQ0FBQyxXQUFXLEdBQUc7QUFDM0IsWUFBWSwwQkFBMEI7QUFDdEMsWUFBWSxnQkFBZ0I7QUFDNUIsWUFBWSw0QkFBNEI7QUFDeEMsWUFBWSxxQkFBcUI7QUFDakMsWUFBWSx3QkFBd0I7QUFDcEMsU0FBUyxDQUFDO0FBQ1YsS0FBSztBQUNMO0FBQ0EsSUFBSSxjQUFjLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRTtBQUN2QztBQUNBLFFBQVEsTUFBTSx1QkFBdUIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUN4RixRQUFRLE1BQU0sb0JBQW9CLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDbEYsUUFBUSxNQUFNLGVBQWUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQztBQUN4RSxRQUFRLE1BQU0sbUJBQW1CLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDaEY7QUFDQSxRQUFRLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUN6QixRQUFRLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxJQUFJLEVBQUU7QUFDNUMsWUFBWSxPQUFPLEdBQUcsK1BBQStQLENBQUM7QUFDdFIsU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLEtBQUssRUFBRTtBQUNsRCxZQUFZLE9BQU8sR0FBRyxrTUFBa00sQ0FBQztBQUN6TixTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsS0FBSyxFQUFFO0FBQ2xELFlBQVksT0FBTyxHQUFHLGdMQUFnTCxDQUFDO0FBQ3ZNLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxJQUFJLEVBQUU7QUFDakQsWUFBWSxPQUFPLEdBQUcsMExBQTBMLENBQUM7QUFDak4sU0FBUztBQUNUO0FBQ0EsUUFBUSxPQUFPO0FBQ2YsWUFBWSxlQUFlLEVBQUUsdUJBQXVCO0FBQ3BELFlBQVksWUFBWSxFQUFFLG9CQUFvQjtBQUM5QyxZQUFZLE9BQU8sRUFBRSxlQUFlO0FBQ3BDLFlBQVksV0FBVyxFQUFFLG1CQUFtQjtBQUM1QyxZQUFZLE9BQU87QUFDbkIsU0FBUyxDQUFDO0FBQ1YsS0FBSztBQUNMO0FBQ0EsSUFBSSxpQkFBaUIsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFO0FBQ3BDLFFBQVEsTUFBTSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQzFCLFFBQVEsTUFBTSxTQUFTLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDO0FBQ3JDLFFBQVEsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssSUFBSSxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtBQUNoRSxZQUFZLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM3RSxZQUFZLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDaEQsWUFBWSxTQUFTLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUM3QyxTQUFTO0FBQ1QsUUFBUSxPQUFPLE1BQU0sQ0FBQztBQUN0QixLQUFLO0FBQ0w7O0FDN0VBO0FBQ08sTUFBTSxtQkFBbUIsQ0FBQztBQUNqQyxJQUFJLFdBQVcsR0FBRztBQUNsQjtBQUNBLFFBQVEsSUFBSSxDQUFDLFdBQVcsR0FBRztBQUMzQixZQUFZLGdCQUFnQjtBQUM1QixZQUFZLGlCQUFpQjtBQUM3QixZQUFZLGtCQUFrQjtBQUM5QixZQUFZLHNCQUFzQjtBQUNsQyxZQUFZLHlCQUF5QjtBQUNyQyxTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLGlCQUFpQixHQUFHO0FBQ2pDLFlBQVkscUJBQXFCO0FBQ2pDLFlBQVksMEJBQTBCO0FBQ3RDLFlBQVksZ0JBQWdCO0FBQzVCLFlBQVksb0JBQW9CO0FBQ2hDLFlBQVkscUJBQXFCO0FBQ2pDLFNBQVMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxJQUFJLENBQUMsYUFBYSxHQUFHO0FBQzdCLFlBQVksbUJBQW1CO0FBQy9CLFlBQVksMEJBQTBCO0FBQ3RDLFlBQVksMEJBQTBCO0FBQ3RDLFlBQVksb0JBQW9CO0FBQ2hDLFlBQVksd0JBQXdCO0FBQ3BDLFNBQVMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxJQUFJLENBQUMsY0FBYyxHQUFHO0FBQzlCLFlBQVksc0JBQXNCO0FBQ2xDLFlBQVksMkJBQTJCO0FBQ3ZDLFlBQVksMEJBQTBCO0FBQ3RDLFlBQVkscUJBQXFCO0FBQ2pDLFlBQVksOEJBQThCO0FBQzFDLFNBQVMsQ0FBQztBQUNWLEtBQUs7QUFDTDtBQUNBLElBQUksY0FBYyxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUU7QUFDdkM7QUFDQSxRQUFRLE1BQU0sbUJBQW1CLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDaEYsUUFBUSxNQUFNLHlCQUF5QixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDNUYsUUFBUSxNQUFNLHFCQUFxQixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3BGLFFBQVEsTUFBTSxzQkFBc0IsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUN0RjtBQUNBLFFBQVEsSUFBSSxPQUFPLEdBQUcsRUFBRSxDQUFDO0FBQ3pCLFFBQVEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLElBQUksRUFBRTtBQUM1QyxZQUFZLE9BQU8sR0FBRyxpT0FBaU8sQ0FBQztBQUN4UCxTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsS0FBSyxFQUFFO0FBQ2xELFlBQVksT0FBTyxHQUFHLHFNQUFxTSxDQUFDO0FBQzVOLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxLQUFLLEVBQUU7QUFDbEQsWUFBWSxPQUFPLEdBQUcsbUxBQW1MLENBQUM7QUFDMU0sU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLElBQUksRUFBRTtBQUNqRCxZQUFZLE9BQU8sR0FBRyxrTUFBa00sQ0FBQztBQUN6TixTQUFTO0FBQ1Q7QUFDQSxRQUFRLE9BQU87QUFDZixZQUFZLFdBQVcsRUFBRSxtQkFBbUI7QUFDNUMsWUFBWSxpQkFBaUIsRUFBRSx5QkFBeUI7QUFDeEQsWUFBWSxhQUFhLEVBQUUscUJBQXFCO0FBQ2hELFlBQVksY0FBYyxFQUFFLHNCQUFzQjtBQUNsRCxZQUFZLE9BQU87QUFDbkIsU0FBUyxDQUFDO0FBQ1YsS0FBSztBQUNMO0FBQ0EsSUFBSSxpQkFBaUIsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFO0FBQ3BDLFFBQVEsTUFBTSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQzFCLFFBQVEsTUFBTSxTQUFTLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDO0FBQ3JDLFFBQVEsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssSUFBSSxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtBQUNoRSxZQUFZLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM3RSxZQUFZLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDaEQsWUFBWSxTQUFTLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUM3QyxTQUFTO0FBQ1QsUUFBUSxPQUFPLE1BQU0sQ0FBQztBQUN0QixLQUFLO0FBQ0w7O0FDN0VBO0FBQ08sTUFBTSxlQUFlLENBQUM7QUFDN0IsSUFBSSxXQUFXLEdBQUc7QUFDbEI7QUFDQSxRQUFRLElBQUksQ0FBQyxtQkFBbUIsR0FBRztBQUNuQyxZQUFZLDRDQUE0QztBQUN4RCxZQUFZLDRCQUE0QjtBQUN4QyxZQUFZLHNCQUFzQjtBQUNsQyxZQUFZLHdCQUF3QjtBQUNwQyxZQUFZLHFCQUFxQjtBQUNqQyxTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLGVBQWUsR0FBRztBQUMvQixZQUFZLHdCQUF3QjtBQUNwQyxZQUFZLHVCQUF1QjtBQUNuQyxZQUFZLDBCQUEwQjtBQUN0QyxZQUFZLDZCQUE2QjtBQUN6QyxZQUFZLDhCQUE4QjtBQUMxQyxTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLGdCQUFnQixHQUFHO0FBQ2hDLFlBQVksd0JBQXdCO0FBQ3BDLFlBQVkseUJBQXlCO0FBQ3JDLFlBQVksNEJBQTRCO0FBQ3hDLFlBQVksOEJBQThCO0FBQzFDLFlBQVkscUJBQXFCO0FBQ2pDLFNBQVMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxJQUFJLENBQUMsVUFBVSxHQUFHO0FBQzFCLFlBQVksa0JBQWtCO0FBQzlCLFlBQVksMEJBQTBCO0FBQ3RDLFlBQVksc0JBQXNCO0FBQ2xDLFlBQVksNEJBQTRCO0FBQ3hDLFlBQVksdUJBQXVCO0FBQ25DLFNBQVMsQ0FBQztBQUNWLEtBQUs7QUFDTDtBQUNBLElBQUksY0FBYyxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUU7QUFDdkM7QUFDQSxRQUFRLE1BQU0sMkJBQTJCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNoRyxRQUFRLE1BQU0sdUJBQXVCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDeEYsUUFBUSxNQUFNLHdCQUF3QixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDMUYsUUFBUSxNQUFNLGtCQUFrQixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzlFO0FBQ0EsUUFBUSxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7QUFDekIsUUFBUSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQzVDLFlBQVksT0FBTyxHQUFHLHlOQUF5TixDQUFDO0FBQ2hQLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxLQUFLLEVBQUU7QUFDbEQsWUFBWSxPQUFPLEdBQUcsa0tBQWtLLENBQUM7QUFDekwsU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLEtBQUssRUFBRTtBQUNsRCxZQUFZLE9BQU8sR0FBRyxvS0FBb0ssQ0FBQztBQUMzTCxTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQ2pELFlBQVksT0FBTyxHQUFHLHlMQUF5TCxDQUFDO0FBQ2hOLFNBQVM7QUFDVDtBQUNBLFFBQVEsT0FBTztBQUNmLFlBQVksbUJBQW1CLEVBQUUsMkJBQTJCO0FBQzVELFlBQVksZUFBZSxFQUFFLHVCQUF1QjtBQUNwRCxZQUFZLGdCQUFnQixFQUFFLHdCQUF3QjtBQUN0RCxZQUFZLFVBQVUsRUFBRSxrQkFBa0I7QUFDMUMsWUFBWSxPQUFPO0FBQ25CLFNBQVMsQ0FBQztBQUNWLEtBQUs7QUFDTDtBQUNBLElBQUksaUJBQWlCLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRTtBQUNwQyxRQUFRLE1BQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUMxQixRQUFRLE1BQU0sU0FBUyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQztBQUNyQyxRQUFRLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLElBQUksU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDaEUsWUFBWSxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDN0UsWUFBWSxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ2hELFlBQVksU0FBUyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDN0MsU0FBUztBQUNULFFBQVEsT0FBTyxNQUFNLENBQUM7QUFDdEIsS0FBSztBQUNMOztBQzdFQTtBQUNPLE1BQU0scUJBQXFCLENBQUM7QUFDbkMsSUFBSSxXQUFXLEdBQUc7QUFDbEI7QUFDQSxRQUFRLElBQUksQ0FBQyxTQUFTLEdBQUc7QUFDekIsWUFBWSxzQkFBc0I7QUFDbEMsWUFBWSxvQkFBb0I7QUFDaEMsWUFBWSxtQkFBbUI7QUFDL0IsWUFBWSxtQkFBbUI7QUFDL0IsWUFBWSw0QkFBNEI7QUFDeEMsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLElBQUksQ0FBQyxvQkFBb0IsR0FBRztBQUNwQyxZQUFZLGtCQUFrQjtBQUM5QixZQUFZLGlCQUFpQjtBQUM3QixZQUFZLHNCQUFzQjtBQUNsQyxZQUFZLHFCQUFxQjtBQUNqQyxZQUFZLHdCQUF3QjtBQUNwQyxTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLG1CQUFtQixHQUFHO0FBQ25DLFlBQVkscUJBQXFCO0FBQ2pDLFlBQVksbUJBQW1CO0FBQy9CLFlBQVksd0JBQXdCO0FBQ3BDLFlBQVksZ0JBQWdCO0FBQzVCLFlBQVksc0JBQXNCO0FBQ2xDLFNBQVMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxJQUFJLENBQUMsY0FBYyxHQUFHO0FBQzlCLFlBQVkscUJBQXFCO0FBQ2pDLFlBQVksNkJBQTZCO0FBQ3pDLFlBQVksd0JBQXdCO0FBQ3BDLFlBQVksNEJBQTRCO0FBQ3hDLFlBQVkseUJBQXlCO0FBQ3JDLFNBQVMsQ0FBQztBQUNWLEtBQUs7QUFDTDtBQUNBLElBQUksY0FBYyxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUU7QUFDdkM7QUFDQSxRQUFRLE1BQU0saUJBQWlCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDNUUsUUFBUSxNQUFNLDRCQUE0QixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDbEcsUUFBUSxNQUFNLDJCQUEyQixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDaEcsUUFBUSxNQUFNLHNCQUFzQixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3RGO0FBQ0EsUUFBUSxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7QUFDekIsUUFBUSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQzVDLFlBQVksT0FBTyxHQUFHLDhQQUE4UCxDQUFDO0FBQ3JSLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxLQUFLLEVBQUU7QUFDbEQsWUFBWSxPQUFPLEdBQUcsb01BQW9NLENBQUM7QUFDM04sU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLEtBQUssRUFBRTtBQUNsRCxZQUFZLE9BQU8sR0FBRyxrTEFBa0wsQ0FBQztBQUN6TSxTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQ2pELFlBQVksT0FBTyxHQUFHLDBNQUEwTSxDQUFDO0FBQ2pPLFNBQVM7QUFDVDtBQUNBLFFBQVEsT0FBTztBQUNmLFlBQVksU0FBUyxFQUFFLGlCQUFpQjtBQUN4QyxZQUFZLG9CQUFvQixFQUFFLDRCQUE0QjtBQUM5RCxZQUFZLG1CQUFtQixFQUFFLDJCQUEyQjtBQUM1RCxZQUFZLGNBQWMsRUFBRSxzQkFBc0I7QUFDbEQsWUFBWSxPQUFPO0FBQ25CLFNBQVMsQ0FBQztBQUNWLEtBQUs7QUFDTDtBQUNBLElBQUksaUJBQWlCLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRTtBQUNwQyxRQUFRLE1BQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUMxQixRQUFRLE1BQU0sU0FBUyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQztBQUNyQyxRQUFRLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLElBQUksU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDaEUsWUFBWSxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDN0UsWUFBWSxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ2hELFlBQVksU0FBUyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDN0MsU0FBUztBQUNULFFBQVEsT0FBTyxNQUFNLENBQUM7QUFDdEIsS0FBSztBQUNMOztBQzdFQTtBQUNPLE1BQU0sV0FBVyxDQUFDO0FBQ3pCLElBQUksV0FBVyxHQUFHO0FBQ2xCO0FBQ0EsUUFBUSxJQUFJLENBQUMsb0JBQW9CLEdBQUc7QUFDcEMsWUFBWSx5QkFBeUI7QUFDckMsWUFBWSxvQkFBb0I7QUFDaEMsWUFBWSxrQkFBa0I7QUFDOUIsWUFBWSxpQkFBaUI7QUFDN0IsWUFBWSxxQkFBcUI7QUFDakMsWUFBWSxtQkFBbUI7QUFDL0IsWUFBWSxpQkFBaUI7QUFDN0IsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLElBQUksQ0FBQyxrQkFBa0IsR0FBRztBQUNsQyxZQUFZLHFCQUFxQjtBQUNqQyxZQUFZLGtCQUFrQjtBQUM5QixZQUFZLHdCQUF3QjtBQUNwQyxZQUFZLHVCQUF1QjtBQUNuQyxZQUFZLDRCQUE0QjtBQUN4QyxTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLFdBQVcsR0FBRztBQUMzQixZQUFZLG9CQUFvQjtBQUNoQyxZQUFZLHNCQUFzQjtBQUNsQyxZQUFZLHlCQUF5QjtBQUNyQyxZQUFZLHNCQUFzQjtBQUNsQyxZQUFZLG9CQUFvQjtBQUNoQyxTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLGtCQUFrQixHQUFHO0FBQ2xDLFlBQVkseUJBQXlCO0FBQ3JDLFlBQVksd0JBQXdCO0FBQ3BDLFlBQVkscUJBQXFCO0FBQ2pDLFlBQVksd0JBQXdCO0FBQ3BDLFlBQVkseUJBQXlCO0FBQ3JDLFNBQVMsQ0FBQztBQUNWLEtBQUs7QUFDTDtBQUNBLElBQUksY0FBYyxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUU7QUFDdkM7QUFDQSxRQUFRLE1BQU0sNEJBQTRCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNsRyxRQUFRLE1BQU0sMEJBQTBCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUM5RixRQUFRLE1BQU0sbUJBQW1CLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDaEYsUUFBUSxNQUFNLDBCQUEwQixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDOUY7QUFDQSxRQUFRLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUN6QixRQUFRLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxJQUFJLEVBQUU7QUFDNUMsWUFBWSxPQUFPLEdBQUcsZ1BBQWdQLENBQUM7QUFDdlEsU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLEtBQUssRUFBRTtBQUNsRCxZQUFZLE9BQU8sR0FBRyw2S0FBNkssQ0FBQztBQUNwTSxTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsS0FBSyxFQUFFO0FBQ2xELFlBQVksT0FBTyxHQUFHLCtMQUErTCxDQUFDO0FBQ3ROLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxJQUFJLEVBQUU7QUFDakQsWUFBWSxPQUFPLEdBQUcsbUxBQW1MLENBQUM7QUFDMU0sU0FBUztBQUNUO0FBQ0EsUUFBUSxPQUFPO0FBQ2YsWUFBWSxvQkFBb0IsRUFBRSw0QkFBNEI7QUFDOUQsWUFBWSxrQkFBa0IsRUFBRSwwQkFBMEI7QUFDMUQsWUFBWSxXQUFXLEVBQUUsbUJBQW1CO0FBQzVDLFlBQVksa0JBQWtCLEVBQUUsMEJBQTBCO0FBQzFELFlBQVksT0FBTztBQUNuQixTQUFTLENBQUM7QUFDVixLQUFLO0FBQ0w7QUFDQSxJQUFJLGlCQUFpQixDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUU7QUFDcEMsUUFBUSxNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDMUIsUUFBUSxNQUFNLFNBQVMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUM7QUFDckMsUUFBUSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxJQUFJLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO0FBQ2hFLFlBQVksTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzdFLFlBQVksTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztBQUNoRCxZQUFZLFNBQVMsQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzdDLFNBQVM7QUFDVCxRQUFRLE9BQU8sTUFBTSxDQUFDO0FBQ3RCLEtBQUs7QUFDTDs7QUMvRUE7QUFDTyxNQUFNLG9CQUFvQixDQUFDO0FBQ2xDLElBQUksV0FBVyxHQUFHO0FBQ2xCO0FBQ0EsUUFBUSxJQUFJLENBQUMsa0JBQWtCLEdBQUc7QUFDbEMsWUFBWSx5QkFBeUI7QUFDckMsWUFBWSxvQkFBb0I7QUFDaEMsWUFBWSx3QkFBd0I7QUFDcEMsWUFBWSxzQkFBc0I7QUFDbEMsWUFBWSxzQkFBc0I7QUFDbEMsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLElBQUksQ0FBQyxpQkFBaUIsR0FBRztBQUNqQyxZQUFZLHlCQUF5QjtBQUNyQyxZQUFZLG1CQUFtQjtBQUMvQixZQUFZLHlCQUF5QjtBQUNyQyxZQUFZLDBCQUEwQjtBQUN0QyxZQUFZLG1CQUFtQjtBQUMvQixTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLGlCQUFpQixHQUFHO0FBQ2pDLFlBQVksb0JBQW9CO0FBQ2hDLFlBQVksd0JBQXdCO0FBQ3BDLFlBQVksZ0JBQWdCO0FBQzVCLFlBQVksVUFBVTtBQUN0QixZQUFZLDZCQUE2QjtBQUN6QyxTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLGFBQWEsR0FBRztBQUM3QixZQUFZLG9CQUFvQjtBQUNoQyxZQUFZLDBCQUEwQjtBQUN0QyxZQUFZLHVCQUF1QjtBQUNuQyxZQUFZLGFBQWE7QUFDekIsWUFBWSwwQkFBMEI7QUFDdEMsU0FBUyxDQUFDO0FBQ1YsS0FBSztBQUNMO0FBQ0EsSUFBSSxjQUFjLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRTtBQUN2QztBQUNBLFFBQVEsTUFBTSwwQkFBMEIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzlGLFFBQVEsTUFBTSx5QkFBeUIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzVGLFFBQVEsTUFBTSx5QkFBeUIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzVGLFFBQVEsTUFBTSxxQkFBcUIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNwRjtBQUNBLFFBQVEsSUFBSSxPQUFPLEdBQUcsRUFBRSxDQUFDO0FBQ3pCLFFBQVEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLElBQUksRUFBRTtBQUM1QyxZQUFZLE9BQU8sR0FBRyw2UUFBNlEsQ0FBQztBQUNwUyxTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsS0FBSyxFQUFFO0FBQ2xELFlBQVksT0FBTyxHQUFHLDhOQUE4TixDQUFDO0FBQ3JQLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxLQUFLLEVBQUU7QUFDbEQsWUFBWSxPQUFPLEdBQUcsK01BQStNLENBQUM7QUFDdE8sU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLElBQUksRUFBRTtBQUNqRCxZQUFZLE9BQU8sR0FBRywwT0FBME8sQ0FBQztBQUNqUSxTQUFTO0FBQ1Q7QUFDQSxRQUFRLE9BQU87QUFDZixZQUFZLGtCQUFrQixFQUFFLDBCQUEwQjtBQUMxRCxZQUFZLGlCQUFpQixFQUFFLHlCQUF5QjtBQUN4RCxZQUFZLGlCQUFpQixFQUFFLHlCQUF5QjtBQUN4RCxZQUFZLGFBQWEsRUFBRSxxQkFBcUI7QUFDaEQsWUFBWSxPQUFPO0FBQ25CLFNBQVMsQ0FBQztBQUNWLEtBQUs7QUFDTDtBQUNBLElBQUksaUJBQWlCLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRTtBQUNwQyxRQUFRLE1BQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUMxQixRQUFRLE1BQU0sU0FBUyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQztBQUNyQyxRQUFRLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLElBQUksU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDaEUsWUFBWSxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDN0UsWUFBWSxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ2hELFlBQVksU0FBUyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDN0MsU0FBUztBQUNULFFBQVEsT0FBTyxNQUFNLENBQUM7QUFDdEIsS0FBSztBQUNMOztBQzdFQTtBQUNPLE1BQU0sZ0JBQWdCLENBQUM7QUFDOUIsSUFBSSxXQUFXLEdBQUc7QUFDbEI7QUFDQSxRQUFRLElBQUksQ0FBQyxZQUFZLEdBQUc7QUFDNUIsWUFBWSxrQkFBa0I7QUFDOUIsWUFBWSxpQkFBaUI7QUFDN0IsWUFBWSxtQkFBbUI7QUFDL0IsWUFBWSxzQkFBc0I7QUFDbEMsWUFBWSx5QkFBeUI7QUFDckMsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLElBQUksQ0FBQyxrQkFBa0IsR0FBRztBQUNsQyxZQUFZLGtCQUFrQjtBQUM5QixZQUFZLHNCQUFzQjtBQUNsQyxZQUFZLGlDQUFpQztBQUM3QyxZQUFZLGtDQUFrQztBQUM5QyxZQUFZLG9CQUFvQjtBQUNoQyxTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLGNBQWMsR0FBRztBQUM5QixZQUFZLDRCQUE0QjtBQUN4QyxZQUFZLGtCQUFrQjtBQUM5QixZQUFZLE9BQU87QUFDbkIsWUFBWSx1QkFBdUI7QUFDbkMsWUFBWSxzQkFBc0I7QUFDbEMsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLElBQUksQ0FBQyxpQkFBaUIsR0FBRztBQUNqQyxZQUFZLGlCQUFpQjtBQUM3QixZQUFZLFdBQVc7QUFDdkIsWUFBWSxjQUFjO0FBQzFCLFlBQVksaUJBQWlCO0FBQzdCLFlBQVksa0JBQWtCO0FBQzlCLFNBQVMsQ0FBQztBQUNWLEtBQUs7QUFDTDtBQUNBLElBQUksY0FBYyxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUU7QUFDdkM7QUFDQSxRQUFRLE1BQU0sb0JBQW9CLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDbEYsUUFBUSxNQUFNLDBCQUEwQixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDOUYsUUFBUSxNQUFNLHNCQUFzQixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3RGLFFBQVEsTUFBTSx5QkFBeUIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzVGO0FBQ0EsUUFBUSxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7QUFDekIsUUFBUSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQzVDLFlBQVksT0FBTyxHQUFHLDhRQUE4USxDQUFDO0FBQ3JTLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxLQUFLLEVBQUU7QUFDbEQsWUFBWSxPQUFPLEdBQUcsNExBQTRMLENBQUM7QUFDbk4sU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLEtBQUssRUFBRTtBQUNsRCxZQUFZLE9BQU8sR0FBRyx1TUFBdU0sQ0FBQztBQUM5TixTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQ2pELFlBQVksT0FBTyxHQUFHLGtNQUFrTSxDQUFDO0FBQ3pOLFNBQVM7QUFDVDtBQUNBLFFBQVEsT0FBTztBQUNmLFlBQVksWUFBWSxFQUFFLG9CQUFvQjtBQUM5QyxZQUFZLGtCQUFrQixFQUFFLDBCQUEwQjtBQUMxRCxZQUFZLGNBQWMsRUFBRSxzQkFBc0I7QUFDbEQsWUFBWSxpQkFBaUIsRUFBRSx5QkFBeUI7QUFDeEQsWUFBWSxPQUFPO0FBQ25CLFNBQVMsQ0FBQztBQUNWLEtBQUs7QUFDTDtBQUNBLElBQUksaUJBQWlCLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRTtBQUNwQyxRQUFRLE1BQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUMxQixRQUFRLE1BQU0sU0FBUyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQztBQUNyQyxRQUFRLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLElBQUksU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDaEUsWUFBWSxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDN0UsWUFBWSxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ2hELFlBQVksU0FBUyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDN0MsU0FBUztBQUNULFFBQVEsT0FBTyxNQUFNLENBQUM7QUFDdEIsS0FBSztBQUNMOztBQzdFQTtBQUNPLE1BQU0sa0JBQWtCLENBQUM7QUFDaEMsSUFBSSxXQUFXLEdBQUc7QUFDbEI7QUFDQSxRQUFRLElBQUksQ0FBQyxvQkFBb0IsR0FBRztBQUNwQyxZQUFZLGdCQUFnQjtBQUM1QixZQUFZLG1CQUFtQjtBQUMvQixZQUFZLHFCQUFxQjtBQUNqQyxZQUFZLHVCQUF1QjtBQUNuQyxZQUFZLDhCQUE4QjtBQUMxQyxZQUFZLDBCQUEwQjtBQUN0QyxTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsSUFBSSxDQUFDLHNCQUFzQixHQUFHO0FBQ3RDLFlBQVksMEJBQTBCO0FBQ3RDLFlBQVksOEJBQThCO0FBQzFDLFlBQVksaUJBQWlCO0FBQzdCLFlBQVksaUJBQWlCO0FBQzdCLFlBQVksMEJBQTBCO0FBQ3RDLFNBQVMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxJQUFJLENBQUMsbUJBQW1CLEdBQUc7QUFDbkMsWUFBWSx5QkFBeUI7QUFDckMsWUFBWSxxQkFBcUI7QUFDakMsWUFBWSx1QkFBdUI7QUFDbkMsWUFBWSw2QkFBNkI7QUFDekMsWUFBWSxrQkFBa0I7QUFDOUIsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLElBQUksQ0FBQyxtQkFBbUIsR0FBRztBQUNuQyxZQUFZLG9CQUFvQjtBQUNoQyxZQUFZLGVBQWU7QUFDM0IsWUFBWSxzQkFBc0I7QUFDbEMsWUFBWSwwQkFBMEI7QUFDdEMsWUFBWSxnQkFBZ0I7QUFDNUIsU0FBUyxDQUFDO0FBQ1YsS0FBSztBQUNMO0FBQ0EsSUFBSSxjQUFjLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRTtBQUN2QztBQUNBLFFBQVEsTUFBTSw0QkFBNEIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ2xHLFFBQVEsTUFBTSw4QkFBOEIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3RHLFFBQVEsTUFBTSwyQkFBMkIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ2hHLFFBQVEsTUFBTSwyQkFBMkIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ2hHO0FBQ0EsUUFBUSxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7QUFDekIsUUFBUSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQzVDLFlBQVksT0FBTyxHQUFHLCtRQUErUSxDQUFDO0FBQ3RTLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxLQUFLLEVBQUU7QUFDbEQsWUFBWSxPQUFPLEdBQUcsd05BQXdOLENBQUM7QUFDL08sU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLEtBQUssRUFBRTtBQUNsRCxZQUFZLE9BQU8sR0FBRyw2TUFBNk0sQ0FBQztBQUNwTyxTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQ2pELFlBQVksT0FBTyxHQUFHLDhOQUE4TixDQUFDO0FBQ3JQLFNBQVM7QUFDVDtBQUNBLFFBQVEsT0FBTztBQUNmLFlBQVksb0JBQW9CLEVBQUUsNEJBQTRCO0FBQzlELFlBQVksc0JBQXNCLEVBQUUsOEJBQThCO0FBQ2xFLFlBQVksbUJBQW1CLEVBQUUsMkJBQTJCO0FBQzVELFlBQVksbUJBQW1CLEVBQUUsMkJBQTJCO0FBQzVELFlBQVksT0FBTztBQUNuQixTQUFTLENBQUM7QUFDVixLQUFLO0FBQ0w7QUFDQSxJQUFJLGlCQUFpQixDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUU7QUFDcEMsUUFBUSxNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDMUIsUUFBUSxNQUFNLFNBQVMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUM7QUFDckMsUUFBUSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxJQUFJLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO0FBQ2hFLFlBQVksTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzdFLFlBQVksTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztBQUNoRCxZQUFZLFNBQVMsQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzdDLFNBQVM7QUFDVCxRQUFRLE9BQU8sTUFBTSxDQUFDO0FBQ3RCLEtBQUs7QUFDTDs7QUM5RUE7QUFDTyxNQUFNLGlCQUFpQixDQUFDO0FBQy9CLElBQUksV0FBVyxHQUFHO0FBQ2xCO0FBQ0EsUUFBUSxJQUFJLENBQUMsUUFBUSxHQUFHO0FBQ3hCLFlBQVksMEJBQTBCO0FBQ3RDLFlBQVksd0JBQXdCO0FBQ3BDLFlBQVksa0JBQWtCO0FBQzlCLFlBQVksbUJBQW1CO0FBQy9CLFlBQVksOEJBQThCO0FBQzFDLFNBQVMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxJQUFJLENBQUMsUUFBUSxHQUFHO0FBQ3hCLFlBQVksMEJBQTBCO0FBQ3RDLFlBQVksb0JBQW9CO0FBQ2hDLFlBQVksZUFBZTtBQUMzQixZQUFZLGlCQUFpQjtBQUM3QixZQUFZLFlBQVk7QUFDeEIsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLElBQUksQ0FBQyxjQUFjLEdBQUc7QUFDOUIsWUFBWSwrQkFBK0I7QUFDM0MsWUFBWSxpQ0FBaUM7QUFDN0MsWUFBWSx3QkFBd0I7QUFDcEMsWUFBWSxrQkFBa0I7QUFDOUIsWUFBWSxlQUFlO0FBQzNCLFNBQVMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxJQUFJLENBQUMsVUFBVSxHQUFHO0FBQzFCLFlBQVksOEJBQThCO0FBQzFDLFlBQVksc0NBQXNDO0FBQ2xELFlBQVksMEJBQTBCO0FBQ3RDLFlBQVksK0JBQStCO0FBQzNDLFlBQVksNEJBQTRCO0FBQ3hDLFNBQVMsQ0FBQztBQUNWLEtBQUs7QUFDTDtBQUNBLElBQUksY0FBYyxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUU7QUFDdkM7QUFDQSxRQUFRLE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDMUUsUUFBUSxNQUFNLGdCQUFnQixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzFFLFFBQVEsTUFBTSxzQkFBc0IsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUN0RixRQUFRLE1BQU0sa0JBQWtCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDOUU7QUFDQSxRQUFRLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUN6QixRQUFRLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxJQUFJLEVBQUU7QUFDNUMsWUFBWSxPQUFPLEdBQUcsaVFBQWlRLENBQUM7QUFDeFIsU0FBUztBQUNULGFBQWEsSUFBSSxTQUFTLEtBQUssV0FBVyxDQUFDLEtBQUssRUFBRTtBQUNsRCxZQUFZLE9BQU8sR0FBRyxrTEFBa0wsQ0FBQztBQUN6TSxTQUFTO0FBQ1QsYUFBYSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsS0FBSyxFQUFFO0FBQ2xELFlBQVksT0FBTyxHQUFHLGlNQUFpTSxDQUFDO0FBQ3hOLFNBQVM7QUFDVCxhQUFhLElBQUksU0FBUyxLQUFLLFdBQVcsQ0FBQyxJQUFJLEVBQUU7QUFDakQsWUFBWSxPQUFPLEdBQUcsa0xBQWtMLENBQUM7QUFDek0sU0FBUztBQUNUO0FBQ0EsUUFBUSxPQUFPO0FBQ2YsWUFBWSxRQUFRLEVBQUUsZ0JBQWdCO0FBQ3RDLFlBQVksUUFBUSxFQUFFLGdCQUFnQjtBQUN0QyxZQUFZLGNBQWMsRUFBRSxzQkFBc0I7QUFDbEQsWUFBWSxVQUFVLEVBQUUsa0JBQWtCO0FBQzFDLFlBQVksT0FBTztBQUNuQixTQUFTLENBQUM7QUFDVixLQUFLO0FBQ0w7QUFDQSxJQUFJLGlCQUFpQixDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUU7QUFDcEMsUUFBUSxNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDMUIsUUFBUSxNQUFNLFNBQVMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUM7QUFDckMsUUFBUSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxJQUFJLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO0FBQ2hFLFlBQVksTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzdFLFlBQVksTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztBQUNoRCxZQUFZLFNBQVMsQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzdDLFNBQVM7QUFDVCxRQUFRLE9BQU8sTUFBTSxDQUFDO0FBQ3RCLEtBQUs7QUFDTDs7QUNyREE7QUFDTyxTQUFTLG9CQUFvQixDQUFDLFdBQVcsRUFBRTtBQUNsRCxJQUFJLFFBQVEsV0FBVztBQUN2QixRQUFRLEtBQUssV0FBVztBQUN4QixZQUFZLE9BQU8sSUFBSSxpQkFBaUIsRUFBRSxDQUFDO0FBQzNDLFFBQVEsS0FBSyxhQUFhO0FBQzFCLFlBQVksT0FBTyxJQUFJLG1CQUFtQixFQUFFLENBQUM7QUFDN0MsUUFBUSxLQUFLLFdBQVc7QUFDeEIsWUFBWSxPQUFPLElBQUksaUJBQWlCLEVBQUUsQ0FBQztBQUMzQyxRQUFRLEtBQUssVUFBVTtBQUN2QixZQUFZLE9BQU8sSUFBSSxnQkFBZ0IsRUFBRSxDQUFDO0FBQzFDLFFBQVEsS0FBSyxVQUFVO0FBQ3ZCLFlBQVksT0FBTyxJQUFJLGdCQUFnQixFQUFFLENBQUM7QUFDMUMsUUFBUSxLQUFLLFNBQVM7QUFDdEIsWUFBWSxPQUFPLElBQUksZUFBZSxFQUFFLENBQUM7QUFDekMsUUFBUSxLQUFLLFlBQVk7QUFDekIsWUFBWSxPQUFPLElBQUksa0JBQWtCLEVBQUUsQ0FBQztBQUM1QyxRQUFRLEtBQUssVUFBVTtBQUN2QixZQUFZLE9BQU8sSUFBSSxnQkFBZ0IsRUFBRSxDQUFDO0FBQzFDLFFBQVEsS0FBSyxXQUFXO0FBQ3hCLFlBQVksT0FBTyxJQUFJLGlCQUFpQixFQUFFLENBQUM7QUFDM0MsUUFBUSxLQUFLLGVBQWU7QUFDNUIsWUFBWSxPQUFPLElBQUkscUJBQXFCLEVBQUUsQ0FBQztBQUMvQyxRQUFRLEtBQUssYUFBYTtBQUMxQixZQUFZLE9BQU8sSUFBSSxtQkFBbUIsRUFBRSxDQUFDO0FBQzdDLFFBQVEsS0FBSyxVQUFVO0FBQ3ZCLFlBQVksT0FBTyxJQUFJLGdCQUFnQixFQUFFLENBQUM7QUFDMUMsUUFBUSxLQUFLLFVBQVU7QUFDdkIsWUFBWSxPQUFPLElBQUksZ0JBQWdCLEVBQUUsQ0FBQztBQUMxQyxRQUFRLEtBQUssY0FBYztBQUMzQixZQUFZLE9BQU8sSUFBSSxvQkFBb0IsRUFBRSxDQUFDO0FBQzlDLFFBQVEsS0FBSyxVQUFVO0FBQ3ZCLFlBQVksT0FBTyxJQUFJLGdCQUFnQixFQUFFLENBQUM7QUFDMUMsUUFBUSxLQUFLLGFBQWE7QUFDMUIsWUFBWSxPQUFPLElBQUksbUJBQW1CLEVBQUUsQ0FBQztBQUM3QyxRQUFRLEtBQUssU0FBUztBQUN0QixZQUFZLE9BQU8sSUFBSSxlQUFlLEVBQUUsQ0FBQztBQUN6QyxRQUFRLEtBQUssZUFBZTtBQUM1QixZQUFZLE9BQU8sSUFBSSxxQkFBcUIsRUFBRSxDQUFDO0FBQy9DLFFBQVEsS0FBSyxLQUFLO0FBQ2xCLFlBQVksT0FBTyxJQUFJLFdBQVcsRUFBRSxDQUFDO0FBQ3JDLFFBQVEsS0FBSyxjQUFjO0FBQzNCLFlBQVksT0FBTyxJQUFJLG9CQUFvQixFQUFFLENBQUM7QUFDOUMsUUFBUSxLQUFLLFVBQVU7QUFDdkIsWUFBWSxPQUFPLElBQUksZ0JBQWdCLEVBQUUsQ0FBQztBQUMxQyxRQUFRLEtBQUssWUFBWTtBQUN6QixZQUFZLE9BQU8sSUFBSSxrQkFBa0IsRUFBRSxDQUFDO0FBQzVDLFFBQVEsS0FBSyxXQUFXO0FBQ3hCLFlBQVksT0FBTyxJQUFJLGlCQUFpQixFQUFFLENBQUM7QUFDM0MsUUFBUTtBQUNSLFlBQVksTUFBTSxJQUFJLEtBQUssQ0FBQyxDQUFDLDJCQUEyQixFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6RSxLQUFLO0FBQ0w7O0FDNUVPLE1BQU0saUJBQWlCLEdBQUc7QUFDakMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsc3RCQUFzdEI7QUFDOXVCLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLHl1QkFBeXVCO0FBQ2x3QixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssR0FBRyw2dkJBQTZ2QjtBQUN0eEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsc3dCQUFzd0I7QUFDOXhCLENBQUM7O0FDTE0sTUFBTSxtQkFBbUIsR0FBRztBQUNuQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksR0FBRyxvc0JBQW9zQjtBQUM1dEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEdBQUcsMHhCQUEweEI7QUFDbnpCLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLDZ4QkFBNnhCO0FBQ3R6QixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksR0FBRyw4MUJBQTgxQjtBQUN0M0IsQ0FBQzs7QUNMTSxNQUFNLGdCQUFnQixHQUFHO0FBQ2hDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxHQUFHLDJ0QkFBMnRCO0FBQ252QixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssR0FBRyxva0JBQW9rQjtBQUM3bEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEdBQUcsd3JCQUF3ckI7QUFDanRCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxHQUFHLG1xQkFBbXFCO0FBQzNyQixDQUFDOztBQ0xNLE1BQU0sZ0JBQWdCLEdBQUc7QUFDaEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsNnhCQUE2eEI7QUFDcnpCLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLHd1QkFBd3VCO0FBQ2p3QixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssR0FBRyxtd0JBQW13QjtBQUM1eEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsOHVCQUE4dUI7QUFDdHdCLENBQUM7O0FDTE0sTUFBTSxpQkFBaUIsR0FBRztBQUNqQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksR0FBRyxxbEJBQXFsQjtBQUM3bUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEdBQUcsdW5CQUF1bkI7QUFDaHBCLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLCtuQkFBK25CO0FBQ3hwQixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksR0FBRyx3dkJBQXd2QjtBQUNoeEIsQ0FBQzs7QUNMTSxNQUFNLGtCQUFrQixHQUFHO0FBQ2xDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxHQUFHLDB0QkFBMHRCO0FBQ2x2QixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssR0FBRyw4cEJBQThwQjtBQUN2ckIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEdBQUcsOHVCQUE4dUI7QUFDdndCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxHQUFHLDR3QkFBNHdCO0FBQ3B5QixDQUFDOztBQ0xNLE1BQU0sZ0JBQWdCLEdBQUc7QUFDaEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsMnJCQUEyckI7QUFDbnRCLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLCt0QkFBK3RCO0FBQ3h2QixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssR0FBRyw2c0JBQTZzQjtBQUN0dUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsNHhCQUE0eEI7QUFDcHpCLENBQUM7O0FDTE0sTUFBTSxXQUFXLEdBQUc7QUFDM0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsa3ZCQUFrdkI7QUFDMXdCLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLGtzQkFBa3NCO0FBQzN0QixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssR0FBRyw2ckJBQTZyQjtBQUN0dEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsdXpCQUF1ekI7QUFDLzBCLENBQUM7O0FDTE0sTUFBTSxnQkFBZ0IsR0FBRztBQUNoQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksR0FBRyw4dUJBQTh1QjtBQUN0d0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEdBQUcsMnZCQUEydkI7QUFDcHhCLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLGt2QkFBa3ZCO0FBQzN3QixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksR0FBRyxzekJBQXN6QjtBQUM5MEIsQ0FBQzs7QUNMTSxNQUFNLG1CQUFtQixHQUFHO0FBQ25DLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxHQUFHLGtzQkFBa3NCO0FBQzF0QixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssR0FBRywydEJBQTJ0QjtBQUNwdkIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEdBQUcsb3RCQUFvdEI7QUFDN3VCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxHQUFHLDR5QkFBNHlCO0FBQ3AwQixDQUFDOztBQ0xNLE1BQU0sZ0JBQWdCLEdBQUc7QUFDaEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsc3NCQUFzc0I7QUFDOXRCLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLGd6QkFBZ3pCO0FBQ3owQixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssR0FBRyxneUJBQWd5QjtBQUN6ekIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsazJCQUFrMkI7QUFDMTNCLENBQUM7O0FDTE0sTUFBTSxlQUFlLEdBQUc7QUFDL0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsb3RCQUFvdEI7QUFDNXVCLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLDZ3QkFBNndCO0FBQ3R5QixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssR0FBRyxreUJBQWt5QjtBQUMzekIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsaTJCQUFpMkI7QUFDejNCLENBQUM7O0FDTE0sTUFBTSxvQkFBb0IsR0FBRztBQUNwQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksR0FBRyxxeUJBQXF5QjtBQUM3ekIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEdBQUcscTRCQUFxNEI7QUFDOTVCLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLDIzQkFBMjNCO0FBQ3A1QixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksR0FBRyw2NkJBQTY2QjtBQUNyOEIsQ0FBQzs7QUNMTSxNQUFNLGVBQWUsR0FBRztBQUMvQixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksR0FBRyw4dkJBQTh2QjtBQUN0eEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEdBQUcseXZCQUF5dkI7QUFDbHhCLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLGd5QkFBZ3lCO0FBQ3p6QixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksR0FBRyxxekJBQXF6QjtBQUM3MEIsQ0FBQzs7QUNMTSxNQUFNLGlCQUFpQixHQUFHO0FBQ2pDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxHQUFHLDR4QkFBNHhCO0FBQ3B6QixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssR0FBRyxxekJBQXF6QjtBQUM5MEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEdBQUcsaXpCQUFpekI7QUFDMTBCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxHQUFHLCswQkFBKzBCO0FBQ3YyQixDQUFDOztBQ0xNLE1BQU0sbUJBQW1CLEdBQUc7QUFDbkMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsMHJCQUEwckI7QUFDbHRCLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLHd6QkFBd3pCO0FBQ2oxQixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssR0FBRyw2MEJBQTYwQjtBQUN0MkIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsb3pCQUFvekI7QUFDNTBCLENBQUM7O0FDTE0sTUFBTSxxQkFBcUIsR0FBRztBQUNyQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksR0FBRyxndkJBQWd2QjtBQUN4d0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEdBQUcsbzFCQUFvMUI7QUFDNzJCLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLG0yQkFBbTJCO0FBQzUzQixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksR0FBRyxzMEJBQXMwQjtBQUM5MUIsQ0FBQzs7QUNMTSxNQUFNLGdCQUFnQixHQUFHO0FBQ2hDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxHQUFHLHF2QkFBcXZCO0FBQzd3QixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssR0FBRyw0eEJBQTR4QjtBQUNyekIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEdBQUcsczBCQUFzMEI7QUFDLzFCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxHQUFHLDB5QkFBMHlCO0FBQ2wwQixDQUFDOztBQ0xNLE1BQU0sb0JBQW9CLEdBQUc7QUFDcEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcseXVCQUF5dUI7QUFDandCLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLGt5QkFBa3lCO0FBQzN6QixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssR0FBRyw2ekJBQTZ6QjtBQUN0MUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsKzBCQUErMEI7QUFDdjJCLENBQUM7O0FDTE0sTUFBTSxrQkFBa0IsR0FBRztBQUNsQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksR0FBRyxpdUJBQWl1QjtBQUN6dkIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEdBQUcsMDBCQUEwMEI7QUFDbjJCLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLG0wQkFBbTBCO0FBQzUxQixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksR0FBRywrekJBQSt6QjtBQUN2MUIsQ0FBQzs7QUNMTSxNQUFNLGdCQUFnQixHQUFHO0FBQ2hDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxHQUFHLGtzQkFBa3NCO0FBQzF0QixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssR0FBRywyMUJBQTIxQjtBQUNwM0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEdBQUcsbTFCQUFtMUI7QUFDNTJCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxHQUFHLHMwQkFBczBCO0FBQzkxQixDQUFDOztBQ0xNLE1BQU0saUJBQWlCLEdBQUc7QUFDakMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsK3RCQUErdEI7QUFDdnZCLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLHN5QkFBc3lCO0FBQy96QixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssR0FBRyx3MEJBQXcwQjtBQUNqMkIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsaTFCQUFpMUI7QUFDejJCLENBQUM7O0FDTE0sTUFBTSxxQkFBcUIsR0FBRztBQUNyQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksR0FBRyw0MEJBQTQwQjtBQUNwMkIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEdBQUcsMDNCQUEwM0I7QUFDbjVCLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLHE0QkFBcTRCO0FBQzk1QixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksR0FBRyw2NEJBQTY0QjtBQUNyNkIsQ0FBQzs7QUNORDtBQXdCQTtBQUNPLE1BQU0sa0JBQWtCLEdBQUc7QUFDbEMsSUFBSSxXQUFXLEVBQUUsaUJBQWlCO0FBQ2xDLElBQUksYUFBYSxFQUFFLG1CQUFtQjtBQUN0QyxJQUFJLFVBQVUsRUFBRSxnQkFBZ0I7QUFDaEMsSUFBSSxVQUFVLEVBQUUsZ0JBQWdCO0FBQ2hDLElBQUksV0FBVyxFQUFFLGlCQUFpQjtBQUNsQyxJQUFJLFlBQVksRUFBRSxrQkFBa0I7QUFDcEMsSUFBSSxVQUFVLEVBQUUsZ0JBQWdCO0FBQ2hDLElBQUksS0FBSyxFQUFFLFdBQVc7QUFDdEIsSUFBSSxVQUFVLEVBQUUsZ0JBQWdCO0FBQ2hDLElBQUksYUFBYSxFQUFFLG1CQUFtQjtBQUN0QyxJQUFJLFVBQVUsRUFBRSxnQkFBZ0I7QUFDaEMsSUFBSSxTQUFTLEVBQUUsZUFBZTtBQUM5QixJQUFJLGNBQWMsRUFBRSxvQkFBb0I7QUFDeEMsSUFBSSxTQUFTLEVBQUUsZUFBZTtBQUM5QixJQUFJLFdBQVcsRUFBRSxpQkFBaUI7QUFDbEMsSUFBSSxhQUFhLEVBQUUsbUJBQW1CO0FBQ3RDLElBQUksZUFBZSxFQUFFLHFCQUFxQjtBQUMxQyxJQUFJLFVBQVUsRUFBRSxnQkFBZ0I7QUFDaEMsSUFBSSxjQUFjLEVBQUUsb0JBQW9CO0FBQ3hDLElBQUksWUFBWSxFQUFFLGtCQUFrQjtBQUNwQyxJQUFJLFVBQVUsRUFBRSxnQkFBZ0I7QUFDaEMsSUFBSSxXQUFXLEVBQUUsaUJBQWlCO0FBQ2xDLElBQUksZUFBZSxFQUFFLHFCQUFxQjtBQUMxQyxDQUFDLENBQUM7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTLHFCQUFxQixDQUFDLFdBQVcsRUFBRSxTQUFTLEVBQUU7QUFDOUQsSUFBSSxJQUFJLEVBQUUsQ0FBQztBQUNYLElBQUksT0FBTyxDQUFDLEVBQUUsR0FBRyxrQkFBa0IsQ0FBQyxXQUFXLENBQUMsTUFBTSxJQUFJLElBQUksRUFBRSxLQUFLLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUNyRyxDQUFDO0FBU0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVMsdUJBQXVCLENBQUMsV0FBVyxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUUsYUFBYSxFQUFFO0FBQ3pGLElBQUksT0FBTyxDQUFDLEtBQUssRUFBRSxTQUFTLENBQUMsRUFBRSxFQUFFLFFBQVEsQ0FBQyxzQ0FBc0MsRUFBRSxhQUFhLENBQUMsaVBBQWlQLEVBQUUsU0FBUyxDQUFDLHFPQUFxTyxFQUFFLFNBQVMsQ0FBQyxtRUFBbUUsRUFBRSxTQUFTLENBQUMsOEVBQThFLENBQUMsQ0FBQztBQUM3dUI7O0FDOUVPLE1BQU0sYUFBYSxDQUFDO0FBQzNCLElBQUksV0FBVyxDQUFDLFFBQVEsRUFBRTtBQUMxQixRQUFRLElBQUksQ0FBQyxNQUFNLEdBQUcsNENBQTRDLENBQUM7QUFDbkUsUUFBUSxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7QUFDL0IsUUFBUSxJQUFJLENBQUMsTUFBTSxHQUFHLFFBQVEsQ0FBQyxZQUFZLElBQUksRUFBRSxDQUFDO0FBQ2xELFFBQVEsSUFBSSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsV0FBVyxJQUFJLGVBQWUsQ0FBQztBQUM3RCxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsSUFBSSxZQUFZLENBQUMsUUFBUSxFQUFFO0FBQzNCLFFBQVEsSUFBSSxDQUFDLE1BQU0sR0FBRyxRQUFRLENBQUMsWUFBWSxJQUFJLEVBQUUsQ0FBQztBQUNsRCxRQUFRLElBQUksQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLFdBQVcsSUFBSSxlQUFlLENBQUM7QUFDN0QsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLElBQUksWUFBWSxHQUFHO0FBQ25CLFFBQVEsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUM3QixLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsSUFBSSxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRTtBQUNwRDtBQUNBLFFBQVEsSUFBSSxXQUFXLEdBQUcsQ0FBQyxDQUFDO0FBQzVCLFFBQVEsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDakQsWUFBWSxXQUFXLEdBQUcsQ0FBQyxDQUFDLFdBQVcsSUFBSSxDQUFDLElBQUksV0FBVyxJQUFJLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckYsWUFBWSxXQUFXLEdBQUcsV0FBVyxHQUFHLFdBQVcsQ0FBQztBQUNwRCxTQUFTO0FBQ1QsUUFBUSxPQUFPLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQztBQUMxRCxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsSUFBSSxNQUFNLGNBQWMsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxhQUFhLEVBQUU7QUFDdkUsUUFBUSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUM7QUFDbkI7QUFDQSxRQUFRLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLEVBQUU7QUFDbEMsWUFBWSxNQUFNLElBQUksS0FBSyxDQUFDLGtDQUFrQyxDQUFDLENBQUM7QUFDaEUsU0FBUztBQUNUO0FBQ0EsUUFBUSxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQztBQUM5RSxRQUFRLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUU7QUFDdEMsWUFBWSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVDLFNBQVM7QUFDVCxRQUFRLElBQUk7QUFDWjtBQUNBLFlBQVksTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLGFBQWEsQ0FBQyxDQUFDO0FBQzNGLFlBQVksTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLGFBQWEsQ0FBQyxDQUFDO0FBQ3JGO0FBQ0EsWUFBWSxNQUFNLE9BQU8sR0FBRztBQUM1QixnQkFBZ0IsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLO0FBQ2pDLGdCQUFnQixRQUFRLEVBQUU7QUFDMUIsb0JBQW9CLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsWUFBWSxFQUFFO0FBQzdELG9CQUFvQixFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLFVBQVUsRUFBRTtBQUN6RCxpQkFBaUI7QUFDakIsZ0JBQWdCLFVBQVUsRUFBRSxJQUFJO0FBQ2hDLGdCQUFnQixXQUFXLEVBQUUsR0FBRztBQUNoQyxhQUFhLENBQUM7QUFDZDtBQUNBLFlBQVksTUFBTSxRQUFRLEdBQUcsTUFBTSxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtBQUN0RCxnQkFBZ0IsTUFBTSxFQUFFLE1BQU07QUFDOUIsZ0JBQWdCLE9BQU8sRUFBRTtBQUN6QixvQkFBb0IsY0FBYyxFQUFFLGtCQUFrQjtBQUN0RCxvQkFBb0IsZUFBZSxFQUFFLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM1RCxpQkFBaUI7QUFDakIsZ0JBQWdCLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQztBQUM3QyxhQUFhLENBQUMsQ0FBQztBQUNmO0FBQ0EsWUFBWSxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRTtBQUM5QixnQkFBZ0IsTUFBTSxTQUFTLEdBQUcsTUFBTSxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUM7QUFDeEQsZ0JBQWdCLE1BQU0sSUFBSSxLQUFLLENBQUMsQ0FBQyxrQkFBa0IsRUFBRSxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckYsYUFBYTtBQUNiLFlBQVksTUFBTSxJQUFJLEdBQUcsTUFBTSxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUM7QUFDL0MsWUFBWSxNQUFNLFlBQVksR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sSUFBSSxJQUFJLEVBQUUsS0FBSyxLQUFLLENBQUMsR0FBRyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxNQUFNLElBQUksSUFBSSxFQUFFLEtBQUssS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sS0FBSyxrQ0FBa0MsQ0FBQztBQUN2TTtBQUNBLFlBQVksSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyxDQUFDO0FBQ25ELFlBQVksT0FBTyxZQUFZLENBQUM7QUFDaEMsU0FBUztBQUNULFFBQVEsT0FBTyxLQUFLLEVBQUU7QUFDdEIsWUFBWSxPQUFPLENBQUMsS0FBSyxDQUFDLDJCQUEyQixFQUFFLEtBQUssQ0FBQyxDQUFDO0FBQzlELFlBQVksTUFBTSxLQUFLLENBQUM7QUFDeEIsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxJQUFJLGVBQWUsQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLGFBQWEsRUFBRTtBQUN6RCxRQUFRLE9BQU8sQ0FBQyxxQkFBcUIsRUFBRSxhQUFhLENBQUM7QUFDckQsd0JBQXdCLEVBQUUsU0FBUyxDQUFDLGdCQUFnQixFQUFFLGFBQWEsQ0FBQztBQUNwRSxnRkFBZ0YsRUFBRSxhQUFhLENBQUM7QUFDaEcsdUhBQXVILEVBQUUsYUFBYSxDQUFDO0FBQ3ZJLDJDQUEyQyxFQUFFLGFBQWEsQ0FBQztBQUMzRCxvQ0FBb0MsRUFBRSxhQUFhLENBQUM7QUFDcEQsOEZBQThGLENBQUMsQ0FBQztBQUNoRyxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsSUFBSSxhQUFhLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxhQUFhLEVBQUU7QUFDckQsUUFBUSxNQUFNLGNBQWMsR0FBRyxPQUFPLENBQUMsTUFBTSxHQUFHLElBQUk7QUFDcEQsY0FBYyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsR0FBRyxLQUFLO0FBQ2hELGNBQWMsT0FBTyxDQUFDO0FBQ3RCLFFBQVEsT0FBTyxDQUFDLHNCQUFzQixFQUFFLFNBQVMsQ0FBQyxlQUFlLEVBQUUsYUFBYSxDQUFDO0FBQ2pGO0FBQ0EsRUFBRSxjQUFjLENBQUM7QUFDakI7QUFDQSwyREFBMkQsRUFBRSxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUUsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLElBQUksVUFBVSxHQUFHO0FBQ2pCLFFBQVEsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsQ0FBQztBQUMzQixLQUFLO0FBQ0w7O0FDL0dPLE1BQU0sY0FBYyxDQUFDO0FBQzVCLElBQUksV0FBVyxDQUFDLEdBQUcsRUFBRSxRQUFRLEVBQUU7QUFDL0IsUUFBUSxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztBQUNsQyxRQUFRLElBQUksQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDO0FBQ3ZCLFFBQVEsSUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7QUFDakM7QUFDQSxRQUFRLElBQUksUUFBUSxDQUFDLFlBQVksRUFBRTtBQUNuQyxZQUFZLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDN0QsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxJQUFJLFlBQVksQ0FBQyxRQUFRLEVBQUU7QUFDM0IsUUFBUSxJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztBQUNqQztBQUNBLFFBQVEsSUFBSSxRQUFRLENBQUMsWUFBWSxFQUFFO0FBQ25DLFlBQVksSUFBSSxJQUFJLENBQUMsYUFBYSxFQUFFO0FBQ3BDLGdCQUFnQixJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUMxRCxhQUFhO0FBQ2IsaUJBQWlCO0FBQ2pCLGdCQUFnQixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2pFLGFBQWE7QUFDYixTQUFTO0FBQ1QsYUFBYTtBQUNiLFlBQVksSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7QUFDdEMsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBLElBQUksY0FBYyxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsVUFBVSxFQUFFO0FBQ25ELFFBQVEsSUFBSTtBQUNaO0FBQ0EsWUFBWSxJQUFJLGdCQUFnQixHQUFHLEtBQUssQ0FBQztBQUN6QyxZQUFZLEtBQUssTUFBTSxJQUFJLElBQUksV0FBVyxFQUFFO0FBQzVDLGdCQUFnQixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsS0FBSyxTQUFTLEVBQUU7QUFDckQsb0JBQW9CLGdCQUFnQixHQUFHLElBQUksQ0FBQztBQUM1QyxvQkFBb0IsTUFBTTtBQUMxQixpQkFBaUI7QUFDakIsYUFBYTtBQUNiLFlBQVksSUFBSSxDQUFDLGdCQUFnQixFQUFFO0FBQ25DLGdCQUFnQixPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsd0JBQXdCLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JFLGdCQUFnQixPQUFPO0FBQ3ZCLG9CQUFvQixTQUFTO0FBQzdCLG9CQUFvQixPQUFPLEVBQUUsQ0FBQyx3QkFBd0IsRUFBRSxTQUFTLENBQUMsQ0FBQztBQUNuRSxvQkFBb0IsaUJBQWlCLEVBQUUsRUFBRTtBQUN6QyxvQkFBb0IsZUFBZSxFQUFFLEVBQUU7QUFDdkMsaUJBQWlCLENBQUM7QUFDbEIsYUFBYTtBQUNiO0FBQ0EsWUFBWSxRQUFRLFNBQVM7QUFDN0IsZ0JBQWdCLEtBQUssV0FBVyxDQUFDLElBQUk7QUFDckMsb0JBQW9CLE1BQU0sVUFBVSxHQUFHLE9BQU8sT0FBTyxLQUFLLFFBQVEsR0FBRyxPQUFPLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQztBQUM1RixvQkFBb0IsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUNwRSxnQkFBZ0IsS0FBSyxXQUFXLENBQUMsS0FBSztBQUN0QyxvQkFBb0IsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUMsQ0FBQztBQUNsRSxnQkFBZ0IsS0FBSyxXQUFXLENBQUMsS0FBSztBQUN0QyxvQkFBb0IsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUMsQ0FBQztBQUNsRSxnQkFBZ0IsS0FBSyxXQUFXLENBQUMsSUFBSTtBQUNyQyxvQkFBb0IsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUMsQ0FBQztBQUNqRSxnQkFBZ0I7QUFDaEI7QUFDQSxvQkFBb0IsTUFBTSxJQUFJLEtBQUssQ0FBQyxDQUFDLHdCQUF3QixFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1RSxhQUFhO0FBQ2IsU0FBUztBQUNULFFBQVEsT0FBTyxLQUFLLEVBQUU7QUFDdEIsWUFBWSxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsd0JBQXdCLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztBQUM3RDtBQUNBLFlBQVksT0FBTztBQUNuQixnQkFBZ0IsU0FBUyxFQUFFLFNBQVM7QUFDcEMsZ0JBQWdCLE9BQU8sRUFBRSxDQUFDLGdEQUFnRCxDQUFDO0FBQzNFLGdCQUFnQixpQkFBaUIsRUFBRSxFQUFFO0FBQ3JDLGdCQUFnQixlQUFlLEVBQUUsQ0FBQyw0Q0FBNEMsQ0FBQztBQUMvRSxnQkFBZ0IsUUFBUSxFQUFFLE9BQU8sT0FBTyxLQUFLLFFBQVEsR0FBRyxPQUFPLENBQUMsSUFBSSxHQUFHLFNBQVM7QUFDaEYsYUFBYSxDQUFDO0FBQ2QsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBLElBQUksV0FBVyxDQUFDLE9BQU8sRUFBRSxVQUFVLEVBQUU7QUFDckMsUUFBUSxNQUFNLE1BQU0sR0FBRztBQUN2QixZQUFZLFNBQVMsRUFBRSxXQUFXLENBQUMsSUFBSTtBQUN2QyxZQUFZLE9BQU8sRUFBRSxJQUFJLENBQUMsbUJBQW1CLENBQUMsT0FBTyxDQUFDO0FBQ3RELFlBQVksaUJBQWlCLEVBQUUsRUFBRTtBQUNqQyxZQUFZLGVBQWUsRUFBRSxFQUFFO0FBQy9CLFNBQVMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxLQUFLLE1BQU0sU0FBUyxJQUFJLFVBQVUsRUFBRTtBQUM1QyxZQUFZLElBQUk7QUFDaEI7QUFDQSxnQkFBZ0IsSUFBSTtBQUNwQixvQkFBb0IsTUFBTSxpQkFBaUIsR0FBRyxvQkFBb0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUM5RSxvQkFBb0IsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxHQUFHLGlCQUFpQixDQUFDLGNBQWMsQ0FBQyxPQUFPLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3RILGlCQUFpQjtBQUNqQixnQkFBZ0IsT0FBTyxDQUFDLEVBQUU7QUFDMUI7QUFDQSxvQkFBb0IsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxHQUFHLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMvSCxpQkFBaUI7QUFDakIsYUFBYTtBQUNiLFlBQVksT0FBTyxLQUFLLEVBQUU7QUFDMUIsZ0JBQWdCLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQywrQkFBK0IsRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7QUFDckYsZ0JBQWdCLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUMsR0FBRyxJQUFJLENBQUMseUJBQXlCLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDM0gsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBLFFBQVEsTUFBTSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUM7QUFDeEYsUUFBUSxPQUFPLE1BQU0sQ0FBQztBQUN0QixLQUFLO0FBQ0w7QUFDQSxJQUFJLFlBQVksQ0FBQyxJQUFJLEVBQUUsVUFBVSxFQUFFO0FBQ25DLFFBQVEsTUFBTSxNQUFNLEdBQUc7QUFDdkIsWUFBWSxTQUFTLEVBQUUsV0FBVyxDQUFDLEtBQUs7QUFDeEMsWUFBWSxRQUFRLEVBQUUsSUFBSSxDQUFDLElBQUk7QUFDL0IsWUFBWSxPQUFPLEVBQUUsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyx3RkFBd0YsQ0FBQztBQUN2SSxZQUFZLGlCQUFpQixFQUFFLEVBQUU7QUFDakMsWUFBWSxlQUFlLEVBQUUsRUFBRTtBQUMvQixTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsS0FBSyxNQUFNLFNBQVMsSUFBSSxVQUFVLEVBQUU7QUFDNUMsWUFBWSxJQUFJO0FBQ2hCO0FBQ0EsZ0JBQWdCLElBQUk7QUFDcEIsb0JBQW9CLE1BQU0saUJBQWlCLEdBQUcsb0JBQW9CLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDOUUsb0JBQW9CLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUMsR0FBRyxpQkFBaUIsQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNwSCxpQkFBaUI7QUFDakIsZ0JBQWdCLE9BQU8sQ0FBQyxFQUFFO0FBQzFCO0FBQ0Esb0JBQW9CLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUMsR0FBRyxJQUFJLENBQUMseUJBQXlCLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxTQUFTLEVBQUUsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2xJLGlCQUFpQjtBQUNqQixhQUFhO0FBQ2IsWUFBWSxPQUFPLEtBQUssRUFBRTtBQUMxQixnQkFBZ0IsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLCtCQUErQixFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztBQUNyRixnQkFBZ0IsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxHQUFHLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLFNBQVMsRUFBRSxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDOUgsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBLFFBQVEsTUFBTSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUM7QUFDeEYsUUFBUSxPQUFPLE1BQU0sQ0FBQztBQUN0QixLQUFLO0FBQ0w7QUFDQSxJQUFJLFlBQVksQ0FBQyxJQUFJLEVBQUUsVUFBVSxFQUFFO0FBQ25DLFFBQVEsTUFBTSxNQUFNLEdBQUc7QUFDdkIsWUFBWSxTQUFTLEVBQUUsV0FBVyxDQUFDLEtBQUs7QUFDeEMsWUFBWSxRQUFRLEVBQUUsSUFBSSxDQUFDLElBQUk7QUFDL0IsWUFBWSxPQUFPLEVBQUUsQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLHVGQUF1RixDQUFDO0FBQzNJLFlBQVksaUJBQWlCLEVBQUUsRUFBRTtBQUNqQyxZQUFZLGVBQWUsRUFBRSxFQUFFO0FBQy9CLFNBQVMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxLQUFLLE1BQU0sU0FBUyxJQUFJLFVBQVUsRUFBRTtBQUM1QyxZQUFZLElBQUk7QUFDaEI7QUFDQSxnQkFBZ0IsSUFBSTtBQUNwQixvQkFBb0IsTUFBTSxpQkFBaUIsR0FBRyxvQkFBb0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUM5RSxvQkFBb0IsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxHQUFHLGlCQUFpQixDQUFDLGNBQWMsQ0FBQyxJQUFJLEVBQUUsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3BILGlCQUFpQjtBQUNqQixnQkFBZ0IsT0FBTyxDQUFDLEVBQUU7QUFDMUI7QUFDQSxvQkFBb0IsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxHQUFHLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLFNBQVMsRUFBRSxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDbEksaUJBQWlCO0FBQ2pCLGFBQWE7QUFDYixZQUFZLE9BQU8sS0FBSyxFQUFFO0FBQzFCLGdCQUFnQixPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsK0JBQStCLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO0FBQ3JGLGdCQUFnQixNQUFNLENBQUMsaUJBQWlCLENBQUMsU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM5SCxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0EsUUFBUSxNQUFNLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsQ0FBQztBQUN4RixRQUFRLE9BQU8sTUFBTSxDQUFDO0FBQ3RCLEtBQUs7QUFDTDtBQUNBLElBQUksV0FBVyxDQUFDLElBQUksRUFBRSxVQUFVLEVBQUU7QUFDbEMsUUFBUSxNQUFNLE1BQU0sR0FBRztBQUN2QixZQUFZLFNBQVMsRUFBRSxXQUFXLENBQUMsSUFBSTtBQUN2QyxZQUFZLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSTtBQUMvQixZQUFZLE9BQU8sRUFBRSxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsc0dBQXNHLENBQUM7QUFDMUosWUFBWSxpQkFBaUIsRUFBRSxFQUFFO0FBQ2pDLFlBQVksZUFBZSxFQUFFLEVBQUU7QUFDL0IsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLEtBQUssTUFBTSxTQUFTLElBQUksVUFBVSxFQUFFO0FBQzVDLFlBQVksSUFBSTtBQUNoQjtBQUNBLGdCQUFnQixJQUFJO0FBQ3BCLG9CQUFvQixNQUFNLGlCQUFpQixHQUFHLG9CQUFvQixDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQzlFLG9CQUFvQixNQUFNLENBQUMsaUJBQWlCLENBQUMsU0FBUyxDQUFDLEdBQUcsaUJBQWlCLENBQUMsY0FBYyxDQUFDLElBQUksRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbkgsaUJBQWlCO0FBQ2pCLGdCQUFnQixPQUFPLENBQUMsRUFBRTtBQUMxQjtBQUNBLG9CQUFvQixNQUFNLENBQUMsaUJBQWlCLENBQUMsU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNqSSxpQkFBaUI7QUFDakIsYUFBYTtBQUNiLFlBQVksT0FBTyxLQUFLLEVBQUU7QUFDMUIsZ0JBQWdCLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQywrQkFBK0IsRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7QUFDckYsZ0JBQWdCLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUMsR0FBRyxJQUFJLENBQUMseUJBQXlCLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxTQUFTLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzdILGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQSxRQUFRLE1BQU0sQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0FBQ3hGLFFBQVEsT0FBTyxNQUFNLENBQUM7QUFDdEIsS0FBSztBQUNMO0FBQ0EsSUFBSSxtQkFBbUIsQ0FBQyxPQUFPLEVBQUU7QUFDakM7QUFDQSxRQUFRLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDbkQsUUFBUSxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDakUsUUFBUSxNQUFNLGtCQUFrQixHQUFHLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUMzRTtBQUNBLFFBQVEsT0FBTyxDQUFDLDZCQUE2QixFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsdUJBQXVCLEVBQUUsYUFBYSxDQUFDLHNDQUFzQyxFQUFFLGtCQUFrQixDQUFDLHdFQUF3RSxDQUFDLENBQUM7QUFDN08sS0FBSztBQUNMO0FBQ0EsSUFBSSxhQUFhLENBQUMsT0FBTyxFQUFFO0FBQzNCLFFBQVEsTUFBTSxhQUFhLEdBQUc7QUFDOUIsWUFBWSxVQUFVLEVBQUUsNERBQTREO0FBQ3BGLFlBQVksUUFBUSxFQUFFLDZDQUE2QztBQUNuRSxZQUFZLGFBQWEsRUFBRSwyREFBMkQ7QUFDdEYsWUFBWSxVQUFVLEVBQUUsMERBQTBEO0FBQ2xGLFlBQVksVUFBVSxFQUFFLDhDQUE4QztBQUN0RSxZQUFZLE9BQU8sRUFBRSwwREFBMEQ7QUFDL0UsWUFBWSxRQUFRLEVBQUUsaUVBQWlFO0FBQ3ZGLFlBQVksT0FBTyxFQUFFLDBEQUEwRDtBQUMvRSxTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsTUFBTSxhQUFhLEdBQUcsRUFBRSxDQUFDO0FBQ2pDLFFBQVEsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxJQUFJO0FBQ3BELFlBQVksTUFBTSxPQUFPLEdBQUcsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2pELFlBQVksSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO0FBQ3ZDLGdCQUFnQixhQUFhLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzFDLGFBQWE7QUFDYixTQUFTLENBQUMsQ0FBQztBQUNYO0FBQ0EsUUFBUSxPQUFPLGFBQWEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLGFBQWEsR0FBRyxDQUFDLFlBQVksRUFBRSxlQUFlLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztBQUM1RyxLQUFLO0FBQ0w7QUFDQSxJQUFJLG9CQUFvQixDQUFDLE9BQU8sRUFBRTtBQUNsQyxRQUFRLE1BQU0sWUFBWSxHQUFHO0FBQzdCLFlBQVksVUFBVSxFQUFFLDJDQUEyQztBQUNuRSxZQUFZLFdBQVcsRUFBRSxnREFBZ0Q7QUFDekUsWUFBWSxPQUFPLEVBQUUsa0RBQWtEO0FBQ3ZFLFlBQVksT0FBTyxFQUFFLGlEQUFpRDtBQUN0RSxZQUFZLE9BQU8sRUFBRSxrREFBa0Q7QUFDdkUsWUFBWSxVQUFVLEVBQUUsZ0RBQWdEO0FBQ3hFLFlBQVksUUFBUSxFQUFFLGdEQUFnRDtBQUN0RSxZQUFZLFVBQVUsRUFBRSw0Q0FBNEM7QUFDcEUsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLE1BQU0sVUFBVSxHQUFHLEVBQUUsQ0FBQztBQUM5QixRQUFRLE1BQU0sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksSUFBSTtBQUNsRCxZQUFZLE1BQU0sT0FBTyxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMvQyxZQUFZLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO0FBQ3pELFlBQVksVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUM7QUFDOUMsU0FBUyxDQUFDLENBQUM7QUFDWDtBQUNBLFFBQVEsSUFBSSxZQUFZLEdBQUcsWUFBWSxDQUFDO0FBQ3hDLFFBQVEsSUFBSSxRQUFRLEdBQUcsQ0FBQyxDQUFDO0FBQ3pCLFFBQVEsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxJQUFJO0FBQ2hELFlBQVksTUFBTSxLQUFLLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzNDLFlBQVksSUFBSSxLQUFLLEdBQUcsUUFBUSxFQUFFO0FBQ2xDLGdCQUFnQixRQUFRLEdBQUcsS0FBSyxDQUFDO0FBQ2pDLGdCQUFnQixZQUFZLEdBQUcsSUFBSSxDQUFDO0FBQ3BDLGFBQWE7QUFDYixTQUFTLENBQUMsQ0FBQztBQUNYLFFBQVEsT0FBTyxZQUFZLENBQUM7QUFDNUIsS0FBSztBQUNMO0FBQ0EsSUFBSSx5QkFBeUIsQ0FBQyxPQUFPLEVBQUU7QUFDdkM7QUFDQSxRQUFRLE1BQU0sYUFBYSxHQUFHLDBDQUEwQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN2RixRQUFRLE1BQU0sZUFBZSxHQUFHLCtDQUErQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM5RixRQUFRLE1BQU0saUJBQWlCLEdBQUcsNkNBQTZDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzlGLFFBQVEsTUFBTSxlQUFlLEdBQUcsMkNBQTJDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzFGO0FBQ0EsUUFBUSxJQUFJLGFBQWEsSUFBSSxlQUFlLEVBQUU7QUFDOUMsWUFBWSxPQUFPLGdGQUFnRixDQUFDO0FBQ3BHLFNBQVM7QUFDVCxhQUFhLElBQUksYUFBYSxFQUFFO0FBQ2hDLFlBQVksT0FBTyx3RUFBd0UsQ0FBQztBQUM1RixTQUFTO0FBQ1QsYUFBYSxJQUFJLGVBQWUsRUFBRTtBQUNsQyxZQUFZLE9BQU8saUVBQWlFLENBQUM7QUFDckYsU0FBUztBQUNULGFBQWEsSUFBSSxpQkFBaUIsRUFBRTtBQUNwQyxZQUFZLE9BQU8sNkRBQTZELENBQUM7QUFDakYsU0FBUztBQUNULGFBQWEsSUFBSSxlQUFlLEVBQUU7QUFDbEMsWUFBWSxPQUFPLCtEQUErRCxDQUFDO0FBQ25GLFNBQVM7QUFDVCxhQUFhO0FBQ2IsWUFBWSxPQUFPLG1FQUFtRSxDQUFDO0FBQ3ZGLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQSxJQUFJLE1BQU0seUJBQXlCLENBQUMsV0FBVyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUU7QUFDdkUsUUFBUSxJQUFJLEVBQUUsQ0FBQztBQUNmO0FBQ0EsUUFBUSxNQUFNLGVBQWUsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVk7QUFDMUQsWUFBWSxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksS0FBSyxZQUFZLENBQUMsT0FBTztBQUMvRCxhQUFhLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxhQUFhLE1BQU0sSUFBSSxJQUFJLEVBQUUsS0FBSyxLQUFLLENBQUMsR0FBRyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsWUFBWSxFQUFFLENBQUMsQ0FBQztBQUMvRjtBQUNBLFFBQVEsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLGdCQUFnQixJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUM7QUFDbkc7QUFDQSxRQUFRLElBQUksZUFBZSxJQUFJLENBQUMsaUJBQWlCLEVBQUU7QUFDbkQsWUFBWSxJQUFJO0FBQ2hCO0FBQ0EsZ0JBQWdCLE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUN2RTtBQUNBLGdCQUFnQixNQUFNLGNBQWMsR0FBRyxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFDLFdBQVcsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLGFBQWEsQ0FBQyxDQUFDO0FBQ2pJO0FBQ0EsZ0JBQWdCLElBQUksQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztBQUNqRDtBQUNBLGdCQUFnQixRQUFRLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYTtBQUNuRCxvQkFBb0IsS0FBSyxPQUFPO0FBQ2hDO0FBQ0Esd0JBQXdCLE9BQU8sY0FBYyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUM7QUFDdkYsb0JBQW9CLEtBQUssVUFBVTtBQUNuQztBQUNBLHdCQUF3QixPQUFPLGNBQWMsR0FBRyxDQUFDLDZCQUE2QixFQUFFLFNBQVMsQ0FBQyxhQUFhLEVBQUUsYUFBYSxDQUFDLGtNQUFrTSxDQUFDLENBQUM7QUFDM1Qsb0JBQW9CLEtBQUssVUFBVSxDQUFDO0FBQ3BDLG9CQUFvQjtBQUNwQjtBQUNBLHdCQUF3QixPQUFPLGNBQWMsQ0FBQztBQUM5QyxpQkFBaUI7QUFDakIsYUFBYTtBQUNiLFlBQVksT0FBTyxLQUFLLEVBQUU7QUFDMUIsZ0JBQWdCLE9BQU8sQ0FBQyxLQUFLLENBQUMsa0NBQWtDLEVBQUUsS0FBSyxDQUFDLENBQUM7QUFDekUsZ0JBQWdCLElBQUlBLGVBQU0sQ0FBQyx1RUFBdUUsQ0FBQyxDQUFDO0FBQ3BHO0FBQ0EsZ0JBQWdCLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLFdBQVcsRUFBRSxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7QUFDbkYsYUFBYTtBQUNiLFNBQVM7QUFDVCxhQUFhLElBQUksZUFBZSxJQUFJLGlCQUFpQixFQUFFO0FBQ3ZEO0FBQ0EsWUFBWSxJQUFJQSxlQUFNLENBQUMsQ0FBQyxnREFBZ0QsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLHVDQUF1QyxDQUFDLENBQUMsQ0FBQztBQUNuSixZQUFZLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLFdBQVcsRUFBRSxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7QUFDL0UsU0FBUztBQUNULGFBQWE7QUFDYjtBQUNBLFlBQVksT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsV0FBVyxFQUFFLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQztBQUMvRSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0EsSUFBSSxtQkFBbUIsQ0FBQyxXQUFXLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRTtBQUMzRCxRQUFRLE1BQU0sUUFBUSxHQUFHLFdBQVcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksV0FBVyxDQUFDO0FBQ3JFO0FBQ0EsUUFBUSxNQUFNLGtCQUFrQixHQUFHLHFCQUFxQixDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQztBQUMvRTtBQUNBLFFBQVEsSUFBSSxZQUFZLEdBQUcsa0JBQWtCO0FBQzdDLFlBQVksdUJBQXVCLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7QUFDdEc7QUFDQSxRQUFRLFFBQVEsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhO0FBQzNDLFlBQVksS0FBSyxPQUFPO0FBQ3hCO0FBQ0EsZ0JBQWdCLE9BQU8sWUFBWSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUM7QUFDN0UsWUFBWSxLQUFLLFVBQVU7QUFDM0I7QUFDQSxnQkFBZ0IsT0FBTyxZQUFZLEdBQUcsQ0FBQyw2QkFBNkIsRUFBRSxTQUFTLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxpVEFBaVQsQ0FBQyxDQUFDO0FBQ25iLFlBQVksS0FBSyxVQUFVLENBQUM7QUFDNUIsWUFBWTtBQUNaO0FBQ0EsZ0JBQWdCLE9BQU8sWUFBWSxDQUFDO0FBQ3BDLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQSxJQUFJLHVCQUF1QixDQUFDLGlCQUFpQixFQUFFO0FBQy9DO0FBQ0EsUUFBUSxNQUFNLGVBQWUsR0FBRztBQUNoQyxZQUFZLGdHQUFnRztBQUM1RyxZQUFZLHlGQUF5RjtBQUNyRyxZQUFZLGdGQUFnRjtBQUM1RixTQUFTLENBQUM7QUFDVjtBQUNBLFFBQVEsTUFBTSx3QkFBd0IsR0FBRztBQUN6QyxZQUFZLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRztBQUNwQyxnQkFBZ0IsaUdBQWlHO0FBQ2pILGdCQUFnQiwyRkFBMkY7QUFDM0csYUFBYTtBQUNiLFlBQVksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHO0FBQ3RDLGdCQUFnQix5R0FBeUc7QUFDekgsZ0JBQWdCLHFGQUFxRjtBQUNyRyxhQUFhO0FBQ2IsWUFBWSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEdBQUc7QUFDbkMsZ0JBQWdCLDZFQUE2RTtBQUM3RixnQkFBZ0IsaUVBQWlFO0FBQ2pGLGFBQWE7QUFDYixZQUFZLENBQUMsVUFBVSxDQUFDLFFBQVEsR0FBRztBQUNuQyxnQkFBZ0IsNkVBQTZFO0FBQzdGLGdCQUFnQixvREFBb0Q7QUFDcEUsYUFBYTtBQUNiLFlBQVksQ0FBQyxVQUFVLENBQUMsT0FBTyxHQUFHO0FBQ2xDLGdCQUFnQixvREFBb0Q7QUFDcEUsZ0JBQWdCLHFFQUFxRTtBQUNyRixhQUFhO0FBQ2IsWUFBWSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUc7QUFDdEMsZ0JBQWdCLHNFQUFzRTtBQUN0RixnQkFBZ0Isb0VBQW9FO0FBQ3BGLGFBQWE7QUFDYixZQUFZLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRztBQUNwQyxnQkFBZ0IsNEZBQTRGO0FBQzVHLGdCQUFnQiwrRUFBK0U7QUFDL0YsYUFBYTtBQUNiO0FBQ0EsU0FBUyxDQUFDO0FBQ1Y7QUFDQSxRQUFRLE1BQU0sQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxJQUFJO0FBQzVELFlBQVksSUFBSSxTQUFTLElBQUksd0JBQXdCLEVBQUU7QUFDdkQsZ0JBQWdCLGVBQWUsQ0FBQyxJQUFJLENBQUMsR0FBRyx3QkFBd0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQzdFLGFBQWE7QUFDYixTQUFTLENBQUMsQ0FBQztBQUNYLFFBQVEsT0FBTyxlQUFlLENBQUM7QUFDL0IsS0FBSztBQUNMO0FBQ0EsSUFBSSxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUU7QUFDbEMsUUFBUSxNQUFNLEtBQUssR0FBRztBQUN0QixZQUFZLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyx1QkFBdUI7QUFDM0QsWUFBWSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEdBQUcseUJBQXlCO0FBQzVELFlBQVksQ0FBQyxVQUFVLENBQUMsUUFBUSxHQUFHLHlCQUF5QjtBQUM1RCxZQUFZLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRywwQkFBMEI7QUFDOUQsWUFBWSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEdBQUcsNkJBQTZCO0FBQ25FLFlBQVksQ0FBQyxVQUFVLENBQUMsT0FBTyxHQUFHLCtCQUErQjtBQUNqRSxZQUFZLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxtQkFBbUI7QUFDeEQsWUFBWSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEdBQUcscUJBQXFCO0FBQ3hELFlBQVksQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLHNCQUFzQjtBQUMxRCxZQUFZLENBQUMsVUFBVSxDQUFDLGFBQWEsR0FBRyxlQUFlO0FBQ3ZELFlBQVksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLHdCQUF3QjtBQUM5RCxZQUFZLENBQUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxpQkFBaUI7QUFDcEQsWUFBWSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEdBQUcsaUJBQWlCO0FBQ3BELFlBQVksQ0FBQyxVQUFVLENBQUMsWUFBWSxHQUFHLGNBQWM7QUFDckQsWUFBWSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEdBQUcscUJBQXFCO0FBQ3hELFlBQVksQ0FBQyxVQUFVLENBQUMsV0FBVyxHQUFHLHdCQUF3QjtBQUM5RCxZQUFZLENBQUMsVUFBVSxDQUFDLE9BQU8sR0FBRyxvQkFBb0I7QUFDdEQsWUFBWSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEdBQUcsMEJBQTBCO0FBQ2xFLFlBQVksQ0FBQyxVQUFVLENBQUMsR0FBRyxHQUFHLDhCQUE4QjtBQUM1RCxZQUFZLENBQUMsVUFBVSxDQUFDLFlBQVksR0FBRyxjQUFjO0FBQ3JELFlBQVksQ0FBQyxVQUFVLENBQUMsUUFBUSxHQUFHLFVBQVU7QUFDN0MsWUFBWSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsWUFBWTtBQUNqRCxZQUFZLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxzQkFBc0I7QUFDMUQsU0FBUyxDQUFDO0FBQ1YsUUFBUSxPQUFPLEtBQUssQ0FBQyxXQUFXLENBQUMsSUFBSSxXQUFXLENBQUM7QUFDakQsS0FBSztBQUNMOztBQ3hiTyxNQUFNLG9CQUFvQixTQUFTQyx5QkFBZ0IsQ0FBQztBQUMzRCxJQUFJLFdBQVcsQ0FBQyxHQUFHLEVBQUUsTUFBTSxFQUFFO0FBQzdCLFFBQVEsS0FBSyxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUMsQ0FBQztBQUMzQixRQUFRLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO0FBQzdCLEtBQUs7QUFDTCxJQUFJLE9BQU8sR0FBRztBQUNkO0FBQ0EsUUFBUSxNQUFNLEVBQUUsV0FBVyxFQUFFLEdBQUcsSUFBSSxDQUFDO0FBQ3JDLFFBQVEsV0FBVyxDQUFDLEtBQUssRUFBRSxDQUFDO0FBQzVCLFFBQVEsV0FBVyxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUUsQ0FBQyxDQUFDO0FBQ3BFO0FBQ0EsUUFBUSxXQUFXLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSx3QkFBd0IsRUFBRSxDQUFDLENBQUM7QUFDdkUsUUFBUSxXQUFXLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxFQUFFLElBQUksRUFBRSx3REFBd0QsRUFBRSxDQUFDLENBQUM7QUFDdEc7QUFDQSxRQUFRLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSTtBQUMvQyxZQUFZLE1BQU0sV0FBVyxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNoRCxZQUFZLE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQzNGLFlBQVksSUFBSUMsZ0JBQU8sQ0FBQyxXQUFXLENBQUM7QUFDcEMsaUJBQWlCLE9BQU8sQ0FBQyxhQUFhLENBQUM7QUFDdkMsaUJBQWlCLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDaEUsaUJBQWlCLFNBQVMsQ0FBQyxNQUFNLElBQUksTUFBTTtBQUMzQyxpQkFBaUIsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQzlFLGlCQUFpQixRQUFRLENBQUMsT0FBTyxLQUFLLEtBQUs7QUFDM0MsZ0JBQWdCLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLFdBQVcsQ0FBQyxHQUFHLEtBQUssQ0FBQztBQUM1RSxnQkFBZ0IsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFDO0FBQ2pELGFBQWEsQ0FBQyxDQUFDLENBQUM7QUFDaEIsU0FBUyxDQUFDLENBQUM7QUFDWDtBQUNBLFFBQVEsV0FBVyxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsQ0FBQyxDQUFDO0FBQ2pFLFFBQVEsSUFBSUEsZ0JBQU8sQ0FBQyxXQUFXLENBQUM7QUFDaEMsYUFBYSxPQUFPLENBQUMsZ0JBQWdCLENBQUM7QUFDdEMsYUFBYSxPQUFPLENBQUMsc0NBQXNDLENBQUM7QUFDNUQsYUFBYSxXQUFXLENBQUMsUUFBUSxJQUFJLFFBQVE7QUFDN0MsYUFBYSxTQUFTLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQztBQUN4QyxhQUFhLFNBQVMsQ0FBQyxVQUFVLEVBQUUsVUFBVSxDQUFDO0FBQzlDLGFBQWEsU0FBUyxDQUFDLFVBQVUsRUFBRSxVQUFVLENBQUM7QUFDOUMsYUFBYSxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDO0FBQ3pELGFBQWEsUUFBUSxDQUFDLE9BQU8sS0FBSyxLQUFLO0FBQ3ZDLFlBQVksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztBQUN2RCxZQUFZLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsQ0FBQztBQUM3QyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQ1o7QUFDQSxRQUFRLElBQUlBLGdCQUFPLENBQUMsV0FBVyxDQUFDO0FBQ2hDLGFBQWEsT0FBTyxDQUFDLG9CQUFvQixDQUFDO0FBQzFDLGFBQWEsT0FBTyxDQUFDLDBEQUEwRCxDQUFDO0FBQ2hGLGFBQWEsU0FBUyxDQUFDLE1BQU0sSUFBSSxNQUFNO0FBQ3ZDLGFBQWEsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLHVCQUF1QixDQUFDO0FBQ25FLGFBQWEsUUFBUSxDQUFDLE9BQU8sS0FBSyxLQUFLO0FBQ3ZDLFlBQVksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsdUJBQXVCLEdBQUcsS0FBSyxDQUFDO0FBQ2pFLFlBQVksTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFDO0FBQzdDLFNBQVMsQ0FBQyxDQUFDLENBQUM7QUFDWjtBQUNBLFFBQVEsSUFBSUEsZ0JBQU8sQ0FBQyxXQUFXLENBQUM7QUFDaEMsYUFBYSxPQUFPLENBQUMsMEJBQTBCLENBQUM7QUFDaEQsYUFBYSxPQUFPLENBQUMsMkRBQTJELENBQUM7QUFDakYsYUFBYSxTQUFTLENBQUMsTUFBTSxJQUFJLE1BQU07QUFDdkMsYUFBYSxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMscUJBQXFCLENBQUM7QUFDakUsYUFBYSxRQUFRLENBQUMsT0FBTyxLQUFLLEtBQUs7QUFDdkMsWUFBWSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsR0FBRyxLQUFLLENBQUM7QUFDL0QsWUFBWSxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUM7QUFDN0MsU0FBUyxDQUFDLENBQUMsQ0FBQztBQUNaO0FBQ0EsUUFBUSxXQUFXLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRSxDQUFDLENBQUM7QUFDbkUsUUFBUSxXQUFXLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxFQUFFLElBQUksRUFBRSxxREFBcUQsRUFBRSxDQUFDLENBQUM7QUFDbkc7QUFDQSxRQUFRLElBQUlBLGdCQUFPLENBQUMsV0FBVyxDQUFDO0FBQ2hDLGFBQWEsT0FBTyxDQUFDLGVBQWUsQ0FBQztBQUNyQyxhQUFhLE9BQU8sQ0FBQywyQkFBMkIsQ0FBQztBQUNqRCxhQUFhLFdBQVcsQ0FBQyxRQUFRLElBQUksUUFBUTtBQUM3QyxhQUFhLFNBQVMsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLDRCQUE0QixDQUFDO0FBQ3ZFLGFBQWEsU0FBUyxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsMEJBQTBCLENBQUM7QUFDeEUsYUFBYSxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDO0FBQ3hELGFBQWEsUUFBUSxDQUFDLE9BQU8sS0FBSyxLQUFLO0FBQ3ZDLFlBQVksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztBQUN0RDtBQUNBLFlBQVksSUFBSSxLQUFLLEtBQUssWUFBWSxDQUFDLE9BQU8sRUFBRTtBQUNoRCxnQkFBZ0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztBQUN6RDtBQUNBLGdCQUFnQixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsWUFBWSxFQUFFO0FBQ3hELG9CQUFvQixJQUFJRixlQUFNLENBQUMsMERBQTBELENBQUMsQ0FBQztBQUMzRixpQkFBaUI7QUFDakIsYUFBYTtBQUNiLFlBQVksTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFDO0FBQzdDLFNBQVMsQ0FBQyxDQUFDLENBQUM7QUFDWjtBQUNBLFFBQVEsSUFBSUUsZ0JBQU8sQ0FBQyxXQUFXLENBQUM7QUFDaEMsYUFBYSxPQUFPLENBQUMsZUFBZSxDQUFDO0FBQ3JDLGFBQWEsT0FBTyxDQUFDLHFEQUFxRCxDQUFDO0FBQzNFLGFBQWEsU0FBUyxDQUFDLE1BQU0sSUFBSSxNQUFNO0FBQ3ZDLGFBQWEsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQztBQUN4RCxhQUFhLFFBQVEsQ0FBQyxPQUFPLEtBQUssS0FBSztBQUN2QyxZQUFZLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7QUFDdEQ7QUFDQSxZQUFZLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsWUFBWSxLQUFLLFlBQVksQ0FBQyxPQUFPLEVBQUU7QUFDdEYsZ0JBQWdCLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFlBQVksR0FBRyxZQUFZLENBQUMsSUFBSSxDQUFDO0FBQ3RFLGdCQUFnQixJQUFJRixlQUFNLENBQUMsMERBQTBELENBQUMsQ0FBQztBQUN2RixhQUFhO0FBQ2IsWUFBWSxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUM7QUFDN0MsU0FBUyxDQUFDLENBQUMsQ0FBQztBQUNaO0FBQ0EsUUFBUSxJQUFJRSxnQkFBTyxDQUFDLFdBQVcsQ0FBQztBQUNoQyxhQUFhLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQztBQUN0QyxhQUFhLE9BQU8sQ0FBQyxzQ0FBc0MsQ0FBQztBQUM1RCxhQUFhLE9BQU8sQ0FBQyxJQUFJLElBQUksSUFBSTtBQUNqQyxhQUFhLGNBQWMsQ0FBQyxRQUFRLENBQUM7QUFDckMsYUFBYSxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDO0FBQ3hELGFBQWEsU0FBUyxDQUFDLE9BQU8sS0FBSyxLQUFLO0FBQ3hDLFlBQVksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztBQUN0RCxZQUFZLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsQ0FBQztBQUM3QztBQUNBLFlBQVksSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRTtBQUMzQyxnQkFBZ0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDN0UsYUFBYTtBQUNiLFNBQVMsQ0FBQyxDQUFDLENBQUM7QUFDWjtBQUNBLFFBQVEsSUFBSUEsZ0JBQU8sQ0FBQyxXQUFXLENBQUM7QUFDaEMsYUFBYSxPQUFPLENBQUMsY0FBYyxDQUFDO0FBQ3BDLGFBQWEsT0FBTyxDQUFDLGtDQUFrQyxDQUFDO0FBQ3hELGFBQWEsV0FBVyxDQUFDLFFBQVEsSUFBSSxRQUFRO0FBQzdDLGFBQWEsU0FBUyxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsaUNBQWlDLENBQUM7QUFDOUUsYUFBYSxTQUFTLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSx1Q0FBdUMsQ0FBQztBQUNsRixhQUFhLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUM7QUFDdkQsYUFBYSxRQUFRLENBQUMsT0FBTyxLQUFLLEtBQUs7QUFDdkMsWUFBWSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO0FBQ3JELFlBQVksTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFDO0FBQzdDO0FBQ0EsWUFBWSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFO0FBQzNDLGdCQUFnQixJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM3RSxhQUFhO0FBQ2IsU0FBUyxDQUFDLENBQUMsQ0FBQztBQUNaO0FBQ0EsUUFBUSxJQUFJQSxnQkFBTyxDQUFDLFdBQVcsQ0FBQztBQUNoQyxhQUFhLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQztBQUMzQyxhQUFhLE9BQU8sQ0FBQyw2Q0FBNkMsQ0FBQztBQUNuRSxhQUFhLFNBQVMsQ0FBQyxNQUFNLElBQUksTUFBTTtBQUN2QyxhQUFhLFNBQVMsQ0FBQyxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsQ0FBQztBQUNuQyxhQUFhLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQztBQUM1RCxhQUFhLFFBQVEsQ0FBQyxPQUFPLEtBQUssS0FBSztBQUN2QyxZQUFZLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztBQUMxRCxZQUFZLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsQ0FBQztBQUM3QyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQ1o7QUFDQSxRQUFRLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDO0FBQ2pFLFFBQVEsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUM7QUFDakUsUUFBUSxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsVUFBVSxHQUFHLFVBQVUsSUFBSSxHQUFHLENBQUMsQ0FBQztBQUN6RSxRQUFRLElBQUlBLGdCQUFPLENBQUMsV0FBVyxDQUFDO0FBQ2hDLGFBQWEsT0FBTyxDQUFDLGtCQUFrQixDQUFDO0FBQ3hDLGFBQWEsT0FBTyxDQUFDLENBQUMsWUFBWSxFQUFFLFVBQVUsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLHNCQUFzQixFQUFFLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUN0RyxhQUFhLFNBQVMsQ0FBQyxNQUFNLElBQUksTUFBTTtBQUN2QyxhQUFhLGFBQWEsQ0FBQyxxQkFBcUIsQ0FBQztBQUNqRCxhQUFhLE9BQU8sQ0FBQyxZQUFZO0FBQ2pDLFlBQVksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDO0FBQ3RELFlBQVksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztBQUM5RCxZQUFZLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsQ0FBQztBQUM3QyxZQUFZLElBQUlGLGVBQU0sQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO0FBQ3ZELFlBQVksSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO0FBQzNCLFNBQVMsQ0FBQyxDQUFDLENBQUM7QUFDWixLQUFLO0FBQ0w7O0FDOUpPLE1BQU0sb0JBQW9CLENBQUM7QUFDbEMsSUFBSSxXQUFXLENBQUMsR0FBRyxFQUFFLE1BQU0sRUFBRTtBQUM3QixRQUFRLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxFQUFFLENBQUM7QUFDckMsUUFBUSxJQUFJLENBQUMsaUJBQWlCLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQztBQUNsRCxRQUFRLElBQUksQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO0FBQzFCLFFBQVEsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7QUFDekIsUUFBUSxJQUFJLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQztBQUN2QixRQUFRLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO0FBQzdCLFFBQVEsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJRyxjQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDcEMsUUFBUSxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDO0FBQzlDO0FBQ0EsUUFBUSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQztBQUN4RixhQUFhLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxLQUFLLE9BQU8sQ0FBQztBQUM5QyxhQUFhLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDO0FBQ2hELEtBQUs7QUFDTCxJQUFJLElBQUksR0FBRztBQUNYLFFBQVEsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztBQUMxQixRQUFRLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztBQUN0QixLQUFLO0FBQ0wsSUFBSSxLQUFLLEdBQUc7QUFDWixRQUFRLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztBQUN2QixRQUFRLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLENBQUM7QUFDM0IsS0FBSztBQUNMLElBQUksTUFBTSxHQUFHO0FBQ2IsUUFBUSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDO0FBQy9CLFFBQVEsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLHNCQUFzQixFQUFFLENBQUMsQ0FBQztBQUN4RTtBQUNBLFFBQVEsSUFBSUQsZ0JBQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO0FBQ25DLGFBQWEsT0FBTyxDQUFDLFlBQVksQ0FBQztBQUNsQyxhQUFhLE9BQU8sQ0FBQyx1Q0FBdUMsQ0FBQztBQUM3RCxhQUFhLFdBQVcsQ0FBQyxRQUFRLElBQUk7QUFDckMsWUFBWSxRQUFRO0FBQ3BCLGlCQUFpQixTQUFTLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUM7QUFDcEQsaUJBQWlCLFNBQVMsQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQztBQUN0RCxpQkFBaUIsU0FBUyxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDO0FBQ3RELGlCQUFpQixTQUFTLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxZQUFZLENBQUM7QUFDMUQsaUJBQWlCLFFBQVEsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUM7QUFDakQsaUJBQWlCLFFBQVEsQ0FBQyxLQUFLLElBQUk7QUFDbkMsZ0JBQWdCLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxLQUFLLENBQUM7QUFDL0MsYUFBYSxDQUFDLENBQUM7QUFDZixTQUFTLENBQUMsQ0FBQztBQUNYO0FBQ0EsUUFBUSxNQUFNLG1CQUFtQixHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLEVBQUUsR0FBRyxFQUFFLHVCQUF1QixFQUFFLENBQUMsQ0FBQztBQUMvRixRQUFRLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsQ0FBQyxDQUFDO0FBQzFFO0FBQ0EsUUFBUSxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUk7QUFDL0MsWUFBWSxNQUFNLFdBQVcsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDaEQsWUFBWSxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUMzRixZQUFZLElBQUlBLGdCQUFPLENBQUMsbUJBQW1CLENBQUM7QUFDNUMsaUJBQWlCLE9BQU8sQ0FBQyxhQUFhLENBQUM7QUFDdkMsaUJBQWlCLFNBQVMsQ0FBQyxNQUFNLElBQUk7QUFDckMsZ0JBQWdCLE1BQU07QUFDdEIscUJBQXFCLFFBQVEsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQzVFLHFCQUFxQixRQUFRLENBQUMsS0FBSyxJQUFJO0FBQ3ZDLG9CQUFvQixJQUFJLEtBQUssRUFBRTtBQUMvQjtBQUNBLHdCQUF3QixJQUFJLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsRUFBRTtBQUM1RSw0QkFBNEIsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUN0RSx5QkFBeUI7QUFDekIscUJBQXFCO0FBQ3JCLHlCQUF5QjtBQUN6QjtBQUNBLHdCQUF3QixJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxFQUFFLElBQUksRUFBRSxLQUFLLFdBQVcsQ0FBQyxDQUFDO0FBQzNHLHFCQUFxQjtBQUNyQixpQkFBaUIsQ0FBQyxDQUFDO0FBQ25CLGFBQWEsQ0FBQyxDQUFDO0FBQ2YsU0FBUyxDQUFDLENBQUM7QUFDWDtBQUNBLFFBQVEsTUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsRUFBRSxHQUFHLEVBQUUsb0JBQW9CLEVBQUUsQ0FBQyxDQUFDO0FBQ3hGO0FBQ0EsUUFBUSxlQUFlLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxFQUFFLElBQUksRUFBRSxZQUFZLEVBQUUsQ0FBQztBQUNsRSxhQUFhLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxNQUFNO0FBQzdDLFlBQVksSUFBSSxDQUFDLGtCQUFrQixHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUMxRixZQUFZLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztBQUN6QixZQUFZLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztBQUN4QixTQUFTLENBQUMsQ0FBQztBQUNYO0FBQ0EsUUFBUSxlQUFlLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxFQUFFLElBQUksRUFBRSxjQUFjLEVBQUUsQ0FBQztBQUNwRSxhQUFhLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxNQUFNO0FBQzdDLFlBQVksSUFBSSxDQUFDLGtCQUFrQixHQUFHLEVBQUUsQ0FBQztBQUN6QyxZQUFZLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztBQUN6QixZQUFZLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztBQUN4QixTQUFTLENBQUMsQ0FBQztBQUNYO0FBQ0EsUUFBUSxlQUFlLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsR0FBRyxFQUFFLFNBQVMsRUFBRSxDQUFDO0FBQy9FLGFBQWEsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLE1BQU07QUFDN0MsWUFBWSxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7QUFDM0IsU0FBUyxDQUFDLENBQUM7QUFDWCxLQUFLO0FBQ0wsSUFBSSxPQUFPLEdBQUc7QUFDZCxRQUFRLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7QUFDL0IsS0FBSztBQUNMO0FBQ0EsSUFBSSxPQUFPLEdBQUc7QUFDZCxRQUFRLElBQUksRUFBRSxFQUFFLEVBQUUsQ0FBQztBQUNuQixRQUFRLElBQUksSUFBSSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7QUFDbEQ7QUFDQSxZQUFZLElBQUlGLGVBQU0sQ0FBQyxvREFBb0QsQ0FBQyxDQUFDO0FBQzdFLFlBQVksT0FBTztBQUNuQixTQUFTO0FBQ1QsUUFBUSxJQUFJO0FBQ1o7QUFDQSxZQUFZLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxDQUFDO0FBQ2xFLFlBQVksSUFBSSxJQUFJLENBQUMsaUJBQWlCLEtBQUssV0FBVyxDQUFDLElBQUksRUFBRTtBQUM3RDtBQUNBLGdCQUFnQixNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUM7QUFDakUsZ0JBQWdCLE1BQU0sTUFBTSxHQUFHLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxHQUFHLFVBQVUsS0FBSyxJQUFJLElBQUksVUFBVSxLQUFLLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQyxHQUFHLFVBQVUsQ0FBQyxJQUFJLE1BQU0sSUFBSSxJQUFJLEVBQUUsS0FBSyxLQUFLLENBQUMsR0FBRyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsVUFBVSxNQUFNLElBQUksSUFBSSxFQUFFLEtBQUssS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLFFBQVEsQ0FBQztBQUN6TixnQkFBZ0IsSUFBSSxNQUFNLEVBQUU7QUFDNUIsb0JBQW9CLE1BQU0sT0FBTyxHQUFHLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUN0RCxvQkFBb0IsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO0FBQ2pDLG9CQUFvQixJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzFFLGlCQUFpQjtBQUNqQixxQkFBcUIsSUFBSSxVQUFVLEVBQUU7QUFDckM7QUFDQSxvQkFBb0IsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO0FBQ2pDLG9CQUFvQixJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7QUFDbkYsaUJBQWlCO0FBQ2pCLHFCQUFxQjtBQUNyQixvQkFBb0IsSUFBSUEsZUFBTSxDQUFDLDBEQUEwRCxDQUFDLENBQUM7QUFDM0YsaUJBQWlCO0FBQ2pCLGFBQWE7QUFDYixpQkFBaUI7QUFDakI7QUFDQSxnQkFBZ0IsSUFBSSxVQUFVLEVBQUU7QUFDaEM7QUFDQSxvQkFBb0IsTUFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztBQUM3RSxvQkFBb0IsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztBQUM1RyxvQkFBb0IsSUFBSSxXQUFXLEVBQUU7QUFDckMsd0JBQXdCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztBQUNyQyx3QkFBd0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0FBQ3ZGLHFCQUFxQjtBQUNyQix5QkFBeUI7QUFDekIsd0JBQXdCLElBQUlBLGVBQU0sQ0FBQyxDQUFDLGdDQUFnQyxFQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ3RHLHFCQUFxQjtBQUNyQixpQkFBaUI7QUFDakIscUJBQXFCO0FBQ3JCLG9CQUFvQixJQUFJQSxlQUFNLENBQUMsQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQztBQUMzRixpQkFBaUI7QUFDakIsYUFBYTtBQUNiLFNBQVM7QUFDVCxRQUFRLE9BQU8sS0FBSyxFQUFFO0FBQ3RCLFlBQVksT0FBTyxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsRUFBRSxLQUFLLENBQUMsQ0FBQztBQUN0RCxZQUFZLElBQUlBLGVBQU0sQ0FBQyxtRUFBbUUsQ0FBQyxDQUFDO0FBQzVGLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQSxJQUFJLHVCQUF1QixDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUU7QUFDbEQsUUFBUSxRQUFRLFNBQVM7QUFDekIsWUFBWSxLQUFLLFdBQVcsQ0FBQyxLQUFLO0FBQ2xDLGdCQUFnQixPQUFPLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDeEYsWUFBWSxLQUFLLFdBQVcsQ0FBQyxLQUFLO0FBQ2xDLGdCQUFnQixPQUFPLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUNoRixZQUFZLEtBQUssV0FBVyxDQUFDLElBQUk7QUFDakMsZ0JBQWdCLE9BQU8sQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ2hGLFlBQVksS0FBSyxXQUFXLENBQUMsSUFBSTtBQUNqQyxnQkFBZ0IsT0FBTyxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUM1RixZQUFZO0FBQ1osZ0JBQWdCLE9BQU8sS0FBSyxDQUFDO0FBQzdCLFNBQVM7QUFDVCxLQUFLO0FBQ0w7O0FDbEtBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBUyxTQUFTLENBQUMsT0FBTyxFQUFFLFVBQVUsRUFBRSxDQUFDLEVBQUUsU0FBUyxFQUFFO0FBQzdELElBQUksU0FBUyxLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsT0FBTyxLQUFLLFlBQVksQ0FBQyxHQUFHLEtBQUssR0FBRyxJQUFJLENBQUMsQ0FBQyxVQUFVLE9BQU8sRUFBRSxFQUFFLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFO0FBQ2hILElBQUksT0FBTyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsT0FBTyxDQUFDLEVBQUUsVUFBVSxPQUFPLEVBQUUsTUFBTSxFQUFFO0FBQy9ELFFBQVEsU0FBUyxTQUFTLENBQUMsS0FBSyxFQUFFLEVBQUUsSUFBSTtBQUN4QyxZQUFZLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDeEMsU0FBUztBQUNULFFBQVEsT0FBTyxDQUFDLEVBQUU7QUFDbEIsWUFBWSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsU0FBUyxFQUFFO0FBQ1gsUUFBUSxTQUFTLFFBQVEsQ0FBQyxLQUFLLEVBQUUsRUFBRSxJQUFJO0FBQ3ZDLFlBQVksSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQzVDLFNBQVM7QUFDVCxRQUFRLE9BQU8sQ0FBQyxFQUFFO0FBQ2xCLFlBQVksTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLFNBQVMsRUFBRTtBQUNYLFFBQVEsU0FBUyxJQUFJLENBQUMsTUFBTSxFQUFFLEVBQUUsTUFBTSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFFO0FBQ3RILFFBQVEsSUFBSSxDQUFDLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLFVBQVUsSUFBSSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO0FBQzlFLEtBQUssQ0FBQyxDQUFDO0FBQ1A7O0FDZmUsTUFBTSxnQkFBZ0IsU0FBU0ksZUFBTSxDQUFDO0FBQ3JELElBQUksV0FBVyxHQUFHO0FBQ2xCLFFBQVEsS0FBSyxDQUFDLEdBQUcsU0FBUyxDQUFDLENBQUM7QUFDNUIsUUFBUSxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztBQUNsQyxLQUFLO0FBQ0wsSUFBSSxNQUFNLEdBQUc7QUFDYixRQUFRLE9BQU8sU0FBUyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsRUFBRSxLQUFLLENBQUMsRUFBRSxhQUFhO0FBQzVELFlBQVksT0FBTyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO0FBQ3JEO0FBQ0EsWUFBWSxNQUFNLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztBQUN0QztBQUNBLFlBQVksSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLGNBQWMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM5RTtBQUNBLFlBQVksSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksRUFBRTtBQUM1QyxnQkFBZ0IsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLGFBQWEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDdEUsYUFBYTtBQUNiO0FBQ0EsWUFBWSxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztBQUNyQztBQUNBLFlBQVksTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsWUFBWSxFQUFFLENBQUMsQ0FBQyxLQUFLO0FBQ2pGO0FBQ0EsZ0JBQWdCLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO0FBQzFDLGFBQWEsQ0FBQyxDQUFDO0FBQ2Y7QUFDQSxZQUFZLFlBQVksQ0FBQyxRQUFRLENBQUMseUJBQXlCLENBQUMsQ0FBQztBQUM3RDtBQUNBLFlBQVksSUFBSSxDQUFDLFVBQVUsQ0FBQztBQUM1QixnQkFBZ0IsRUFBRSxFQUFFLHNCQUFzQjtBQUMxQyxnQkFBZ0IsSUFBSSxFQUFFLHNCQUFzQjtBQUM1QyxnQkFBZ0IsUUFBUSxFQUFFLE1BQU07QUFDaEMsb0JBQW9CLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO0FBQzlDLGlCQUFpQjtBQUNqQixhQUFhLENBQUMsQ0FBQztBQUNmO0FBQ0EsWUFBWSxJQUFJLENBQUMsVUFBVSxDQUFDO0FBQzVCLGdCQUFnQixFQUFFLEVBQUUsdUJBQXVCO0FBQzNDLGdCQUFnQixJQUFJLEVBQUUsdUJBQXVCO0FBQzdDLGdCQUFnQixjQUFjLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxLQUFLO0FBQy9DLG9CQUFvQixNQUFNLFlBQVksR0FBRyxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUM7QUFDL0Qsb0JBQW9CLElBQUksWUFBWSxFQUFFO0FBQ3RDLHdCQUF3QixJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDNUUscUJBQXFCO0FBQ3JCLHlCQUF5QjtBQUN6Qix3QkFBd0IsSUFBSUosZUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUM7QUFDdkQscUJBQXFCO0FBQ3JCLGlCQUFpQjtBQUNqQixhQUFhLENBQUMsQ0FBQztBQUNmO0FBQ0EsWUFBWSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksb0JBQW9CLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3pFO0FBQ0EsWUFBWSxJQUFJLENBQUMsVUFBVSxDQUFDO0FBQzVCLGdCQUFnQixFQUFFLEVBQUUsdUJBQXVCO0FBQzNDLGdCQUFnQixJQUFJLEVBQUUsdUJBQXVCO0FBQzdDLGdCQUFnQixRQUFRLEVBQUUsTUFBTTtBQUNoQyxvQkFBb0IsSUFBSSxDQUFDLHdCQUF3QixFQUFFLENBQUM7QUFDcEQsaUJBQWlCO0FBQ2pCLGFBQWEsQ0FBQyxDQUFDO0FBQ2YsU0FBUyxDQUFDLENBQUM7QUFDWCxLQUFLO0FBQ0wsSUFBSSxRQUFRLEdBQUc7QUFDZixRQUFRLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLENBQUMsQ0FBQztBQUNuRCxLQUFLO0FBQ0wsSUFBSSxZQUFZLEdBQUc7QUFDbkIsUUFBUSxPQUFPLFNBQVMsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUUsYUFBYTtBQUM1RCxZQUFZLE1BQU0sSUFBSSxHQUFHLE1BQU0sSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQy9DLFlBQVksSUFBSSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsQ0FBQztBQUN0RSxTQUFTLENBQUMsQ0FBQztBQUNYLEtBQUs7QUFDTCxJQUFJLFlBQVksR0FBRztBQUNuQixRQUFRLE9BQU8sU0FBUyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsRUFBRSxLQUFLLENBQUMsRUFBRSxhQUFhO0FBQzVELFlBQVksTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUMvQztBQUNBLFlBQVksSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVEO0FBQ0EsWUFBWSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxFQUFFO0FBQzVDLGdCQUFnQixJQUFJLElBQUksQ0FBQyxhQUFhLEVBQUU7QUFDeEMsb0JBQW9CLElBQUksQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNuRSxpQkFBaUI7QUFDakIscUJBQXFCO0FBQ3JCLG9CQUFvQixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksYUFBYSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUMxRSxpQkFBaUI7QUFDakIsYUFBYTtBQUNiLGlCQUFpQjtBQUNqQixnQkFBZ0IsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7QUFDMUMsYUFBYTtBQUNiLFNBQVMsQ0FBQyxDQUFDO0FBQ1gsS0FBSztBQUNMO0FBQ0EsSUFBSSxpQkFBaUIsR0FBRztBQUN4QixRQUFRLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztBQUMvQixRQUFRLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDO0FBQ3hELFFBQVEsTUFBTSxVQUFVLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQztBQUNwRDtBQUNBLFFBQVEsSUFBSSxHQUFHLEdBQUcsU0FBUyxHQUFHLFVBQVUsRUFBRTtBQUMxQyxZQUFZLElBQUksQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDO0FBQy9DLFlBQVksSUFBSSxDQUFDLFFBQVEsQ0FBQyxlQUFlLEdBQUcsR0FBRyxDQUFDO0FBQ2hELFlBQVksSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO0FBQ2hDLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQSxJQUFJLGtCQUFrQixHQUFHO0FBQ3pCLFFBQVEsT0FBTyxTQUFTLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUFFLGFBQWE7QUFDNUQsWUFBWSxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztBQUNsRSxZQUFZLElBQUksQ0FBQyxVQUFVLEVBQUU7QUFDN0I7QUFDQSxnQkFBZ0IsSUFBSUEsZUFBTSxDQUFDLDJCQUEyQixDQUFDLENBQUM7QUFDeEQsZ0JBQWdCLE9BQU87QUFDdkIsYUFBYTtBQUNiO0FBQ0EsWUFBWSxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDcEUsWUFBWSxJQUFJLFNBQVMsS0FBSyxXQUFXLENBQUMsSUFBSSxFQUFFO0FBQ2hEO0FBQ0EsZ0JBQWdCLE1BQU0sT0FBTyxHQUFHLE1BQU0sSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RFLGdCQUFnQixJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDcEUsYUFBYTtBQUNiLGlCQUFpQjtBQUNqQjtBQUNBLGdCQUFnQixJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsRUFBRSxTQUFTLENBQUMsQ0FBQztBQUMzRCxhQUFhO0FBQ2IsU0FBUyxDQUFDLENBQUM7QUFDWCxLQUFLO0FBQ0w7QUFDQSxJQUFJLG9CQUFvQixDQUFDLElBQUksRUFBRTtBQUMvQixRQUFRLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLENBQUM7QUFDdkQsUUFBUSxJQUFJLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLEVBQUU7QUFDdkQsWUFBWSxPQUFPLFdBQVcsQ0FBQyxJQUFJLENBQUM7QUFDcEMsU0FBUztBQUNULGFBQWEsSUFBSSxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxFQUFFO0FBQ2xGLFlBQVksT0FBTyxXQUFXLENBQUMsS0FBSyxDQUFDO0FBQ3JDLFNBQVM7QUFDVCxhQUFhLElBQUksQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxFQUFFO0FBQzNFLFlBQVksT0FBTyxXQUFXLENBQUMsS0FBSyxDQUFDO0FBQ3JDLFNBQVM7QUFDVCxhQUFhLElBQUksQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxFQUFFO0FBQzNFLFlBQVksT0FBTyxXQUFXLENBQUMsSUFBSSxDQUFDO0FBQ3BDLFNBQVM7QUFDVCxhQUFhO0FBQ2I7QUFDQSxZQUFZLE9BQU8sV0FBVyxDQUFDLElBQUksQ0FBQztBQUNwQyxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0EsSUFBSSxjQUFjLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUU7QUFDN0MsUUFBUSxPQUFPLFNBQVMsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUUsYUFBYTtBQUM1RDtBQUNBLFlBQVksTUFBTSxpQkFBaUIsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUM7QUFDckYsaUJBQWlCLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxLQUFLLE9BQU8sQ0FBQztBQUNsRCxpQkFBaUIsR0FBRyxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUM7QUFDcEQsWUFBWSxJQUFJLGlCQUFpQixDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7QUFDaEQsZ0JBQWdCLElBQUlBLGVBQU0sQ0FBQyx1RkFBdUYsQ0FBQyxDQUFDO0FBQ3BILGdCQUFnQixPQUFPO0FBQ3ZCLGFBQWE7QUFDYixZQUFZLElBQUk7QUFDaEI7QUFDQSxnQkFBZ0IsSUFBSUEsZUFBTSxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFDbkQ7QUFDQSxnQkFBZ0IsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO0FBQ3pHO0FBQ0EsZ0JBQWdCLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7QUFDMUQsYUFBYTtBQUNiLFlBQVksT0FBTyxLQUFLLEVBQUU7QUFDMUIsZ0JBQWdCLE9BQU8sQ0FBQyxLQUFLLENBQUMsMEJBQTBCLEVBQUUsS0FBSyxDQUFDLENBQUM7QUFDakUsZ0JBQWdCLElBQUlBLGVBQU0sQ0FBQyxxREFBcUQsQ0FBQyxDQUFDO0FBQ2xGLGFBQWE7QUFDYixTQUFTLENBQUMsQ0FBQztBQUNYLEtBQUs7QUFDTDtBQUNBLElBQUksc0JBQXNCLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRTtBQUN6QztBQUNBLFFBQVEsSUFBSSxRQUFRLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0FBQ25EO0FBQ0EsUUFBUSxJQUFJLE1BQU0sQ0FBQyxRQUFRLEVBQUU7QUFDN0IsWUFBWSxRQUFRLElBQUksQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMzRCxTQUFTO0FBQ1QsYUFBYSxJQUFJLElBQUksRUFBRTtBQUN2QixZQUFZLFFBQVEsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3JELFNBQVM7QUFDVDtBQUNBLFFBQVEsUUFBUSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM5RDtBQUNBLFFBQVEsUUFBUSxJQUFJLENBQUMsY0FBYyxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDMUQ7QUFDQSxRQUFRLFFBQVEsSUFBSSxDQUFDLHlCQUF5QixDQUFDLENBQUM7QUFDaEQsUUFBUSxLQUFLLE1BQU0sQ0FBQyxTQUFTLEVBQUUsUUFBUSxDQUFDLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsRUFBRTtBQUN0RixZQUFZLE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDbEYsWUFBWSxRQUFRLElBQUksQ0FBQyxJQUFJLEVBQUUsYUFBYSxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbEUsU0FBUztBQUNUO0FBQ0EsUUFBUSxJQUFJLE1BQU0sQ0FBQyxlQUFlLElBQUksTUFBTSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO0FBQ3pFLFlBQVksUUFBUSxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQztBQUNqRCxZQUFZLEtBQUssTUFBTSxjQUFjLElBQUksTUFBTSxDQUFDLGVBQWUsRUFBRTtBQUNqRSxnQkFBZ0IsUUFBUSxJQUFJLENBQUMsRUFBRSxFQUFFLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNwRCxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0EsUUFBUSxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDdEQ7QUFDQSxRQUFRLElBQUksQ0FBQyxZQUFZLENBQUM7QUFDMUIsWUFBWSxJQUFJLEVBQUUsVUFBVTtBQUM1QixZQUFZLEtBQUssRUFBRTtBQUNuQixnQkFBZ0IsSUFBSSxFQUFFLFNBQVM7QUFDL0IsZ0JBQWdCLE1BQU0sRUFBRSxRQUFRO0FBQ2hDLGFBQWE7QUFDYixTQUFTLENBQUMsQ0FBQztBQUNYLEtBQUs7QUFDTDtBQUNBLElBQUksd0JBQXdCLEdBQUc7QUFDL0IsUUFBUSxNQUFNLEtBQUssR0FBRyxJQUFJLG9CQUFvQixDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUM7QUFDL0QsUUFBUSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7QUFDckIsS0FBSztBQUNMOzs7OyJ9
