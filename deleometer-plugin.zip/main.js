console.log('Deleometer plugin loaded');
